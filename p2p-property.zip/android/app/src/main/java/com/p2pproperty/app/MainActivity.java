package com.p2pproperty.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
