import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '..', 'data');
const DB_FILE = path.resolve(DATA_DIR, 'p2p_property.sqlite');

let dbInstance: Database | null = null;

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export async function getDb(): Promise<Database> {
  if (dbInstance) return dbInstance;

  const SQL = await initSqlJs();

  if (fs.existsSync(DB_FILE)) {
    const fileBuffer = fs.readFileSync(DB_FILE);
    dbInstance = new SQL.Database(fileBuffer);
  } else {
    dbInstance = new SQL.Database();
  }

  // Initialize Schema
  initSchema(dbInstance);

  return dbInstance;
}

export function saveDb(): void {
  if (!dbInstance) return;
  const data = dbInstance.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_FILE, buffer);
}

function initSchema(db: Database) {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'buyer',
      capabilities TEXT NOT NULL DEFAULT '["buyer"]',
      is_verified INTEGER DEFAULT 0,
      avatar_url TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS properties (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL REFERENCES users(id),
      category TEXT NOT NULL,
      transaction_type TEXT NOT NULL,
      property_type TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      price REAL NOT NULL,
      rent REAL,
      security_deposit REAL,
      maintenance REAL,
      carpet_area REAL NOT NULL,
      built_up_area REAL,
      bedrooms INTEGER,
      bathrooms INTEGER,
      floor INTEGER,
      total_floors INTEGER,
      furnishing TEXT,
      parking TEXT,
      address TEXT,
      locality TEXT NOT NULL,
      city TEXT NOT NULL DEFAULT 'Mumbai',
      pincode TEXT NOT NULL,
      latitude REAL,
      longitude REAL,
      status TEXT NOT NULL DEFAULT 'PENDING_APPROVAL',
      verification_status TEXT NOT NULL DEFAULT 'UNVERIFIED',
      rejection_reason TEXT,
      is_sample INTEGER DEFAULT 0,
      washrooms INTEGER,
      power_backup INTEGER DEFAULT 0,
      loading_unloading INTEGER DEFAULT 0,
      business_type TEXT,
      frontage REAL,
      ceiling_height REAL,
      commercial_use_type TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS property_images (
      id TEXT PRIMARY KEY,
      property_id TEXT NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      image_url TEXT NOT NULL,
      display_order INTEGER DEFAULT 0,
      caption TEXT,
      is_primary INTEGER DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS property_amenities (
      id TEXT PRIMARY KEY,
      property_id TEXT NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      amenity_name TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS locations (
      id TEXT PRIMARY KEY,
      property_id TEXT NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      building_name TEXT,
      area TEXT,
      locality TEXT,
      city TEXT DEFAULT 'Mumbai',
      pincode TEXT,
      landmark TEXT,
      latitude REAL,
      longitude REAL
    );

    CREATE TABLE IF NOT EXISTS property_inquiries (
      id TEXT PRIMARY KEY,
      property_id TEXT NOT NULL REFERENCES properties(id),
      buyer_user_id TEXT NOT NULL REFERENCES users(id),
      buyer_name TEXT NOT NULL,
      buyer_phone TEXT NOT NULL,
      buyer_email TEXT NOT NULL,
      message TEXT NOT NULL,
      preferred_contact_time TEXT,
      status TEXT NOT NULL DEFAULT 'NEW',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS site_visits (
      id TEXT PRIMARY KEY,
      property_id TEXT NOT NULL REFERENCES properties(id),
      visitor_user_id TEXT NOT NULL REFERENCES users(id),
      visitor_name TEXT NOT NULL,
      visitor_phone TEXT NOT NULL,
      visitor_email TEXT NOT NULL,
      preferred_date TEXT NOT NULL,
      preferred_time TEXT NOT NULL,
      message TEXT,
      status TEXT NOT NULL DEFAULT 'REQUESTED',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS saved_properties (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      property_id TEXT NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL,
      UNIQUE(user_id, property_id)
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      admin_id TEXT NOT NULL,
      admin_name TEXT,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      details TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS property_reviews (
      id TEXT PRIMARY KEY,
      property_id TEXT NOT NULL,
      admin_id TEXT NOT NULL,
      action TEXT NOT NULL,
      reason TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS customer_profiles (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      mobile TEXT NOT NULL,
      email TEXT NOT NULL,
      user_id TEXT,
      customer_type TEXT DEFAULT 'BUYER',
      preferred_transaction TEXT,
      preferred_category TEXT,
      preferred_locations TEXT,
      budget_min REAL,
      budget_max REAL,
      preferred_property_types TEXT,
      bhk TEXT,
      carpet_area_min REAL,
      carpet_area_max REAL,
      furnishing_preference TEXT,
      parking_requirement TEXT,
      business_type TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS leads (
      id TEXT PRIMARY KEY,
      property_id TEXT REFERENCES properties(id),
      customer_id TEXT NOT NULL REFERENCES customer_profiles(id),
      owner_id TEXT NOT NULL REFERENCES users(id),
      assigned_agent_id TEXT REFERENCES users(id),
      source TEXT NOT NULL DEFAULT 'PROPERTY_ENQUIRY',
      status TEXT NOT NULL DEFAULT 'NEW',
      priority TEXT NOT NULL DEFAULT 'MEDIUM',
      customer_message TEXT,
      internal_notes TEXT,
      preferred_contact_method TEXT DEFAULT 'PHONE',
      budget REAL,
      requirement_type TEXT,
      business_type TEXT,
      required_carpet_area REAL,
      bhk TEXT,
      furnishing_preference TEXT,
      parking_requirement TEXT,
      last_contacted_at TEXT,
      next_follow_up_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS lead_activities (
      id TEXT PRIMARY KEY,
      lead_id TEXT NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
      performed_by_id TEXT NOT NULL,
      performed_by_name TEXT,
      performed_by_role TEXT,
      action TEXT NOT NULL,
      details TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS lead_followups (
      id TEXT PRIMARY KEY,
      lead_id TEXT NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
      follow_up_date TEXT NOT NULL,
      follow_up_time TEXT,
      note TEXT NOT NULL,
      assigned_to TEXT REFERENCES users(id),
      assigned_to_name TEXT,
      status TEXT NOT NULL DEFAULT 'PENDING',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS lead_assignments (
      id TEXT PRIMARY KEY,
      lead_id TEXT NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
      assigned_by_id TEXT NOT NULL REFERENCES users(id),
      assigned_by_name TEXT,
      assigned_to_id TEXT NOT NULL REFERENCES users(id),
      assigned_to_name TEXT,
      assigned_to_role TEXT,
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS deals (
      id TEXT PRIMARY KEY,
      deal_number TEXT UNIQUE NOT NULL,
      lead_id TEXT REFERENCES leads(id),
      property_id TEXT NOT NULL REFERENCES properties(id),
      customer_id TEXT NOT NULL REFERENCES customer_profiles(id),
      owner_id TEXT NOT NULL REFERENCES users(id),
      assigned_agent_id TEXT REFERENCES users(id),
      transaction_type TEXT NOT NULL DEFAULT 'BUY',
      category TEXT NOT NULL DEFAULT 'RESIDENTIAL',
      deal_status TEXT NOT NULL DEFAULT 'NEGOTIATION',
      agreed_property_value REAL,
      agreed_rent REAL,
      agreed_lease_value REAL,
      commission_type TEXT NOT NULL DEFAULT 'PERCENTAGE',
      commission_rate REAL,
      commission_base REAL,
      commission_amount REAL NOT NULL DEFAULT 0,
      commission_payer TEXT NOT NULL DEFAULT 'BUYER',
      commission_status TEXT NOT NULL DEFAULT 'NOT_SET',
      expected_closing_date TEXT,
      actual_closing_date TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS deal_payments (
      id TEXT PRIMARY KEY,
      deal_id TEXT NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
      receipt_number TEXT UNIQUE NOT NULL,
      amount REAL NOT NULL,
      payment_method TEXT NOT NULL DEFAULT 'UPI',
      transaction_reference TEXT,
      payment_date TEXT NOT NULL,
      payer_name TEXT,
      recorded_by_id TEXT NOT NULL REFERENCES users(id),
      recorded_by_name TEXT,
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS deal_invoices (
      id TEXT PRIMARY KEY,
      deal_id TEXT NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
      invoice_number TEXT UNIQUE NOT NULL,
      issue_date TEXT NOT NULL,
      due_date TEXT NOT NULL,
      subtotal REAL NOT NULL,
      gst_rate REAL NOT NULL DEFAULT 18,
      gst_amount REAL NOT NULL,
      total_amount REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'ISSUED',
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS deal_activities (
      id TEXT PRIMARY KEY,
      deal_id TEXT NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
      performed_by_id TEXT NOT NULL,
      performed_by_name TEXT,
      performed_by_role TEXT,
      action TEXT NOT NULL,
      details TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS property_documents (
      id TEXT PRIMARY KEY,
      property_id TEXT NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      document_type TEXT NOT NULL,
      title TEXT NOT NULL,
      file_url TEXT NOT NULL,
      file_name TEXT NOT NULL,
      file_size INTEGER DEFAULT 0,
      mime_type TEXT,
      uploaded_by_id TEXT NOT NULL REFERENCES users(id),
      verification_status TEXT NOT NULL DEFAULT 'PENDING',
      admin_notes TEXT,
      verified_by_id TEXT REFERENCES users(id),
      verified_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'INFO',
      link TEXT,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS contact_enquiries (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      enquiry_type TEXT NOT NULL DEFAULT 'GENERAL',
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'NEW',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      description TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS legal_pages (
      slug TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      updated_by TEXT
    );

    CREATE TABLE IF NOT EXISTS analytics_events (
      id TEXT PRIMARY KEY,
      event_name TEXT NOT NULL,
      entity_type TEXT,
      entity_id TEXT,
      user_id TEXT,
      metadata TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS property_requirements (
      id TEXT PRIMARY KEY,
      query_number TEXT UNIQUE NOT NULL,
      customer_id TEXT NOT NULL REFERENCES customer_profiles(id) ON DELETE CASCADE,
      lead_id TEXT REFERENCES leads(id) ON DELETE SET NULL,
      transaction_type TEXT NOT NULL,
      category TEXT NOT NULL,
      preferred_locations TEXT,
      budget_min REAL,
      budget_max REAL,
      property_type TEXT,
      bhk TEXT,
      area_min REAL,
      area_max REAL,
      furnishing TEXT,
      parking_required TEXT,
      business_type TEXT,
      lease_duration TEXT,
      possession_date TEXT,
      requirements_text TEXT,
      status TEXT NOT NULL DEFAULT 'NEW',
      priority TEXT NOT NULL DEFAULT 'MEDIUM',
      assigned_agent_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      source TEXT NOT NULL DEFAULT 'PORTAL_QUERY',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      last_contacted_at TEXT,
      next_follow_up_at TEXT
    );

    CREATE TABLE IF NOT EXISTS query_activities (
      id TEXT PRIMARY KEY,
      query_id TEXT NOT NULL REFERENCES property_requirements(id) ON DELETE CASCADE,
      performed_by_id TEXT NOT NULL,
      performed_by_name TEXT,
      performed_by_role TEXT,
      action TEXT NOT NULL,
      details TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS off_market_matches (
      id TEXT PRIMARY KEY,
      query_id TEXT NOT NULL REFERENCES property_requirements(id) ON DELETE CASCADE,
      source TEXT,
      location TEXT NOT NULL,
      property_type TEXT NOT NULL,
      transaction_type TEXT NOT NULL,
      asking_price REAL,
      expected_rent REAL,
      area REAL,
      bhk TEXT,
      availability TEXT,
      owner_or_representative_name TEXT,
      owner_or_representative_contact_reference TEXT,
      contacted_by TEXT,
      contacted_at TEXT,
      match_notes TEXT,
      status TEXT NOT NULL DEFAULT 'IDENTIFIED',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_leads_property_id ON leads(property_id);
    CREATE INDEX IF NOT EXISTS idx_leads_customer_id ON leads(customer_id);
    CREATE INDEX IF NOT EXISTS idx_leads_owner_id ON leads(owner_id);
    CREATE INDEX IF NOT EXISTS idx_leads_assigned_agent_id ON leads(assigned_agent_id);
    CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
    CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at);
    CREATE INDEX IF NOT EXISTS idx_lead_activities_lead_id ON lead_activities(lead_id);
    CREATE INDEX IF NOT EXISTS idx_lead_followups_lead_id ON lead_followups(lead_id);

    CREATE INDEX IF NOT EXISTS idx_deals_lead_id ON deals(lead_id);
    CREATE INDEX IF NOT EXISTS idx_deals_property_id ON deals(property_id);
    CREATE INDEX IF NOT EXISTS idx_deals_customer_id ON deals(customer_id);
    CREATE INDEX IF NOT EXISTS idx_deals_owner_id ON deals(owner_id);
    CREATE INDEX IF NOT EXISTS idx_deals_assigned_agent_id ON deals(assigned_agent_id);
    CREATE INDEX IF NOT EXISTS idx_deals_deal_status ON deals(deal_status);
    CREATE INDEX IF NOT EXISTS idx_deals_commission_status ON deals(commission_status);
    CREATE INDEX IF NOT EXISTS idx_deals_created_at ON deals(created_at);
    CREATE INDEX IF NOT EXISTS idx_deal_payments_deal_id ON deal_payments(deal_id);
    CREATE INDEX IF NOT EXISTS idx_deal_invoices_deal_id ON deal_invoices(deal_id);
    CREATE INDEX IF NOT EXISTS idx_deal_activities_deal_id ON deal_activities(deal_id);

    CREATE INDEX IF NOT EXISTS idx_property_documents_property_id ON property_documents(property_id);
    CREATE INDEX IF NOT EXISTS idx_property_documents_status ON property_documents(verification_status);
    CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
    CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
    CREATE INDEX IF NOT EXISTS idx_analytics_events_name ON analytics_events(event_name);
    CREATE INDEX IF NOT EXISTS idx_analytics_events_created_at ON analytics_events(created_at);

    CREATE INDEX IF NOT EXISTS idx_requirements_customer_id ON property_requirements(customer_id);
    CREATE INDEX IF NOT EXISTS idx_requirements_lead_id ON property_requirements(lead_id);
    CREATE INDEX IF NOT EXISTS idx_requirements_assigned_agent ON property_requirements(assigned_agent_id);
    CREATE INDEX IF NOT EXISTS idx_requirements_status ON property_requirements(status);
    CREATE INDEX IF NOT EXISTS idx_requirements_created_at ON property_requirements(created_at);
    CREATE INDEX IF NOT EXISTS idx_query_activities_query_id ON query_activities(query_id);
    CREATE INDEX IF NOT EXISTS idx_off_market_matches_query_id ON off_market_matches(query_id);
    CREATE INDEX IF NOT EXISTS idx_off_market_matches_status ON off_market_matches(status);
  `);

  // Run migrations on existing databases safely
  try {
    db.run("ALTER TABLE users ADD COLUMN account_status TEXT NOT NULL DEFAULT 'ACTIVE';");
  } catch {}
  try {
    db.run("ALTER TABLE users ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'UNVERIFIED';");
  } catch {}
  try {
    db.run("ALTER TABLE site_visits ADD COLUMN lead_id TEXT;");
  } catch {}
  try {
    db.run("ALTER TABLE site_visits ADD COLUMN owner_id TEXT;");
  } catch {}
  try {
    db.run("ALTER TABLE site_visits ADD COLUMN customer_id TEXT;");
  } catch {}
  try {
    db.run("CREATE INDEX IF NOT EXISTS idx_site_visits_lead_id ON site_visits(lead_id);");
  } catch {}

  // Update existing admin and sample users verification status if needed
  try {
    db.run("UPDATE users SET verification_status = 'VERIFIED' WHERE is_verified = 1 AND (verification_status IS NULL OR verification_status = 'UNVERIFIED');");
  } catch {}

  // Seed default admin and sample owners if users table is empty
  const userCountRes = db.exec("SELECT COUNT(*) as count FROM users;");
  const count = userCountRes[0]?.values[0]?.[0] || 0;

  if (count === 0) {
    seedInitialData(db);
  } else {
    // Check if initial sample leads should be seeded
    seedInitialLeadsIfEmpty(db);
    seedInitialDealsIfEmpty(db);
    seedInitialSettingsAndLegalIfEmpty(db);
    seedSampleDocumentsIfEmpty(db);
    saveDb();
  }
}

export function logLeadActivity(
  db: Database,
  leadId: string,
  performedById: string,
  performedByName: string,
  performedByRole: string,
  action: string,
  details?: string
): void {
  try {
    const id = `act-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const cleanName = (performedByName || 'System').replace(/'/g, "''");
    const cleanRole = (performedByRole || 'user').replace(/'/g, "''");
    const cleanAction = (action || '').replace(/'/g, "''");
    const cleanDetails = (details || '').replace(/'/g, "''");
    db.run(`
      INSERT INTO lead_activities (id, lead_id, performed_by_id, performed_by_name, performed_by_role, action, details, created_at)
      VALUES ('${id}', '${leadId}', '${performedById}', '${cleanName}', '${cleanRole}', '${cleanAction}', '${cleanDetails}', '${now}');
    `);
    saveDb();
  } catch (err) {
    console.error('Error logging lead activity:', err);
  }
}

function seedInitialLeadsIfEmpty(db: Database) {
  try {
    const leadCountRes = db.exec("SELECT COUNT(*) as count FROM leads;");
    const leadCount = Number(leadCountRes[0]?.values[0]?.[0] || 0);
    if (leadCount > 0) return;

    const now = new Date();
    const dateStr = (daysAgo: number) => new Date(now.getTime() - daysAgo * 24 * 60 * 60 * 1000).toISOString();
    const futureDateStr = (daysAhead: number) => {
      const d = new Date(now.getTime() + daysAhead * 24 * 60 * 60 * 1000);
      return d.toISOString().split('T')[0];
    };

    // Customer 1: Rohan Mehta (High net worth buyer for Bandra apartment)
    db.run(`
      INSERT INTO customer_profiles (
        id, name, mobile, email, user_id, customer_type, preferred_transaction, preferred_category,
        preferred_locations, budget_min, budget_max, preferred_property_types, bhk, carpet_area_min,
        carpet_area_max, furnishing_preference, parking_requirement, notes, created_at, updated_at
      ) VALUES (
        'cust-101', 'Rohan Mehta', '+91 98201 12345', 'rohan.mehta@investmumbai.com', 'usr-buyer-kavita',
        'BUYER', 'buy', 'residential', 'Bandra West, Khar, Carter Road', 70000000, 95000000,
        '3 BHK, 4+ BHK', '3 BHK', 1300, 1800, 'semi-furnished', '2 Covered',
        'Looking for direct sea view or prime Carter Road location. Ready buyer with pre-approved HDFC luxury loan.',
        '${dateStr(5)}', '${dateStr(1)}'
      );
    `);

    // Lead 1: Rohan Mehta for prop-mum-01 (Carter Rd 3 BHK) - Stage: SITE_VISIT
    db.run(`
      INSERT INTO leads (
        id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
        customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
        bhk, required_carpet_area, furnishing_preference, parking_requirement,
        last_contacted_at, next_follow_up_at, created_at, updated_at
      ) VALUES (
        'lead-101', 'prop-mum-01', 'cust-101', 'usr-owner-sameer', NULL, 'PROPERTY_ENQUIRY', 'SITE_VISIT', 'HIGH',
        'Interested in inspecting the Carter Road 3 BHK sea-facing flat this Saturday with family and interior architect.',
        'High intent buyer. Verified funds. Specifically interested in the Arabian sea deck.',
        'PHONE', 87500000, 'residential', '3 BHK', 1480, 'semi-furnished', '2 Covered',
        '${dateStr(1)}', '${futureDateStr(2)}', '${dateStr(5)}', '${dateStr(1)}'
      );
    `);

    // Lead 1 activities
    logLeadActivity(db, 'lead-101', 'cust-101', 'Rohan Mehta', 'buyer', 'LEAD_CREATED', 'Enquiry received from Carter Road listing for direct inspection');
    logLeadActivity(db, 'lead-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'CONTACTED', 'Spoke on phone. Buyer verified financing and requested weekend slot');
    logLeadActivity(db, 'lead-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'STATUS_CHANGED', 'Status updated to SITE_VISIT');
    logLeadActivity(db, 'lead-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'FOLLOW_UP_SCHEDULED', `Site visit walk-through scheduled for ${futureDateStr(2)} 11:00 AM`);

    // Lead 1 follow-up
    db.run(`
      INSERT INTO lead_followups (id, lead_id, follow_up_date, follow_up_time, note, assigned_to, assigned_to_name, status, created_at, updated_at)
      VALUES ('fol-101', 'lead-101', '${futureDateStr(2)}', '11:00 AM', 'In-person site visit and title document review at Carter Road building lobby.', 'usr-owner-sameer', 'Sameer Merchant', 'PENDING', '${dateStr(1)}', '${dateStr(1)}');
    `);

    // Customer 2: Priya Deshmukh (Fintech CXO seeking BKC commercial office)
    db.run(`
      INSERT INTO customer_profiles (
        id, name, mobile, email, user_id, customer_type, preferred_transaction, preferred_category,
        preferred_locations, budget_min, budget_max, preferred_property_types, business_type,
        carpet_area_min, carpet_area_max, notes, created_at, updated_at
      ) VALUES (
        'cust-102', 'Priya Deshmukh', '+91 99302 45678', 'priya.d@apexfintech.in', NULL,
        'TENANT', 'rent', 'commercial', 'BKC, Bandra East, Kalina', 500000, 750000,
        'Office', 'Fintech, Corporate HQ', 2800, 3600,
        'Expanding fintech company, 45-60 employees. Needs plug and play corporate setup with DG backup.',
        '${dateStr(7)}', '${dateStr(2)}'
      );
    `);

    // Lead 2: Priya Deshmukh for prop-mum-02 (BKC Office) - Stage: NEGOTIATING
    db.run(`
      INSERT INTO leads (
        id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
        customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
        business_type, required_carpet_area,
        last_contacted_at, next_follow_up_at, created_at, updated_at
      ) VALUES (
        'lead-102', 'prop-mum-02', 'cust-102', 'usr-owner-sameer', NULL, 'WEBSITE', 'NEGOTIATING', 'URGENT',
        'Requesting commercial lease proposal for 3-year term for Grade-A office at BKC G Block.',
        'Completed 2 rounds of site visits. Negotiating security deposit from 6 months to 4 months and rent free fit-out period of 30 days.',
        'WHATSAPP', 650000, 'commercial', 'Fintech, Corporate HQ', 3200,
        '${dateStr(1)}', '${futureDateStr(1)}', '${dateStr(7)}', '${dateStr(1)}'
      );
    `);

    logLeadActivity(db, 'lead-102', 'cust-102', 'Priya Deshmukh', 'tenant', 'LEAD_CREATED', 'Direct inquiry for BKC Grade-A office lease');
    logLeadActivity(db, 'lead-102', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'SITE_VISIT_COMPLETED', 'First site visit completed with facilities director');
    logLeadActivity(db, 'lead-102', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'STATUS_CHANGED', 'Status updated to NEGOTIATING');
    logLeadActivity(db, 'lead-102', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'NOTE_ADDED', 'Draft LOI shared with tenant counsel');

    db.run(`
      INSERT INTO lead_followups (id, lead_id, follow_up_date, follow_up_time, note, assigned_to, assigned_to_name, status, created_at, updated_at)
      VALUES ('fol-102', 'lead-102', '${futureDateStr(1)}', '03:30 PM', 'Call with CFO to finalize fit-out grace period and sign lease term sheet.', 'usr-owner-sameer', 'Sameer Merchant', 'PENDING', '${dateStr(1)}', '${dateStr(1)}');
    `);

    // Customer 3: Aditya Kapoor (Doctor / Clinic Director seeking Lower Parel showroom)
    db.run(`
      INSERT INTO customer_profiles (
        id, name, mobile, email, user_id, customer_type, preferred_transaction, preferred_category,
        preferred_locations, budget_min, budget_max, preferred_property_types, business_type,
        carpet_area_min, carpet_area_max, notes, created_at, updated_at
      ) VALUES (
        'cust-103', 'Dr. Aditya Kapoor', '+91 98199 87654', 'aditya.kapoor@southmumbaidental.com', NULL,
        'TENANT', 'lease', 'commercial', 'Lower Parel, Worli, Prabhadevi', 300000, 450000,
        'Showroom, Clinic', 'Clinic, Wellness Center', 1500, 2200,
        'Establishing dental and aesthetic clinic. Needs street visibility and frontage.',
        '${dateStr(3)}', '${dateStr(3)}'
      );
    `);

    // Lead 3: Dr. Aditya Kapoor for prop-mum-04 - Stage: QUALIFIED
    db.run(`
      INSERT INTO leads (
        id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
        customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
        business_type, required_carpet_area,
        last_contacted_at, next_follow_up_at, created_at, updated_at
      ) VALUES (
        'lead-103', 'prop-mum-04', 'cust-103', 'usr-owner-sameer', NULL, 'PHONE', 'QUALIFIED', 'MEDIUM',
        'Inquiring if high ceiling in Lower Parel showroom allows medical drainage and clinic fitouts.',
        'Owner confirmed clear height and medical MEP permissions are viable.',
        'PHONE', 380000, 'commercial', 'Clinic, Wellness Center', 1850,
        '${dateStr(2)}', '${futureDateStr(3)}', '${dateStr(3)}', '${dateStr(2)}'
      );
    `);

    logLeadActivity(db, 'lead-103', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'LEAD_CREATED', 'Inbound call logged from Senapati Bapat Marg listing');
    logLeadActivity(db, 'lead-103', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'CONTACTED', 'Clarified double height and mezzanine specifications');
    logLeadActivity(db, 'lead-103', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'STATUS_CHANGED', 'Marked as QUALIFIED');

    // Customer 4: Vikram Singhania (Industrialist seeking Worli Penthouse) - Stage: WON
    db.run(`
      INSERT INTO customer_profiles (
        id, name, mobile, email, user_id, customer_type, preferred_transaction, preferred_category,
        preferred_locations, budget_min, budget_max, preferred_property_types, bhk, carpet_area_min,
        carpet_area_max, notes, created_at, updated_at
      ) VALUES (
        'cust-104', 'Vikram Singhania', '+91 98200 99887', 'vikram.singhania@apexholding.com', NULL,
        'BUYER', 'buy', 'residential', 'Worli Sea Face, Malabar Hill', 150000000, 180000000,
        '4+ BHK, Penthouse', '4+ BHK', 2500, 3500,
        'Trophy property acquirer. Full cash payment readiness.',
        '${dateStr(14)}', '${dateStr(1)}'
      );
    `);

    db.run(`
      INSERT INTO leads (
        id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
        customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
        bhk, required_carpet_area,
        last_contacted_at, created_at, updated_at
      ) VALUES (
        'lead-104', 'prop-mum-03', 'cust-104', 'usr-owner-sameer', NULL, 'REFERRAL', 'WON', 'HIGH',
        'Direct inquiry for Worli Sea-Link penthouse via private family office.',
        'Sale agreement executed. Token received. Title clearance completed by Khaitan & Co.',
        'PHONE', 165000000, 'residential', '4+ BHK', 2850,
        '${dateStr(1)}', '${dateStr(14)}', '${dateStr(1)}'
      );
    `);

    logLeadActivity(db, 'lead-104', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'LEAD_CREATED', 'Private referral lead received');
    logLeadActivity(db, 'lead-104', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'DEAL_WON', 'Sale transaction finalized at agreed valuation. Agreement registered.');

    // Lead 5: New website enquiry
    db.run(`
      INSERT INTO customer_profiles (
        id, name, mobile, email, user_id, customer_type, preferred_transaction, preferred_category,
        preferred_locations, budget_min, budget_max, preferred_property_types, bhk,
        furnishing_preference, parking_requirement, notes, created_at, updated_at
      ) VALUES (
        'cust-105', 'Ananya Sharma', '+91 97112 33445', 'ananya.s@studioarch.in', NULL,
        'BUYER', 'buy', 'residential', 'Bandra West, Pali Hill', 80000000, 90000000,
        '3 BHK', '3 BHK', 'fully-furnished', '2 Covered',
        'Interior architect looking for ready residential apartment in Bandra.',
        '${dateStr(0)}', '${dateStr(0)}'
      );
    `);

    db.run(`
      INSERT INTO leads (
        id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
        customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
        bhk, required_carpet_area,
        created_at, updated_at
      ) VALUES (
        'lead-105', 'prop-mum-01', 'cust-105', 'usr-owner-sameer', NULL, 'PROPERTY_ENQUIRY', 'NEW', 'URGENT',
        'Hi, is this Carter Road property still available for direct inspection? Can you share building OC status?',
        'Fresh inquiry received from website portal.',
        'WHATSAPP', 87500000, 'residential', '3 BHK', 1480,
        '${dateStr(0)}', '${dateStr(0)}'
      );
    `);

    logLeadActivity(db, 'lead-105', 'cust-105', 'Ananya Sharma', 'buyer', 'LEAD_CREATED', 'Lead automatically generated from Carter Road property enquiry');

    console.log('Successfully seeded initial Phase 4 leads & customer profiles');
  } catch (err) {
    console.error('Error seeding initial leads:', err);
  }
}

export function logDealActivity(
  db: Database,
  dealId: string,
  performedById: string,
  performedByName: string,
  performedByRole: string,
  action: string,
  details?: string
): void {
  try {
    const id = `act-deal-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const cleanName = (performedByName || 'System').replace(/'/g, "''");
    const cleanRole = (performedByRole || 'user').replace(/'/g, "''");
    const cleanAction = (action || '').replace(/'/g, "''");
    const cleanDetails = (details || '').replace(/'/g, "''");
    db.run(`
      INSERT INTO deal_activities (id, deal_id, performed_by_id, performed_by_name, performed_by_role, action, details, created_at)
      VALUES ('${id}', '${dealId}', '${performedById}', '${cleanName}', '${cleanRole}', '${cleanAction}', '${cleanDetails}', '${now}');
    `);
    saveDb();
  } catch (err) {
    console.error('Error logging deal activity:', err);
  }
}

export function logQueryActivity(
  db: Database,
  queryId: string,
  performedById: string,
  performedByName: string,
  performedByRole: string,
  action: string,
  details?: string
): void {
  try {
    const id = `act-qry-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const cleanName = (performedByName || 'System').replace(/'/g, "''");
    const cleanRole = (performedByRole || 'user').replace(/'/g, "''");
    const cleanAction = (action || '').replace(/'/g, "''");
    const cleanDetails = (details || '').replace(/'/g, "''");
    db.run(`
      INSERT INTO query_activities (id, query_id, performed_by_id, performed_by_name, performed_by_role, action, details, created_at)
      VALUES ('${id}', '${queryId}', '${performedById}', '${cleanName}', '${cleanRole}', '${cleanAction}', '${cleanDetails}', '${now}');
    `);
    saveDb();
  } catch (err) {
    console.error('Error logging query activity:', err);
  }
}

function seedInitialDealsIfEmpty(db: Database) {
  try {
    const dealCountRes = db.exec("SELECT COUNT(*) as count FROM deals;");
    const dealCount = Number(dealCountRes[0]?.values[0]?.[0] || 0);
    if (dealCount > 0) return;

    const now = new Date();
    const dateStr = (daysAgo: number) => new Date(now.getTime() - daysAgo * 24 * 60 * 60 * 1000).toISOString();
    const futureDateStr = (daysAhead: number) => {
      const d = new Date(now.getTime() + daysAhead * 24 * 60 * 60 * 1000);
      return d.toISOString().split('T')[0];
    };

    // Deal 1: Completed Residential Sale for Worli Sea Face Penthouse
    db.run(`
      INSERT INTO deals (
        id, deal_number, lead_id, property_id, customer_id, owner_id, assigned_agent_id,
        transaction_type, category, deal_status, agreed_property_value,
        commission_type, commission_rate, commission_base, commission_amount,
        commission_payer, commission_status, expected_closing_date, actual_closing_date,
        notes, created_at, updated_at
      ) VALUES (
        'deal-101', 'DEAL-2026-0001', 'lead-104', 'prop-mum-03', 'cust-104', 'usr-owner-sameer', NULL,
        'BUY', 'RESIDENTIAL', 'COMPLETED', 165000000,
        'PERCENTAGE', 1.0, 165000000, 1650000,
        'BUYER', 'PAID', '${dateStr(5)}', '${dateStr(1)}',
        'Trophy property deal closed smoothly. Registration completed with Sub-Registrar Worli.',
        '${dateStr(12)}', '${dateStr(1)}'
      );
    `);

    // Deal 1 Payments
    db.run(`
      INSERT INTO deal_payments (
        id, deal_id, receipt_number, amount, payment_method, transaction_reference,
        payment_date, payer_name, recorded_by_id, recorded_by_name, notes, created_at
      ) VALUES (
        'pay-101', 'deal-101', 'REC-2026-0001', 825000, 'NEFT_RTGS', 'CMS98421094',
        '${dateStr(4).split('T')[0]}', 'Vikram Singhania', 'usr-owner-sameer', 'Sameer Merchant',
        'First tranche 50% brokerage advance upon agreement signing.', '${dateStr(4)}'
      );
    `);

    db.run(`
      INSERT INTO deal_payments (
        id, deal_id, receipt_number, amount, payment_method, transaction_reference,
        payment_date, payer_name, recorded_by_id, recorded_by_name, notes, created_at
      ) VALUES (
        'pay-102', 'deal-101', 'REC-2026-0002', 825000, 'NEFT_RTGS', 'CMS98429910',
        '${dateStr(1).split('T')[0]}', 'Vikram Singhania', 'usr-owner-sameer', 'Sameer Merchant',
        'Final 50% brokerage settlement upon key handover.', '${dateStr(1)}'
      );
    `);

    // Deal 1 Invoice
    db.run(`
      INSERT INTO deal_invoices (
        id, deal_id, invoice_number, issue_date, due_date, subtotal, gst_rate, gst_amount, total_amount, status, notes, created_at
      ) VALUES (
        'inv-101', 'deal-101', 'INV-2026-0001', '${dateStr(5).split('T')[0]}', '${dateStr(1).split('T')[0]}',
        1650000, 18, 297000, 1947000, 'PAID', 'Full brokerage invoice for Worli Sea Face luxury penthouse transaction.', '${dateStr(5)}'
      );
    `);

    // Deal 1 Activities
    logDealActivity(db, 'deal-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'DEAL_CREATED', 'Converted from qualified lead lead-104 with agreed value ₹16,50,00,000');
    logDealActivity(db, 'deal-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'COMMISSION_SET', 'Agreed 1.0% brokerage payable by BUYER (₹16,50,000)');
    logDealActivity(db, 'deal-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'INVOICE_GENERATED', 'Generated invoice INV-2026-0001 for ₹19,47,000 (inclusive of 18% GST)');
    logDealActivity(db, 'deal-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'PAYMENT_RECORDED', 'Received ₹8,25,000 via NEFT_RTGS (Ref: CMS98421094)');
    logDealActivity(db, 'deal-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'PAYMENT_RECORDED', 'Received ₹8,25,000 final settlement (Ref: CMS98429910)');
    logDealActivity(db, 'deal-101', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'DEAL_COMPLETED', 'Deal successfully executed and closed');

    // Deal 2: Commercial Lease for BKC Grade-A Office
    db.run(`
      INSERT INTO deals (
        id, deal_number, lead_id, property_id, customer_id, owner_id, assigned_agent_id,
        transaction_type, category, deal_status, agreed_rent,
        commission_type, commission_amount, commission_payer, commission_status,
        expected_closing_date, notes, created_at, updated_at
      ) VALUES (
        'deal-102', 'DEAL-2026-0002', 'lead-102', 'prop-mum-02', 'cust-102', 'usr-owner-sameer', NULL,
        'RENT', 'COMMERCIAL', 'AGREEMENT_SIGNED', 650000,
        'FIXED_AMOUNT', 650000, 'TENANT', 'PARTIALLY_PAID',
        '${futureDateStr(7)}', '3-year lease executed with 30-day rent-free fitout grace period.',
        '${dateStr(6)}', '${dateStr(1)}'
      );
    `);

    // Deal 2 Payment
    db.run(`
      INSERT INTO deal_payments (
        id, deal_id, receipt_number, amount, payment_method, transaction_reference,
        payment_date, payer_name, recorded_by_id, recorded_by_name, notes, created_at
      ) VALUES (
        'pay-103', 'deal-102', 'REC-2026-0003', 325000, 'BANK_TRANSFER', 'HDFC77281920',
        '${dateStr(2).split('T')[0]}', 'Priya Deshmukh (Apex Fintech)', 'usr-owner-sameer', 'Sameer Merchant',
        '50% retainer brokerage received upon LOI execution.', '${dateStr(2)}'
      );
    `);

    // Deal 2 Invoice
    db.run(`
      INSERT INTO deal_invoices (
        id, deal_id, invoice_number, issue_date, due_date, subtotal, gst_rate, gst_amount, total_amount, status, notes, created_at
      ) VALUES (
        'inv-102', 'deal-102', 'INV-2026-0002', '${dateStr(3).split('T')[0]}', '${futureDateStr(5)}',
        650000, 18, 117000, 767000, 'ISSUED', 'Commercial brokerage invoice for 3-year BKC office lease.', '${dateStr(3)}'
      );
    `);

    // Deal 2 Activities
    logDealActivity(db, 'deal-102', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'DEAL_CREATED', 'Converted from qualified lead lead-102 with agreed monthly rent ₹6,50,000');
    logDealActivity(db, 'deal-102', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'COMMISSION_SET', 'Fixed 1-month brokerage ₹6,50,000 payable by TENANT');
    logDealActivity(db, 'deal-102', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'INVOICE_GENERATED', 'Generated invoice INV-2026-0002 for ₹7,67,000');
    logDealActivity(db, 'deal-102', 'usr-owner-sameer', 'Sameer Merchant', 'owner', 'PAYMENT_RECORDED', 'Received partial advance ₹3,25,000 via BANK_TRANSFER (Ref: HDFC77281920)');

    console.log('Successfully seeded initial Phase 5 deals, payments, and invoices');
  } catch (err) {
    console.error('Error seeding initial deals:', err);
  }
}

export function createNotification(
  db: Database,
  userId: string,
  title: string,
  message: string,
  type: string = 'INFO',
  link?: string
): void {
  try {
    const id = `notif-${Date.now()}-${Math.round(Math.random() * 10000)}`;
    const now = new Date().toISOString();
    const cleanTitle = (title || '').replace(/'/g, "''");
    const cleanMessage = (message || '').replace(/'/g, "''");
    const cleanType = (type || 'INFO').replace(/'/g, "''");
    const cleanLink = link ? `'${link.replace(/'/g, "''")}'` : 'NULL';

    db.run(`
      INSERT INTO notifications (id, user_id, title, message, type, link, is_read, created_at)
      VALUES ('${id}', '${userId}', '${cleanTitle}', '${cleanMessage}', '${cleanType}', ${cleanLink}, 0, '${now}');
    `);
    saveDb();
  } catch (err) {
    console.error('Error creating notification:', err);
  }
}

function seedInitialSettingsAndLegalIfEmpty(db: Database) {
  try {
    const settingsCountRes = db.exec("SELECT COUNT(*) as count FROM system_settings;");
    const count = Number(settingsCountRes[0]?.values[0]?.[0] || 0);
    const now = new Date().toISOString();

    if (count === 0) {
      const defaultSettings = [
        { key: 'business_name', value: 'P2P Property Technologies Pvt. Ltd.', desc: 'Registered legal operating business entity' },
        { key: 'brand_tagline', value: 'MUMBAI DIRECT — Direct Peer-to-Peer Real Estate', desc: 'Public branding subtitle' },
        { key: 'broker_name', value: 'P2P Property Advisory Desk (MahaRERA Registered Agent)', desc: 'Authorized broker/advisor entity name' },
        { key: 'maharera_reg_number', value: 'A51900034821', desc: 'MahaRERA Real Estate Agent Registration Number' },
        { key: 'certificate_of_competency', value: 'CoC-MAH-2024-99182', desc: 'MahaRERA Real Estate Agent Certificate of Competency details' },
        { key: 'business_phone', value: '+91 (022) 6820-0022', desc: 'Official concierge and grievance phone number' },
        { key: 'business_email', value: 'concierge@p2pproperty.in', desc: 'Official customer support email address' },
        { key: 'office_address', value: 'Floor 8, Maker Maxity, Bandra Kurla Complex (BKC), Mumbai, Maharashtra 400051', desc: 'Physical Mumbai operating office address' },
        { key: 'whatsapp_number', value: '+919820098200', desc: 'Direct WhatsApp verified business communication number' },
        { key: 'currency', value: 'INR', desc: 'Base transaction currency code' },
        { key: 'default_gst_rate', value: '18', desc: 'Statutory GST percentage for commercial services' },
        { key: 'razorpay_enabled', value: '0', desc: 'Enable/disable online payment gateway' }
      ];

      for (const s of defaultSettings) {
        db.run(`
          INSERT OR REPLACE INTO system_settings (key, value, description, updated_at)
          VALUES ('${s.key}', '${s.value.replace(/'/g, "''")}', '${s.desc.replace(/'/g, "''")}', '${now}');
        `);
      }
    }

    const legalCountRes = db.exec("SELECT COUNT(*) as count FROM legal_pages;");
    const legalCount = Number(legalCountRes[0]?.values[0]?.[0] || 0);

    if (legalCount === 0) {
      const legalDocs = [
        {
          slug: 'privacy',
          title: 'Privacy Policy',
          content: 'P2P Property Technologies Pvt. Ltd. is committed to protecting your personal information. We operate a direct peer-to-peer real estate platform in the Mumbai Metropolitan Region (MMRDA). In accordance with the Information Technology Act 2000 and Digital Personal Data Protection guidelines, we implement strict role-based access control, masked owner contact channels, and zero public exposure of personal financial or identity documents. Personal information is only shared when an explicit direct enquiry or site visit is confirmed by the property owner.'
        },
        {
          slug: 'terms',
          title: 'Terms & Conditions',
          content: 'By accessing or using P2P Property, you agree to comply with our Terms of Service. P2P Property connects genuine property owners and buyers/tenants across Mumbai. Users represent and warrant that all listing details, property valuations, and submitted legal documents are truthful, non-infringing, and lawful. P2P Property reserves the right to review, reject, or delist properties failing physical verification or standard due diligence criteria.'
        },
        {
          slug: 'brokerage-terms',
          title: 'Brokerage & Advisory Terms',
          content: 'P2P Property operates with transparent, mutually agreed brokerage agreements. Brokerage rates are determined on a deal-by-deal basis between parties (whether percentage-based or fixed amount) and are formally documented before transaction closing. Brokerage invoices are issued in accordance with Indian tax laws (including applicable 18% GST). Payment tranches must adhere to milestones specified in the signed deal agreement.'
        },
        {
          slug: 'refund-policy',
          title: 'Refund & Cancellation Policy',
          content: 'Listing submission on P2P Property is free of charge for individual property owners. Any fee-based advisory or verification packages may be cancelled within 24 hours of purchase if site verification has not commenced. Brokerage fees paid upon completed property transactions, agreement executions, or successful possession handovers are non-refundable.'
        },
        {
          slug: 'verification-policy',
          title: 'Property Verification Policy & Disclaimer',
          content: 'P2P Property performs preliminary document sanity checks and geo-tagging verifications for properties bearing the "VERIFIED" badge. However, platform verification does not substitute for independent legal title search, encumbrance verification, structural audits, or local municipal clearance checks. Prospective buyers and tenants are advised to engage independent legal counsel and verify official Land Records (7/12 extract / City Survey Index II) before remitting property considerations.'
        },
        {
          slug: 'about',
          title: 'About P2P Property Mumbai',
          content: 'Founded in Mumbai, P2P Property is the first dedicated peer-to-peer residential and commercial real-estate platform engineered specifically for the Mumbai Metropolitan Region. We eliminate arbitrary brokerage friction, provide transparent document verification workflows, and enable direct negotiations between verified owners, licensed advisors, and qualified buyers.'
        }
      ];

      for (const d of legalDocs) {
        db.run(`
          INSERT OR REPLACE INTO legal_pages (slug, title, content, updated_at, updated_by)
          VALUES ('${d.slug}', '${d.title.replace(/'/g, "''")}', '${d.content.replace(/'/g, "''")}', '${now}', 'SYSTEM');
        `);
      }
    }
  } catch (err) {
    console.error('Error seeding settings and legal pages:', err);
  }
}

function seedSampleDocumentsIfEmpty(db: Database) {
  try {
    const docCountRes = db.exec("SELECT COUNT(*) as count FROM property_documents;");
    const docCount = Number(docCountRes[0]?.values[0]?.[0] || 0);
    if (docCount > 0) return;

    const now = new Date().toISOString();
    // Sample verified documents for Carter Road property
    db.run(`
      INSERT INTO property_documents (
        id, property_id, document_type, title, file_url, file_name, file_size, mime_type,
        uploaded_by_id, verification_status, admin_notes, verified_by_id, verified_at, created_at, updated_at
      ) VALUES 
      (
        'doc-101', 'prop-mum-01', 'OWNERSHIP_DEED', 'Registered Sale Deed (Index II)',
        '/uploads/documents/carter_road_index2.pdf', 'carter_road_index2.pdf', 2450000, 'application/pdf',
        'usr-owner-sameer', 'VERIFIED', 'Title verified against Sub-Registrar Bandra records. Clear ownership chain.',
        'usr-admin-rajesh', '${now}', '${now}', '${now}'
      ),
      (
        'doc-102', 'prop-mum-01', 'OC_CC', 'Occupancy Certificate (MCGM)',
        '/uploads/documents/carter_road_oc.pdf', 'carter_road_oc.pdf', 1820000, 'application/pdf',
        'usr-owner-sameer', 'VERIFIED', 'MCGM H-West Ward OC valid and cross-verified.',
        'usr-admin-rajesh', '${now}', '${now}', '${now}'
      ),
      (
        'doc-103', 'prop-mum-01', 'PROPERTY_TAX_RECEIPT', 'MCGM Property Tax Assessment Receipt 2025-26',
        '/uploads/documents/carter_road_tax.pdf', 'carter_road_tax.pdf', 980000, 'application/pdf',
        'usr-owner-sameer', 'VERIFIED', 'No tax dues pending.',
        'usr-admin-rajesh', '${now}', '${now}', '${now}'
      );
    `);
    console.log('Successfully seeded sample property verification documents');
  } catch (err) {
    console.error('Error seeding property documents:', err);
  }
}

export function logAudit(
  db: Database,
  adminId: string,
  adminName: string,
  action: string,
  entityType: string,
  entityId: string,
  details?: string
): void {
  try {
    const id = `audit-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const cleanAdminName = (adminName || 'Admin').replace(/'/g, "''");
    const cleanDetails = (details || '').replace(/'/g, "''");
    db.run(`
      INSERT INTO audit_logs (id, admin_id, admin_name, action, entity_type, entity_id, details, created_at)
      VALUES ('${id}', '${adminId}', '${cleanAdminName}', '${action}', '${entityType}', '${entityId}', '${cleanDetails}', '${now}');
    `);
    saveDb();
  } catch (err) {
    console.error('Error logging audit entry:', err);
  }
}

function seedInitialData(db: Database) {
  const now = new Date().toISOString();
  const salt = bcrypt.genSaltSync(10);

  // 1. Admin
  const adminPassHash = bcrypt.hashSync('Admin@12345', salt);
  db.run(`
    INSERT INTO users (id, name, email, phone, password_hash, role, capabilities, is_verified, created_at, updated_at)
    VALUES ('usr-admin-1', 'P2P Platform Admin', 'admin@p2pproperty.in', '+91 22 68200022', '${adminPassHash}', 'admin', '["admin","owner","buyer"]', 1, '${now}', '${now}');
  `);

  // 2. Verified Sample Owner
  const ownerPassHash = bcrypt.hashSync('Owner@12345', salt);
  db.run(`
    INSERT INTO users (id, name, email, phone, password_hash, role, capabilities, is_verified, created_at, updated_at)
    VALUES ('usr-owner-sameer', 'Sameer Merchant', 'sameer.merchant@mumbai.in', '+91 98201 44584', '${ownerPassHash}', 'owner', '["owner"]', 1, '${now}', '${now}');
  `);

  // 3. Sample Buyer
  const buyerPassHash = bcrypt.hashSync('Buyer@12345', salt);
  db.run(`
    INSERT INTO users (id, name, email, phone, password_hash, role, capabilities, is_verified, created_at, updated_at)
    VALUES ('usr-buyer-ananya', 'Ananya Deshmukh', 'ananya.deshmukh@mumbai.in', '+91 98202 88471', '${buyerPassHash}', 'buyer', '["buyer"]', 1, '${now}', '${now}');
  `);

  // Seed Approved Development Sample Properties
  seedSampleProperties(db, now);

  saveDb();
}

function seedSampleProperties(db: Database, now: string) {
  // Sample Property 1: Sea-Facing 3 BHK in Bandra
  db.run(`
    INSERT INTO properties (
      id, owner_id, category, transaction_type, property_type, title, description, price, maintenance,
      carpet_area, built_up_area, bedrooms, bathrooms, floor, total_floors, furnishing, parking,
      address, locality, city, pincode, latitude, longitude, status, verification_status, is_sample,
      created_at, updated_at
    ) VALUES (
      'prop-mum-01', 'usr-owner-sameer', 'residential', 'buy', '3 BHK',
      'Sea-Facing 3 BHK Luxury Residence at Carter Road',
      'An exceptional high-floor 3 BHK apartment directly overlooking the Arabian Sea on Carter Road, Bandra West. Designed with expansive floor-to-ceiling soundproof glass, continuous Italian Statuario marble flooring, custom modular kitchen, and double-height private deck. Directly offered by verified owner with clear title documents and OC received.',
      87500000, 18500, 1480, 1950, 3, 3, 14, 22, 'semi-furnished', '2 Covered',
      'Carter Road, Bandra West', 'Bandra West', 'Mumbai', '400050', 19.0657, 72.8258,
      'APPROVED', 'VERIFIED', 1, '${now}', '${now}'
    );
  `);

  // Images for Prop 1
  db.run(`
    INSERT INTO property_images (id, property_id, image_url, display_order, caption, is_primary, created_at)
    VALUES 
      ('img-1-1', 'prop-mum-01', '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg', 0, 'Spacious sea-view living room with Italian marble floor', 1, '${now}'),
      ('img-1-2', 'prop-mum-01', '/src/assets/images/worli_seaface_residence_1791457653070.jpg', 1, 'Master bedroom balcony view', 0, '${now}'),
      ('img-1-3', 'prop-mum-01', '/src/assets/images/hero_mumbai_skyline_1791457614725.jpg', 2, 'Coastal evening view from tower terrace', 0, '${now}');
  `);

  // Amenities for Prop 1
  const a1 = ['Arabian Sea View', '2 Dedicated Covered Parkings', 'High-Speed Mitsubishi Elevators', '24/7 Biometric Security', 'Rooftop Infinity Pool', 'Full DG Power Backup'];
  a1.forEach((am, i) => {
    db.run(`INSERT INTO property_amenities (id, property_id, amenity_name, created_at) VALUES ('am-1-${i}', 'prop-mum-01', '${am}', '${now}');`);
  });

  // Sample Property 2: Commercial Office in BKC
  db.run(`
    INSERT INTO properties (
      id, owner_id, category, transaction_type, property_type, title, description, price, rent, security_deposit, maintenance,
      carpet_area, built_up_area, floor, total_floors, furnishing, parking,
      address, locality, city, pincode, latitude, longitude, status, verification_status, is_sample,
      washrooms, power_backup, loading_unloading, business_type, commercial_use_type,
      created_at, updated_at
    ) VALUES (
      'prop-mum-02', 'usr-owner-sameer', 'commercial', 'rent', 'Office',
      'Grade-A Corporate Headquarters Office in BKC',
      'Plug-and-play Grade A commercial office suite situated in the heart of Mumbai CBD (BKC G Block). Features 48 ergonomic workstations, 2 director cabins, 12-seater AV board room, pantry, server room with independent VRF air conditioning, and 100% DG backup.',
      650000, 650000, 3900000, 48000, 3200, 4400, 8, 16, 'fully-furnished', '4 Covered',
      'G Block, BKC', 'Bandra Kurla Complex (BKC)', 'Mumbai', '400051', 19.0664, 72.8687,
      'APPROVED', 'VERIFIED', 1, 4, 1, 1, 'Fintech, Corporate HQ, Legal', 'Corporate Office',
      '${now}', '${now}'
    );
  `);

  db.run(`
    INSERT INTO property_images (id, property_id, image_url, display_order, caption, is_primary, created_at)
    VALUES 
      ('img-2-1', 'prop-mum-02', '/src/assets/images/bkc_commercial_office_1791457642520.jpg', 0, 'Fully plug & play corporate office workstations', 1, '${now}'),
      ('img-2-2', 'prop-mum-02', '/src/assets/images/mumbai_retail_showroom_1791457664965.jpg', 1, 'Executive boardroom and reception lobby', 0, '${now}');
  `);

  const a2 = ['Plug & Play Ready', 'Central VRF Chilled Water HVAC', '100% Full Power Backup', '4 Reserved Basement Parkings', 'LEED Platinum Certified Building'];
  a2.forEach((am, i) => {
    db.run(`INSERT INTO property_amenities (id, property_id, amenity_name, created_at) VALUES ('am-2-${i}', 'prop-mum-02', '${am}', '${now}');`);
  });

  // Sample Property 3: Penthouse in Worli
  db.run(`
    INSERT INTO properties (
      id, owner_id, category, transaction_type, property_type, title, description, price, maintenance,
      carpet_area, built_up_area, bedrooms, bathrooms, floor, total_floors, furnishing, parking,
      address, locality, city, pincode, latitude, longitude, status, verification_status, is_sample,
      created_at, updated_at
    ) VALUES (
      'prop-mum-03', 'usr-owner-sameer', 'residential', 'buy', '4+ BHK',
      'Signature Sea-Link View 4+ BHK Penthouse in Worli',
      'An elite trophy penthouse on the 38th floor in Worli Sea Face with unhindered 270-degree vistas of the Bandra-Worli Sea Link and Mumbai skyline. Features private elevator lobby, expansive wrap-around sky terrace, four en-suite bedrooms, and 4 stilt parking spaces.',
      165000000, 32000, 2850, 3800, 4, 5, 38, 42, 'unfurnished', '4 Covered',
      'Worli Sea Face', 'Worli', 'Mumbai', '400030', 19.0178, 72.8152,
      'APPROVED', 'VERIFIED', 1,
      '${now}', '${now}'
    );
  `);

  db.run(`
    INSERT INTO property_images (id, property_id, image_url, display_order, caption, is_primary, created_at)
    VALUES 
      ('img-3-1', 'prop-mum-03', '/src/assets/images/worli_seaface_residence_1791457653070.jpg', 0, 'Expansive private terrace looking onto the Arabian Sea', 1, '${now}'),
      ('img-3-2', 'prop-mum-03', '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg', 1, 'Grand living room with 12-foot clear ceiling', 0, '${now}');
  `);

  // Sample Property 4: Retail Showroom in Lower Parel
  db.run(`
    INSERT INTO properties (
      id, owner_id, category, transaction_type, property_type, title, description, price, rent, security_deposit, maintenance,
      carpet_area, built_up_area, floor, total_floors, furnishing, parking,
      address, locality, city, pincode, latitude, longitude, status, verification_status, is_sample,
      washrooms, power_backup, loading_unloading, business_type, frontage, ceiling_height, commercial_use_type,
      created_at, updated_at
    ) VALUES (
      'prop-mum-04', 'usr-owner-sameer', 'commercial', 'lease', 'Showroom',
      'Double-Height High-Street Flagship Showroom in Lower Parel',
      'Prominent ground-floor commercial showroom boasting 45 feet of clear street frontage along main Senapati Bapat Marg in Lower Parel. Features 18-foot clear ceiling height, approved mezzanine level, 3-phase commercial electrical sanction, and dedicated valet drop-off.',
      380000, 380000, 2280000, 22000, 1850, 2400, 0, 12, 'unfurnished', '2 Covered, 2 Open',
      'Senapati Bapat Marg', 'Lower Parel', 'Mumbai', '400013', 18.9953, 72.8274,
      'APPROVED', 'VERIFIED', 1,
      2, 1, 1, 'Luxury Fashion, Auto, Electronics', 45, 18, 'Retail Showroom',
      '${now}', '${now}'
    );
  `);

  db.run(`
    INSERT INTO property_images (id, property_id, image_url, display_order, caption, is_primary, created_at)
    VALUES 
      ('img-4-1', 'prop-mum-04', '/src/assets/images/mumbai_retail_showroom_1791457664965.jpg', 0, 'Double height high-visibility glass frontage', 1, '${now}'),
      ('img-4-2', 'prop-mum-04', '/src/assets/images/bkc_commercial_office_1791457642520.jpg', 1, 'Mezzanine design and back office area', 0, '${now}');
  `);
}
