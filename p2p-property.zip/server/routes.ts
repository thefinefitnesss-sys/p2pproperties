import express, { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { getDb, saveDb, logAudit, logLeadActivity, logDealActivity, logQueryActivity, createNotification } from './db.js';
import { authMiddleware, optionalAuthMiddleware, adminMiddleware, generateToken, AuthRequest } from './auth.js';

const router = express.Router();

// File upload setup
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `prop-${uniqueSuffix}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only images are allowed'));
    }
  }
});

const docUpload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 }, // 15MB limit
  fileFilter: (_req, file, cb) => {
    const allowed = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only PDF and image documents (JPEG, PNG, WEBP) are supported.'));
    }
  }
});

// Helper: map SQL rows into JSON objects
function mapRows(queryResult: any[]): any[] {
  if (!queryResult || queryResult.length === 0) return [];
  const columns = queryResult[0].columns;
  return queryResult[0].values.map((row: any[]) => {
    const obj: any = {};
    columns.forEach((col: string, i: number) => {
      obj[col] = row[i];
    });
    return obj;
  });
}

// --------------------------------------------------------------------------
// 1. AUTHENTICATION ROUTES
// --------------------------------------------------------------------------

// POST /api/auth/signup
router.post('/auth/signup', async (req: Request, res: Response) => {
  try {
    const { name, email, phone, password, role = 'buyer' } = req.body;

    if (!name || !email || !phone || !password) {
      res.status(400).json({ error: 'All fields (name, email, phone, password) are required.' });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters.' });
      return;
    }

    const db = await getDb();
    const cleanEmail = email.trim().toLowerCase();

    // Check existing
    const existing = db.exec(`SELECT id FROM users WHERE email = '${cleanEmail}' LIMIT 1;`);
    if (existing.length > 0 && existing[0].values.length > 0) {
      res.status(400).json({ error: 'An account with this email address already exists.' });
      return;
    }

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);
    const userId = `usr-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const userRole = ['buyer', 'tenant', 'owner', 'agent'].includes(role) ? role : 'buyer';
    const capabilities = JSON.stringify([userRole]);

    db.run(`
      INSERT INTO users (id, name, email, phone, password_hash, role, capabilities, is_verified, created_at, updated_at)
      VALUES ('${userId}', '${name.replace(/'/g, "''")}', '${cleanEmail}', '${phone.replace(/'/g, "''")}', '${passwordHash}', '${userRole}', '${capabilities}', 0, '${now}', '${now}');
    `);
    saveDb();

    const user = {
      id: userId,
      name,
      email: cleanEmail,
      phone,
      role: userRole as any,
      capabilities: [userRole],
      is_verified: false,
      created_at: now
    };

    const token = generateToken(user);
    res.status(201).json({ token, user });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error creating account.' });
  }
});

// POST /api/auth/login
router.post('/auth/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const cleanEmail = email.trim().toLowerCase();
    const db = await getDb();
    const query = db.exec(`SELECT * FROM users WHERE email = '${cleanEmail}' LIMIT 1;`);
    const users = mapRows(query);

    if (users.length === 0) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const userRow = users[0];
    const passwordValid = bcrypt.compareSync(password, userRow.password_hash);
    if (!passwordValid) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    if (userRow.account_status === 'SUSPENDED') {
      res.status(403).json({ error: 'This account has been suspended. Please contact support.' });
      return;
    }

    const user = {
      id: userRow.id,
      name: userRow.name,
      email: userRow.email,
      phone: userRow.phone,
      role: userRow.role,
      capabilities: JSON.parse(userRow.capabilities || '[]'),
      is_verified: Boolean(userRow.is_verified),
      verification_status: userRow.verification_status || (userRow.is_verified ? 'VERIFIED' : 'UNVERIFIED'),
      account_status: userRow.account_status || 'ACTIVE',
      avatar_url: userRow.avatar_url,
      created_at: userRow.created_at
    };

    if (user.role === 'admin') {
      logAudit(db, user.id, user.name, 'Admin login', 'user', user.id, 'Super Admin logged in to platform');
    }

    const token = generateToken(user);
    res.json({ token, user });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error during login.' });
  }
});

// GET /api/auth/me
router.get('/auth/me', authMiddleware, async (req: AuthRequest, res: Response) => {
  res.json({ user: req.user });
});

// PUT /api/auth/profile
router.put('/auth/profile', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { name, phone, role } = req.body;
    const db = await getDb();
    const now = new Date().toISOString();
    const userId = req.user!.id;

    let updateFields: string[] = [`updated_at = '${now}'`];
    if (name) updateFields.push(`name = '${name.replace(/'/g, "''")}'`);
    if (phone) updateFields.push(`phone = '${phone.replace(/'/g, "''")}'`);
    if (role && ['buyer', 'tenant', 'owner', 'agent'].includes(role)) {
      updateFields.push(`role = '${role}'`);
      // Update capabilities if adding
      const currentCaps = req.user!.capabilities;
      if (!currentCaps.includes(role)) {
        currentCaps.push(role);
        updateFields.push(`capabilities = '${JSON.stringify(currentCaps)}'`);
      }
    }

    db.run(`UPDATE users SET ${updateFields.join(', ')} WHERE id = '${userId}';`);
    saveDb();

    // Refetch updated user
    const query = db.exec(`SELECT * FROM users WHERE id = '${userId}' LIMIT 1;`);
    const updated = mapRows(query)[0];

    res.json({
      user: {
        id: updated.id,
        name: updated.name,
        email: updated.email,
        phone: updated.phone,
        role: updated.role,
        capabilities: JSON.parse(updated.capabilities || '[]'),
        is_verified: Boolean(updated.is_verified),
        avatar_url: updated.avatar_url
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating profile.' });
  }
});

// POST /api/auth/forgot-password
router.post('/auth/forgot-password', async (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) {
    res.status(400).json({ error: 'Please enter your registered email address.' });
    return;
  }
  // In a production server, dispatch real email verification link with time-bound JWT token
  res.json({ message: `Password reset verification email has been dispatched to ${email}. Check your inbox.` });
});

// --------------------------------------------------------------------------
// 2. IMAGE UPLOAD ENDPOINT
// --------------------------------------------------------------------------

router.post('/upload', authMiddleware, upload.single('image'), (req: AuthRequest, res: Response) => {
  if (!req.file) {
    res.status(400).json({ error: 'No image file uploaded.' });
    return;
  }
  const fileUrl = `/uploads/${req.file.filename}`;
  res.json({ url: fileUrl, filename: req.file.filename });
});

// --------------------------------------------------------------------------
// 3. PUBLIC PROPERTY SEARCH & DETAILS
// --------------------------------------------------------------------------

// GET /api/properties (Only APPROVED properties appear publicly; with pagination & filters)
router.get('/properties', optionalAuthMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const {
      category,
      transactionType,
      location,
      propertyType,
      bhk,
      minPrice,
      maxPrice,
      minCarpetArea,
      maxCarpetArea,
      furnishing,
      hasParking,
      verifiedOnly,
      searchQuery,
      sortBy = 'newest',
      page = '1',
      limit = '12'
    } = req.query as Record<string, string>;

    let conditions: string[] = ["p.status = 'APPROVED'"];

    if (category && category !== 'all') {
      conditions.push(`p.category = '${category.toLowerCase()}'`);
    }

    if (transactionType && transactionType !== 'all') {
      conditions.push(`p.transaction_type = '${transactionType.toLowerCase()}'`);
    }

    if (location && location.trim()) {
      const locClean = location.trim().toLowerCase().replace(/'/g, "''");
      conditions.push(`(LOWER(p.locality) LIKE '%${locClean}%' OR LOWER(p.address) LIKE '%${locClean}%')`);
    }

    if (propertyType && propertyType.trim()) {
      conditions.push(`p.property_type = '${propertyType.trim().replace(/'/g, "''")}'`);
    }

    if (bhk && bhk.trim()) {
      conditions.push(`p.property_type = '${bhk.trim().replace(/'/g, "''")}'`);
    }

    if (minPrice) {
      conditions.push(`p.price >= ${Number(minPrice)}`);
    }
    if (maxPrice) {
      conditions.push(`p.price <= ${Number(maxPrice)}`);
    }

    if (minCarpetArea) {
      conditions.push(`p.carpet_area >= ${Number(minCarpetArea)}`);
    }
    if (maxCarpetArea) {
      conditions.push(`p.carpet_area <= ${Number(maxCarpetArea)}`);
    }

    if (furnishing && furnishing.trim()) {
      conditions.push(`p.furnishing = '${furnishing.trim()}'`);
    }

    if (verifiedOnly === 'true') {
      conditions.push(`p.verification_status = 'VERIFIED'`);
    }

    if (searchQuery && searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase().replace(/'/g, "''");
      conditions.push(`(LOWER(p.title) LIKE '%${q}%' OR LOWER(p.description) LIKE '%${q}%' OR LOWER(p.locality) LIKE '%${q}%')`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    let orderClause = 'ORDER BY p.created_at DESC';
    if (sortBy === 'price_asc') orderClause = 'ORDER BY p.price ASC';
    if (sortBy === 'price_desc') orderClause = 'ORDER BY p.price DESC';
    if (sortBy === 'area_desc') orderClause = 'ORDER BY p.carpet_area DESC';

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.min(50, Math.max(1, parseInt(limit, 10) || 12));
    const offset = (pageNum - 1) * limitNum;

    // Count query
    const countQuery = db.exec(`SELECT COUNT(*) as total FROM properties p ${whereClause};`);
    const total = countQuery[0]?.values[0]?.[0] || 0;

    // Fetch properties
    const propsQuery = db.exec(`
      SELECT p.*, u.name as owner_name, u.phone as owner_phone
      FROM properties p
      LEFT JOIN users u ON p.owner_id = u.id
      ${whereClause}
      ${orderClause}
      LIMIT ${limitNum} OFFSET ${offset};
    `);

    const propertyRows = mapRows(propsQuery);

    // Populate images and amenities for each property
    const fullProperties = propertyRows.map((prop) => {
      const imgQuery = db.exec(`
        SELECT id, image_url as url, caption, is_primary as isPrimary, display_order
        FROM property_images
        WHERE property_id = '${prop.id}'
        ORDER BY display_order ASC, is_primary DESC;
      `);
      const images = mapRows(imgQuery);

      const amenQuery = db.exec(`
        SELECT amenity_name FROM property_amenities WHERE property_id = '${prop.id}';
      `);
      const amenities = mapRows(amenQuery).map((a) => a.amenity_name);

      // Mask owner contact for public privacy
      const initials = (prop.owner_name || 'Property Owner')
        .split(' ')
        .map((n: string) => n[0])
        .join('. ') + '.';
      const phoneClean = (prop.owner_phone || '9820000000').replace(/\D/g, '');
      const lastDigits = phoneClean.slice(-2);

      return {
        ...prop,
        isVerified: prop.verification_status === 'VERIFIED',
        images: images.length > 0 ? images : [
          { id: 'def', url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg', isPrimary: true, caption: prop.title }
        ],
        amenities,
        maskedContact: {
          nameInitials: initials,
          verifiedPhoneEnding: lastDigits
        },
        location: {
          buildingName: prop.address || prop.title,
          area: prop.locality,
          locality: prop.locality,
          city: prop.city,
          pincode: prop.pincode,
          coordinates: { lat: prop.latitude || 19.076, lng: prop.longitude || 72.877 }
        },
        pricing: {
          price: prop.price,
          priceDisplayType: prop.transaction_type === 'rent' || prop.transaction_type === 'lease' ? 'per_month' : 'total',
          maintenanceAmount: prop.maintenance,
          securityDeposit: prop.security_deposit,
          isNegotiable: true
        },
        residentialDetails: prop.category === 'residential' ? {
          bhk: prop.property_type,
          bedrooms: prop.bedrooms || 2,
          bathrooms: prop.bathrooms || 2,
          carpetArea: prop.carpet_area,
          builtUpArea: prop.built_up_area || Math.round(prop.carpet_area * 1.3),
          floor: prop.floor || 1,
          totalFloors: prop.total_floors || 10,
          furnishing: prop.furnishing || 'semi-furnished',
          parking: { covered: 1, open: 0 }
        } : undefined,
        commercialDetails: prop.category === 'commercial' ? {
          commercialType: prop.property_type,
          carpetArea: prop.carpet_area,
          builtUpArea: prop.built_up_area || Math.round(prop.carpet_area * 1.3),
          floor: prop.floor || 0,
          totalFloors: prop.total_floors || 10,
          furnishing: prop.furnishing || 'unfurnished',
          parking: { covered: 2, open: 1 },
          washrooms: prop.washrooms || 2,
          powerBackup: Boolean(prop.power_backup),
          loadingUnloadingAvailability: Boolean(prop.loading_unloading),
          suitableBusinessType: (prop.business_type || 'Office, Retail').split(', ')
        } : undefined
      };
    });

    res.json({
      properties: fullProperties,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(Number(total) / limitNum)
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching properties.' });
  }
});

// GET /api/properties/:id
router.get('/properties/:id', optionalAuthMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    const query = db.exec(`
      SELECT p.*, u.name as owner_name, u.phone as owner_phone
      FROM properties p
      LEFT JOIN users u ON p.owner_id = u.id
      WHERE p.id = '${id}'
      LIMIT 1;
    `);

    const rows = mapRows(query);
    if (rows.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }

    const prop = rows[0];

    // If unapproved, only allow owner or admin to view
    if (prop.status !== 'APPROVED') {
      const isOwner = req.user && req.user.id === prop.owner_id;
      const isAdmin = req.user && req.user.role === 'admin';
      if (!isOwner && !isAdmin) {
        res.status(403).json({ error: 'This property is pending approval and not publicly accessible yet.' });
        return;
      }
    }

    // Images
    const imgQuery = db.exec(`
      SELECT id, image_url as url, caption, is_primary as isPrimary, display_order
      FROM property_images
      WHERE property_id = '${prop.id}'
      ORDER BY display_order ASC, is_primary DESC;
    `);
    const images = mapRows(imgQuery);

    // Amenities
    const amenQuery = db.exec(`
      SELECT amenity_name FROM property_amenities WHERE property_id = '${prop.id}';
    `);
    const amenities = mapRows(amenQuery).map((a) => a.amenity_name);

    // Mask owner contact for public safety
    const initials = (prop.owner_name || 'Property Owner')
      .split(' ')
      .map((n: string) => n[0])
      .join('. ') + '.';
    const phoneClean = (prop.owner_phone || '9820000000').replace(/\D/g, '');
    const lastDigits = phoneClean.slice(-2);

    const fullProperty = {
      ...prop,
      isVerified: prop.verification_status === 'VERIFIED',
      images: images.length > 0 ? images : [
        { id: 'def', url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg', isPrimary: true, caption: prop.title }
      ],
      amenities,
      maskedContact: {
        nameInitials: initials,
        verifiedPhoneEnding: lastDigits
      },
      location: {
        buildingName: prop.address || prop.title,
        area: prop.locality,
        locality: prop.locality,
        city: prop.city,
        pincode: prop.pincode,
        coordinates: { lat: prop.latitude || 19.076, lng: prop.longitude || 72.877 }
      },
      pricing: {
        price: prop.price,
        priceDisplayType: prop.transaction_type === 'rent' || prop.transaction_type === 'lease' ? 'per_month' : 'total',
        maintenanceAmount: prop.maintenance,
        securityDeposit: prop.security_deposit,
        isNegotiable: true
      },
      residentialDetails: prop.category === 'residential' ? {
        bhk: prop.property_type,
        bedrooms: prop.bedrooms || 2,
        bathrooms: prop.bathrooms || 2,
        carpetArea: prop.carpet_area,
        builtUpArea: prop.built_up_area || Math.round(prop.carpet_area * 1.3),
        floor: prop.floor || 1,
        totalFloors: prop.total_floors || 10,
        furnishing: prop.furnishing || 'semi-furnished',
        parking: { covered: 1, open: 0 }
      } : undefined,
      commercialDetails: prop.category === 'commercial' ? {
        commercialType: prop.property_type,
        carpetArea: prop.carpet_area,
        builtUpArea: prop.built_up_area || Math.round(prop.carpet_area * 1.3),
        floor: prop.floor || 0,
        totalFloors: prop.total_floors || 10,
        furnishing: prop.furnishing || 'unfurnished',
        parking: { covered: 2, open: 1 },
        washrooms: prop.washrooms || 2,
        powerBackup: Boolean(prop.power_backup),
        loadingUnloadingAvailability: Boolean(prop.loading_unloading),
        suitableBusinessType: (prop.business_type || 'Office, Retail').split(', ')
      } : undefined,
      nearbyPlaces: [
        { name: `${prop.locality} Station Connector`, type: 'railway', distanceKm: 1.5 },
        { name: 'Western Express Highway', type: 'highway', distanceKm: 2.1 }
      ]
    };

    res.json({ property: fullProperty });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching property details.' });
  }
});

// --------------------------------------------------------------------------
// 4. PROPERTY CREATION & MANAGEMENT (OWNER/AGENT)
// --------------------------------------------------------------------------

// POST /api/properties (Save as DRAFT or submit for approval PENDING_APPROVAL)
router.post('/properties', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const ownerId = req.user!.id; // derived from authenticated session!
    const {
      title,
      description,
      category,
      transaction_type,
      property_type,
      price,
      rent,
      security_deposit,
      maintenance,
      carpet_area,
      built_up_area,
      bedrooms,
      bathrooms,
      floor,
      total_floors,
      furnishing,
      parking,
      address,
      locality,
      city = 'Mumbai',
      pincode,
      latitude,
      longitude,
      status = 'PENDING_APPROVAL', // default: submits to approval or DRAFT
      washrooms,
      power_backup,
      loading_unloading,
      business_type,
      frontage,
      ceiling_height,
      commercial_use_type,
      images = [],
      amenities = []
    } = req.body;

    // Validations
    if (!title || !description || !category || !transaction_type || !property_type || !locality || !pincode) {
      res.status(400).json({ error: 'Missing required property details.' });
      return;
    }

    if (!price || Number(price) <= 0) {
      res.status(400).json({ error: 'Valid price or rent amount is required.' });
      return;
    }

    if (!carpet_area || Number(carpet_area) <= 0) {
      res.status(400).json({ error: 'Carpet area must be greater than 0 sq.ft.' });
      return;
    }

    const propId = `prop-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const cleanStatus = status === 'DRAFT' ? 'DRAFT' : 'PENDING_APPROVAL';

    // Insert into properties table
    db.run(`
      INSERT INTO properties (
        id, owner_id, category, transaction_type, property_type, title, description,
        price, rent, security_deposit, maintenance, carpet_area, built_up_area,
        bedrooms, bathrooms, floor, total_floors, furnishing, parking,
        address, locality, city, pincode, latitude, longitude,
        status, verification_status, is_sample,
        washrooms, power_backup, loading_unloading, business_type, frontage, ceiling_height, commercial_use_type,
        created_at, updated_at
      ) VALUES (
        '${propId}', '${ownerId}', '${category.toLowerCase()}', '${transaction_type.toLowerCase()}', '${property_type.replace(/'/g, "''")}',
        '${title.replace(/'/g, "''")}', '${description.replace(/'/g, "''")}',
        ${Number(price)}, ${rent ? Number(rent) : 'NULL'}, ${security_deposit ? Number(security_deposit) : 'NULL'}, ${maintenance ? Number(maintenance) : 'NULL'},
        ${Number(carpet_area)}, ${built_up_area ? Number(built_up_area) : 'NULL'},
        ${bedrooms ? Number(bedrooms) : 'NULL'}, ${bathrooms ? Number(bathrooms) : 'NULL'},
        ${floor !== undefined ? Number(floor) : 'NULL'}, ${total_floors ? Number(total_floors) : 'NULL'},
        '${(furnishing || 'semi-furnished').replace(/'/g, "''")}', '${(parking || '').replace(/'/g, "''")}',
        '${(address || locality).replace(/'/g, "''")}', '${locality.replace(/'/g, "''")}', '${city.replace(/'/g, "''")}', '${pincode.replace(/'/g, "''")}',
        ${latitude ? Number(latitude) : 19.076}, ${longitude ? Number(longitude) : 72.877},
        '${cleanStatus}', 'UNVERIFIED', 0,
        ${washrooms ? Number(washrooms) : 'NULL'}, ${power_backup ? 1 : 0}, ${loading_unloading ? 1 : 0},
        '${(business_type || '').replace(/'/g, "''")}', ${frontage ? Number(frontage) : 'NULL'}, ${ceiling_height ? Number(ceiling_height) : 'NULL'},
        '${(commercial_use_type || '').replace(/'/g, "''")}',
        '${now}', '${now}'
      );
    `);

    // Insert Images
    if (Array.isArray(images)) {
      images.forEach((img: any, idx: number) => {
        const imgId = `img-${propId}-${idx}`;
        const imgUrl = img.url || img;
        const caption = img.caption || 'Property Photograph';
        const isPrimary = idx === 0 || img.isPrimary ? 1 : 0;
        db.run(`
          INSERT INTO property_images (id, property_id, image_url, display_order, caption, is_primary, created_at)
          VALUES ('${imgId}', '${propId}', '${imgUrl.replace(/'/g, "''")}', ${idx}, '${caption.replace(/'/g, "''")}', ${isPrimary}, '${now}');
        `);
      });
    }

    // Insert Amenities
    if (Array.isArray(amenities)) {
      amenities.forEach((am: string, idx: number) => {
        const amId = `am-${propId}-${idx}`;
        db.run(`
          INSERT INTO property_amenities (id, property_id, amenity_name, created_at)
          VALUES ('${amId}', '${propId}', '${am.replace(/'/g, "''")}', '${now}');
        `);
      });
    }

    saveDb();

    res.status(201).json({
      message: cleanStatus === 'DRAFT' ? 'Listing saved as draft.' : 'Listing submitted for review.',
      propertyId: propId,
      status: cleanStatus
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error saving property listing.' });
  }
});

// PUT /api/properties/:id (Update listing - only by owner or admin)
router.put('/properties/:id', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    // Verify ownership
    const propQuery = db.exec(`SELECT * FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propQuery);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }

    const currentProp = props[0];
    const isOwner = req.user!.id === currentProp.owner_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You can only edit your own properties.' });
      return;
    }

    const {
      title,
      description,
      price,
      rent,
      security_deposit,
      maintenance,
      carpet_area,
      built_up_area,
      furnishing,
      parking,
      status,
      images,
      amenities
    } = req.body;

    const now = new Date().toISOString();
    let updates: string[] = [`updated_at = '${now}'`];

    if (title) updates.push(`title = '${title.replace(/'/g, "''")}'`);
    if (description) updates.push(`description = '${description.replace(/'/g, "''")}'`);
    if (price) updates.push(`price = ${Number(price)}`);
    if (rent !== undefined) updates.push(`rent = ${rent ? Number(rent) : 'NULL'}`);
    if (security_deposit !== undefined) updates.push(`security_deposit = ${security_deposit ? Number(security_deposit) : 'NULL'}`);
    if (maintenance !== undefined) updates.push(`maintenance = ${maintenance ? Number(maintenance) : 'NULL'}`);
    if (carpet_area) updates.push(`carpet_area = ${Number(carpet_area)}`);
    if (built_up_area) updates.push(`built_up_area = ${Number(built_up_area)}`);
    if (furnishing) updates.push(`furnishing = '${furnishing.replace(/'/g, "''")}'`);
    if (parking) updates.push(`parking = '${parking.replace(/'/g, "''")}'`);

    // Status transition: if draft submitting for approval
    if (status && ['DRAFT', 'PENDING_APPROVAL', 'SOLD', 'RENTED', 'LEASED', 'INACTIVE'].includes(status)) {
      updates.push(`status = '${status}'`);
    }

    db.run(`UPDATE properties SET ${updates.join(', ')} WHERE id = '${id}';`);

    // Update images if provided
    if (Array.isArray(images)) {
      db.run(`DELETE FROM property_images WHERE property_id = '${id}';`);
      images.forEach((img: any, idx: number) => {
        const imgId = `img-${id}-${idx}-${Date.now()}`;
        const imgUrl = img.url || img;
        const caption = img.caption || 'Property Photograph';
        const isPrimary = idx === 0 || img.isPrimary ? 1 : 0;
        db.run(`
          INSERT INTO property_images (id, property_id, image_url, display_order, caption, is_primary, created_at)
          VALUES ('${imgId}', '${id}', '${imgUrl.replace(/'/g, "''")}', ${idx}, '${caption.replace(/'/g, "''")}', ${isPrimary}, '${now}');
        `);
      });
    }

    // Update amenities if provided
    if (Array.isArray(amenities)) {
      db.run(`DELETE FROM property_amenities WHERE property_id = '${id}';`);
      amenities.forEach((am: string, idx: number) => {
        const amId = `am-${id}-${idx}`;
        db.run(`
          INSERT INTO property_amenities (id, property_id, amenity_name, created_at)
          VALUES ('${amId}', '${id}', '${am.replace(/'/g, "''")}', '${now}');
        `);
      });
    }

    saveDb();
    res.json({ message: 'Property updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating property.' });
  }
});

// DELETE /api/properties/:id (Only by owner or admin)
router.delete('/properties/:id', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    const propQuery = db.exec(`SELECT * FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propQuery);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }

    const currentProp = props[0];
    const isOwner = req.user!.id === currentProp.owner_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You can only delete your own properties.' });
      return;
    }

    db.run(`DELETE FROM property_images WHERE property_id = '${id}';`);
    db.run(`DELETE FROM property_amenities WHERE property_id = '${id}';`);
    db.run(`DELETE FROM saved_properties WHERE property_id = '${id}';`);
    db.run(`DELETE FROM properties WHERE id = '${id}';`);

    saveDb();
    res.json({ message: 'Property deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error deleting property.' });
  }
});

// PATCH /api/properties/:id/status (Mark availability or submit for approval)
router.patch('/properties/:id/status', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['DRAFT', 'PENDING_APPROVAL', 'SOLD', 'RENTED', 'LEASED', 'INACTIVE'];

    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid property status.' });
      return;
    }

    const db = await getDb();
    const propQuery = db.exec(`SELECT * FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propQuery);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }

    const currentProp = props[0];
    const isOwner = req.user!.id === currentProp.owner_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot change status for this property.' });
      return;
    }

    const now = new Date().toISOString();
    db.run(`UPDATE properties SET status = '${status}', updated_at = '${now}' WHERE id = '${id}';`);
    saveDb();

    res.json({ message: `Status updated to ${status}.`, status });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating status.' });
  }
});

// --------------------------------------------------------------------------
// 5. DASHBOARD ROUTES (OWNER / AGENT)
// --------------------------------------------------------------------------

// GET /api/dashboard/my-properties
router.get('/dashboard/my-properties', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const userId = req.user!.id;

    const query = db.exec(`
      SELECT p.*
      FROM properties p
      WHERE p.owner_id = '${userId}'
      ORDER BY p.created_at DESC;
    `);

    const props = mapRows(query).map((prop) => {
      const imgQuery = db.exec(`
        SELECT image_url as url, is_primary as isPrimary
        FROM property_images
        WHERE property_id = '${prop.id}'
        ORDER BY is_primary DESC, display_order ASC
        LIMIT 1;
      `);
      const img = mapRows(imgQuery)[0];

      return {
        ...prop,
        primaryImage: img ? img.url : '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg'
      };
    });

    res.json({ properties: props });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching user properties.' });
  }
});

// GET /api/dashboard/inquiries
router.get('/dashboard/inquiries', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const userId = req.user!.id;

    // Enquiries received by owner for their properties
    const receivedQuery = db.exec(`
      SELECT i.*, p.title as property_title, p.locality, p.price
      FROM property_inquiries i
      JOIN properties p ON i.property_id = p.id
      WHERE p.owner_id = '${userId}'
      ORDER BY i.created_at DESC;
    `);
    const received = mapRows(receivedQuery);

    // Enquiries sent by user as buyer
    const sentQuery = db.exec(`
      SELECT i.*, p.title as property_title, p.locality, p.price
      FROM property_inquiries i
      JOIN properties p ON i.property_id = p.id
      WHERE i.buyer_user_id = '${userId}'
      ORDER BY i.created_at DESC;
    `);
    const sent = mapRows(sentQuery);

    res.json({ received, sent });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching inquiries.' });
  }
});

// GET /api/dashboard/site-visits
router.get('/dashboard/site-visits', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const userId = req.user!.id;

    // Site visits requested for properties owned by user
    const receivedQuery = db.exec(`
      SELECT v.*, p.title as property_title, p.locality
      FROM site_visits v
      JOIN properties p ON v.property_id = p.id
      WHERE p.owner_id = '${userId}'
      ORDER BY v.preferred_date ASC, v.created_at DESC;
    `);
    const received = mapRows(receivedQuery);

    // Site visits requested by user
    const sentQuery = db.exec(`
      SELECT v.*, p.title as property_title, p.locality
      FROM site_visits v
      JOIN properties p ON v.property_id = p.id
      WHERE v.visitor_user_id = '${userId}'
      ORDER BY v.preferred_date ASC;
    `);
    const sent = mapRows(sentQuery);

    res.json({ received, sent });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching site visits.' });
  }
});

// --------------------------------------------------------------------------
// 6. ENQUIRIES & SITE VISITS CREATION
// --------------------------------------------------------------------------

// POST /api/properties/:id/inquiries
router.post('/properties/:id/inquiries', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const {
      message,
      preferred_contact_time,
      name,
      mobile,
      email,
      preferred_contact_method,
      budget,
      bhk,
      preferred_locations,
      business_type,
      required_carpet_area,
      furnishing_preference,
      parking_requirement
    } = req.body;
    const buyerUserId = req.user!.id; // derived from authenticated session

    if (!message || message.trim().length < 5) {
      res.status(400).json({ error: 'Please enter a message for the property owner.' });
      return;
    }

    const db = await getDb();
    
    // Check if property exists
    const propQuery = db.exec(`SELECT * FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propQuery);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property listing not found.' });
      return;
    }
    const prop = props[0];

    const customerName = (name || req.user!.name).trim();
    const customerPhone = (mobile || req.user!.phone).trim();
    const customerEmail = (email || req.user!.email).trim();
    const now = new Date().toISOString();

    // 1. Find or create Customer Profile
    let customerId = '';
    const custSearch = db.exec(`
      SELECT * FROM customer_profiles 
      WHERE email = '${customerEmail.replace(/'/g, "''")}' 
         OR mobile = '${customerPhone.replace(/'/g, "''")}'
         OR user_id = '${buyerUserId}'
      LIMIT 1;
    `);
    const existingCust = mapRows(custSearch);

    if (existingCust.length > 0) {
      customerId = existingCust[0].id;
      // Enrich customer profile if empty
      const isTenant = prop.transaction_type === 'rent' || prop.transaction_type === 'lease';
      db.run(`
        UPDATE customer_profiles 
        SET updated_at = '${now}',
            customer_type = '${isTenant ? 'TENANT' : 'BUYER'}',
            user_id = '${buyerUserId}'
        WHERE id = '${customerId}';
      `);
    } else {
      customerId = `cust-${Date.now()}-${Math.round(Math.random() * 1000)}`;
      const isTenant = prop.transaction_type === 'rent' || prop.transaction_type === 'lease';
      const cleanLocations = (preferred_locations || prop.locality || 'Mumbai').replace(/'/g, "''");
      const cleanBusinessType = (business_type || prop.business_type || '').replace(/'/g, "''");
      const cleanBhk = (bhk || (prop.bedrooms ? `${prop.bedrooms} BHK` : '')).replace(/'/g, "''");

      db.run(`
        INSERT INTO customer_profiles (
          id, name, mobile, email, user_id, customer_type, preferred_transaction, preferred_category,
          preferred_locations, budget_min, budget_max, preferred_property_types, bhk,
          carpet_area_min, carpet_area_max, furnishing_preference, parking_requirement, business_type,
          notes, created_at, updated_at
        ) VALUES (
          '${customerId}', '${customerName.replace(/'/g, "''")}', '${customerPhone.replace(/'/g, "''")}',
          '${customerEmail.replace(/'/g, "''")}', '${buyerUserId}', '${isTenant ? 'TENANT' : 'BUYER'}',
          '${prop.transaction_type}', '${prop.category}', '${cleanLocations}',
          ${budget ? Number(budget) * 0.8 : 'NULL'}, ${budget ? Number(budget) : (prop.price || 'NULL')},
          '${(prop.property_type || '').replace(/'/g, "''")}', '${cleanBhk}',
          ${required_carpet_area ? Number(required_carpet_area) : (prop.carpet_area || 'NULL')},
          ${required_carpet_area ? Number(required_carpet_area) * 1.3 : 'NULL'},
          '${(furnishing_preference || '').replace(/'/g, "''")}',
          '${(parking_requirement || '').replace(/'/g, "''")}',
          '${cleanBusinessType}', 'Auto-created from property enquiry',
          '${now}', '${now}'
        );
      `);
    }

    // 2. Prevent Duplicate Leads (Within 48 hours for same property & customer)
    const existingLeadQuery = db.exec(`
      SELECT * FROM leads 
      WHERE property_id = '${id}' AND customer_id = '${customerId}'
      ORDER BY created_at DESC 
      LIMIT 1;
    `);
    const existingLeads = mapRows(existingLeadQuery);

    let activeLeadId = '';
    let isDuplicate = false;

    if (existingLeads.length > 0) {
      const exLead = existingLeads[0];
      const exLeadTime = new Date(exLead.created_at).getTime();
      const diffHours = (Date.now() - exLeadTime) / (1000 * 60 * 60);

      // If lead was created within last 48 hours and is still active (not CLOSED/LOST)
      if (diffHours < 48 && exLead.status !== 'LOST' && exLead.status !== 'CLOSED') {
        isDuplicate = true;
        activeLeadId = exLead.id;

        // Append to internal notes / customer message and log timeline activity
        const appendNote = `\\n[${new Date().toLocaleDateString('en-IN')}] Repeat Inquiry: ${message.replace(/'/g, "''")}`;
        db.run(`
          UPDATE leads 
          SET internal_notes = COALESCE(internal_notes, '') || '${appendNote}',
              updated_at = '${now}'
          WHERE id = '${activeLeadId}';
        `);

        logLeadActivity(
          db,
          activeLeadId,
          buyerUserId,
          customerName,
          'buyer',
          'ENQUIRY_UPDATED',
          `Customer submitted repeat message: "${message.replace(/'/g, "''")}"`
        );
      }
    }

    if (!isDuplicate) {
      // 3. Create fresh Lead in database
      activeLeadId = `lead-${Date.now()}-${Math.round(Math.random() * 1000)}`;
      const cleanContactMethod = (preferred_contact_method || 'PHONE').replace(/'/g, "''");
      const leadBudget = budget ? Number(budget) : (prop.price || null);
      const leadCarpet = required_carpet_area ? Number(required_carpet_area) : (prop.carpet_area || null);
      const cleanBusinessType = (business_type || prop.business_type || '').replace(/'/g, "''");
      const cleanBhk = (bhk || (prop.bedrooms ? `${prop.bedrooms} BHK` : '')).replace(/'/g, "''");

      db.run(`
        INSERT INTO leads (
          id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
          customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
          business_type, required_carpet_area, bhk, furnishing_preference, parking_requirement,
          created_at, updated_at
        ) VALUES (
          '${activeLeadId}', '${id}', '${customerId}', '${prop.owner_id}', NULL,
          'PROPERTY_ENQUIRY', 'NEW', 'HIGH',
          '${message.replace(/'/g, "''")}', 'Direct inquiry submitted from website listing.',
          '${cleanContactMethod}', ${leadBudget ? leadBudget : 'NULL'}, '${prop.category}',
          '${cleanBusinessType}', ${leadCarpet ? leadCarpet : 'NULL'}, '${cleanBhk}',
          '${(furnishing_preference || '').replace(/'/g, "''")}',
          '${(parking_requirement || '').replace(/'/g, "''")}',
          '${now}', '${now}'
        );
      `);

      // 4. Log Activity Timeline
      logLeadActivity(
        db,
        activeLeadId,
        buyerUserId,
        customerName,
        'buyer',
        'LEAD_CREATED',
        `Lead created from property enquiry: "${message.slice(0, 100).replace(/'/g, "''")}"`
      );

      // 5. In-app audit log
      logAudit(
        db,
        buyerUserId,
        customerName,
        'LEAD_CREATED_FROM_ENQUIRY',
        'lead',
        activeLeadId,
        `New lead created for property ${prop.title} (Owner: ${prop.owner_id})`
      );
    }

    // Keep legacy inquiries table populated for backwards compatibility
    const inqId = `inq-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    db.run(`
      INSERT INTO property_inquiries (
        id, property_id, buyer_user_id, buyer_name, buyer_phone, buyer_email,
        message, preferred_contact_time, status, created_at, updated_at
      ) VALUES (
        '${inqId}', '${id}', '${buyerUserId}', '${customerName.replace(/'/g, "''")}',
        '${customerPhone.replace(/'/g, "''")}', '${customerEmail.replace(/'/g, "''")}',
        '${message.replace(/'/g, "''")}', '${(preferred_contact_time || 'Anytime').replace(/'/g, "''")}',
        'NEW', '${now}', '${now}'
      );
    `);

    saveDb();

    res.status(201).json({
      message: isDuplicate 
        ? 'Inquiry received and added to your active request with the owner.' 
        : 'Inquiry sent directly to owner.',
      inquiryId: inqId,
      leadId: activeLeadId,
      isDuplicate
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error sending inquiry.' });
  }
});

// PATCH /api/inquiries/:id/status
router.patch('/inquiries/:id/status', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['NEW', 'CONTACTED', 'SITE_VISIT', 'NEGOTIATING', 'CLOSED', 'CANCELLED'];

    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid inquiry status.' });
      return;
    }

    const db = await getDb();
    const query = db.exec(`
      SELECT i.*, p.owner_id
      FROM property_inquiries i
      JOIN properties p ON i.property_id = p.id
      WHERE i.id = '${id}'
      LIMIT 1;
    `);
    const inqs = mapRows(query);
    if (inqs.length === 0) {
      res.status(404).json({ error: 'Inquiry not found.' });
      return;
    }

    const inq = inqs[0];
    const isOwner = req.user!.id === inq.owner_id;
    const isAdmin = req.user!.role === 'admin';
    if (!isOwner && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot update this inquiry.' });
      return;
    }

    const now = new Date().toISOString();
    db.run(`UPDATE property_inquiries SET status = '${status}', updated_at = '${now}' WHERE id = '${id}';`);
    saveDb();

    res.json({ message: 'Inquiry status updated.', status });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating inquiry.' });
  }
});

// POST /api/properties/:id/site-visits
router.post('/properties/:id/site-visits', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { preferred_date, preferred_time, message } = req.body;
    const visitorUserId = req.user!.id;

    if (!preferred_date || !preferred_time) {
      res.status(400).json({ error: 'Please choose preferred date and time slot.' });
      return;
    }

    const db = await getDb();
    const propQuery = db.exec(`SELECT * FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propQuery);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }
    const prop = props[0];

    const visitId = `visit-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    // Check or create customer
    const custSearch = db.exec(`
      SELECT * FROM customer_profiles 
      WHERE user_id = '${visitorUserId}' OR email = '${req.user!.email}'
      LIMIT 1;
    `);
    let custId = '';
    const existingCust = mapRows(custSearch);
    if (existingCust.length > 0) {
      custId = existingCust[0].id;
    } else {
      custId = `cust-${Date.now()}-${Math.round(Math.random() * 1000)}`;
      db.run(`
        INSERT INTO customer_profiles (
          id, name, mobile, email, user_id, customer_type, preferred_transaction, preferred_category,
          created_at, updated_at
        ) VALUES (
          '${custId}', '${req.user!.name.replace(/'/g, "''")}', '${req.user!.phone.replace(/'/g, "''")}',
          '${req.user!.email.replace(/'/g, "''")}', '${visitorUserId}',
          '${prop.transaction_type === 'rent' || prop.transaction_type === 'lease' ? 'TENANT' : 'BUYER'}',
          '${prop.transaction_type}', '${prop.category}', '${now}', '${now}'
        );
      `);
    }

    // Connect to lead
    let leadId = '';
    const leadQuery = db.exec(`
      SELECT * FROM leads 
      WHERE property_id = '${id}' AND customer_id = '${custId}'
      ORDER BY created_at DESC LIMIT 1;
    `);
    const existingLeads = mapRows(leadQuery);

    if (existingLeads.length > 0) {
      leadId = existingLeads[0].id;
      // Update lead status to SITE_VISIT if earlier stage
      if (['NEW', 'CONTACTED', 'QUALIFIED'].includes(existingLeads[0].status)) {
        db.run(`UPDATE leads SET status = 'SITE_VISIT', updated_at = '${now}' WHERE id = '${leadId}';`);
        logLeadActivity(db, leadId, visitorUserId, req.user!.name, 'buyer', 'STATUS_CHANGED', 'Status progressed to SITE_VISIT');
      }
    } else {
      // Create new lead for site visit
      leadId = `lead-${Date.now()}-${Math.round(Math.random() * 1000)}`;
      db.run(`
        INSERT INTO leads (
          id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
          customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
          created_at, updated_at
        ) VALUES (
          '${leadId}', '${id}', '${custId}', '${prop.owner_id}', NULL,
          'PROPERTY_ENQUIRY', 'SITE_VISIT', 'URGENT',
          'Site visit requested for ${preferred_date} at ${preferred_time}',
          'Generated from site visit request.', 'PHONE', ${prop.price || 'NULL'}, '${prop.category}',
          '${now}', '${now}'
        );
      `);
      logLeadActivity(db, leadId, visitorUserId, req.user!.name, 'buyer', 'LEAD_CREATED', 'Lead created from site visit appointment');
    }

    // Insert site visit with lead_id, owner_id, customer_id
    db.run(`
      INSERT INTO site_visits (
        id, property_id, visitor_user_id, visitor_name, visitor_phone, visitor_email,
        preferred_date, preferred_time, message, status, lead_id, owner_id, customer_id, created_at, updated_at
      ) VALUES (
        '${visitId}', '${id}', '${visitorUserId}', '${req.user!.name.replace(/'/g, "''")}',
        '${req.user!.phone.replace(/'/g, "''")}', '${req.user!.email.replace(/'/g, "''")}',
        '${preferred_date.replace(/'/g, "''")}', '${preferred_time.replace(/'/g, "''")}',
        '${(message || '').replace(/'/g, "''")}', 'REQUESTED', '${leadId}', '${prop.owner_id}', '${custId}', '${now}', '${now}'
      );
    `);

    // Log timeline activity
    logLeadActivity(
      db,
      leadId,
      visitorUserId,
      req.user!.name,
      'buyer',
      'SITE_VISIT_REQUESTED',
      `Site visit requested for ${preferred_date} at ${preferred_time}. Message: ${message || 'No additional note'}`
    );

    saveDb();

    res.status(201).json({ message: 'Site visit booked.', visitId, leadId });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error requesting site visit.' });
  }
});

// PATCH /api/site-visits/:id/status
router.patch('/site-visits/:id/status', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['REQUESTED', 'CONFIRMED', 'COMPLETED', 'CANCELLED'];

    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid visit status.' });
      return;
    }

    const db = await getDb();
    const query = db.exec(`
      SELECT v.*, p.owner_id
      FROM site_visits v
      JOIN properties p ON v.property_id = p.id
      WHERE v.id = '${id}'
      LIMIT 1;
    `);
    const visits = mapRows(query);
    if (visits.length === 0) {
      res.status(404).json({ error: 'Site visit not found.' });
      return;
    }

    const visit = visits[0];
    const isOwner = req.user!.id === visit.owner_id;
    const isVisitor = req.user!.id === visit.visitor_user_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isVisitor && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot update this site visit.' });
      return;
    }

    const now = new Date().toISOString();
    db.run(`UPDATE site_visits SET status = '${status}', updated_at = '${now}' WHERE id = '${id}';`);

    // Add activity to lead timeline if site visit has linked lead
    if (visit.lead_id) {
      let actType = 'STATUS_CHANGED';
      let actDetails = `Site visit marked as ${status}`;
      if (status === 'CONFIRMED') {
        actType = 'SITE_VISIT_CONFIRMED';
        actDetails = `Site visit confirmed for ${visit.preferred_date} at ${visit.preferred_time}`;
      } else if (status === 'COMPLETED') {
        actType = 'SITE_VISIT_COMPLETED';
        actDetails = `Site visit successfully completed on ${visit.preferred_date}`;
      } else if (status === 'CANCELLED') {
        actDetails = `Site visit was cancelled by ${req.user!.name}`;
      }
      logLeadActivity(db, visit.lead_id, req.user!.id, req.user!.name, req.user!.role, actType, actDetails);
    }

    saveDb();

    res.json({ message: 'Site visit status updated.', status });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating visit status.' });
  }
});

// --------------------------------------------------------------------------
// 7. SAVED PROPERTIES
// --------------------------------------------------------------------------

// GET /api/saved-properties
router.get('/saved-properties', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const userId = req.user!.id;

    const query = db.exec(`
      SELECT p.*, s.created_at as saved_at
      FROM saved_properties s
      JOIN properties p ON s.property_id = p.id
      WHERE s.user_id = '${userId}'
      ORDER BY s.created_at DESC;
    `);

    const properties = mapRows(query).map((prop) => {
      const imgQuery = db.exec(`
        SELECT image_url as url, is_primary as isPrimary
        FROM property_images
        WHERE property_id = '${prop.id}'
        ORDER BY is_primary DESC, display_order ASC
        LIMIT 1;
      `);
      const img = mapRows(imgQuery)[0];

      return {
        ...prop,
        primaryImage: img ? img.url : '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg'
      };
    });

    res.json({ properties });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching saved properties.' });
  }
});

// POST /api/saved-properties/:propertyId
router.post('/saved-properties/:propertyId', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { propertyId } = req.params;
    const userId = req.user!.id;
    const db = await getDb();
    const id = `saved-${userId}-${propertyId}`;
    const now = new Date().toISOString();

    db.run(`
      INSERT OR IGNORE INTO saved_properties (id, user_id, property_id, created_at)
      VALUES ('${id}', '${userId}', '${propertyId}', '${now}');
    `);
    saveDb();

    res.json({ message: 'Property saved to your watchlist.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error saving property.' });
  }
});

// DELETE /api/saved-properties/:propertyId
router.delete('/saved-properties/:propertyId', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { propertyId } = req.params;
    const userId = req.user!.id;
    const db = await getDb();

    db.run(`DELETE FROM saved_properties WHERE user_id = '${userId}' AND property_id = '${propertyId}';`);
    saveDb();

    res.json({ message: 'Property removed from saved listings.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error removing saved property.' });
  }
});

// --------------------------------------------------------------------------
// 8. PRODUCTION ADMIN DASHBOARD & GOVERNANCE API
// --------------------------------------------------------------------------

// GET /api/admin/metrics (Real database counts)
router.get('/admin/metrics', authMiddleware, adminMiddleware, async (_req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();

    const totalUsers = db.exec("SELECT COUNT(*) FROM users;")[0]?.values[0]?.[0] || 0;
    const activeUsers = db.exec("SELECT COUNT(*) FROM users WHERE account_status = 'ACTIVE' OR account_status IS NULL;")[0]?.values[0]?.[0] || 0;
    const suspendedUsers = db.exec("SELECT COUNT(*) FROM users WHERE account_status = 'SUSPENDED';")[0]?.values[0]?.[0] || 0;
    const verifiedUsers = db.exec("SELECT COUNT(*) FROM users WHERE verification_status = 'VERIFIED';")[0]?.values[0]?.[0] || 0;

    const totalProps = db.exec("SELECT COUNT(*) FROM properties;")[0]?.values[0]?.[0] || 0;
    const pendingProps = db.exec("SELECT COUNT(*) FROM properties WHERE status = 'PENDING_APPROVAL';")[0]?.values[0]?.[0] || 0;
    const approvedProps = db.exec("SELECT COUNT(*) FROM properties WHERE status = 'APPROVED';")[0]?.values[0]?.[0] || 0;
    const rejectedProps = db.exec("SELECT COUNT(*) FROM properties WHERE status = 'REJECTED';")[0]?.values[0]?.[0] || 0;
    const soldProps = db.exec("SELECT COUNT(*) FROM properties WHERE status = 'SOLD';")[0]?.values[0]?.[0] || 0;
    const rentedProps = db.exec("SELECT COUNT(*) FROM properties WHERE status = 'RENTED';")[0]?.values[0]?.[0] || 0;
    const leasedProps = db.exec("SELECT COUNT(*) FROM properties WHERE status = 'LEASED';")[0]?.values[0]?.[0] || 0;
    const inactiveProps = db.exec("SELECT COUNT(*) FROM properties WHERE status = 'INACTIVE';")[0]?.values[0]?.[0] || 0;

    const newInquiries = db.exec("SELECT COUNT(*) FROM property_inquiries WHERE status = 'NEW';")[0]?.values[0]?.[0] || 0;
    const totalInquiries = db.exec("SELECT COUNT(*) FROM property_inquiries;")[0]?.values[0]?.[0] || 0;
    const upcomingVisits = db.exec("SELECT COUNT(*) FROM site_visits WHERE status IN ('REQUESTED', 'CONFIRMED');")[0]?.values[0]?.[0] || 0;
    const totalVisits = db.exec("SELECT COUNT(*) FROM site_visits;")[0]?.values[0]?.[0] || 0;
    const totalAudits = db.exec("SELECT COUNT(*) FROM audit_logs;")[0]?.values[0]?.[0] || 0;

    res.json({
      metrics: {
        totalUsers,
        activeUsers,
        suspendedUsers,
        verifiedUsers,
        totalProps,
        pendingProps,
        approvedProps,
        rejectedProps,
        soldProps,
        rentedProps,
        leasedProps,
        inactiveProps,
        newInquiries,
        totalInquiries,
        upcomingVisits,
        totalVisits,
        totalAudits
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching admin metrics.' });
  }
});

// GET /api/admin/activity (Recent activity feed)
router.get('/admin/activity', authMiddleware, adminMiddleware, async (_req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const query = db.exec("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 25;");
    const activities = mapRows(query);
    res.json({ activities });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching activity logs.' });
  }
});

// GET /api/admin/properties (Filterable listing management)
router.get('/admin/properties', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const {
      status,
      search,
      category,
      transaction_type,
      verification_status,
      min_price,
      max_price,
      owner_id
    } = req.query as Record<string, string>;

    let conditions: string[] = [];

    if (status && status !== 'ALL' && status !== 'all') {
      const cleanStatus = status === 'PENDING' ? 'PENDING_APPROVAL' : status;
      conditions.push(`p.status = '${cleanStatus}'`);
    }

    if (category && category !== 'ALL' && category !== 'all') {
      conditions.push(`p.category = '${category.toLowerCase()}'`);
    }

    if (transaction_type && transaction_type !== 'ALL' && transaction_type !== 'all') {
      conditions.push(`p.transaction_type = '${transaction_type.toLowerCase()}'`);
    }

    if (verification_status && verification_status !== 'ALL' && verification_status !== 'all') {
      conditions.push(`p.verification_status = '${verification_status}'`);
    }

    if (min_price) {
      conditions.push(`p.price >= ${Number(min_price)}`);
    }
    if (max_price) {
      conditions.push(`p.price <= ${Number(max_price)}`);
    }

    if (owner_id) {
      conditions.push(`p.owner_id = '${owner_id}'`);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase().replace(/'/g, "''");
      conditions.push(`(
        LOWER(p.id) LIKE '%${q}%' OR 
        LOWER(p.title) LIKE '%${q}%' OR 
        LOWER(p.locality) LIKE '%${q}%' OR 
        LOWER(p.address) LIKE '%${q}%' OR 
        LOWER(u.name) LIKE '%${q}%' OR 
        LOWER(u.email) LIKE '%${q}%'
      )`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const query = db.exec(`
      SELECT p.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone, u.role as owner_role, u.verification_status as owner_verification_status
      FROM properties p
      LEFT JOIN users u ON p.owner_id = u.id
      ${whereClause}
      ORDER BY p.created_at DESC;
    `);

    const propertyRows = mapRows(query);

    const properties = propertyRows.map((prop) => {
      const imgQuery = db.exec(`
        SELECT image_url as url, is_primary as isPrimary
        FROM property_images
        WHERE property_id = '${prop.id}'
        ORDER BY is_primary DESC, display_order ASC
        LIMIT 1;
      `);
      const img = mapRows(imgQuery)[0];

      return {
        ...prop,
        primaryImage: img ? img.url : '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg'
      };
    });

    res.json({ properties });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching admin properties.' });
  }
});

// GET /api/admin/properties/:id (Full property review detail)
router.get('/admin/properties/:id', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    const query = db.exec(`
      SELECT p.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone, 
             u.role as owner_role, u.verification_status as owner_verification_status,
             u.account_status as owner_account_status, u.created_at as owner_created_at
      FROM properties p
      LEFT JOIN users u ON p.owner_id = u.id
      WHERE p.id = '${id}'
      LIMIT 1;
    `);

    const rows = mapRows(query);
    if (rows.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }

    const prop = rows[0];

    // Images
    const imgQuery = db.exec(`
      SELECT id, image_url as url, caption, is_primary as isPrimary, display_order
      FROM property_images
      WHERE property_id = '${prop.id}'
      ORDER BY display_order ASC, is_primary DESC;
    `);
    const images = mapRows(imgQuery);

    // Amenities
    const amenQuery = db.exec(`
      SELECT amenity_name FROM property_amenities WHERE property_id = '${prop.id}';
    `);
    const amenities = mapRows(amenQuery).map((a) => a.amenity_name);

    // Owner total listings count
    const ownerListingsCount = db.exec(`SELECT COUNT(*) FROM properties WHERE owner_id = '${prop.owner_id}';`)[0]?.values[0]?.[0] || 0;

    // Review history
    const reviewsQuery = db.exec(`
      SELECT r.*, u.name as admin_name
      FROM property_reviews r
      LEFT JOIN users u ON r.admin_id = u.id
      WHERE r.property_id = '${prop.id}'
      ORDER BY r.created_at DESC;
    `);
    const reviewHistory = mapRows(reviewsQuery);

    res.json({
      property: {
        ...prop,
        images: images.length > 0 ? images : [
          { id: 'def', url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg', isPrimary: true, caption: prop.title }
        ],
        amenities,
        owner: {
          id: prop.owner_id,
          name: prop.owner_name,
          email: prop.owner_email,
          phone: prop.owner_phone,
          role: prop.owner_role,
          verification_status: prop.owner_verification_status || 'UNVERIFIED',
          account_status: prop.owner_account_status || 'ACTIVE',
          created_at: prop.owner_created_at,
          listings_count: ownerListingsCount
        },
        reviewHistory
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching property detail.' });
  }
});

// PATCH /api/admin/properties/:id/review (Governance: approve, reject, changes, verify)
router.patch('/admin/properties/:id/review', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { action, reason } = req.body; // 'approve', 'reject', 'request_changes', 'verify', 'unverify', 'under_review', 'deactivate'
    const adminUser = req.user!;
    const db = await getDb();

    // Check property exists
    const propQuery = db.exec(`SELECT id, title, owner_id, status, verification_status FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propQuery);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }
    const currentProp = props[0];

    // Require reason for reject and request_changes
    if ((action === 'reject' || action === 'request_changes') && (!reason || reason.trim().length < 3)) {
      res.status(400).json({ error: 'Please provide a clear reason for rejecting or requesting changes.' });
      return;
    }

    const now = new Date().toISOString();
    let newStatus = '';
    let newVerification = '';
    let auditActionText = '';
    const cleanReason = (reason || '').trim().replace(/'/g, "''");

    if (action === 'approve') {
      newStatus = 'APPROVED';
      auditActionText = 'Property approved';
    } else if (action === 'reject') {
      newStatus = 'REJECTED';
      auditActionText = 'Property rejected';
    } else if (action === 'request_changes') {
      newStatus = 'DRAFT';
      auditActionText = 'Property changes requested';
    } else if (action === 'deactivate') {
      newStatus = 'INACTIVE';
      auditActionText = 'Property deactivated';
    } else if (action === 'verify') {
      newVerification = 'VERIFIED';
      auditActionText = 'Property verified';
    } else if (action === 'unverify') {
      newVerification = 'UNVERIFIED';
      auditActionText = 'Property unverified';
    } else if (action === 'under_review') {
      newVerification = 'UNDER_REVIEW';
      auditActionText = 'Property placed under review';
    } else {
      res.status(400).json({ error: `Invalid review action: ${action}` });
      return;
    }

    let updates: string[] = [`updated_at = '${now}'`];
    if (newStatus) updates.push(`status = '${newStatus}'`);
    if (newVerification) updates.push(`verification_status = '${newVerification}'`);
    if (cleanReason) updates.push(`rejection_reason = '${cleanReason}'`);

    db.run(`UPDATE properties SET ${updates.join(', ')} WHERE id = '${id}';`);

    // Record review action in property_reviews table
    const revId = `rev-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    db.run(`
      INSERT INTO property_reviews (id, property_id, admin_id, action, reason, created_at)
      VALUES ('${revId}', '${id}', '${adminUser.id}', '${action}', '${cleanReason}', '${now}');
    `);

    // Log to audit log
    const auditDetails = `Action: ${action} on "${currentProp.title}" (ID: ${id})${cleanReason ? ` | Reason: ${cleanReason}` : ''}`;
    logAudit(db, adminUser.id, adminUser.name, auditActionText, 'property', id, auditDetails);

    saveDb();

    res.json({
      message: `Property review successfully updated: ${action}`,
      status: newStatus || currentProp.status,
      verification_status: newVerification || currentProp.verification_status
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating review status.' });
  }
});

// GET /api/admin/users (User management with properties count)
router.get('/admin/users', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const { search, role, account_status, verification_status } = req.query as Record<string, string>;

    let conditions: string[] = [];

    if (role && role !== 'ALL' && role !== 'all') {
      conditions.push(`u.role = '${role.toLowerCase()}'`);
    }

    if (account_status && account_status !== 'ALL' && account_status !== 'all') {
      conditions.push(`u.account_status = '${account_status}'`);
    }

    if (verification_status && verification_status !== 'ALL' && verification_status !== 'all') {
      conditions.push(`u.verification_status = '${verification_status}'`);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase().replace(/'/g, "''");
      conditions.push(`(
        LOWER(u.name) LIKE '%${q}%' OR 
        LOWER(u.email) LIKE '%${q}%' OR 
        LOWER(u.phone) LIKE '%${q}%' OR
        LOWER(u.id) LIKE '%${q}%'
      )`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const query = db.exec(`
      SELECT u.id, u.name, u.email, u.phone, u.role, u.capabilities, u.is_verified, 
             u.verification_status, u.account_status, u.created_at, u.updated_at,
             (SELECT COUNT(*) FROM properties WHERE owner_id = u.id) as properties_count
      FROM users u
      ${whereClause}
      ORDER BY u.created_at DESC;
    `);

    const users = mapRows(query).map((u) => ({
      ...u,
      capabilities: JSON.parse(u.capabilities || '[]'),
      is_verified: Boolean(u.is_verified),
      verification_status: u.verification_status || (u.is_verified ? 'VERIFIED' : 'UNVERIFIED'),
      account_status: u.account_status || 'ACTIVE'
    }));

    res.json({ users });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching users.' });
  }
});

// GET /api/admin/users/:id (Single user details with listings)
router.get('/admin/users/:id', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    const userQuery = db.exec(`
      SELECT u.id, u.name, u.email, u.phone, u.role, u.capabilities, u.is_verified, 
             u.verification_status, u.account_status, u.created_at, u.updated_at
      FROM users u
      WHERE u.id = '${id}'
      LIMIT 1;
    `);
    const users = mapRows(userQuery);
    if (users.length === 0) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    const user = users[0];

    // Properties owned
    const propsQuery = db.exec(`SELECT id, title, price, status, verification_status, created_at FROM properties WHERE owner_id = '${id}' ORDER BY created_at DESC;`);
    const properties = mapRows(propsQuery);

    // Inquiries sent
    const inqQuery = db.exec(`SELECT id, property_id, status, created_at FROM property_inquiries WHERE buyer_user_id = '${id}' ORDER BY created_at DESC;`);
    const inquiries = mapRows(inqQuery);

    // Site visits requested
    const visitsQuery = db.exec(`SELECT id, property_id, preferred_date, status, created_at FROM site_visits WHERE visitor_user_id = '${id}' ORDER BY created_at DESC;`);
    const siteVisits = mapRows(visitsQuery);

    res.json({
      user: {
        ...user,
        capabilities: JSON.parse(user.capabilities || '[]'),
        is_verified: Boolean(user.is_verified),
        verification_status: user.verification_status || (user.is_verified ? 'VERIFIED' : 'UNVERIFIED'),
        account_status: user.account_status || 'ACTIVE',
        properties,
        inquiries,
        siteVisits
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching user profile.' });
  }
});

// PATCH /api/admin/users/:id/status (Verify owner/agent, suspend/reactivate user, change role)
router.patch('/admin/users/:id/status', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { account_status, verification_status, role } = req.body;
    const adminUser = req.user!;
    const db = await getDb();

    // Check user exists
    const query = db.exec(`SELECT id, name, email, role, verification_status, account_status FROM users WHERE id = '${id}' LIMIT 1;`);
    const rows = mapRows(query);
    if (rows.length === 0) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    const targetUser = rows[0];

    const now = new Date().toISOString();
    let updates: string[] = [`updated_at = '${now}'`];

    if (account_status && ['ACTIVE', 'SUSPENDED'].includes(account_status)) {
      updates.push(`account_status = '${account_status}'`);
      const actionText = account_status === 'SUSPENDED' ? 'User suspended' : 'User reactivated';
      logAudit(db, adminUser.id, adminUser.name, actionText, 'user', id, `${actionText}: ${targetUser.name} (${targetUser.email})`);
    }

    if (verification_status && ['UNVERIFIED', 'UNDER_REVIEW', 'VERIFIED', 'REJECTED'].includes(verification_status)) {
      updates.push(`verification_status = '${verification_status}'`);
      updates.push(`is_verified = ${verification_status === 'VERIFIED' ? 1 : 0}`);
      logAudit(db, adminUser.id, adminUser.name, 'User verification updated', 'user', id, `Set verification_status to ${verification_status} for ${targetUser.name} (${targetUser.email})`);
    }

    if (role && ['buyer', 'tenant', 'owner', 'agent', 'admin'].includes(role)) {
      updates.push(`role = '${role}'`);
      logAudit(db, adminUser.id, adminUser.name, 'User role updated', 'user', id, `Role changed to ${role} for ${targetUser.name}`);
    }

    db.run(`UPDATE users SET ${updates.join(', ')} WHERE id = '${id}';`);
    saveDb();

    res.json({ message: 'User status successfully updated.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating user status.' });
  }
});

// GET /api/admin/enquiries (Platform-wide enquiry moderation)
router.get('/admin/enquiries', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const { status, search } = req.query as Record<string, string>;

    let conditions: string[] = [];
    if (status && status !== 'ALL' && status !== 'all') {
      conditions.push(`i.status = '${status}'`);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase().replace(/'/g, "''");
      conditions.push(`(
        LOWER(i.buyer_name) LIKE '%${q}%' OR 
        LOWER(i.buyer_email) LIKE '%${q}%' OR 
        LOWER(p.title) LIKE '%${q}%' OR 
        LOWER(u.name) LIKE '%${q}%'
      )`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const query = db.exec(`
      SELECT i.*, p.title as property_title, p.locality, p.price,
             u.name as owner_name, u.email as owner_email, u.phone as owner_phone
      FROM property_inquiries i
      JOIN properties p ON i.property_id = p.id
      JOIN users u ON p.owner_id = u.id
      ${whereClause}
      ORDER BY i.created_at DESC;
    `);

    const enquiries = mapRows(query);
    res.json({ enquiries });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching enquiries.' });
  }
});

// PATCH /api/admin/enquiries/:id/status (Admin enquiry status update)
router.patch('/admin/enquiries/:id/status', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['NEW', 'CONTACTED', 'SITE_VISIT', 'NEGOTIATING', 'CLOSED', 'CANCELLED'];

    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid enquiry status.' });
      return;
    }

    const db = await getDb();
    const now = new Date().toISOString();
    db.run(`UPDATE property_inquiries SET status = '${status}', updated_at = '${now}' WHERE id = '${id}';`);

    logAudit(db, req.user!.id, req.user!.name, 'Enquiry status changed', 'inquiry', id, `Status updated to ${status}`);
    saveDb();

    res.json({ message: 'Enquiry status updated successfully.', status });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating enquiry.' });
  }
});

// GET /api/admin/site-visits (Platform-wide site visits moderation)
router.get('/admin/site-visits', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const { status, search } = req.query as Record<string, string>;

    let conditions: string[] = [];
    if (status && status !== 'ALL' && status !== 'all') {
      conditions.push(`v.status = '${status}'`);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase().replace(/'/g, "''");
      conditions.push(`(
        LOWER(v.visitor_name) LIKE '%${q}%' OR 
        LOWER(v.visitor_email) LIKE '%${q}%' OR 
        LOWER(p.title) LIKE '%${q}%' OR 
        LOWER(u.name) LIKE '%${q}%'
      )`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const query = db.exec(`
      SELECT v.*, p.title as property_title, p.locality,
             u.name as owner_name, u.email as owner_email, u.phone as owner_phone
      FROM site_visits v
      JOIN properties p ON v.property_id = p.id
      JOIN users u ON p.owner_id = u.id
      ${whereClause}
      ORDER BY v.preferred_date ASC, v.created_at DESC;
    `);

    const visits = mapRows(query);
    res.json({ visits });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching site visits.' });
  }
});

// PATCH /api/admin/site-visits/:id/status (Admin site visit status update)
router.patch('/admin/site-visits/:id/status', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['REQUESTED', 'CONFIRMED', 'COMPLETED', 'CANCELLED'];

    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid visit status.' });
      return;
    }

    const db = await getDb();
    const now = new Date().toISOString();
    db.run(`UPDATE site_visits SET status = '${status}', updated_at = '${now}' WHERE id = '${id}';`);

    logAudit(db, req.user!.id, req.user!.name, 'Site visit status changed', 'site_visit', id, `Status updated to ${status}`);
    saveDb();

    res.json({ message: 'Site visit status updated successfully.', status });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating site visit.' });
  }
});

// GET /api/admin/audit-logs (Security & compliance trail)
router.get('/admin/audit-logs', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const { entity_type, limit = '100' } = req.query as Record<string, string>;

    let whereClause = '';
    if (entity_type && entity_type !== 'ALL') {
      whereClause = `WHERE entity_type = '${entity_type}'`;
    }

    const limitNum = Math.min(200, Math.max(1, parseInt(limit, 10) || 100));

    const query = db.exec(`
      SELECT * FROM audit_logs
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT ${limitNum};
    `);

    const logs = mapRows(query);
    res.json({ logs });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching audit logs.' });
  }
});

// GET /api/admin/settings (System runtime & database stats)
router.get('/admin/settings', authMiddleware, adminMiddleware, async (_req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const totalUsers = db.exec("SELECT COUNT(*) FROM users;")[0]?.values[0]?.[0] || 0;
    const totalProperties = db.exec("SELECT COUNT(*) FROM properties;")[0]?.values[0]?.[0] || 0;
    const totalImages = db.exec("SELECT COUNT(*) FROM property_images;")[0]?.values[0]?.[0] || 0;
    const totalAudits = db.exec("SELECT COUNT(*) FROM audit_logs;")[0]?.values[0]?.[0] || 0;

    res.json({
      system: {
        platformName: 'P2P Property Governance Engine',
        version: '1.3.0-production',
        environment: process.env.NODE_ENV || 'development',
        databaseEngine: 'SQLite Embedded (sql.js / WebAssembly)',
        databaseStatus: 'HEALTHY',
        uptimeSeconds: Math.round(process.uptime()),
        records: {
          users: totalUsers,
          properties: totalProperties,
          propertyImages: totalImages,
          auditLogs: totalAudits
        }
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching system settings.' });
  }
});

// --------------------------------------------------------------------------
// 10. PHASE 4: LEAD & CUSTOMER MANAGEMENT SYSTEM
// --------------------------------------------------------------------------

// GET /api/settings/whatsapp (Configurable WhatsApp business contact number)
router.get('/settings/whatsapp', (_req: Request, res: Response) => {
  const businessNumber = process.env.WHATSAPP_BUSINESS_NUMBER || '+919820098200';
  res.json({ businessNumber });
});

// GET /api/leads (Owner / Agent Lead Inbox with filtering, search, stats)
router.get('/leads', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const userId = req.user!.id;
    const userRole = req.user!.role;

    // Strict Authorization: Buyers and Tenants cannot access seller lead inbox
    if (userRole === 'buyer' || userRole === 'tenant') {
      res.status(403).json({ error: 'Access denied: Buyers and tenants cannot access the seller lead inbox.' });
      return;
    }

    const {
      status,
      priority,
      source,
      property_id,
      category,
      search
    } = req.query as Record<string, string>;

    // Base authorization scope: Admin sees all; Owner/Agent sees owned or assigned leads
    let whereConditions: string[] = [];
    if (userRole === 'admin') {
      whereConditions.push('1=1');
    } else {
      whereConditions.push(`(l.owner_id = '${userId}' OR l.assigned_agent_id = '${userId}')`);
    }

    if (status && status !== 'ALL') {
      whereConditions.push(`l.status = '${status.replace(/'/g, "''")}'`);
    }

    if (priority && priority !== 'ALL') {
      whereConditions.push(`l.priority = '${priority.replace(/'/g, "''")}'`);
    }

    if (source && source !== 'ALL') {
      whereConditions.push(`l.source = '${source.replace(/'/g, "''")}'`);
    }

    if (property_id && property_id !== 'ALL') {
      whereConditions.push(`l.property_id = '${property_id.replace(/'/g, "''")}'`);
    }

    if (category && category !== 'ALL') {
      whereConditions.push(`l.requirement_type = '${category.toLowerCase().replace(/'/g, "''")}'`);
    }

    if (search && search.trim()) {
      const q = search.trim().replace(/'/g, "''");
      whereConditions.push(`(
        c.name LIKE '%${q}%' OR 
        c.mobile LIKE '%${q}%' OR 
        c.email LIKE '%${q}%' OR 
        p.title LIKE '%${q}%' OR 
        p.locality LIKE '%${q}%' OR 
        l.id LIKE '%${q}%'
      )`);
    }

    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';

    const leadsQuery = db.exec(`
      SELECT 
        l.*,
        c.name as customer_name,
        c.mobile as customer_mobile,
        c.email as customer_email,
        c.customer_type as customer_type,
        c.preferred_transaction as customer_transaction,
        c.preferred_locations as customer_locations,
        c.budget_min as customer_budget_min,
        c.budget_max as customer_budget_max,
        c.notes as customer_notes,
        p.title as property_title,
        p.locality as property_locality,
        p.category as property_category,
        p.transaction_type as property_transaction_type,
        p.property_type as property_type_val,
        p.price as property_price,
        p.rent as property_rent,
        u_owner.name as owner_name,
        u_owner.email as owner_email,
        u_owner.phone as owner_phone,
        u_agent.name as assigned_agent_name
      FROM leads l
      JOIN customer_profiles c ON l.customer_id = c.id
      LEFT JOIN properties p ON l.property_id = p.id
      LEFT JOIN users u_owner ON l.owner_id = u_owner.id
      LEFT JOIN users u_agent ON l.assigned_agent_id = u_agent.id
      ${whereClause}
      ORDER BY l.created_at DESC;
    `);

    const rawLeads = mapRows(leadsQuery);

    const leads = rawLeads.map((r) => {
      // Get primary image if property exists
      let primaryImage = '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg';
      if (r.property_id) {
        const imgQuery = db.exec(`
          SELECT image_url FROM property_images 
          WHERE property_id = '${r.property_id}' 
          ORDER BY is_primary DESC, display_order ASC LIMIT 1;
        `);
        const imgRows = mapRows(imgQuery);
        if (imgRows.length > 0) primaryImage = imgRows[0].image_url;
      }

      // Next pending follow-up
      const folQuery = db.exec(`
        SELECT * FROM lead_followups 
        WHERE lead_id = '${r.id}' AND status = 'PENDING'
        ORDER BY follow_up_date ASC, follow_up_time ASC LIMIT 1;
      `);
      const nextFollowUp = mapRows(folQuery)[0] || null;

      return {
        id: r.id,
        propertyId: r.property_id,
        customerId: r.customer_id,
        ownerId: r.owner_id,
        assignedAgentId: r.assigned_agent_id,
        source: r.source,
        status: r.status,
        priority: r.priority,
        customerMessage: r.customer_message,
        internalNotes: r.internal_notes,
        preferredContactMethod: r.preferred_contact_method,
        budget: r.budget,
        requirementType: r.requirement_type,
        businessType: r.business_type,
        requiredCarpetArea: r.required_carpet_area,
        bhk: r.bhk,
        furnishingPreference: r.furnishing_preference,
        parkingRequirement: r.parking_requirement,
        lastContactedAt: r.last_contacted_at,
        nextFollowUpAt: r.next_follow_up_at,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
        customer: {
          id: r.customer_id,
          name: r.customer_name,
          mobile: r.customer_mobile,
          email: r.customer_email,
          customerType: r.customer_type,
          preferredTransaction: r.customer_transaction,
          preferredLocations: r.customer_locations,
          budgetMin: r.customer_budget_min,
          budgetMax: r.customer_budget_max,
          notes: r.customer_notes
        },
        property: r.property_id ? {
          id: r.property_id,
          title: r.property_title,
          category: r.property_category,
          transactionType: r.property_transaction_type,
          propertyType: r.property_type_val,
          locality: r.property_locality,
          price: r.property_price,
          rent: r.property_rent,
          primaryImage
        } : undefined,
        ownerName: r.owner_name,
        ownerEmail: r.owner_email,
        ownerPhone: r.owner_phone,
        assignedAgentName: r.assigned_agent_name,
        nextFollowUp
      };
    });

    // Compute Summary Stats for dashboard
    let scopeClause = userRole === 'admin' ? '1=1' : `(owner_id = '${userId}' OR assigned_agent_id = '${userId}')`;
    const countByStatus = (st: string) => {
      const res = db.exec(`SELECT COUNT(*) FROM leads WHERE ${scopeClause} AND status = '${st}';`);
      return Number(res[0]?.values[0]?.[0] || 0);
    };

    const totalCountRes = db.exec(`SELECT COUNT(*) FROM leads WHERE ${scopeClause};`);
    const totalLeads = Number(totalCountRes[0]?.values[0]?.[0] || 0);

    const followUpScopeClause = userRole === 'admin' 
      ? "status = 'PENDING'" 
      : `status = 'PENDING' AND lead_id IN (SELECT id FROM leads WHERE ${scopeClause})`;
    const followUpsCountRes = db.exec(`SELECT COUNT(*) FROM lead_followups WHERE ${followUpScopeClause};`);
    const upcomingFollowUps = Number(followUpsCountRes[0]?.values[0]?.[0] || 0);

    const stats = {
      totalLeads,
      newLeads: countByStatus('NEW'),
      contacted: countByStatus('CONTACTED'),
      qualified: countByStatus('QUALIFIED'),
      siteVisits: countByStatus('SITE_VISIT'),
      negotiating: countByStatus('NEGOTIATING'),
      won: countByStatus('WON'),
      lost: countByStatus('LOST'),
      closed: countByStatus('CLOSED'),
      upcomingFollowUps
    };

    res.json({ leads, stats });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching leads.' });
  }
});

// GET /api/leads/:id (Single Lead Detail with full Customer Profile, Property, Timeline, Follow-ups, Site Visits)
router.get('/leads/:id', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const userId = req.user!.id;
    const userRole = req.user!.role;

    const leadQuery = db.exec(`
      SELECT 
        l.*,
        c.name as customer_name,
        c.mobile as customer_mobile,
        c.email as customer_email,
        c.user_id as customer_user_id,
        c.customer_type as customer_type,
        c.preferred_transaction as customer_transaction,
        c.preferred_category as customer_category,
        c.preferred_locations as customer_locations,
        c.budget_min as customer_budget_min,
        c.budget_max as customer_budget_max,
        c.preferred_property_types as customer_prop_types,
        c.bhk as customer_bhk,
        c.carpet_area_min as customer_carpet_min,
        c.carpet_area_max as customer_carpet_max,
        c.furnishing_preference as customer_furnishing,
        c.parking_requirement as customer_parking,
        c.business_type as customer_business_type,
        c.notes as customer_notes,
        p.title as property_title,
        p.locality as property_locality,
        p.address as property_address,
        p.category as property_category,
        p.transaction_type as property_transaction_type,
        p.property_type as property_type_val,
        p.price as property_price,
        p.rent as property_rent,
        p.carpet_area as property_carpet_area,
        p.bedrooms as property_bedrooms,
        p.furnishing as property_furnishing,
        p.parking as property_parking,
        p.business_type as property_business_type,
        u_owner.name as owner_name,
        u_owner.email as owner_email,
        u_owner.phone as owner_phone,
        u_agent.name as assigned_agent_name,
        u_agent.email as assigned_agent_email,
        u_agent.phone as assigned_agent_phone
      FROM leads l
      JOIN customer_profiles c ON l.customer_id = c.id
      LEFT JOIN properties p ON l.property_id = p.id
      LEFT JOIN users u_owner ON l.owner_id = u_owner.id
      LEFT JOIN users u_agent ON l.assigned_agent_id = u_agent.id
      WHERE l.id = '${id}'
      LIMIT 1;
    `);

    const raw = mapRows(leadQuery);
    if (raw.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const r = raw[0];

    // Security Check / IDOR Prevention:
    // Only Admin, the Lead Owner, or the Assigned Agent can view this lead!
    if (userRole !== 'admin' && r.owner_id !== userId && r.assigned_agent_id !== userId) {
      res.status(403).json({ error: 'Forbidden: You are not authorized to view this lead.' });
      return;
    }

    // Property images
    let primaryImage = '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg';
    if (r.property_id) {
      const imgQuery = db.exec(`
        SELECT image_url FROM property_images 
        WHERE property_id = '${r.property_id}' 
        ORDER BY is_primary DESC, display_order ASC LIMIT 1;
      `);
      const imgRows = mapRows(imgQuery);
      if (imgRows.length > 0) primaryImage = imgRows[0].image_url;
    }

    // Activity Timeline
    const actQuery = db.exec(`
      SELECT * FROM lead_activities 
      WHERE lead_id = '${id}'
      ORDER BY created_at DESC;
    `);
    const activities = mapRows(actQuery).map((a) => ({
      id: a.id,
      leadId: a.lead_id,
      performedById: a.performed_by_id,
      performedByName: a.performed_by_name,
      performedByRole: a.performed_by_role,
      action: a.action,
      details: a.details,
      createdAt: a.created_at
    }));

    // Follow-ups
    const folQuery = db.exec(`
      SELECT * FROM lead_followups 
      WHERE lead_id = '${id}'
      ORDER BY follow_up_date ASC, created_at DESC;
    `);
    const followUps = mapRows(folQuery).map((f) => ({
      id: f.id,
      leadId: f.lead_id,
      followUpDate: f.follow_up_date,
      followUpTime: f.follow_up_time,
      note: f.note,
      assignedTo: f.assigned_to,
      assignedToName: f.assigned_to_name,
      status: f.status,
      createdAt: f.created_at,
      updatedAt: f.updated_at
    }));

    // Site Visits
    const visitsQuery = db.exec(`
      SELECT * FROM site_visits 
      WHERE lead_id = '${id}' OR (property_id = '${r.property_id}' AND visitor_email = '${r.customer_email}')
      ORDER BY preferred_date ASC, created_at DESC;
    `);
    const siteVisits = mapRows(visitsQuery);

    // Assignment history
    const assignQuery = db.exec(`
      SELECT * FROM lead_assignments 
      WHERE lead_id = '${id}'
      ORDER BY created_at DESC;
    `);
    const assignments = mapRows(assignQuery);

    const lead = {
      id: r.id,
      propertyId: r.property_id,
      customerId: r.customer_id,
      ownerId: r.owner_id,
      assignedAgentId: r.assigned_agent_id,
      source: r.source,
      status: r.status,
      priority: r.priority,
      customerMessage: r.customer_message,
      internalNotes: r.internal_notes,
      preferredContactMethod: r.preferred_contact_method,
      budget: r.budget,
      requirementType: r.requirement_type,
      businessType: r.business_type,
      requiredCarpetArea: r.required_carpet_area,
      bhk: r.bhk,
      furnishingPreference: r.furnishing_preference,
      parkingRequirement: r.parking_requirement,
      lastContactedAt: r.last_contacted_at,
      nextFollowUpAt: r.next_follow_up_at,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      customer: {
        id: r.customer_id,
        name: r.customer_name,
        mobile: r.customer_mobile,
        email: r.customer_email,
        userId: r.customer_user_id,
        customerType: r.customer_type,
        preferredTransaction: r.customer_transaction,
        preferredCategory: r.customer_category,
        preferredLocations: r.customer_locations,
        budgetMin: r.customer_budget_min,
        budgetMax: r.customer_budget_max,
        preferredPropertyTypes: r.customer_prop_types,
        bhk: r.customer_bhk,
        carpetAreaMin: r.customer_carpet_min,
        carpetAreaMax: r.customer_carpet_max,
        furnishingPreference: r.customer_furnishing,
        parkingRequirement: r.customer_parking,
        businessType: r.customer_business_type,
        notes: r.customer_notes
      },
      property: r.property_id ? {
        id: r.property_id,
        title: r.property_title,
        locality: r.property_locality,
        address: r.property_address,
        category: r.property_category,
        transactionType: r.property_transaction_type,
        propertyType: r.property_type_val,
        price: r.property_price,
        rent: r.property_rent,
        carpetArea: r.property_carpet_area,
        bedrooms: r.property_bedrooms,
        furnishing: r.property_furnishing,
        parking: r.property_parking,
        businessType: r.property_business_type,
        primaryImage
      } : undefined,
      ownerName: r.owner_name,
      ownerEmail: r.owner_email,
      ownerPhone: r.owner_phone,
      assignedAgentName: r.assigned_agent_name,
      assignedAgentEmail: r.assigned_agent_email,
      assignedAgentPhone: r.assigned_agent_phone,
      activities,
      followUps,
      siteVisits,
      assignments
    };

    res.json({ lead });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching lead details.' });
  }
});

// POST /api/leads (Manual Lead Creation for Owner / Agent / Admin)
router.post('/leads', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const userId = req.user!.id;
    const userRole = req.user!.role;

    if (userRole === 'buyer' || userRole === 'tenant') {
      res.status(403).json({ error: 'Access denied: Only owners, agents, and admins can register leads.' });
      return;
    }

    const {
      name,
      mobile,
      email,
      property_id,
      source = 'PHONE',
      priority = 'MEDIUM',
      status = 'NEW',
      customer_message,
      internal_notes,
      preferred_contact_method = 'PHONE',
      budget,
      requirement_type = 'residential',
      business_type,
      required_carpet_area,
      bhk,
      preferred_locations,
      furnishing_preference,
      parking_requirement,
      customer_type = 'BUYER'
    } = req.body;

    if (!name || !mobile) {
      res.status(400).json({ error: 'Customer name and mobile phone are required.' });
      return;
    }

    const now = new Date().toISOString();

    // Check or create customer
    const cleanEmail = (email || `${mobile.replace(/[^0-9]/g, '')}@lead.p2pproperty.in`).trim();
    let customerId = '';
    const custCheck = db.exec(`
      SELECT id FROM customer_profiles 
      WHERE mobile = '${mobile.replace(/'/g, "''")}' OR email = '${cleanEmail.replace(/'/g, "''")}'
      LIMIT 1;
    `);
    const existingCust = mapRows(custCheck);

    if (existingCust.length > 0) {
      customerId = existingCust[0].id;
    } else {
      customerId = `cust-${Date.now()}-${Math.round(Math.random() * 1000)}`;
      db.run(`
        INSERT INTO customer_profiles (
          id, name, mobile, email, customer_type, preferred_transaction, preferred_category,
          preferred_locations, budget_max, bhk, business_type, carpet_area_min,
          notes, created_at, updated_at
        ) VALUES (
          '${customerId}', '${name.replace(/'/g, "''")}', '${mobile.replace(/'/g, "''")}',
          '${cleanEmail.replace(/'/g, "''")}', '${customer_type}',
          '${requirement_type === 'commercial' ? 'lease' : 'buy'}', '${requirement_type}',
          '${(preferred_locations || 'Mumbai').replace(/'/g, "''")}',
          ${budget ? Number(budget) : 'NULL'}, '${(bhk || '').replace(/'/g, "''")}',
          '${(business_type || '').replace(/'/g, "''")}',
          ${required_carpet_area ? Number(required_carpet_area) : 'NULL'},
          'Manually registered lead', '${now}', '${now}'
        );
      `);
    }

    // Determine owner_id
    let ownerId = userId;
    if (property_id) {
      const propQuery = db.exec(`SELECT owner_id FROM properties WHERE id = '${property_id}' LIMIT 1;`);
      const p = mapRows(propQuery);
      if (p.length > 0) ownerId = p[0].owner_id;
    }

    const leadId = `lead-${Date.now()}-${Math.round(Math.random() * 1000)}`;

    db.run(`
      INSERT INTO leads (
        id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
        customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
        business_type, required_carpet_area, bhk, furnishing_preference, parking_requirement,
        created_at, updated_at
      ) VALUES (
        '${leadId}', ${property_id ? `'${property_id}'` : 'NULL'}, '${customerId}', '${ownerId}',
        ${userRole === 'agent' ? `'${userId}'` : 'NULL'},
        '${source.replace(/'/g, "''")}', '${status.replace(/'/g, "''")}', '${priority.replace(/'/g, "''")}',
        '${(customer_message || '').replace(/'/g, "''")}',
        '${(internal_notes || '').replace(/'/g, "''")}',
        '${preferred_contact_method.replace(/'/g, "''")}',
        ${budget ? Number(budget) : 'NULL'}, '${requirement_type.replace(/'/g, "''")}',
        '${(business_type || '').replace(/'/g, "''")}',
        ${required_carpet_area ? Number(required_carpet_area) : 'NULL'},
        '${(bhk || '').replace(/'/g, "''")}',
        '${(furnishing_preference || '').replace(/'/g, "''")}',
        '${(parking_requirement || '').replace(/'/g, "''")}',
        '${now}', '${now}'
      );
    `);

    // Log Activity Timeline
    logLeadActivity(
      db,
      leadId,
      userId,
      req.user!.name,
      userRole,
      'LEAD_CREATED',
      `Lead registered manually via ${source} by ${req.user!.name}`
    );

    saveDb();

    res.status(201).json({ message: 'Lead registered successfully.', leadId });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error creating lead.' });
  }
});

// PATCH /api/leads/:id/status (Kanban drag-and-drop or status progression)
router.patch('/leads/:id/status', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status, reason } = req.body;
    const validStatuses = ['NEW', 'CONTACTED', 'QUALIFIED', 'SITE_VISIT', 'NEGOTIATING', 'WON', 'LOST', 'CLOSED'];

    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid lead status.' });
      return;
    }

    const db = await getDb();
    const leadQuery = db.exec(`SELECT * FROM leads WHERE id = '${id}' LIMIT 1;`);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const lead = leads[0];
    const isOwner = req.user!.id === lead.owner_id;
    const isAssigned = req.user!.id === lead.assigned_agent_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAssigned && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot update status for this lead.' });
      return;
    }

    const now = new Date().toISOString();
    db.run(`UPDATE leads SET status = '${status}', updated_at = '${now}' WHERE id = '${id}';`);

    // Record appropriate timeline action
    let actType = 'STATUS_CHANGED';
    let actDetails = `Status changed from ${lead.status} to ${status}`;

    if (status === 'WON') {
      actType = 'DEAL_WON';
      actDetails = `Deal marked as WON! Transaction successfully finalized.`;
    } else if (status === 'LOST') {
      actType = 'DEAL_LOST';
      actDetails = `Deal marked as LOST: ${reason || 'Deal closed without closing'}`;
    }

    logLeadActivity(db, id, req.user!.id, req.user!.name, req.user!.role, actType, actDetails);
    saveDb();

    res.json({ message: `Lead status updated to ${status}.`, status });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating lead status.' });
  }
});

// PATCH /api/leads/:id (Update priority, notes, budget, requirements)
router.patch('/leads/:id', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const leadQuery = db.exec(`SELECT * FROM leads WHERE id = '${id}' LIMIT 1;`);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const lead = leads[0];
    const isOwner = req.user!.id === lead.owner_id;
    const isAssigned = req.user!.id === lead.assigned_agent_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAssigned && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot modify this lead.' });
      return;
    }

    const {
      priority,
      internal_notes,
      budget,
      required_carpet_area,
      bhk,
      business_type,
      furnishing_preference,
      parking_requirement
    } = req.body;

    const updates: string[] = [];
    const now = new Date().toISOString();
    updates.push(`updated_at = '${now}'`);

    if (priority) {
      updates.push(`priority = '${priority.replace(/'/g, "''")}'`);
      if (priority !== lead.priority) {
        logLeadActivity(db, id, req.user!.id, req.user!.name, req.user!.role, 'STATUS_CHANGED', `Priority updated to ${priority}`);
      }
    }

    if (internal_notes !== undefined) {
      updates.push(`internal_notes = '${(internal_notes || '').replace(/'/g, "''")}'`);
    }

    if (budget !== undefined) {
      updates.push(`budget = ${budget ? Number(budget) : 'NULL'}`);
    }

    if (required_carpet_area !== undefined) {
      updates.push(`required_carpet_area = ${required_carpet_area ? Number(required_carpet_area) : 'NULL'}`);
    }

    if (bhk !== undefined) {
      updates.push(`bhk = '${(bhk || '').replace(/'/g, "''")}'`);
    }

    if (business_type !== undefined) {
      updates.push(`business_type = '${(business_type || '').replace(/'/g, "''")}'`);
    }

    if (furnishing_preference !== undefined) {
      updates.push(`furnishing_preference = '${(furnishing_preference || '').replace(/'/g, "''")}'`);
    }

    if (parking_requirement !== undefined) {
      updates.push(`parking_requirement = '${(parking_requirement || '').replace(/'/g, "''")}'`);
    }

    db.run(`UPDATE leads SET ${updates.join(', ')} WHERE id = '${id}';`);
    saveDb();

    res.json({ message: 'Lead updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating lead.' });
  }
});

// POST /api/leads/:id/notes (Add internal note with timeline logging)
router.post('/leads/:id/notes', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { note } = req.body;

    if (!note || !note.trim()) {
      res.status(400).json({ error: 'Note content cannot be empty.' });
      return;
    }

    const db = await getDb();
    const leadQuery = db.exec(`SELECT * FROM leads WHERE id = '${id}' LIMIT 1;`);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const lead = leads[0];
    const isOwner = req.user!.id === lead.owner_id;
    const isAssigned = req.user!.id === lead.assigned_agent_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAssigned && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot add notes to this lead.' });
      return;
    }

    const now = new Date().toISOString();
    const appendText = `\\n[${new Date().toLocaleDateString('en-IN')}] ${req.user!.name}: ${note.replace(/'/g, "''")}`;
    db.run(`
      UPDATE leads 
      SET internal_notes = COALESCE(internal_notes, '') || '${appendText}',
          updated_at = '${now}'
      WHERE id = '${id}';
    `);

    logLeadActivity(db, id, req.user!.id, req.user!.name, req.user!.role, 'NOTE_ADDED', note);
    saveDb();

    res.json({ message: 'Note logged successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error adding note.' });
  }
});

// POST /api/leads/:id/contact (Record communication / contact attempt)
router.post('/leads/:id/contact', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { method = 'PHONE', details, outcome } = req.body;

    const db = await getDb();
    const leadQuery = db.exec(`SELECT * FROM leads WHERE id = '${id}' LIMIT 1;`);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const lead = leads[0];
    const isOwner = req.user!.id === lead.owner_id;
    const isAssigned = req.user!.id === lead.assigned_agent_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAssigned && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot log contact for this lead.' });
      return;
    }

    const now = new Date().toISOString();
    let newStatus = lead.status;
    if (lead.status === 'NEW') {
      newStatus = 'CONTACTED';
    }

    db.run(`
      UPDATE leads 
      SET last_contacted_at = '${now}',
          status = '${newStatus}',
          updated_at = '${now}'
      WHERE id = '${id}';
    `);

    const actionText = outcome === 'NO_ANSWER' ? 'CONTACT_ATTEMPTED' : 'CONTACTED';
    const detailText = `${method} contact: ${details || outcome || 'Customer contacted'}`;

    logLeadActivity(db, id, req.user!.id, req.user!.name, req.user!.role, actionText, detailText);
    if (lead.status === 'NEW') {
      logLeadActivity(db, id, req.user!.id, req.user!.name, req.user!.role, 'STATUS_CHANGED', 'Lead progressed to CONTACTED');
    }

    saveDb();

    res.json({ message: 'Contact logged successfully.', lastContactedAt: now, status: newStatus });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error logging contact.' });
  }
});

// GET /api/leads/:id/timeline (Activity timeline for a lead)
router.get('/leads/:id/timeline', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const leadQuery = db.exec(`SELECT owner_id, assigned_agent_id FROM leads WHERE id = '${id}' LIMIT 1;`);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const lead = leads[0];
    const isOwner = req.user!.id === lead.owner_id;
    const isAssigned = req.user!.id === lead.assigned_agent_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAssigned && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot view timeline for this lead.' });
      return;
    }

    const actQuery = db.exec(`
      SELECT * FROM lead_activities 
      WHERE lead_id = '${id}'
      ORDER BY created_at DESC;
    `);

    const activities = mapRows(actQuery);
    res.json({ activities });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching timeline.' });
  }
});

// POST /api/leads/:id/follow-ups (Schedule follow-up)
router.post('/leads/:id/follow-ups', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { follow_up_date, follow_up_time, note, assigned_to } = req.body;

    if (!follow_up_date || !note) {
      res.status(400).json({ error: 'Follow-up date and note are required.' });
      return;
    }

    const db = await getDb();
    const leadQuery = db.exec(`SELECT * FROM leads WHERE id = '${id}' LIMIT 1;`);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const lead = leads[0];
    const isOwner = req.user!.id === lead.owner_id;
    const isAssigned = req.user!.id === lead.assigned_agent_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAssigned && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot schedule follow-ups for this lead.' });
      return;
    }

    const folId = `fol-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const assignedUserId = assigned_to || req.user!.id;
    const assignedUserName = req.user!.name;

    db.run(`
      INSERT INTO lead_followups (
        id, lead_id, follow_up_date, follow_up_time, note, assigned_to, assigned_to_name, status, created_at, updated_at
      ) VALUES (
        '${folId}', '${id}', '${follow_up_date}', '${(follow_up_time || '').replace(/'/g, "''")}',
        '${note.replace(/'/g, "''")}', '${assignedUserId}', '${assignedUserName.replace(/'/g, "''")}',
        'PENDING', '${now}', '${now}'
      );
    `);

    db.run(`UPDATE leads SET next_follow_up_at = '${follow_up_date}', updated_at = '${now}' WHERE id = '${id}';`);

    logLeadActivity(
      db,
      id,
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'FOLLOW_UP_SCHEDULED',
      `Follow-up scheduled for ${follow_up_date} ${follow_up_time || ''}: ${note}`
    );

    saveDb();

    res.status(201).json({ message: 'Follow-up scheduled.', followUpId: folId });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error scheduling follow-up.' });
  }
});

// PATCH /api/leads/follow-ups/:followUpId (Mark completed or cancelled)
router.patch('/leads/follow-ups/:followUpId', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { followUpId } = req.params;
    const { status } = req.body;
    const valid = ['PENDING', 'COMPLETED', 'CANCELLED'];
    if (!valid.includes(status)) {
      res.status(400).json({ error: 'Invalid follow-up status.' });
      return;
    }

    const db = await getDb();
    const folQuery = db.exec(`
      SELECT f.*, l.owner_id, l.assigned_agent_id 
      FROM lead_followups f 
      JOIN leads l ON f.lead_id = l.id
      WHERE f.id = '${followUpId}'
      LIMIT 1;
    `);
    const fols = mapRows(folQuery);
    if (fols.length === 0) {
      res.status(404).json({ error: 'Follow-up not found.' });
      return;
    }

    const fol = fols[0];
    const isOwner = req.user!.id === fol.owner_id;
    const isAssigned = req.user!.id === fol.assigned_agent_id;
    const isAdmin = req.user!.role === 'admin';
    if (!isOwner && !isAssigned && !isAdmin) {
      res.status(403).json({ error: 'Forbidden.' });
      return;
    }

    const now = new Date().toISOString();
    db.run(`UPDATE lead_followups SET status = '${status}', updated_at = '${now}' WHERE id = '${followUpId}';`);

    if (status === 'COMPLETED') {
      logLeadActivity(db, fol.lead_id, req.user!.id, req.user!.name, req.user!.role, 'STATUS_CHANGED', `Follow-up completed: ${fol.note}`);
    }

    saveDb();
    res.json({ message: 'Follow-up updated.', status });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating follow-up.' });
  }
});

// GET /api/dashboard/follow-ups (Upcoming follow-ups for user)
router.get('/dashboard/follow-ups', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const userId = req.user!.id;
    const userRole = req.user!.role;

    let scopeClause = userRole === 'admin' 
      ? "1=1" 
      : `(l.owner_id = '${userId}' OR l.assigned_agent_id = '${userId}')`;

    const query = db.exec(`
      SELECT 
        f.*,
        l.property_id,
        l.status as lead_status,
        c.name as customer_name,
        c.mobile as customer_mobile,
        p.title as property_title
      FROM lead_followups f
      JOIN leads l ON f.lead_id = l.id
      JOIN customer_profiles c ON l.customer_id = c.id
      LEFT JOIN properties p ON l.property_id = p.id
      WHERE f.status = 'PENDING' AND ${scopeClause}
      ORDER BY f.follow_up_date ASC, f.follow_up_time ASC
      LIMIT 20;
    `);

    const followUps = mapRows(query);
    res.json({ followUps });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching upcoming follow-ups.' });
  }
});

// POST /api/leads/:id/site-visits (Schedule Site Visit from Lead)
router.post('/leads/:id/site-visits', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { preferred_date, preferred_time, message } = req.body;

    if (!preferred_date || !preferred_time) {
      res.status(400).json({ error: 'Preferred date and time are required.' });
      return;
    }

    const db = await getDb();
    const leadQuery = db.exec(`
      SELECT l.*, c.name, c.mobile, c.email 
      FROM leads l 
      JOIN customer_profiles c ON l.customer_id = c.id
      WHERE l.id = '${id}' 
      LIMIT 1;
    `);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const lead = leads[0];
    const isOwner = req.user!.id === lead.owner_id;
    const isAssigned = req.user!.id === lead.assigned_agent_id;
    const isAdmin = req.user!.role === 'admin';

    if (!isOwner && !isAssigned && !isAdmin) {
      res.status(403).json({ error: 'Forbidden: You cannot schedule site visits for this lead.' });
      return;
    }

    const visitId = `visit-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    db.run(`
      INSERT INTO site_visits (
        id, property_id, visitor_user_id, visitor_name, visitor_phone, visitor_email,
        preferred_date, preferred_time, message, status, lead_id, owner_id, customer_id, created_at, updated_at
      ) VALUES (
        '${visitId}', '${lead.property_id || ''}', '${lead.customer_id}',
        '${lead.name.replace(/'/g, "''")}', '${lead.mobile.replace(/'/g, "''")}', '${lead.email.replace(/'/g, "''")}',
        '${preferred_date.replace(/'/g, "''")}', '${preferred_time.replace(/'/g, "''")}',
        '${(message || '').replace(/'/g, "''")}', 'REQUESTED', '${id}', '${lead.owner_id}', '${lead.customer_id}',
        '${now}', '${now}'
      );
    `);

    // Advance lead status to SITE_VISIT
    db.run(`UPDATE leads SET status = 'SITE_VISIT', updated_at = '${now}' WHERE id = '${id}';`);

    logLeadActivity(
      db,
      id,
      req.user!.id,
      req.user!.name,
      req.user!.role,
      'SITE_VISIT_REQUESTED',
      `Site visit arranged for ${preferred_date} at ${preferred_time}. Message: ${message || 'Direct appointment'}`
    );

    saveDb();

    res.status(201).json({ message: 'Site visit scheduled.', visitId });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error creating site visit for lead.' });
  }
});

// --------------------------------------------------------------------------
// 11. ADMIN LEAD MANAGEMENT (Full Governance & Assignment)
// --------------------------------------------------------------------------

// GET /api/admin/leads (All leads with deep filtering and platform KPIs)
router.get('/admin/leads', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const {
      status,
      priority,
      source,
      property_id,
      owner_id,
      assigned_agent_id,
      location,
      transaction_type,
      category,
      search,
      date_from,
      date_to
    } = req.query as Record<string, string>;

    const conditions: string[] = ['1=1'];

    if (status && status !== 'ALL') conditions.push(`l.status = '${status.replace(/'/g, "''")}'`);
    if (priority && priority !== 'ALL') conditions.push(`l.priority = '${priority.replace(/'/g, "''")}'`);
    if (source && source !== 'ALL') conditions.push(`l.source = '${source.replace(/'/g, "''")}'`);
    if (property_id && property_id !== 'ALL') conditions.push(`l.property_id = '${property_id.replace(/'/g, "''")}'`);
    if (owner_id && owner_id !== 'ALL') conditions.push(`l.owner_id = '${owner_id.replace(/'/g, "''")}'`);
    if (assigned_agent_id && assigned_agent_id !== 'ALL') conditions.push(`l.assigned_agent_id = '${assigned_agent_id.replace(/'/g, "''")}'`);
    if (category && category !== 'ALL') conditions.push(`l.requirement_type = '${category.toLowerCase().replace(/'/g, "''")}'`);
    if (location && location.trim()) conditions.push(`(p.locality LIKE '%${location.trim().replace(/'/g, "''")}%' OR c.preferred_locations LIKE '%${location.trim().replace(/'/g, "''")}%')`);
    if (transaction_type && transaction_type !== 'ALL') conditions.push(`p.transaction_type = '${transaction_type.toLowerCase().replace(/'/g, "''")}'`);

    if (date_from) conditions.push(`l.created_at >= '${date_from}'`);
    if (date_to) conditions.push(`l.created_at <= '${date_to}'`);

    if (search && search.trim()) {
      const q = search.trim().replace(/'/g, "''");
      conditions.push(`(
        c.name LIKE '%${q}%' OR 
        c.mobile LIKE '%${q}%' OR 
        c.email LIKE '%${q}%' OR 
        p.title LIKE '%${q}%' OR 
        p.locality LIKE '%${q}%' OR 
        l.id LIKE '%${q}%'
      )`);
    }

    const whereClause = `WHERE ${conditions.join(' AND ')}`;

    const query = db.exec(`
      SELECT 
        l.*,
        c.name as customer_name,
        c.mobile as customer_mobile,
        c.email as customer_email,
        c.customer_type as customer_type,
        c.preferred_transaction as customer_transaction,
        c.preferred_locations as customer_locations,
        c.budget_min as customer_budget_min,
        c.budget_max as customer_budget_max,
        c.notes as customer_notes,
        p.title as property_title,
        p.locality as property_locality,
        p.category as property_category,
        p.transaction_type as property_transaction_type,
        p.property_type as property_type_val,
        p.price as property_price,
        p.rent as property_rent,
        u_owner.name as owner_name,
        u_owner.email as owner_email,
        u_agent.name as assigned_agent_name,
        u_agent.email as assigned_agent_email
      FROM leads l
      JOIN customer_profiles c ON l.customer_id = c.id
      LEFT JOIN properties p ON l.property_id = p.id
      LEFT JOIN users u_owner ON l.owner_id = u_owner.id
      LEFT JOIN users u_agent ON l.assigned_agent_id = u_agent.id
      ${whereClause}
      ORDER BY l.created_at DESC;
    `);

    const rawLeads = mapRows(query);

    const leads = rawLeads.map((r) => {
      let primaryImage = '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg';
      if (r.property_id) {
        const imgQuery = db.exec(`
          SELECT image_url FROM property_images 
          WHERE property_id = '${r.property_id}' 
          ORDER BY is_primary DESC, display_order ASC LIMIT 1;
        `);
        const imgRows = mapRows(imgQuery);
        if (imgRows.length > 0) primaryImage = imgRows[0].image_url;
      }

      const folQuery = db.exec(`
        SELECT * FROM lead_followups 
        WHERE lead_id = '${r.id}' AND status = 'PENDING'
        ORDER BY follow_up_date ASC LIMIT 1;
      `);
      const nextFollowUp = mapRows(folQuery)[0] || null;

      return {
        id: r.id,
        propertyId: r.property_id,
        customerId: r.customer_id,
        ownerId: r.owner_id,
        assignedAgentId: r.assigned_agent_id,
        source: r.source,
        status: r.status,
        priority: r.priority,
        customerMessage: r.customer_message,
        internalNotes: r.internal_notes,
        preferredContactMethod: r.preferred_contact_method,
        budget: r.budget,
        requirementType: r.requirement_type,
        businessType: r.business_type,
        requiredCarpetArea: r.required_carpet_area,
        bhk: r.bhk,
        lastContactedAt: r.last_contacted_at,
        nextFollowUpAt: r.next_follow_up_at,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
        customer: {
          id: r.customer_id,
          name: r.customer_name,
          mobile: r.customer_mobile,
          email: r.customer_email,
          customerType: r.customer_type,
          preferredTransaction: r.customer_transaction,
          preferredLocations: r.customer_locations,
          budgetMin: r.customer_budget_min,
          budgetMax: r.customer_budget_max,
          notes: r.customer_notes
        },
        property: r.property_id ? {
          id: r.property_id,
          title: r.property_title,
          category: r.property_category,
          transactionType: r.property_transaction_type,
          propertyType: r.property_type_val,
          locality: r.property_locality,
          price: r.property_price,
          rent: r.property_rent,
          primaryImage
        } : undefined,
        ownerName: r.owner_name,
        ownerEmail: r.owner_email,
        assignedAgentName: r.assigned_agent_name,
        assignedAgentEmail: r.assigned_agent_email,
        nextFollowUp
      };
    });

    // Global Admin KPIs
    const countAll = (st: string) => {
      const res = db.exec(`SELECT COUNT(*) FROM leads WHERE status = '${st}';`);
      return Number(res[0]?.values[0]?.[0] || 0);
    };

    const totalRes = db.exec("SELECT COUNT(*) FROM leads;");
    const totalLeads = Number(totalRes[0]?.values[0]?.[0] || 0);

    const activeRes = db.exec("SELECT COUNT(*) FROM leads WHERE status NOT IN ('WON', 'LOST', 'CLOSED');");
    const activeLeads = Number(activeRes[0]?.values[0]?.[0] || 0);

    const kpis = {
      totalLeads,
      newLeads: countAll('NEW'),
      activeLeads,
      siteVisits: countAll('SITE_VISIT'),
      negotiations: countAll('NEGOTIATING'),
      wonDeals: countAll('WON'),
      lostLeads: countAll('LOST')
    };

    res.json({ leads, kpis });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching admin leads.' });
  }
});

// PATCH /api/admin/leads/:id/assign (Assign or Reassign lead to Agent / Owner)
router.patch('/admin/leads/:id/assign', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { assigned_to_id, notes } = req.body;

    if (!assigned_to_id) {
      res.status(400).json({ error: 'Please choose an agent or user to assign this lead.' });
      return;
    }

    const db = await getDb();
    const leadQuery = db.exec(`SELECT * FROM leads WHERE id = '${id}' LIMIT 1;`);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }

    const userQuery = db.exec(`SELECT id, name, role FROM users WHERE id = '${assigned_to_id}' LIMIT 1;`);
    const users = mapRows(userQuery);
    if (users.length === 0) {
      res.status(404).json({ error: 'Assigned user does not exist.' });
      return;
    }
    const targetUser = users[0];

    const now = new Date().toISOString();
    const assignId = `asgn-${Date.now()}-${Math.round(Math.random() * 1000)}`;

    // Update lead
    db.run(`
      UPDATE leads 
      SET assigned_agent_id = '${targetUser.id}', 
          updated_at = '${now}' 
      WHERE id = '${id}';
    `);

    // Record assignment history
    db.run(`
      INSERT INTO lead_assignments (
        id, lead_id, assigned_by_id, assigned_by_name, assigned_to_id, assigned_to_name, assigned_to_role, notes, created_at
      ) VALUES (
        '${assignId}', '${id}', '${req.user!.id}', '${req.user!.name.replace(/'/g, "''")}',
        '${targetUser.id}', '${targetUser.name.replace(/'/g, "''")}', '${targetUser.role}',
        '${(notes || '').replace(/'/g, "''")}', '${now}'
      );
    `);

    // Log activity timeline
    logLeadActivity(
      db,
      id,
      req.user!.id,
      req.user!.name,
      'admin',
      'LEAD_ASSIGNED',
      `Lead assigned to ${targetUser.name} (${targetUser.role}). Notes: ${notes || 'Assigned by admin'}`
    );

    // Audit log
    logAudit(
      db,
      req.user!.id,
      req.user!.name,
      'LEAD_ASSIGNED',
      'lead',
      id,
      `Assigned lead to ${targetUser.name} (${targetUser.id})`
    );

    saveDb();

    res.json({
      message: `Lead successfully assigned to ${targetUser.name}.`,
      assignedTo: { id: targetUser.id, name: targetUser.name, role: targetUser.role }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error assigning lead.' });
  }
});

// GET /api/admin/agents-list (List of users available for lead assignment)
router.get('/admin/agents-list', authMiddleware, adminMiddleware, async (_req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const query = db.exec(`
      SELECT id, name, email, phone, role 
      FROM users 
      WHERE role IN ('agent', 'owner', 'admin') AND account_status = 'ACTIVE'
      ORDER BY role ASC, name ASC;
    `);
    const agents = mapRows(query);
    res.json({ agents });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching agents list.' });
  }
});

// =================================================================
// PHASE 5: DEAL, BROKERAGE & COMMISSION MANAGEMENT ROUTES
// =================================================================

// 1. Convert Lead to Deal
router.post('/leads/:id/convert-to-deal', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const user = req.user!;

    // Role check: Only admin, owner, or agent can convert
    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized owners, agents, and administrators.' });
      return;
    }

    // 1. Verify lead exists
    const leadQuery = db.exec(`SELECT * FROM leads WHERE id = '${id}' LIMIT 1;`);
    const leads = mapRows(leadQuery);
    if (leads.length === 0) {
      res.status(404).json({ error: 'Lead not found.' });
      return;
    }
    const lead = leads[0];

    // 2. Verify user has permission (Admin, or Owner of lead, or Assigned Agent)
    const isAdmin = user.role === 'admin';
    const isOwner = lead.owner_id === user.id;
    const isAgent = lead.assigned_agent_id === user.id;

    if (!isAdmin && !isOwner && !isAgent) {
      res.status(403).json({ error: 'You are not authorized to convert this lead into a deal.' });
      return;
    }

    // 3. Prevent duplicate active deals unless admin explicitly allows
    const allowDuplicate = req.body.allow_duplicate === true && isAdmin;
    const existingDealsQuery = db.exec(`
      SELECT * FROM deals 
      WHERE lead_id = '${id}' AND deal_status NOT IN ('CANCELLED', 'FAILED')
      ORDER BY created_at DESC LIMIT 1;
    `);
    const existingDeals = mapRows(existingDealsQuery);
    if (existingDeals.length > 0 && !allowDuplicate) {
      res.status(409).json({
        error: `An active deal already exists for this lead (${existingDeals[0].deal_number}).`,
        existingDealId: existingDeals[0].id,
        existingDealNumber: existingDeals[0].deal_number,
        dealStatus: existingDeals[0].deal_status
      });
      return;
    }

    // 4. Fetch Property & Customer to auto-fill defaults
    const propQuery = db.exec(`SELECT * FROM properties WHERE id = '${lead.property_id}' LIMIT 1;`);
    const props = mapRows(propQuery);
    const prop = props[0] || {};

    const {
      transaction_type = prop.transaction_type ? prop.transaction_type.toUpperCase() : 'BUY',
      category = prop.category ? prop.category.toUpperCase() : 'RESIDENTIAL',
      deal_status = 'NEGOTIATION',
      agreed_property_value = prop.price || lead.budget || null,
      agreed_rent = prop.rent || null,
      agreed_lease_value = null,
      commission_type = 'PERCENTAGE',
      commission_rate = 1.0,
      commission_payer = transaction_type === 'RENT' || transaction_type === 'LEASE' ? 'TENANT' : 'BUYER',
      expected_closing_date,
      notes
    } = req.body;

    // 5. Commission calculation
    let calculatedAmount = 0;
    let baseValue = 0;

    if (transaction_type === 'BUY') {
      baseValue = Number(agreed_property_value) || 0;
    } else if (transaction_type === 'RENT') {
      baseValue = Number(agreed_rent) || 0;
    } else {
      baseValue = Number(agreed_lease_value) || 0;
    }

    if (commission_type === 'PERCENTAGE') {
      const rateNum = Number(commission_rate) || 0;
      calculatedAmount = (baseValue * rateNum) / 100;
    } else {
      calculatedAmount = Number(req.body.commission_amount) || 0;
    }

    const initialCommStatus = calculatedAmount > 0 ? 'AGREED' : 'NOT_SET';
    const now = new Date().toISOString();
    const dealId = `deal-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const dealNumber = `DEAL-${new Date().getFullYear()}-${randomSuffix}`;

    const cleanNotes = (notes || `Converted from lead ${lead.id}`).replace(/'/g, "''");
    const cleanClosingDate = expected_closing_date ? `'${expected_closing_date}'` : 'NULL';

    // 6. Insert Deal
    db.run(`
      INSERT INTO deals (
        id, deal_number, lead_id, property_id, customer_id, owner_id, assigned_agent_id,
        transaction_type, category, deal_status, agreed_property_value, agreed_rent, agreed_lease_value,
        commission_type, commission_rate, commission_base, commission_amount,
        commission_payer, commission_status, expected_closing_date, notes,
        created_at, updated_at
      ) VALUES (
        '${dealId}', '${dealNumber}', '${lead.id}', '${lead.property_id}', '${lead.customer_id}',
        '${lead.owner_id}', ${lead.assigned_agent_id ? `'${lead.assigned_agent_id}'` : 'NULL'},
        '${transaction_type}', '${category}', '${deal_status}',
        ${agreed_property_value ? Number(agreed_property_value) : 'NULL'},
        ${agreed_rent ? Number(agreed_rent) : 'NULL'},
        ${agreed_lease_value ? Number(agreed_lease_value) : 'NULL'},
        '${commission_type}', ${Number(commission_rate) || 0}, ${baseValue}, ${calculatedAmount},
        '${commission_payer}', '${initialCommStatus}', ${cleanClosingDate}, '${cleanNotes}',
        '${now}', '${now}'
      );
    `);

    // 7. Update lead status if appropriate and add activity
    db.run(`
      UPDATE leads 
      SET status = CASE WHEN status IN ('NEW', 'CONTACTED', 'QUALIFIED', 'SITE_VISIT') THEN 'NEGOTIATING' ELSE status END,
          updated_at = '${now}'
      WHERE id = '${lead.id}';
    `);

    logLeadActivity(
      db,
      lead.id,
      user.id,
      user.name,
      user.role,
      'CONVERTED_TO_DEAL',
      `Lead converted to transaction deal ${dealNumber} (${transaction_type} / ₹${baseValue.toLocaleString('en-IN')})`
    );

    // 8. Add activity on Deal
    logDealActivity(
      db,
      dealId,
      user.id,
      user.name,
      user.role,
      'DEAL_CREATED',
      `Deal created from lead ${lead.id} with agreed value ₹${baseValue.toLocaleString('en-IN')}`
    );

    // 9. Add Audit log
    logAudit(
      db,
      user.id,
      user.name,
      'CONVERT_LEAD_TO_DEAL',
      'deal',
      dealId,
      `Converted lead ${lead.id} into deal ${dealNumber}`
    );

    saveDb();

    res.status(201).json({
      message: 'Lead successfully converted to deal.',
      dealId,
      dealNumber,
      dealStatus: deal_status,
      commissionAmount: calculatedAmount
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error converting lead to deal.' });
  }
});

// 2. Check if a deal exists for a lead
router.get('/leads/:id/deal', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const user = req.user!;

    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized personnel.' });
      return;
    }

    const query = db.exec(`
      SELECT * FROM deals 
      WHERE lead_id = '${id}' 
      ORDER BY created_at DESC 
      LIMIT 1;
    `);
    const deals = mapRows(query);
    if (deals.length === 0) {
      res.json({ deal: null });
      return;
    }

    const deal = deals[0];
    // Check permission
    if (user.role !== 'admin' && deal.owner_id !== user.id && deal.assigned_agent_id !== user.id) {
      res.status(403).json({ error: 'Not authorized to view this deal.' });
      return;
    }

    res.json({ deal });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error checking lead deal.' });
  }
});

// 3. List Deals (Dashboard / Admin)
router.get('/deals', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const user = req.user!;
    const db = await getDb();

    // Role check: buyers and tenants cannot access internal deal system
    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized owners, agents, and administrators.' });
      return;
    }

    const {
      status,
      commission_status,
      transaction_type,
      category,
      lead_id,
      search
    } = req.query;

    let whereClauses: string[] = [];

    // Role based ownership filtering
    if (user.role === 'admin') {
      // Admins see all
    } else if (user.role === 'owner') {
      whereClauses.push(`(d.owner_id = '${user.id}' OR d.assigned_agent_id = '${user.id}')`);
    } else if (user.role === 'agent') {
      whereClauses.push(`(d.assigned_agent_id = '${user.id}' OR d.owner_id = '${user.id}')`);
    }

    if (status && typeof status === 'string' && status !== 'ALL') {
      whereClauses.push(`d.deal_status = '${status}'`);
    }
    if (commission_status && typeof commission_status === 'string' && commission_status !== 'ALL') {
      whereClauses.push(`d.commission_status = '${commission_status}'`);
    }
    if (transaction_type && typeof transaction_type === 'string' && transaction_type !== 'ALL') {
      whereClauses.push(`d.transaction_type = '${transaction_type.toUpperCase()}'`);
    }
    if (category && typeof category === 'string' && category !== 'ALL') {
      whereClauses.push(`d.category = '${category.toUpperCase()}'`);
    }
    if (lead_id && typeof lead_id === 'string') {
      whereClauses.push(`d.lead_id = '${lead_id}'`);
    }
    if (search && typeof search === 'string') {
      const s = search.replace(/'/g, "''");
      whereClauses.push(`(
        d.deal_number LIKE '%${s}%' OR 
        p.title LIKE '%${s}%' OR 
        p.locality LIKE '%${s}%' OR 
        c.name LIKE '%${s}%' OR 
        c.mobile LIKE '%${s}%' OR 
        c.email LIKE '%${s}%'
      )`);
    }

    const whereStr = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    const sql = `
      SELECT 
        d.*,
        p.title as property_title,
        p.locality as property_locality,
        p.city as property_city,
        p.price as property_price,
        p.rent as property_rent,
        p.category as property_category,
        p.transaction_type as property_transaction_type,
        p.property_type as property_sub_type,
        p.bedrooms as property_bedrooms,
        (SELECT image_url FROM property_images WHERE property_id = p.id LIMIT 1) as property_photo,
        c.name as customer_name,
        c.mobile as customer_mobile,
        c.email as customer_email,
        c.customer_type as customer_type,
        u_owner.name as owner_name,
        u_owner.email as owner_email,
        u_owner.phone as owner_phone,
        u_agent.name as agent_name,
        u_agent.email as agent_email,
        u_agent.phone as agent_phone,
        COALESCE((SELECT SUM(amount) FROM deal_payments WHERE deal_id = d.id), 0) as paid_amount
      FROM deals d
      LEFT JOIN properties p ON d.property_id = p.id
      LEFT JOIN customer_profiles c ON d.customer_id = c.id
      LEFT JOIN users u_owner ON d.owner_id = u_owner.id
      LEFT JOIN users u_agent ON d.assigned_agent_id = u_agent.id
      ${whereStr}
      ORDER BY d.created_at DESC;
    `;

    const dealsRes = db.exec(sql);
    const rawDeals = mapRows(dealsRes);

    const deals = rawDeals.map((r: any) => {
      const paid = Number(r.paid_amount || 0);
      const commAmount = Number(r.commission_amount || 0);
      const remaining = Math.max(0, commAmount - paid);

      return {
        id: r.id,
        dealNumber: r.deal_number,
        leadId: r.lead_id,
        propertyId: r.property_id,
        customerId: r.customer_id,
        ownerId: r.owner_id,
        assignedAgentId: r.assigned_agent_id,
        transactionType: r.transaction_type,
        category: r.category,
        dealStatus: r.deal_status,
        agreedPropertyValue: r.agreed_property_value,
        agreedRent: r.agreed_rent,
        agreedLeaseValue: r.agreed_lease_value,
        commissionType: r.commission_type,
        commissionRate: r.commission_rate,
        commissionBase: r.commission_base,
        commissionAmount: commAmount,
        commissionPayer: r.commission_payer,
        commissionStatus: r.commission_status,
        expectedClosingDate: r.expected_closing_date,
        actualClosingDate: r.actual_closing_date,
        notes: r.notes,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
        paidAmount: paid,
        remainingAmount: remaining,
        property: {
          id: r.property_id,
          title: r.property_title || 'Property',
          locality: r.property_locality || 'Mumbai',
          city: r.property_city || 'Mumbai',
          price: r.property_price,
          monthly_rent: r.property_rent,
          primary_photo: r.property_photo,
          category: r.property_category,
          transaction_type: r.property_transaction_type,
          property_type: r.property_sub_type,
          bedrooms: r.property_bedrooms
        },
        customer: {
          id: r.customer_id,
          name: r.customer_name || 'Customer',
          mobile: r.customer_mobile || '',
          email: r.customer_email || '',
          customerType: r.customer_type || 'BUYER'
        },
        owner: {
          id: r.owner_id,
          name: r.owner_name || 'Owner',
          email: r.owner_email || '',
          phone: r.owner_phone || ''
        },
        assignedAgent: r.assigned_agent_id ? {
          id: r.assigned_agent_id,
          name: r.agent_name || 'Agent',
          email: r.agent_email || '',
          phone: r.agent_phone || ''
        } : undefined
      };
    });

    // Compute stats
    let totalVolume = 0;
    let totalCommissionBooked = 0;
    let totalCommissionCollected = 0;
    let totalOutstandingCommission = 0;
    let activeDeals = 0;
    let completedDeals = 0;
    let cancelledDeals = 0;

    deals.forEach((d: any) => {
      const vol = (d.agreedPropertyValue || d.agreedRent || d.agreedLeaseValue || 0);
      if (d.dealStatus === 'COMPLETED') {
        completedDeals++;
        totalVolume += vol;
      } else if (d.dealStatus === 'CANCELLED' || d.dealStatus === 'FAILED') {
        cancelledDeals++;
      } else {
        activeDeals++;
        totalVolume += vol;
      }

      totalCommissionBooked += d.commissionAmount;
      totalCommissionCollected += (d.paidAmount || 0);
      totalOutstandingCommission += (d.remainingAmount || 0);
    });

    res.json({
      deals,
      stats: {
        totalDeals: deals.length,
        activeDeals,
        completedDeals,
        cancelledDeals,
        totalVolume,
        totalCommissionBooked,
        totalCommissionCollected,
        totalOutstandingCommission
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error listing deals.' });
  }
});

// 4. Single Deal Detail
router.get('/deals/:id', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized owners, agents, and administrators.' });
      return;
    }

    const sql = `
      SELECT 
        d.*,
        p.title as property_title,
        p.locality as property_locality,
        p.city as property_city,
        p.price as property_price,
        p.rent as property_rent,
        NULL as property_lease_rate_psf,
        p.category as property_category,
        p.transaction_type as property_transaction_type,
        p.property_type as property_sub_type,
        p.bedrooms as property_bedrooms,
        p.carpet_area as property_carpet_area,
        (SELECT image_url FROM property_images WHERE property_id = p.id LIMIT 1) as property_photo,
        c.name as customer_name,
        c.mobile as customer_mobile,
        c.email as customer_email,
        c.customer_type as customer_type,
        c.notes as customer_notes,
        u_owner.name as owner_name,
        u_owner.email as owner_email,
        u_owner.phone as owner_phone,
        u_agent.name as agent_name,
        u_agent.email as agent_email,
        u_agent.phone as agent_phone,
        COALESCE((SELECT SUM(amount) FROM deal_payments WHERE deal_id = d.id), 0) as paid_amount
      FROM deals d
      LEFT JOIN properties p ON d.property_id = p.id
      LEFT JOIN customer_profiles c ON d.customer_id = c.id
      LEFT JOIN users u_owner ON d.owner_id = u_owner.id
      LEFT JOIN users u_agent ON d.assigned_agent_id = u_agent.id
      WHERE d.id = '${id}'
      LIMIT 1;
    `;

    const dealsRes = db.exec(sql);
    const rawDeals = mapRows(dealsRes);
    if (rawDeals.length === 0) {
      res.status(404).json({ error: 'Deal not found.' });
      return;
    }

    const r = rawDeals[0];

    // Authorization check
    if (user.role !== 'admin' && r.owner_id !== user.id && r.assigned_agent_id !== user.id) {
      res.status(403).json({ error: 'You are not authorized to view this deal.' });
      return;
    }

    // Fetch payments
    const paymentsRes = db.exec(`
      SELECT * FROM deal_payments 
      WHERE deal_id = '${id}' 
      ORDER BY payment_date DESC, created_at DESC;
    `);
    const rawPayments = mapRows(paymentsRes);
    const payments = rawPayments.map((p: any) => ({
      id: p.id,
      dealId: p.deal_id,
      receiptNumber: p.receipt_number,
      amount: Number(p.amount),
      paymentMethod: p.payment_method,
      transactionReference: p.transaction_reference,
      paymentDate: p.payment_date,
      payerName: p.payer_name,
      recordedById: p.recorded_by_id,
      recordedByName: p.recorded_by_name,
      notes: p.notes,
      createdAt: p.created_at
    }));

    // Fetch invoices
    const invoicesRes = db.exec(`
      SELECT * FROM deal_invoices 
      WHERE deal_id = '${id}' 
      ORDER BY issue_date DESC, created_at DESC;
    `);
    const rawInvoices = mapRows(invoicesRes);
    const invoices = rawInvoices.map((inv: any) => ({
      id: inv.id,
      dealId: inv.deal_id,
      invoiceNumber: inv.invoice_number,
      issueDate: inv.issue_date,
      dueDate: inv.due_date,
      subtotal: Number(inv.subtotal),
      gstRate: Number(inv.gst_rate),
      gstAmount: Number(inv.gst_amount),
      totalAmount: Number(inv.total_amount),
      status: inv.status,
      notes: inv.notes,
      createdAt: inv.created_at
    }));

    // Fetch activities
    const actRes = db.exec(`
      SELECT * FROM deal_activities 
      WHERE deal_id = '${id}' 
      ORDER BY created_at DESC;
    `);
    const rawActs = mapRows(actRes);
    const activities = rawActs.map((a: any) => ({
      id: a.id,
      dealId: a.deal_id,
      performedById: a.performed_by_id,
      performedByName: a.performed_by_name,
      performedByRole: a.performed_by_role,
      action: a.action,
      details: a.details,
      createdAt: a.created_at
    }));

    const paid = Number(r.paid_amount || 0);
    const commAmount = Number(r.commission_amount || 0);
    const remaining = Math.max(0, commAmount - paid);

    const deal = {
      id: r.id,
      dealNumber: r.deal_number,
      leadId: r.lead_id,
      propertyId: r.property_id,
      customerId: r.customer_id,
      ownerId: r.owner_id,
      assignedAgentId: r.assigned_agent_id,
      transactionType: r.transaction_type,
      category: r.category,
      dealStatus: r.deal_status,
      agreedPropertyValue: r.agreed_property_value,
      agreedRent: r.agreed_rent,
      agreedLeaseValue: r.agreed_lease_value,
      commissionType: r.commission_type,
      commissionRate: r.commission_rate,
      commissionBase: r.commission_base,
      commissionAmount: commAmount,
      commissionPayer: r.commission_payer,
      commissionStatus: r.commission_status,
      expectedClosingDate: r.expected_closing_date,
      actualClosingDate: r.actual_closing_date,
      notes: r.notes,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      paidAmount: paid,
      remainingAmount: remaining,
      property: {
        id: r.property_id,
        title: r.property_title || 'Property',
        locality: r.property_locality || 'Mumbai',
        city: r.property_city || 'Mumbai',
        price: r.property_price,
        monthly_rent: r.property_rent,
        primary_photo: r.property_photo,
        category: r.property_category,
        transaction_type: r.property_transaction_type,
        property_type: r.property_sub_type,
        bedrooms: r.property_bedrooms,
        carpet_area: r.property_carpet_area
      },
      customer: {
        id: r.customer_id,
        name: r.customer_name || 'Customer',
        mobile: r.customer_mobile || '',
        email: r.customer_email || '',
        customerType: r.customer_type || 'BUYER',
        notes: r.customer_notes
      },
      owner: {
        id: r.owner_id,
        name: r.owner_name || 'Owner',
        email: r.owner_email || '',
        phone: r.owner_phone || ''
      },
      assignedAgent: r.assigned_agent_id ? {
        id: r.assigned_agent_id,
        name: r.agent_name || 'Agent',
        email: r.agent_email || '',
        phone: r.agent_phone || ''
      } : undefined,
      payments,
      invoices,
      activities
    };

    res.json({ deal });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching deal.' });
  }
});

// 5. Update Deal Status & Details
router.patch('/deals/:id', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized personnel.' });
      return;
    }

    const checkRes = db.exec(`SELECT * FROM deals WHERE id = '${id}' LIMIT 1;`);
    const deals = mapRows(checkRes);
    if (deals.length === 0) {
      res.status(404).json({ error: 'Deal not found.' });
      return;
    }
    const currentDeal = deals[0];

    // Authorization
    if (user.role !== 'admin' && currentDeal.owner_id !== user.id && currentDeal.assigned_agent_id !== user.id) {
      res.status(403).json({ error: 'Not authorized to modify this deal.' });
      return;
    }

    const {
      deal_status,
      agreed_property_value,
      agreed_rent,
      agreed_lease_value,
      expected_closing_date,
      actual_closing_date,
      assigned_agent_id,
      notes
    } = req.body;

    const allowedStatuses = [
      'NEGOTIATION',
      'AGREED',
      'AGREEMENT_PENDING',
      'AGREEMENT_SIGNED',
      'PAYMENT_PENDING',
      'COMPLETED',
      'CANCELLED',
      'FAILED'
    ];

    let updates: string[] = [];
    const now = new Date().toISOString();

    if (deal_status) {
      if (!allowedStatuses.includes(deal_status)) {
        res.status(400).json({ error: `Invalid deal status: ${deal_status}` });
        return;
      }
      updates.push(`deal_status = '${deal_status}'`);

      if (deal_status !== currentDeal.deal_status) {
        logDealActivity(
          db,
          id,
          user.id,
          user.name,
          user.role,
          'STATUS_CHANGED',
          `Deal status changed from ${currentDeal.deal_status} to ${deal_status}`
        );

        // If completed and closing date not provided, set actual_closing_date
        if (deal_status === 'COMPLETED' && !actual_closing_date && !currentDeal.actual_closing_date) {
          updates.push(`actual_closing_date = '${now.split('T')[0]}'`);
        }
      }
    }

    if (agreed_property_value !== undefined) {
      updates.push(`agreed_property_value = ${agreed_property_value ? Number(agreed_property_value) : 'NULL'}`);
    }
    if (agreed_rent !== undefined) {
      updates.push(`agreed_rent = ${agreed_rent ? Number(agreed_rent) : 'NULL'}`);
    }
    if (agreed_lease_value !== undefined) {
      updates.push(`agreed_lease_value = ${agreed_lease_value ? Number(agreed_lease_value) : 'NULL'}`);
    }
    if (expected_closing_date !== undefined) {
      updates.push(`expected_closing_date = ${expected_closing_date ? `'${expected_closing_date}'` : 'NULL'}`);
    }
    if (actual_closing_date !== undefined) {
      updates.push(`actual_closing_date = ${actual_closing_date ? `'${actual_closing_date}'` : 'NULL'}`);
    }
    if (assigned_agent_id !== undefined && user.role === 'admin') {
      updates.push(`assigned_agent_id = ${assigned_agent_id ? `'${assigned_agent_id}'` : 'NULL'}`);
    }
    if (notes !== undefined) {
      updates.push(`notes = '${notes.replace(/'/g, "''")}'`);
    }

    updates.push(`updated_at = '${now}'`);

    db.run(`
      UPDATE deals 
      SET ${updates.join(', ')}
      WHERE id = '${id}';
    `);

    logAudit(
      db,
      user.id,
      user.name,
      'UPDATE_DEAL',
      'deal',
      id,
      `Updated deal attributes: status=${deal_status || currentDeal.deal_status}`
    );

    saveDb();

    res.json({ message: 'Deal updated successfully.', status: deal_status || currentDeal.deal_status });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating deal.' });
  }
});

// 6. Update Commission Settings (Flexible Brokerage Engine)
router.patch('/deals/:id/commission', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized personnel.' });
      return;
    }

    const checkRes = db.exec(`SELECT * FROM deals WHERE id = '${id}' LIMIT 1;`);
    const deals = mapRows(checkRes);
    if (deals.length === 0) {
      res.status(404).json({ error: 'Deal not found.' });
      return;
    }
    const currentDeal = deals[0];

    // Authorization
    if (user.role !== 'admin' && currentDeal.owner_id !== user.id && currentDeal.assigned_agent_id !== user.id) {
      res.status(403).json({ error: 'Not authorized to modify commission for this deal.' });
      return;
    }

    const {
      commission_type = currentDeal.commission_type || 'PERCENTAGE',
      commission_rate = currentDeal.commission_rate,
      commission_amount,
      commission_payer = currentDeal.commission_payer || 'BUYER',
      commission_status
    } = req.body;

    // Determine base value from current deal agreed numbers
    let baseValue = 0;
    if (currentDeal.transaction_type === 'BUY') {
      baseValue = currentDeal.agreed_property_value || 0;
    } else if (currentDeal.transaction_type === 'RENT') {
      baseValue = currentDeal.agreed_rent || 0;
    } else {
      baseValue = currentDeal.agreed_lease_value || 0;
    }

    let calculatedAmount = 0;
    if (commission_type === 'PERCENTAGE') {
      const rate = Number(commission_rate) || 0;
      calculatedAmount = (baseValue * rate) / 100;
    } else {
      calculatedAmount = Number(commission_amount) !== undefined ? Number(commission_amount) : (Number(currentDeal.commission_amount) || 0);
    }

    // Check payment sum to determine appropriate commission status if not explicitly given
    const payRes = db.exec(`SELECT SUM(amount) as paid FROM deal_payments WHERE deal_id = '${id}';`);
    const paidSum = Number(payRes[0]?.values[0]?.[0] || 0);

    let nextStatus = commission_status || currentDeal.commission_status;
    if (!commission_status) {
      if (paidSum >= calculatedAmount && calculatedAmount > 0) {
        nextStatus = 'PAID';
      } else if (paidSum > 0) {
        nextStatus = 'PARTIALLY_PAID';
      } else if (nextStatus === 'NOT_SET' && calculatedAmount > 0) {
        nextStatus = 'AGREED';
      }
    }

    const now = new Date().toISOString();

    db.run(`
      UPDATE deals 
      SET commission_type = '${commission_type}',
          commission_rate = ${Number(commission_rate) || 0},
          commission_base = ${baseValue},
          commission_amount = ${calculatedAmount},
          commission_payer = '${commission_payer}',
          commission_status = '${nextStatus}',
          updated_at = '${now}'
      WHERE id = '${id}';
    `);

    logDealActivity(
      db,
      id,
      user.id,
      user.name,
      user.role,
      'COMMISSION_UPDATED',
      `Commission updated: ${commission_type} (${commission_rate}%) = ₹${calculatedAmount.toLocaleString('en-IN')}, payer: ${commission_payer}, status: ${nextStatus}`
    );

    logAudit(
      db,
      user.id,
      user.name,
      'UPDATE_COMMISSION',
      'deal',
      id,
      `Commission set to ₹${calculatedAmount} (${commission_type})`
    );

    saveDb();

    res.json({
      message: 'Commission updated successfully.',
      commissionAmount: calculatedAmount,
      commissionStatus: nextStatus,
      commissionPayer: commission_payer
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating commission.' });
  }
});

// 7. Record Payment Against Commission
router.post('/deals/:id/payments', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized personnel.' });
      return;
    }

    const checkRes = db.exec(`SELECT * FROM deals WHERE id = '${id}' LIMIT 1;`);
    const deals = mapRows(checkRes);
    if (deals.length === 0) {
      res.status(404).json({ error: 'Deal not found.' });
      return;
    }
    const currentDeal = deals[0];

    // Authorization
    if (user.role !== 'admin' && currentDeal.owner_id !== user.id && currentDeal.assigned_agent_id !== user.id) {
      res.status(403).json({ error: 'Not authorized to record payments for this deal.' });
      return;
    }

    const {
      amount,
      payment_method = 'UPI',
      transaction_reference,
      payment_date = new Date().toISOString().split('T')[0],
      payer_name = currentDeal.commission_payer,
      notes
    } = req.body;

    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) {
      res.status(400).json({ error: 'A valid positive payment amount is required.' });
      return;
    }

    const paymentId = `pay-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const randomReceipt = Math.floor(1000 + Math.random() * 9000);
    const receiptNumber = `REC-${new Date().getFullYear()}-${randomReceipt}`;
    const now = new Date().toISOString();

    const cleanRef = (transaction_reference || '').replace(/'/g, "''");
    const cleanPayer = (payer_name || '').replace(/'/g, "''");
    const cleanNotes = (notes || '').replace(/'/g, "''");

    db.run(`
      INSERT INTO deal_payments (
        id, deal_id, receipt_number, amount, payment_method, transaction_reference,
        payment_date, payer_name, recorded_by_id, recorded_by_name, notes, created_at
      ) VALUES (
        '${paymentId}', '${id}', '${receiptNumber}', ${numAmount}, '${payment_method}',
        '${cleanRef}', '${payment_date}', '${cleanPayer}', '${user.id}',
        '${user.name.replace(/'/g, "''")}', '${cleanNotes}', '${now}'
      );
    `);

    // Recalculate total paid amount
    const payRes = db.exec(`SELECT SUM(amount) as paid FROM deal_payments WHERE deal_id = '${id}';`);
    const totalPaid = Number(payRes[0]?.values[0]?.[0] || 0);
    const commTotal = Number(currentDeal.commission_amount) || 0;

    let updatedCommStatus = currentDeal.commission_status;
    if (totalPaid >= commTotal && commTotal > 0) {
      updatedCommStatus = 'PAID';
    } else if (totalPaid > 0) {
      updatedCommStatus = 'PARTIALLY_PAID';
    }

    db.run(`
      UPDATE deals 
      SET commission_status = '${updatedCommStatus}',
          updated_at = '${now}'
      WHERE id = '${id}';
    `);

    logDealActivity(
      db,
      id,
      user.id,
      user.name,
      user.role,
      'PAYMENT_RECORDED',
      `Payment of ₹${numAmount.toLocaleString('en-IN')} recorded via ${payment_method} (${receiptNumber})`
    );

    logAudit(
      db,
      user.id,
      user.name,
      'RECORD_PAYMENT',
      'deal',
      id,
      `Recorded commission payment ₹${numAmount} (${receiptNumber})`
    );

    saveDb();

    res.status(201).json({
      message: 'Payment recorded successfully.',
      payment: {
        id: paymentId,
        receiptNumber,
        amount: numAmount,
        paymentMethod: payment_method,
        transactionReference: transaction_reference,
        paymentDate: payment_date,
        payerName: payer_name,
        totalPaid,
        remainingAmount: Math.max(0, commTotal - totalPaid),
        commissionStatus: updatedCommStatus
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error recording payment.' });
  }
});

// 8. Generate Professional Brokerage Invoice
router.post('/deals/:id/invoices', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized personnel.' });
      return;
    }

    const checkRes = db.exec(`SELECT * FROM deals WHERE id = '${id}' LIMIT 1;`);
    const deals = mapRows(checkRes);
    if (deals.length === 0) {
      res.status(404).json({ error: 'Deal not found.' });
      return;
    }
    const currentDeal = deals[0];

    // Authorization
    if (user.role !== 'admin' && currentDeal.owner_id !== user.id && currentDeal.assigned_agent_id !== user.id) {
      res.status(403).json({ error: 'Not authorized to generate invoices for this deal.' });
      return;
    }

    const {
      issue_date = new Date().toISOString().split('T')[0],
      due_date = new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      subtotal = currentDeal.commission_amount || 0,
      gst_rate = 18,
      notes
    } = req.body;

    const numSubtotal = Number(subtotal);
    const numGstRate = Number(gst_rate);
    const gstAmount = (numSubtotal * numGstRate) / 100;
    const totalAmount = numSubtotal + gstAmount;

    const invoiceId = `inv-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const randomInv = Math.floor(1000 + Math.random() * 9000);
    const invoiceNumber = `INV-${new Date().getFullYear()}-${randomInv}`;
    const now = new Date().toISOString();
    const cleanNotes = (notes || 'Brokerage and consultancy professional fee').replace(/'/g, "''");

    db.run(`
      INSERT INTO deal_invoices (
        id, deal_id, invoice_number, issue_date, due_date, subtotal, gst_rate, gst_amount, total_amount, status, notes, created_at
      ) VALUES (
        '${invoiceId}', '${id}', '${invoiceNumber}', '${issue_date}', '${due_date}',
        ${numSubtotal}, ${numGstRate}, ${gstAmount}, ${totalAmount}, 'ISSUED',
        '${cleanNotes}', '${now}'
      );
    `);

    // If deal commission_status is NOT_SET or AGREED, update to INVOICED
    if (currentDeal.commission_status === 'NOT_SET' || currentDeal.commission_status === 'AGREED') {
      db.run(`
        UPDATE deals 
        SET commission_status = 'INVOICED',
            updated_at = '${now}'
        WHERE id = '${id}';
      `);
    }

    logDealActivity(
      db,
      id,
      user.id,
      user.name,
      user.role,
      'INVOICE_GENERATED',
      `Generated invoice ${invoiceNumber} for ₹${totalAmount.toLocaleString('en-IN')} (incl. ${numGstRate}% GST)`
    );

    logAudit(
      db,
      user.id,
      user.name,
      'GENERATE_INVOICE',
      'deal',
      id,
      `Generated invoice ${invoiceNumber} for deal ${currentDeal.deal_number}`
    );

    saveDb();

    res.status(201).json({
      message: 'Invoice generated successfully.',
      invoice: {
        id: invoiceId,
        invoiceNumber,
        issueDate: issue_date,
        dueDate: due_date,
        subtotal: numSubtotal,
        gstRate: numGstRate,
        gstAmount,
        totalAmount,
        status: 'ISSUED',
        notes: cleanNotes
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error generating invoice.' });
  }
});

// 9. Add Note / Log Activity to Deal
router.post('/deals/:id/notes', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    if (user.role === 'buyer' || user.role === 'tenant') {
      res.status(403).json({ error: 'Access restricted to authorized personnel.' });
      return;
    }

    const checkRes = db.exec(`SELECT * FROM deals WHERE id = '${id}' LIMIT 1;`);
    const deals = mapRows(checkRes);
    if (deals.length === 0) {
      res.status(404).json({ error: 'Deal not found.' });
      return;
    }
    const currentDeal = deals[0];

    if (user.role !== 'admin' && currentDeal.owner_id !== user.id && currentDeal.assigned_agent_id !== user.id) {
      res.status(403).json({ error: 'Not authorized to add notes to this deal.' });
      return;
    }

    const { note } = req.body;
    if (!note || !note.trim()) {
      res.status(400).json({ error: 'Note text cannot be empty.' });
      return;
    }

    const now = new Date().toISOString();
    const cleanNote = note.trim().replace(/'/g, "''");

    db.run(`
      UPDATE deals 
      SET notes = COALESCE(notes, '') || '\\n[' || '${new Date().toLocaleDateString('en-IN')}' || '] ' || '${cleanNote}',
          updated_at = '${now}'
      WHERE id = '${id}';
    `);

    logDealActivity(
      db,
      id,
      user.id,
      user.name,
      user.role,
      'NOTE_ADDED',
      note.trim()
    );

    saveDb();

    res.json({ message: 'Note added successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error adding note.' });
  }
});

// --------------------------------------------------------------------------
// 12. PHASE 6 MASTER: PROPERTY DOCUMENTS VERIFICATION (Part 5)
// --------------------------------------------------------------------------

// GET /api/properties/:id/documents (Authorized: Owner, assigned agent, admin)
router.get('/properties/:id/documents', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    const propRes = db.exec(`SELECT * FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propRes);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }
    const prop = props[0];

    // Check authorization: Admin, property owner, or assigned agent
    if (user.role !== 'admin' && prop.owner_id !== user.id) {
      // Check if user is an assigned agent for any lead on this property
      const leadAgentCheck = db.exec(`SELECT id FROM leads WHERE property_id = '${id}' AND assigned_agent_id = '${user.id}' LIMIT 1;`);
      if (!leadAgentCheck[0]?.values?.length) {
        res.status(403).json({ error: 'Access denied: You are not authorized to view this property documents.' });
        return;
      }
    }

    const docRes = db.exec(`
      SELECT d.*, u.name as uploader_name, v.name as verifier_name
      FROM property_documents d
      LEFT JOIN users u ON d.uploaded_by_id = u.id
      LEFT JOIN users v ON d.verified_by_id = v.id
      WHERE d.property_id = '${id}'
      ORDER BY d.created_at DESC;
    `);

    const documents = mapRows(docRes).map(d => ({
      id: d.id,
      propertyId: d.property_id,
      documentType: d.document_type,
      title: d.title,
      fileUrl: d.file_url,
      fileName: d.file_name,
      fileSize: d.file_size,
      mimeType: d.mime_type,
      uploadedById: d.uploaded_by_id,
      uploaderName: d.uploader_name || 'Owner',
      verificationStatus: d.verification_status,
      adminNotes: d.admin_notes,
      verifiedById: d.verified_by_id,
      verifierName: d.verifier_name,
      verifiedAt: d.verified_at,
      createdAt: d.created_at,
      updatedAt: d.updated_at
    }));

    res.json({ documents });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching property documents.' });
  }
});

// POST /api/properties/:id/documents (Upload document: Owner or Admin)
router.post('/properties/:id/documents', authMiddleware, docUpload.single('file'), async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    const propRes = db.exec(`SELECT * FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propRes);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }
    const prop = props[0];

    if (user.role !== 'admin' && prop.owner_id !== user.id) {
      res.status(403).json({ error: 'Not authorized to upload documents for this property.' });
      return;
    }

    const { document_type, title, file_url, file_name, file_size, mime_type } = req.body;
    
    let finalUrl = file_url;
    let finalName = file_name;
    let finalSize = file_size ? Number(file_size) : 0;
    let finalMime = mime_type || 'application/pdf';

    if (req.file) {
      finalUrl = `/uploads/${req.file.filename}`;
      finalName = req.file.originalname;
      finalSize = req.file.size;
      finalMime = req.file.mimetype;
    }

    if (!document_type || !title || !finalUrl) {
      res.status(400).json({ error: 'Document type, title, and file are required.' });
      return;
    }

    const docId = `doc-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const cleanType = document_type.replace(/'/g, "''");
    const cleanTitle = title.replace(/'/g, "''");
    const cleanUrl = finalUrl.replace(/'/g, "''");
    const cleanName = (finalName || 'document.pdf').replace(/'/g, "''");
    const cleanMime = finalMime.replace(/'/g, "''");

    db.run(`
      INSERT INTO property_documents (
        id, property_id, document_type, title, file_url, file_name, file_size, mime_type,
        uploaded_by_id, verification_status, created_at, updated_at
      ) VALUES (
        '${docId}', '${id}', '${cleanType}', '${cleanTitle}', '${cleanUrl}', '${cleanName}',
        ${finalSize}, '${cleanMime}', '${user.id}', 'PENDING', '${now}', '${now}'
      );
    `);

    // Notify admins that a new document was submitted for review
    const adminRows = mapRows(db.exec("SELECT id FROM users WHERE role = 'admin';"));
    for (const a of adminRows) {
      createNotification(
        db,
        a.id,
        'New Property Document Submitted',
        `A new document "${title}" was submitted for property "${prop.title}". Verification pending.`,
        'DOCUMENT_SUBMITTED',
        `/admin/properties/${id}`
      );
    }

    logAudit(
      db,
      user.id,
      user.name,
      'UPLOAD_DOCUMENT',
      'property',
      id,
      `Uploaded document: ${title} (${document_type})`
    );

    saveDb();

    res.status(201).json({
      message: 'Property document uploaded successfully and queued for verification.',
      document: {
        id: docId,
        propertyId: id,
        documentType: document_type,
        title,
        fileUrl: finalUrl,
        fileName: finalName,
        fileSize: finalSize,
        mimeType: finalMime,
        uploadedById: user.id,
        verificationStatus: 'PENDING',
        createdAt: now,
        updatedAt: now
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error uploading property document.' });
  }
});

// PATCH /api/properties/:id/documents/:docId/status (Admin verifies/rejects document)
router.patch('/properties/:id/documents/:docId/status', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id, docId } = req.params;
    const { verification_status, admin_notes } = req.body;
    const admin = req.user!;
    const db = await getDb();

    const validStatuses = ['PENDING', 'VERIFIED', 'REJECTED', 'NOT_REQUIRED'];
    if (!verification_status || !validStatuses.includes(verification_status)) {
      res.status(400).json({ error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
      return;
    }

    const docRes = db.exec(`SELECT * FROM property_documents WHERE id = '${docId}' AND property_id = '${id}' LIMIT 1;`);
    const docs = mapRows(docRes);
    if (docs.length === 0) {
      res.status(404).json({ error: 'Property document not found.' });
      return;
    }
    const currentDoc = docs[0];

    const propRes = db.exec(`SELECT title, owner_id FROM properties WHERE id = '${id}' LIMIT 1;`);
    const prop = mapRows(propRes)[0];

    const now = new Date().toISOString();
    const cleanNotes = (admin_notes || '').replace(/'/g, "''");

    db.run(`
      UPDATE property_documents
      SET verification_status = '${verification_status}',
          admin_notes = '${cleanNotes}',
          verified_by_id = '${admin.id}',
          verified_at = '${now}',
          updated_at = '${now}'
      WHERE id = '${docId}';
    `);

    // Notify the property owner
    if (prop && prop.owner_id) {
      createNotification(
        db,
        prop.owner_id,
        `Document Verification: ${verification_status}`,
        `Your document "${currentDoc.title}" for property "${prop.title}" has been marked as ${verification_status}.${admin_notes ? ' Note: ' + admin_notes : ''}`,
        'DOCUMENT_VERIFIED',
        `/dashboard`
      );
    }

    logAudit(
      db,
      admin.id,
      admin.name,
      'VERIFY_DOCUMENT',
      'property_document',
      docId,
      `Document ${currentDoc.title} set to ${verification_status}. Notes: ${admin_notes || 'None'}`
    );

    saveDb();

    res.json({
      message: `Document status updated to ${verification_status}.`,
      document: {
        id: docId,
        verificationStatus: verification_status,
        adminNotes: admin_notes,
        verifiedById: admin.id,
        verifierName: admin.name,
        verifiedAt: now
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating document verification status.' });
  }
});

// DELETE /api/properties/:id/documents/:docId (Owner or Admin deletes document)
router.delete('/properties/:id/documents/:docId', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id, docId } = req.params;
    const user = req.user!;
    const db = await getDb();

    const propRes = db.exec(`SELECT owner_id FROM properties WHERE id = '${id}' LIMIT 1;`);
    const props = mapRows(propRes);
    if (props.length === 0) {
      res.status(404).json({ error: 'Property not found.' });
      return;
    }
    const prop = props[0];

    if (user.role !== 'admin' && prop.owner_id !== user.id) {
      res.status(403).json({ error: 'Not authorized to delete this document.' });
      return;
    }

    db.run(`DELETE FROM property_documents WHERE id = '${docId}' AND property_id = '${id}';`);
    logAudit(db, user.id, user.name, 'DELETE_DOCUMENT', 'property_document', docId, `Deleted document ${docId}`);
    saveDb();

    res.json({ message: 'Document deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error deleting document.' });
  }
});

// --------------------------------------------------------------------------
// 13. PHASE 6 MASTER: INTERNAL NOTIFICATIONS SYSTEM (Part 17)
// --------------------------------------------------------------------------

// GET /api/notifications (User's real notifications list and unread count)
router.get('/notifications', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const user = req.user!;
    const db = await getDb();

    const notifRes = db.exec(`
      SELECT * FROM notifications 
      WHERE user_id = '${user.id}' 
      ORDER BY created_at DESC 
      LIMIT 50;
    `);
    const notifications = mapRows(notifRes).map(n => ({
      id: n.id,
      title: n.title,
      message: n.message,
      type: n.type,
      link: n.link,
      isRead: Boolean(n.is_read),
      createdAt: n.created_at
    }));

    const unreadCountRes = db.exec(`
      SELECT COUNT(*) as count FROM notifications 
      WHERE user_id = '${user.id}' AND is_read = 0;
    `);
    const unreadCount = Number(unreadCountRes[0]?.values[0]?.[0] || 0);

    res.json({ notifications, unreadCount });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching notifications.' });
  }
});

// PATCH /api/notifications/:id/read (Mark single notification as read)
router.patch('/notifications/:id/read', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    db.run(`UPDATE notifications SET is_read = 1 WHERE id = '${id}' AND user_id = '${user.id}';`);
    saveDb();

    res.json({ success: true, message: 'Notification marked as read.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating notification.' });
  }
});

// POST /api/notifications/mark-all-read (Mark all user notifications read)
router.post('/notifications/mark-all-read', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const user = req.user!;
    const db = await getDb();

    db.run(`UPDATE notifications SET is_read = 1 WHERE user_id = '${user.id}';`);
    saveDb();

    res.json({ success: true, message: 'All notifications marked as read.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error marking notifications read.' });
  }
});

// --------------------------------------------------------------------------
// 14. PHASE 6 MASTER: MAHARERA & BUSINESS SETTINGS (Part 6 & Part 33)
// --------------------------------------------------------------------------

// GET /api/settings/public (Public compliance and business information)
router.get('/settings/public', async (_req: Request, res: Response) => {
  try {
    const db = await getDb();
    const rows = mapRows(db.exec("SELECT key, value FROM system_settings;"));
    const settingsMap: Record<string, string> = {};
    for (const r of rows) {
      settingsMap[r.key] = r.value;
    }

    const razorpayKeyId = process.env.RAZORPAY_KEY_ID || '';
    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET || '';
    const razorpayConfigured = Boolean(razorpayKeyId && razorpayKeySecret);

    res.json({
      businessName: settingsMap['business_name'] || 'P2P Property Technologies Pvt. Ltd.',
      brandTagline: settingsMap['brand_tagline'] || 'MUMBAI DIRECT — Direct Peer-to-Peer Real Estate',
      brokerName: settingsMap['broker_name'] || 'P2P Property Advisory Desk (MahaRERA Registered Agent)',
      mahareraRegNumber: settingsMap['maharera_reg_number'] || 'A51900034821',
      certificateOfCompetency: settingsMap['certificate_of_competency'] || 'CoC-MAH-2024-99182',
      businessPhone: settingsMap['business_phone'] || '+91 (022) 6820-0022',
      businessEmail: settingsMap['business_email'] || 'concierge@p2pproperty.in',
      officeAddress: settingsMap['office_address'] || 'Floor 8, Maker Maxity, Bandra Kurla Complex (BKC), Mumbai, Maharashtra 400051',
      whatsappNumber: settingsMap['whatsapp_number'] || '+919820098200',
      currency: settingsMap['currency'] || 'INR',
      defaultGstRate: Number(settingsMap['default_gst_rate'] || 18),
      razorpayConfigured,
      razorpayKeyId: razorpayConfigured ? razorpayKeyId : null
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching public settings.' });
  }
});

// GET /api/admin/system-settings (Admin view of all settings)
router.get('/admin/system-settings', authMiddleware, adminMiddleware, async (_req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const rows = mapRows(db.exec("SELECT * FROM system_settings ORDER BY key ASC;"));
    
    const razorpayConfigured = Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);
    
    res.json({
      settings: rows,
      paymentGateway: {
        razorpayKeyIdConfigured: Boolean(process.env.RAZORPAY_KEY_ID),
        razorpaySecretConfigured: Boolean(process.env.RAZORPAY_KEY_SECRET),
        isLive: razorpayConfigured
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching admin system settings.' });
  }
});

// PATCH /api/admin/system-settings (Admin updates business & compliance settings)
router.patch('/admin/system-settings', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const admin = req.user!;
    const db = await getDb();
    const { settings } = req.body as { settings: Record<string, string> };

    if (!settings || typeof settings !== 'object') {
      res.status(400).json({ error: 'Settings object is required.' });
      return;
    }

    const now = new Date().toISOString();
    for (const [key, value] of Object.entries(settings)) {
      const cleanKey = key.replace(/'/g, "''");
      const cleanVal = String(value).replace(/'/g, "''");
      db.run(`
        INSERT INTO system_settings (key, value, updated_at)
        VALUES ('${cleanKey}', '${cleanVal}', '${now}')
        ON CONFLICT(key) DO UPDATE SET value = '${cleanVal}', updated_at = '${now}';
      `);
    }

    logAudit(
      db,
      admin.id,
      admin.name,
      'UPDATE_SYSTEM_SETTINGS',
      'system_settings',
      'global',
      `Updated settings: ${Object.keys(settings).join(', ')}`
    );

    saveDb();

    res.json({ message: 'System settings updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating system settings.' });
  }
});

// --------------------------------------------------------------------------
// 15. PHASE 6 MASTER: LEGAL & BUSINESS POLICY PAGES (Part 29)
// --------------------------------------------------------------------------

// GET /api/legal/:slug (Public legal content retrieval)
router.get('/legal/:slug', async (req: Request, res: Response) => {
  try {
    const { slug } = req.params;
    const db = await getDb();
    const cleanSlug = slug.replace(/'/g, "''");

    const query = db.exec(`SELECT * FROM legal_pages WHERE slug = '${cleanSlug}' LIMIT 1;`);
    const pages = mapRows(query);

    if (pages.length === 0) {
      res.status(404).json({ error: `Legal policy document for "${slug}" not found.` });
      return;
    }

    const p = pages[0];
    res.json({
      slug: p.slug,
      title: p.title,
      content: p.content,
      updatedAt: p.updated_at,
      updatedBy: p.updated_by
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching legal document.' });
  }
});

// PATCH /api/admin/legal/:slug (Admin edits legal & compliance document)
router.patch('/admin/legal/:slug', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { slug } = req.params;
    const { title, content } = req.body;
    const admin = req.user!;
    const db = await getDb();

    if (!content || !content.trim()) {
      res.status(400).json({ error: 'Content cannot be empty.' });
      return;
    }

    const cleanSlug = slug.replace(/'/g, "''");
    const cleanTitle = (title || slug).replace(/'/g, "''");
    const cleanContent = content.trim().replace(/'/g, "''");
    const now = new Date().toISOString();

    db.run(`
      INSERT INTO legal_pages (slug, title, content, updated_at, updated_by)
      VALUES ('${cleanSlug}', '${cleanTitle}', '${cleanContent}', '${now}', '${admin.name}')
      ON CONFLICT(slug) DO UPDATE SET 
        title = '${cleanTitle}',
        content = '${cleanContent}',
        updated_at = '${now}',
        updated_by = '${admin.name}';
    `);

    logAudit(db, admin.id, admin.name, 'UPDATE_LEGAL_PAGE', 'legal_pages', slug, `Updated legal text for ${slug}`);
    saveDb();

    res.json({ message: 'Legal document updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating legal document.' });
  }
});

// --------------------------------------------------------------------------
// 16. PHASE 6 MASTER: CONTACT & BUSINESS ENQUIRIES (Part 32)
// --------------------------------------------------------------------------

// POST /api/contact (Public contact submission)
router.post('/contact', async (req: Request, res: Response) => {
  try {
    const { name, email, phone, enquiry_type, message } = req.body;

    if (!name || !email || !phone || !message) {
      res.status(400).json({ error: 'Name, email, phone, and message are required.' });
      return;
    }

    const db = await getDb();
    const id = `cnt-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const cleanName = name.trim().replace(/'/g, "''");
    const cleanEmail = email.trim().replace(/'/g, "''");
    const cleanPhone = phone.trim().replace(/'/g, "''");
    const cleanType = (enquiry_type || 'GENERAL').replace(/'/g, "''");
    const cleanMsg = message.trim().replace(/'/g, "''");

    db.run(`
      INSERT INTO contact_enquiries (id, name, email, phone, enquiry_type, message, status, created_at)
      VALUES ('${id}', '${cleanName}', '${cleanEmail}', '${cleanPhone}', '${cleanType}', '${cleanMsg}', 'NEW', '${now}');
    `);

    // Notify all admins of incoming contact enquiry
    const adminRows = mapRows(db.exec("SELECT id FROM users WHERE role = 'admin';"));
    for (const a of adminRows) {
      createNotification(
        db,
        a.id,
        'New Contact Message Received',
        `${name} submitted an enquiry regarding "${enquiry_type || 'General'}": "${message.slice(0, 80)}..."`,
        'CONTACT_ENQUIRY',
        '/admin/enquiries'
      );
    }

    saveDb();

    res.status(201).json({
      message: 'Thank you for reaching out. A P2P Property Mumbai representative will contact you shortly.',
      id
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error submitting contact enquiry.' });
  }
});

// GET /api/admin/contact-enquiries (Admin view of contact submissions)
router.get('/admin/contact-enquiries', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const { status, search } = req.query as Record<string, string>;

    let sql = "SELECT * FROM contact_enquiries WHERE 1=1";
    if (status) {
      sql += ` AND status = '${status.replace(/'/g, "''")}'`;
    }
    if (search) {
      const cleanSearch = search.replace(/'/g, "''");
      sql += ` AND (name LIKE '%${cleanSearch}%' OR email LIKE '%${cleanSearch}%' OR phone LIKE '%${cleanSearch}%' OR message LIKE '%${cleanSearch}%')`;
    }
    sql += " ORDER BY created_at DESC LIMIT 100;";

    const rows = mapRows(db.exec(sql));
    res.json({ enquiries: rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching contact enquiries.' });
  }
});

// PATCH /api/admin/contact-enquiries/:id/status (Admin updates contact enquiry status)
router.patch('/admin/contact-enquiries/:id/status', authMiddleware, adminMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const db = await getDb();

    const cleanStatus = (status || 'RESOLVED').replace(/'/g, "''");
    db.run(`UPDATE contact_enquiries SET status = '${cleanStatus}' WHERE id = '${id}';`);
    saveDb();

    res.json({ message: `Contact enquiry marked as ${cleanStatus}.` });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating contact enquiry status.' });
  }
});

// --------------------------------------------------------------------------
// 17. PHASE 6 MASTER: RAZORPAY INTEGRATION & ONLINE PAYMENTS (Part 13)
// --------------------------------------------------------------------------

// POST /api/payments/razorpay/create-order (Server-side order creation)
router.post('/payments/razorpay/create-order', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { dealId, amount } = req.body;
    const user = req.user!;
    const db = await getDb();

    if (!dealId || !amount || Number(amount) <= 0) {
      res.status(400).json({ error: 'Valid dealId and positive amount are required.' });
      return;
    }

    const checkRes = db.exec(`SELECT * FROM deals WHERE id = '${dealId}' LIMIT 1;`);
    const deals = mapRows(checkRes);
    if (deals.length === 0) {
      res.status(404).json({ error: 'Deal not found.' });
      return;
    }
    const currentDeal = deals[0];

    // Check authorization: Admin, owner, assigned agent, or customer
    if (
      user.role !== 'admin' &&
      currentDeal.owner_id !== user.id &&
      currentDeal.assigned_agent_id !== user.id &&
      currentDeal.customer_id !== user.id
    ) {
      res.status(403).json({ error: 'Unauthorized to initiate payment for this deal.' });
      return;
    }

    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;

    // Strict compliance with Part 13:
    // If Razorpay is not configured, the application must still work and show:
    // "Online payment is currently unavailable."
    if (!keyId || !keySecret) {
      res.json({
        configured: false,
        message: 'Online payment is currently unavailable. Please record payment manually via bank transfer or cheque.'
      });
      return;
    }

    // In a live configured environment, Razorpay order is generated with amount in paise
    const amountInPaise = Math.round(Number(amount) * 100);
    const receipt = `RCP-${dealId.slice(-6)}-${Date.now().toString().slice(-4)}`;
    
    // Simulate / call Razorpay standard order creation
    const orderId = `order_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

    res.json({
      configured: true,
      orderId,
      amount: amountInPaise,
      currency: 'INR',
      keyId, // Only public key is shared with the client; secret stays on server!
      receipt
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error creating Razorpay payment order.' });
  }
});

// POST /api/payments/razorpay/verify (Server-side signature verification & record)
router.post('/payments/razorpay/verify', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { dealId, razorpay_order_id, razorpay_payment_id, razorpay_signature, amount, payer_name, notes } = req.body;
    const user = req.user!;
    const db = await getDb();

    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keySecret) {
      res.status(400).json({ error: 'Payment gateway secret not configured on server.' });
      return;
    }

    // Cryptographic signature verification
    const bodyToSign = razorpay_order_id + '|' + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac('sha256', keySecret)
      .update(bodyToSign)
      .digest('hex');

    if (expectedSignature !== razorpay_signature) {
      res.status(400).json({ error: 'Payment signature verification failed. Tampering detected.' });
      return;
    }

    // Fetch deal
    const dealRes = db.exec(`SELECT * FROM deals WHERE id = '${dealId}' LIMIT 1;`);
    const deals = mapRows(dealRes);
    if (deals.length === 0) {
      res.status(404).json({ error: 'Deal not found.' });
      return;
    }
    const currentDeal = deals[0];

    // Record verified payment
    const paymentId = `pay-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const receiptNumber = `REC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString();
    const paymentDate = now.split('T')[0];
    const numAmount = Number(amount);

    db.run(`
      INSERT INTO deal_payments (
        id, deal_id, receipt_number, amount, payment_method, transaction_reference,
        payment_date, payer_name, recorded_by_id, recorded_by_name, notes, created_at
      ) VALUES (
        '${paymentId}', '${dealId}', '${receiptNumber}', ${numAmount}, 'RAZORPAY_GATEWAY',
        '${razorpay_payment_id}', '${paymentDate}', '${(payer_name || user.name).replace(/'/g, "''")}',
        '${user.id}', '${user.name.replace(/'/g, "''")}', '${(notes || 'Online payment verified via Razorpay').replace(/'/g, "''")}',
        '${now}'
      );
    `);

    // Calculate new total paid
    const sumRes = db.exec(`SELECT SUM(amount) FROM deal_payments WHERE deal_id = '${dealId}';`);
    const totalPaid = Number(sumRes[0]?.values[0]?.[0] || 0);

    let newCommStatus = currentDeal.commission_status;
    if (totalPaid >= currentDeal.commission_amount) {
      newCommStatus = 'PAID';
    } else if (totalPaid > 0) {
      newCommStatus = 'PARTIALLY_PAID';
    }

    db.run(`
      UPDATE deals
      SET commission_status = '${newCommStatus}',
          updated_at = '${now}'
      WHERE id = '${dealId}';
    `);

    logDealActivity(
      db,
      dealId,
      user.id,
      user.name,
      user.role,
      'PAYMENT_RECORDED',
      `Verified Razorpay payment ₹${numAmount.toLocaleString('en-IN')} (Ref: ${razorpay_payment_id}). Status: ${newCommStatus}`
    );

    logAudit(
      db,
      user.id,
      user.name,
      'VERIFY_RAZORPAY_PAYMENT',
      'deal_payment',
      paymentId,
      `Verified online payment of ₹${numAmount} for deal ${currentDeal.deal_number}`
    );

    saveDb();

    res.json({
      success: true,
      message: 'Payment verified and recorded successfully.',
      payment: {
        id: paymentId,
        receiptNumber,
        amount: numAmount,
        commissionStatus: newCommStatus,
        totalPaid
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error verifying Razorpay payment.' });
  }
});

// --------------------------------------------------------------------------
// 18. PHASE 6 MASTER: INTERNAL ANALYTICS FOUNDATION (Part 31)
// --------------------------------------------------------------------------

// POST /api/analytics/events (Safe client event logging)
router.post('/analytics/events', optionalAuthMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { event_name, entity_type, entity_id, metadata } = req.body;
    if (!event_name) {
      res.status(400).json({ error: 'event_name is required.' });
      return;
    }

    const db = await getDb();
    const id = `evt-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();
    const userId = req.user ? `'${req.user.id}'` : 'NULL';
    const cleanEvent = event_name.replace(/'/g, "''");
    const cleanType = entity_type ? `'${entity_type.replace(/'/g, "''")}'` : 'NULL';
    const cleanEntityId = entity_id ? `'${entity_id.replace(/'/g, "''")}'` : 'NULL';
    const cleanMeta = metadata ? `'${JSON.stringify(metadata).replace(/'/g, "''")}'` : 'NULL';

    db.run(`
      INSERT INTO analytics_events (id, event_name, entity_type, entity_id, user_id, metadata, created_at)
      VALUES ('${id}', '${cleanEvent}', ${cleanType}, ${cleanEntityId}, ${userId}, ${cleanMeta}, '${now}');
    `);
    saveDb();

    res.status(201).json({ success: true });
  } catch (err: any) {
    // Non-blocking for client analytics
    res.status(200).json({ success: false });
  }
});

// GET /api/admin/analytics/summary (Admin platform metrics report)
router.get('/admin/analytics/summary', authMiddleware, adminMiddleware, async (_req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const viewsCount = Number(db.exec("SELECT COUNT(*) FROM analytics_events WHERE event_name = 'PROPERTY_VIEW';")[0]?.values[0]?.[0] || 0);
    const searchCount = Number(db.exec("SELECT COUNT(*) FROM analytics_events WHERE event_name = 'SEARCH_EXECUTED';")[0]?.values[0]?.[0] || 0);
    const enquiriesCount = Number(db.exec("SELECT COUNT(*) FROM property_inquiries;")[0]?.values[0]?.[0] || 0);
    const visitsCount = Number(db.exec("SELECT COUNT(*) FROM site_visits;")[0]?.values[0]?.[0] || 0);
    const leadsCount = Number(db.exec("SELECT COUNT(*) FROM leads;")[0]?.values[0]?.[0] || 0);
    const dealsCount = Number(db.exec("SELECT COUNT(*) FROM deals;")[0]?.values[0]?.[0] || 0);
    const completedDeals = Number(db.exec("SELECT COUNT(*) FROM deals WHERE deal_status = 'COMPLETED';")[0]?.values[0]?.[0] || 0);

    res.json({
      analytics: {
        totalPropertyViews: viewsCount,
        totalSearches: searchCount,
        totalEnquiries: enquiriesCount,
        totalSiteVisits: visitsCount,
        totalLeads: leadsCount,
        totalDeals: dealsCount,
        completedDeals,
        leadToDealConversionRate: leadsCount > 0 ? ((dealsCount / leadsCount) * 100).toFixed(1) + '%' : '0%',
        dealCompletionRate: dealsCount > 0 ? ((completedDeals / dealsCount) * 100).toFixed(1) + '%' : '0%'
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching analytics summary.' });
  }
});

// ====================================================================
// QUERY MODE & OFF-MARKET PROPERTY MATCHING API ROUTES
// ====================================================================

// Helper to generate formatted Query Number: P2P-Q-100001
function generateQueryNumber(db: any): string {
  const countRes = db.exec("SELECT COUNT(*) as count FROM property_requirements;");
  const count = Number(countRes[0]?.values[0]?.[0] || 0) + 1;
  const num = 100000 + count;
  return `P2P-Q-${num}`;
}

// POST /api/queries - Customer submits requirement ("Post Your Requirement")
router.post('/queries', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const user = req.user!;
    const {
      transaction_type,
      category,
      preferred_locations,
      budget_min,
      budget_max,
      property_type,
      bhk,
      area_min,
      area_max,
      furnishing,
      parking_required,
      business_type,
      lease_duration,
      possession_date,
      requirements_text,
      priority = 'MEDIUM'
    } = req.body;

    if (!transaction_type || !category) {
      res.status(400).json({ error: 'transaction_type and category are required.' });
      return;
    }

    const db = await getDb();
    const now = new Date().toISOString();

    // 1. Get or create Customer Profile
    let customerId = '';
    const custRes = db.exec(`SELECT id FROM customer_profiles WHERE user_id = '${user.id}' LIMIT 1;`);
    const custRows = mapRows(custRes);
    if (custRows.length > 0) {
      customerId = custRows[0].id;
    } else {
      // Check by email
      const custEmailRes = db.exec(`SELECT id FROM customer_profiles WHERE email = '${user.email.replace(/'/g, "''")}' LIMIT 1;`);
      const custEmailRows = mapRows(custEmailRes);
      if (custEmailRows.length > 0) {
        customerId = custEmailRows[0].id;
        db.run(`UPDATE customer_profiles SET user_id = '${user.id}' WHERE id = '${customerId}';`);
      } else {
        // Create new customer profile
        customerId = `cust-${Date.now()}-${Math.round(Math.random() * 1000)}`;
        const cleanName = (user.name || 'Valued Customer').replace(/'/g, "''");
        const cleanEmail = (user.email || '').replace(/'/g, "''");
        const cleanPhone = (user.phone || '').replace(/'/g, "''");
        const custType = transaction_type.toUpperCase() === 'BUY' ? 'BUYER' : 'TENANT';
        db.run(`
          INSERT INTO customer_profiles (
            id, name, mobile, email, user_id, customer_type, preferred_transaction, preferred_category,
            preferred_locations, budget_min, budget_max, preferred_property_types, bhk, carpet_area_min,
            carpet_area_max, furnishing_preference, parking_requirement, business_type, notes, created_at, updated_at
          ) VALUES (
            '${customerId}', '${cleanName}', '${cleanPhone}', '${cleanEmail}', '${user.id}', '${custType}',
            '${transaction_type.toLowerCase()}', '${category.toLowerCase()}',
            '${(preferred_locations || '').replace(/'/g, "''")}', ${budget_min || 'NULL'}, ${budget_max || 'NULL'},
            '${(property_type || '').replace(/'/g, "''")}', '${(bhk || '').replace(/'/g, "''")}',
            ${area_min || 'NULL'}, ${area_max || 'NULL'}, '${(furnishing || '').replace(/'/g, "''")}',
            '${(parking_required || '').replace(/'/g, "''")}', '${(business_type || '').replace(/'/g, "''")}',
            'Created from customer query requirement.', '${now}', '${now}'
          );
        `);
      }
    }

    // 2. Create Lead for CRM pipeline
    const leadId = `lead-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const leadMsg = (requirements_text || `Customer requirement for ${transaction_type} ${category} in ${preferred_locations || 'Mumbai'}`).replace(/'/g, "''");
    // For query-originated leads without a listed property, assign platform owner (usr-admin-p2p or first admin)
    const adminUserRes = db.exec("SELECT id FROM users WHERE role = 'admin' LIMIT 1;");
    const defaultOwnerId = adminUserRes[0]?.values[0]?.[0] || 'usr-admin-p2p';

    db.run(`
      INSERT INTO leads (
        id, property_id, customer_id, owner_id, assigned_agent_id, source, status, priority,
        customer_message, internal_notes, preferred_contact_method, budget, requirement_type,
        business_type, required_carpet_area, bhk, furnishing_preference, parking_requirement,
        created_at, updated_at
      ) VALUES (
        '${leadId}', NULL, '${customerId}', '${defaultOwnerId}', NULL, 'CUSTOMER_QUERY', 'NEW', '${priority.replace(/'/g, "''")}',
        '${leadMsg}', 'Generated from Customer Requirement Query submission.',
        'WHATSAPP', ${budget_max || budget_min || 'NULL'}, '${category.toLowerCase()}',
        '${(business_type || '').replace(/'/g, "''")}', ${area_max || area_min || 'NULL'},
        '${(bhk || '').replace(/'/g, "''")}', '${(furnishing || '').replace(/'/g, "''")}',
        '${(parking_required || '').replace(/'/g, "''")}', '${now}', '${now}'
      );
    `);

    logLeadActivity(db, leadId, user.id, user.name, user.role, 'LEAD_CREATED', `Lead generated from query requirement submission.`);

    // 3. Create Property Requirement / Query
    const queryId = `qry-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const queryNumber = generateQueryNumber(db);

    db.run(`
      INSERT INTO property_requirements (
        id, query_number, customer_id, lead_id, transaction_type, category, preferred_locations,
        budget_min, budget_max, property_type, bhk, area_min, area_max, furnishing,
        parking_required, business_type, lease_duration, possession_date, requirements_text,
        status, priority, assigned_agent_id, source, created_at, updated_at
      ) VALUES (
        '${queryId}', '${queryNumber}', '${customerId}', '${leadId}',
        '${transaction_type.toUpperCase()}', '${category.toUpperCase()}',
        '${(preferred_locations || '').replace(/'/g, "''")}',
        ${budget_min !== undefined && budget_min !== null ? Number(budget_min) : 'NULL'},
        ${budget_max !== undefined && budget_max !== null ? Number(budget_max) : 'NULL'},
        '${(property_type || '').replace(/'/g, "''")}',
        '${(bhk || '').replace(/'/g, "''")}',
        ${area_min !== undefined && area_min !== null ? Number(area_min) : 'NULL'},
        ${area_max !== undefined && area_max !== null ? Number(area_max) : 'NULL'},
        '${(furnishing || '').replace(/'/g, "''")}',
        '${(parking_required || '').replace(/'/g, "''")}',
        '${(business_type || '').replace(/'/g, "''")}',
        '${(lease_duration || '').replace(/'/g, "''")}',
        '${(possession_date || '').replace(/'/g, "''")}',
        '${(requirements_text || '').replace(/'/g, "''")}',
        'NEW', '${priority.replace(/'/g, "''")}', NULL, 'PORTAL_QUERY', '${now}', '${now}'
      );
    `);

    // Log Query Activity & Audit
    logQueryActivity(db, queryId, user.id, user.name, user.role, 'QUERY_CREATED', `Customer requirement posted with Query ID ${queryNumber}`);
    logAudit(db, user.id, user.name, 'QUERY_CREATED', 'PROPERTY_REQUIREMENT', queryId, `Posted query ${queryNumber}: ${transaction_type} ${category} in ${preferred_locations || 'Mumbai'}`);

    saveDb();

    res.status(201).json({
      message: 'Property requirement successfully submitted.',
      queryId,
      queryNumber,
      leadId,
      customerId
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error creating property requirement.' });
  }
});

// GET /api/queries - List queries (Customer gets their own; Admin gets all; Agent gets assigned)
router.get('/queries', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const user = req.user!;
    const db = await getDb();
    const { status, priority, search } = req.query as Record<string, string>;

    let sql = `
      SELECT q.*, c.name as customer_name, c.email as customer_email, c.mobile as customer_mobile, c.user_id as customer_user_id,
             u.name as agent_name, u.email as agent_email, u.phone as agent_phone
      FROM property_requirements q
      JOIN customer_profiles c ON q.customer_id = c.id
      LEFT JOIN users u ON q.assigned_agent_id = u.id
      WHERE 1=1
    `;

    // Role-based filtering
    if (user.role === 'admin') {
      // Admin sees all
    } else if (user.role === 'agent') {
      // Agent sees assigned queries
      sql += ` AND q.assigned_agent_id = '${user.id}'`;
    } else {
      // Customer sees only their own queries
      sql += ` AND c.user_id = '${user.id}'`;
    }

    if (status) {
      sql += ` AND q.status = '${status.replace(/'/g, "''")}'`;
    }
    if (priority) {
      sql += ` AND q.priority = '${priority.replace(/'/g, "''")}'`;
    }
    if (search) {
      const s = search.replace(/'/g, "''");
      sql += ` AND (q.query_number LIKE '%${s}%' OR q.preferred_locations LIKE '%${s}%' OR q.requirements_text LIKE '%${s}%' OR c.name LIKE '%${s}%')`;
    }

    sql += " ORDER BY q.created_at DESC;";

    const rows = mapRows(db.exec(sql));

    const queries = rows.map((r) => {
      // Count matches
      const matchCountRes = db.exec(`SELECT COUNT(*) as count FROM off_market_matches WHERE query_id = '${r.id}';`);
      const offMarketCount = Number(matchCountRes[0]?.values[0]?.[0] || 0);

      const isCustomer = user.role !== 'admin' && user.role !== 'agent';

      return {
        id: r.id,
        queryNumber: r.query_number,
        customerId: r.customer_id,
        leadId: r.lead_id,
        transactionType: r.transaction_type,
        category: r.category,
        preferredLocations: r.preferred_locations,
        budgetMin: r.budget_min,
        budgetMax: r.budget_max,
        propertyType: r.property_type,
        bhk: r.bhk,
        areaMin: r.area_min,
        areaMax: r.area_max,
        furnishing: r.furnishing,
        parkingRequired: r.parking_required,
        businessType: r.business_type,
        leaseDuration: r.lease_duration,
        possessionDate: r.possession_date,
        requirementsText: r.requirements_text,
        status: r.status,
        priority: r.priority,
        assignedAgentId: r.assigned_agent_id,
        assignedAgentName: r.agent_name,
        assignedAgentEmail: r.agent_email,
        source: r.source,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
        lastContactedAt: r.last_contacted_at,
        nextFollowUpAt: r.next_follow_up_at,
        offMarketMatchCount: offMarketCount,
        customer: {
          id: r.customer_id,
          name: r.customer_name,
          email: isCustomer ? r.customer_email : (user.role === 'admin' || user.role === 'agent' ? r.customer_email : undefined),
          mobile: isCustomer ? r.customer_mobile : (user.role === 'admin' || user.role === 'agent' ? r.customer_mobile : undefined)
        }
      };
    });

    res.json({ queries });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error retrieving queries.' });
  }
});

// GET /api/queries/:id - Retrieve query details, listed inventory matches, and off-market matches
router.get('/queries/:id', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    const qRes = db.exec(`
      SELECT q.*, c.name as customer_name, c.email as customer_email, c.mobile as customer_mobile, c.user_id as customer_user_id,
             u.name as agent_name, u.email as agent_email, u.phone as agent_phone
      FROM property_requirements q
      JOIN customer_profiles c ON q.customer_id = c.id
      LEFT JOIN users u ON q.assigned_agent_id = u.id
      WHERE q.id = '${id}' OR q.query_number = '${id}'
      LIMIT 1;
    `);
    const qRows = mapRows(qRes);
    if (qRows.length === 0) {
      res.status(404).json({ error: 'Property requirement not found.' });
      return;
    }

    const r = qRows[0];

    // Authorization & IDOR protection
    const isOwnerCustomer = r.customer_user_id === user.id;
    const isAdmin = user.role === 'admin';
    const isAssignedAgent = user.role === 'agent' && r.assigned_agent_id === user.id;

    if (!isOwnerCustomer && !isAdmin && !isAssignedAgent) {
      res.status(403).json({ error: 'Forbidden: You do not have authorization to view this property requirement.' });
      return;
    }

    // 1. Matched Approved Public Listings (Existing Inventory Matching Engine)
    let listedMatches: any[] = [];
    try {
      let matchSql = `
        SELECT p.id, p.title, p.locality, p.address, p.category, p.transaction_type, p.property_type,
               p.price, p.rent, p.carpet_area, p.bedrooms, p.furnishing, p.parking, p.verification_status
        FROM properties p
        WHERE p.status = 'APPROVED'
      `;

      if (r.category) {
        matchSql += ` AND LOWER(p.category) = '${r.category.toLowerCase()}'`;
      }
      if (r.transaction_type) {
        const tType = r.transaction_type.toLowerCase();
        if (tType === 'buy') {
          matchSql += " AND (LOWER(p.transaction_type) = 'buy' OR LOWER(p.transaction_type) = 'sale')";
        } else if (tType === 'rent') {
          matchSql += " AND LOWER(p.transaction_type) = 'rent'";
        } else if (tType === 'lease') {
          matchSql += " AND (LOWER(p.transaction_type) = 'lease' OR LOWER(p.transaction_type) = 'rent')";
        }
      }

      // Budget filtering
      if (r.budget_max) {
        matchSql += ` AND (p.price <= ${r.budget_max * 1.25} OR p.rent <= ${r.budget_max * 1.25})`;
      }

      matchSql += " ORDER BY p.is_verified DESC, p.created_at DESC LIMIT 10;";
      const matchedProps = mapRows(db.exec(matchSql));

      listedMatches = matchedProps.map((p) => {
        const imgRes = db.exec(`SELECT image_url FROM property_images WHERE property_id = '${p.id}' ORDER BY is_primary DESC LIMIT 1;`);
        const primaryImage = imgRes[0]?.values[0]?.[0] || '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg';
        return {
          id: p.id,
          title: p.title,
          locality: p.locality,
          address: p.address,
          category: p.category,
          transactionType: p.transaction_type,
          propertyType: p.property_type,
          price: p.price,
          rent: p.rent,
          carpetArea: p.carpet_area,
          bedrooms: p.bedrooms,
          furnishing: p.furnishing,
          parking: p.parking,
          verificationStatus: p.verification_status,
          primaryImage,
          matchType: 'P2P_LISTED_VERIFIED'
        };
      });
    } catch (mErr) {
      console.error('Error calculating listed inventory matches:', mErr);
    }

    // 2. Off-Market Matches
    let offMarketMatches: any[] = [];
    const offRes = db.exec(`
      SELECT * FROM off_market_matches
      WHERE query_id = '${r.id}'
      ORDER BY created_at DESC;
    `);
    const rawOffRows = mapRows(offRes);

    if (isAdmin || isAssignedAgent) {
      // Internal view: Full data including sourcing and private owner references
      offMarketMatches = rawOffRows.map((o) => ({
        id: o.id,
        queryId: o.query_id,
        source: o.source,
        location: o.location,
        propertyType: o.property_type,
        transactionType: o.transaction_type,
        askingPrice: o.asking_price,
        expectedRent: o.expected_rent,
        area: o.area,
        bhk: o.bhk,
        availability: o.availability,
        ownerOrRepresentativeName: o.owner_or_representative_name,
        ownerOrRepresentativeContactReference: o.owner_or_representative_contact_reference,
        contactedBy: o.contacted_by,
        contactedAt: o.contacted_at,
        matchNotes: o.match_notes,
        status: o.status,
        createdAt: o.created_at,
        updatedAt: o.updated_at,
        isOffMarket: true,
        label: 'OFF-MARKET — PRIVATE'
      }));
    } else {
      // Customer view: Redacted private details (no broker notes, no internal contact references)
      offMarketMatches = rawOffRows
        .filter((o) => ['AVAILABLE', 'CUSTOMER_INTERESTED', 'SITE_VISIT', 'NEGOTIATING'].includes(o.status))
        .map((o) => ({
          id: o.id,
          queryId: o.query_id,
          location: o.location,
          propertyType: o.property_type,
          transactionType: o.transaction_type,
          askingPrice: o.asking_price,
          expectedRent: o.expected_rent,
          area: o.area,
          bhk: o.bhk,
          availability: o.availability,
          status: o.status,
          createdAt: o.created_at,
          isOffMarket: true,
          label: 'OFF-MARKET — PRIVATE'
        }));
    }

    // 3. Query Activities
    const actRes = db.exec(`
      SELECT * FROM query_activities
      WHERE query_id = '${r.id}'
      ORDER BY created_at DESC;
    `);
    const activities = mapRows(actRes).map((a) => ({
      id: a.id,
      queryId: a.query_id,
      performedById: a.performed_by_id,
      performedByName: a.performed_by_name,
      performedByRole: a.performed_by_role,
      action: a.action,
      details: a.details,
      createdAt: a.created_at
    }));

    // 4. Linked Site Visits (via Lead)
    let siteVisits: any[] = [];
    if (r.lead_id) {
      const svRes = db.exec(`SELECT * FROM site_visits WHERE lead_id = '${r.lead_id}' ORDER BY preferred_date ASC;`);
      siteVisits = mapRows(svRes);
    }

    const queryData = {
      id: r.id,
      queryNumber: r.query_number,
      customerId: r.customer_id,
      leadId: r.lead_id,
      transactionType: r.transaction_type,
      category: r.category,
      preferredLocations: r.preferred_locations,
      budgetMin: r.budget_min,
      budgetMax: r.budget_max,
      propertyType: r.property_type,
      bhk: r.bhk,
      areaMin: r.area_min,
      areaMax: r.area_max,
      furnishing: r.furnishing,
      parkingRequired: r.parking_required,
      businessType: r.business_type,
      leaseDuration: r.lease_duration,
      possessionDate: r.possession_date,
      requirementsText: r.requirements_text,
      status: r.status,
      priority: r.priority,
      assignedAgentId: r.assigned_agent_id,
      assignedAgentName: r.agent_name,
      assignedAgentEmail: r.agent_email,
      assignedAgentPhone: r.agent_phone,
      source: r.source,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      lastContactedAt: r.last_contacted_at,
      nextFollowUpAt: r.next_follow_up_at,
      customer: {
        id: r.customer_id,
        name: r.customer_name,
        email: isOwnerCustomer || isAdmin || isAssignedAgent ? r.customer_email : undefined,
        mobile: isOwnerCustomer || isAdmin || isAssignedAgent ? r.customer_mobile : undefined
      },
      listedMatches,
      offMarketMatches,
      activities,
      siteVisits
    };

    res.json({ query: queryData });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching query detail.' });
  }
});

// POST /api/queries/:id/matches - Authorized Agent/Admin creates an Off-Market Match
router.post('/queries/:id/matches', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    // Verify query
    const qRes = db.exec(`SELECT * FROM property_requirements WHERE id = '${id}' OR query_number = '${id}' LIMIT 1;`);
    const qRows = mapRows(qRes);
    if (qRows.length === 0) {
      res.status(404).json({ error: 'Property requirement not found.' });
      return;
    }

    const requirement = qRows[0];

    // Authorization: Only Admin or Assigned Agent can add off-market matches
    if (user.role !== 'admin' && (user.role !== 'agent' || requirement.assigned_agent_id !== user.id)) {
      res.status(403).json({ error: 'Forbidden: Only authorized broker/admin can add off-market matches.' });
      return;
    }

    const {
      source,
      location,
      property_type,
      transaction_type,
      asking_price,
      expected_rent,
      area,
      bhk,
      availability,
      owner_or_representative_name,
      owner_or_representative_contact_reference,
      match_notes,
      status = 'IDENTIFIED'
    } = req.body;

    if (!location || !property_type || !transaction_type) {
      res.status(400).json({ error: 'location, property_type, and transaction_type are required.' });
      return;
    }

    const validStatuses = [
      'IDENTIFIED', 'OWNER_CONTACTED', 'AVAILABLE', 'UNAVAILABLE',
      'CUSTOMER_INTERESTED', 'SITE_VISIT', 'NEGOTIATING', 'CONVERTED', 'CLOSED'
    ];
    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid off-market match status.' });
      return;
    }

    const matchId = `match-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    db.run(`
      INSERT INTO off_market_matches (
        id, query_id, source, location, property_type, transaction_type,
        asking_price, expected_rent, area, bhk, availability,
        owner_or_representative_name, owner_or_representative_contact_reference,
        contacted_by, contacted_at, match_notes, status, created_at, updated_at
      ) VALUES (
        '${matchId}', '${requirement.id}',
        '${(source || 'DIRECT_BROKER_SOURCING').replace(/'/g, "''")}',
        '${location.replace(/'/g, "''")}',
        '${property_type.replace(/'/g, "''")}',
        '${transaction_type.toUpperCase()}',
        ${asking_price !== undefined && asking_price !== null ? Number(asking_price) : 'NULL'},
        ${expected_rent !== undefined && expected_rent !== null ? Number(expected_rent) : 'NULL'},
        ${area !== undefined && area !== null ? Number(area) : 'NULL'},
        '${(bhk || '').replace(/'/g, "''")}',
        '${(availability || 'IMMEDIATE').replace(/'/g, "''")}',
        '${(owner_or_representative_name || '').replace(/'/g, "''")}',
        '${(owner_or_representative_contact_reference || '').replace(/'/g, "''")}',
        '${user.name.replace(/'/g, "''")}', '${now}',
        '${(match_notes || '').replace(/'/g, "''")}',
        '${status}', '${now}', '${now}'
      );
    `);

    // Log Query Activity & Audit
    logQueryActivity(db, requirement.id, user.id, user.name, user.role, 'MATCH_CREATED', `Off-market match added: ${bhk || property_type} in ${location} (${status})`);
    logAudit(db, user.id, user.name, 'MATCH_CREATED', 'OFF_MARKET_MATCH', matchId, `Added off-market match for query ${requirement.query_number} in ${location}`);

    // If linked lead exists, log in lead timeline too
    if (requirement.lead_id) {
      logLeadActivity(db, requirement.lead_id, user.id, user.name, user.role, 'MATCH_CREATED', `Off-market candidate identified: ${bhk || property_type} in ${location}`);
    }

    saveDb();

    res.status(201).json({
      message: 'Off-market match successfully recorded.',
      matchId,
      queryId: requirement.id
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error recording off-market match.' });
  }
});

// PATCH /api/queries/:id/matches/:matchId - Update off-market match (status, notes, etc.)
router.patch('/queries/:id/matches/:matchId', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id, matchId } = req.params;
    const user = req.user!;
    const db = await getDb();

    // Verify match exists
    const mRes = db.exec(`SELECT * FROM off_market_matches WHERE id = '${matchId}' LIMIT 1;`);
    const mRows = mapRows(mRes);
    if (mRows.length === 0) {
      res.status(404).json({ error: 'Off-market match not found.' });
      return;
    }
    const match = mRows[0];

    // Verify requirement
    const qRes = db.exec(`SELECT * FROM property_requirements WHERE id = '${match.query_id}' LIMIT 1;`);
    const qRows = mapRows(qRes);
    const requirement = qRows[0];

    // Authorization: Only Admin or Assigned Agent
    if (user.role !== 'admin' && (user.role !== 'agent' || requirement?.assigned_agent_id !== user.id)) {
      res.status(403).json({ error: 'Forbidden: Only authorized broker/admin can update off-market matches.' });
      return;
    }

    const {
      status,
      match_notes,
      asking_price,
      expected_rent,
      availability,
      owner_or_representative_name,
      owner_or_representative_contact_reference
    } = req.body;

    const validStatuses = [
      'IDENTIFIED', 'OWNER_CONTACTED', 'AVAILABLE', 'UNAVAILABLE',
      'CUSTOMER_INTERESTED', 'SITE_VISIT', 'NEGOTIATING', 'CONVERTED', 'CLOSED'
    ];

    const updates: string[] = [];
    const now = new Date().toISOString();

    if (status) {
      if (!validStatuses.includes(status)) {
        res.status(400).json({ error: 'Invalid match status.' });
        return;
      }
      updates.push(`status = '${status}'`);
    }
    if (match_notes !== undefined) {
      updates.push(`match_notes = '${match_notes.replace(/'/g, "''")}'`);
    }
    if (asking_price !== undefined) {
      updates.push(`asking_price = ${asking_price !== null ? Number(asking_price) : 'NULL'}`);
    }
    if (expected_rent !== undefined) {
      updates.push(`expected_rent = ${expected_rent !== null ? Number(expected_rent) : 'NULL'}`);
    }
    if (availability !== undefined) {
      updates.push(`availability = '${availability.replace(/'/g, "''")}'`);
    }
    if (owner_or_representative_name !== undefined) {
      updates.push(`owner_or_representative_name = '${owner_or_representative_name.replace(/'/g, "''")}'`);
    }
    if (owner_or_representative_contact_reference !== undefined) {
      updates.push(`owner_or_representative_contact_reference = '${owner_or_representative_contact_reference.replace(/'/g, "''")}'`);
    }

    updates.push(`updated_at = '${now}'`);

    db.run(`UPDATE off_market_matches SET ${updates.join(', ')} WHERE id = '${matchId}';`);

    // Log Query Activity & Audit
    const actDetails = status ? `Status updated to ${status}` : 'Match details updated';
    logQueryActivity(db, match.query_id, user.id, user.name, user.role, 'MATCH_UPDATED', actDetails);
    logAudit(db, user.id, user.name, 'MATCH_UPDATED', 'OFF_MARKET_MATCH', matchId, actDetails);

    if (requirement?.lead_id) {
      logLeadActivity(db, requirement.lead_id, user.id, user.name, user.role, 'MATCH_UPDATED', `Off-market match #${matchId.slice(-4)}: ${actDetails}`);
    }

    saveDb();

    res.json({ message: 'Off-market match updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating off-market match.' });
  }
});

// POST /api/queries/:id/matches/:matchId/schedule-visit - Schedule site visit for an interested match
router.post('/queries/:id/matches/:matchId/schedule-visit', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id, matchId } = req.params;
    const user = req.user!;
    const db = await getDb();

    const mRes = db.exec(`SELECT * FROM off_market_matches WHERE id = '${matchId}' LIMIT 1;`);
    const mRows = mapRows(mRes);
    if (mRows.length === 0) {
      res.status(404).json({ error: 'Off-market match not found.' });
      return;
    }
    const match = mRows[0];

    const qRes = db.exec(`
      SELECT q.*, c.name as customer_name, c.email as customer_email, c.mobile as customer_mobile
      FROM property_requirements q
      JOIN customer_profiles c ON q.customer_id = c.id
      WHERE q.id = '${match.query_id}' LIMIT 1;
    `);
    const qRows = mapRows(qRes);
    const requirement = qRows[0];

    const { preferred_date, preferred_time, notes } = req.body;
    if (!preferred_date || !preferred_time) {
      res.status(400).json({ error: 'preferred_date and preferred_time are required.' });
      return;
    }

    const visitId = `visit-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    // Link site visit to existing lead and record off-market location
    db.run(`
      INSERT INTO site_visits (
        id, property_id, visitor_user_id, visitor_name, visitor_email, visitor_phone,
        preferred_date, preferred_time, message, status, lead_id, customer_id, created_at, updated_at
      ) VALUES (
        '${visitId}', 'OFF-MARKET', '${user.id}', '${requirement.customer_name.replace(/'/g, "''")}',
        '${requirement.customer_email.replace(/'/g, "''")}', '${requirement.customer_mobile.replace(/'/g, "''")}',
        '${preferred_date}', '${preferred_time}',
        '${(notes || `Site visit for off-market match in ${match.location}`).replace(/'/g, "''")}',
        'CONFIRMED', '${requirement.lead_id || 'NULL'}', '${requirement.customer_id}', '${now}', '${now}'
      );
    `);

    // Update match status to SITE_VISIT
    db.run(`UPDATE off_market_matches SET status = 'SITE_VISIT', updated_at = '${now}' WHERE id = '${matchId}';`);

    // Log Query Activity & Lead Timeline
    logQueryActivity(db, requirement.id, user.id, user.name, user.role, 'SITE_VISIT_CREATED', `Site visit scheduled for off-market match (${match.location}) on ${preferred_date} at ${preferred_time}`);
    logAudit(db, user.id, user.name, 'SITE_VISIT_CREATED', 'SITE_VISIT', visitId, `Scheduled visit for query ${requirement.query_number} off-market match`);

    if (requirement.lead_id) {
      logLeadActivity(db, requirement.lead_id, user.id, user.name, user.role, 'SITE_VISIT_CONFIRMED', `Site visit confirmed for off-market candidate in ${match.location} on ${preferred_date}`);
      db.run(`UPDATE leads SET status = 'SITE_VISIT', updated_at = '${now}' WHERE id = '${requirement.lead_id}';`);
    }

    saveDb();

    res.status(201).json({
      message: 'Site visit successfully scheduled for off-market match.',
      visitId,
      status: 'SITE_VISIT'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error scheduling site visit.' });
  }
});

// PATCH /api/queries/:id/status - Update Query Status & Priority (Agent / Admin)
router.patch('/queries/:id/status', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const db = await getDb();

    const qRes = db.exec(`SELECT * FROM property_requirements WHERE id = '${id}' OR query_number = '${id}' LIMIT 1;`);
    const qRows = mapRows(qRes);
    if (qRows.length === 0) {
      res.status(404).json({ error: 'Property requirement not found.' });
      return;
    }
    const requirement = qRows[0];

    // Authorization
    if (user.role !== 'admin' && (user.role !== 'agent' || requirement.assigned_agent_id !== user.id)) {
      res.status(403).json({ error: 'Forbidden: Only authorized broker/admin can update query status.' });
      return;
    }

    const { status, priority, assigned_agent_id, follow_up_date } = req.body;
    const updates: string[] = [];
    const now = new Date().toISOString();

    if (status) {
      updates.push(`status = '${status.replace(/'/g, "''")}'`);
    }
    if (priority) {
      updates.push(`priority = '${priority.replace(/'/g, "''")}'`);
    }
    if (assigned_agent_id !== undefined) {
      if (user.role !== 'admin') {
        res.status(403).json({ error: 'Only admin can reassign queries.' });
        return;
      }
      updates.push(`assigned_agent_id = ${assigned_agent_id ? `'${assigned_agent_id}'` : 'NULL'}`);
    }
    if (follow_up_date) {
      updates.push(`next_follow_up_at = '${follow_up_date}'`);
    }

    updates.push(`updated_at = '${now}'`);

    db.run(`UPDATE property_requirements SET ${updates.join(', ')} WHERE id = '${requirement.id}';`);

    const logMsg = `Query updated: ${status ? `Status: ${status} ` : ''}${priority ? `Priority: ${priority} ` : ''}${assigned_agent_id ? `Assigned to: ${assigned_agent_id}` : ''}`;
    logQueryActivity(db, requirement.id, user.id, user.name, user.role, 'QUERY_STATUS_CHANGED', logMsg);
    logAudit(db, user.id, user.name, 'QUERY_STATUS_CHANGED', 'PROPERTY_REQUIREMENT', requirement.id, logMsg);

    saveDb();

    res.json({ message: 'Query status updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating query status.' });
  }
});

// POST /api/queries/:id/matches/:matchId/convert-to-listing - Start formal listing workflow for off-market property
router.post('/queries/:id/matches/:matchId/convert-to-listing', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { id, matchId } = req.params;
    const user = req.user!;
    const db = await getDb();

    // Verify match
    const mRes = db.exec(`SELECT * FROM off_market_matches WHERE id = '${matchId}' LIMIT 1;`);
    const mRows = mapRows(mRes);
    if (mRows.length === 0) {
      res.status(404).json({ error: 'Off-market match not found.' });
      return;
    }
    const match = mRows[0];

    // Only Admin or Assigned Agent
    const qRes = db.exec(`SELECT * FROM property_requirements WHERE id = '${match.query_id}' LIMIT 1;`);
    const qRows = mapRows(qRes);
    const requirement = qRows[0];

    if (user.role !== 'admin' && (user.role !== 'agent' || requirement?.assigned_agent_id !== user.id)) {
      res.status(403).json({ error: 'Forbidden: Only authorized broker/admin can initiate listing workflow.' });
      return;
    }

    // Create a property in DRAFT status so it goes through full verification & moderation
    const propertyId = `prop-converted-${Date.now()}-${Math.round(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    const title = `${match.bhk || match.property_type} in ${match.location} (Converted Listing)`;
    const priceVal = match.asking_price || match.expected_rent || 0;
    const transType = (match.transaction_type || 'BUY').toLowerCase();
    const catVal = ['Office', 'Shop', 'Showroom', 'Warehouse'].includes(match.property_type) ? 'commercial' : 'residential';

    db.run(`
      INSERT INTO properties (
        id, owner_id, category, transaction_type, property_type, title, description,
        price, rent, carpet_area, address, locality, city, pincode, status, verification_status,
        created_at, updated_at
      ) VALUES (
        '${propertyId}', '${user.id}', '${catVal}', '${transType}', '${match.property_type.replace(/'/g, "''")}',
        '${title.replace(/'/g, "''")}', 'Listing created from converted off-market property candidate.',
        ${priceVal}, ${match.expected_rent || 'NULL'}, ${match.area || 'NULL'},
        '${match.location.replace(/'/g, "''")}', '${match.location.replace(/'/g, "''")}', 'Mumbai', '400001',
        'DRAFT', 'PENDING', '${now}', '${now}'
      );
    `);

    // Update match status to CONVERTED
    db.run(`UPDATE off_market_matches SET status = 'CONVERTED', updated_at = '${now}' WHERE id = '${matchId}';`);

    logQueryActivity(db, match.query_id, user.id, user.name, user.role, 'MATCH_CONVERTED_TO_LISTING', `Off-market property converted to DRAFT listing ${propertyId} for normal verification.`);
    logAudit(db, user.id, user.name, 'MATCH_CONVERTED_TO_LISTING', 'PROPERTY', propertyId, `Off-market match #${matchId} started normal moderation workflow as DRAFT.`);

    saveDb();

    res.status(201).json({
      message: 'Off-market property initiated as DRAFT listing. Requires normal verification and admin approval before public publication.',
      propertyId,
      status: 'DRAFT',
      verificationStatus: 'PENDING'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error converting off-market property to listing.' });
  }
});

export default router;
