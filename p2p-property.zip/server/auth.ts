import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { getDb } from './db.js';

export const getJwtSecret = (): string => process.env.JWT_SECRET || 'p2p-mumbai-real-estate-secret-key-2026';
export const JWT_SECRET = getJwtSecret();

export interface AuthenticatedUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'buyer' | 'tenant' | 'owner' | 'agent' | 'admin';
  capabilities: string[];
  is_verified: boolean;
  verification_status: 'UNVERIFIED' | 'UNDER_REVIEW' | 'VERIFIED' | 'REJECTED';
  account_status: 'ACTIVE' | 'SUSPENDED';
  avatar_url?: string;
}

export interface AuthRequest extends Request {
  user?: AuthenticatedUser;
}

export function generateToken(user: { id: string; email: string; role: string }): string {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    getJwtSecret(),
    { expiresIn: '7d' }
  );
}

export async function authMiddleware(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please log in.' });
    return;
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, getJwtSecret()) as { id: string; email: string; role: string };
    const db = await getDb();
    const query = db.exec(`SELECT id, name, email, phone, role, capabilities, is_verified, verification_status, account_status, avatar_url FROM users WHERE id = '${decoded.id}' LIMIT 1;`);

    if (!query || query.length === 0 || query[0].values.length === 0) {
      res.status(401).json({ error: 'User session invalid. Please log in again.' });
      return;
    }

    const row = query[0].values[0];
    const columns = query[0].columns;
    const userObj: any = {};
    columns.forEach((col, index) => {
      userObj[col] = row[index];
    });

    if (userObj.account_status === 'SUSPENDED') {
      res.status(403).json({ error: 'Your account is suspended. Please contact support.' });
      return;
    }

    req.user = {
      id: userObj.id,
      name: userObj.name,
      email: userObj.email,
      phone: userObj.phone,
      role: userObj.role,
      capabilities: JSON.parse(userObj.capabilities || '[]'),
      is_verified: Boolean(userObj.is_verified),
      verification_status: userObj.verification_status || (userObj.is_verified ? 'VERIFIED' : 'UNVERIFIED'),
      account_status: userObj.account_status || 'ACTIVE',
      avatar_url: userObj.avatar_url
    };

    next();
  } catch (err) {
    res.status(401).json({ error: 'Session expired or invalid token.' });
  }
}

export async function optionalAuthMiddleware(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, getJwtSecret()) as { id: string; email: string; role: string };
    const db = await getDb();
    const query = db.exec(`SELECT id, name, email, phone, role, capabilities, is_verified, verification_status, account_status, avatar_url FROM users WHERE id = '${decoded.id}' LIMIT 1;`);

    if (query && query.length > 0 && query[0].values.length > 0) {
      const row = query[0].values[0];
      const columns = query[0].columns;
      const userObj: any = {};
      columns.forEach((col, index) => {
        userObj[col] = row[index];
      });

      if (userObj.account_status !== 'SUSPENDED') {
        req.user = {
          id: userObj.id,
          name: userObj.name,
          email: userObj.email,
          phone: userObj.phone,
          role: userObj.role,
          capabilities: JSON.parse(userObj.capabilities || '[]'),
          is_verified: Boolean(userObj.is_verified),
          verification_status: userObj.verification_status || (userObj.is_verified ? 'VERIFIED' : 'UNVERIFIED'),
          account_status: userObj.account_status || 'ACTIVE',
          avatar_url: userObj.avatar_url
        };
      }
    }
  } catch {
    // Ignore invalid optional tokens
  }
  next();
}

export function adminMiddleware(req: AuthRequest, res: Response, next: NextFunction): void {
  if (!req.user || req.user.role !== 'admin') {
    res.status(403).json({ error: 'Admin privileges required to access this action.' });
    return;
  }
  next();
}
