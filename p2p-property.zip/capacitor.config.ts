import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.p2pproperty.app',
  appName: 'P2P Property',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: false
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#1C1917',
      showSpinner: true,
      spinnerColor: '#F59E0B'
    },
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#1C1917'
    }
  }
};

export default config;
