import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { PropertyProvider } from './context/PropertyContext';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { AuthModal } from './components/common/AuthModal';
import { Toast } from './components/common/Toast';
import { HomePage } from './pages/HomePage';
import { PropertiesPage } from './pages/PropertiesPage';
import { PropertyDetailPage } from './pages/PropertyDetailPage';
import { ListPropertyPage } from './pages/ListPropertyPage';
import { SellPage } from './pages/SellPage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { ProfilePage } from './pages/ProfilePage';
import { DashboardPage } from './pages/DashboardPage';
import { SavedPropertiesPage } from './pages/SavedPropertiesPage';
import { AdminRoute } from './components/admin/AdminRoute';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminPropertiesPage } from './pages/admin/AdminPropertiesPage';
import { AdminPropertyDetailPage } from './pages/admin/AdminPropertyDetailPage';
import { AdminUsersPage } from './pages/admin/AdminUsersPage';
import { AdminEnquiriesPage } from './pages/admin/AdminEnquiriesPage';
import { AdminSiteVisitsPage } from './pages/admin/AdminSiteVisitsPage';
import { AdminAuditLogsPage } from './pages/admin/AdminAuditLogsPage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';
import { OwnerLeadsPage } from './pages/dashboard/OwnerLeadsPage';
import { LeadDetailPage } from './pages/dashboard/LeadDetailPage';
import { AdminLeadsPage } from './pages/admin/AdminLeadsPage';
import { DealsPage } from './pages/dashboard/DealsPage';
import { DealDetailPage } from './pages/dashboard/DealDetailPage';
import { AdminDealsPage } from './pages/admin/AdminDealsPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { LegalPage } from './pages/LegalPage';
import { PostRequirementPage } from './pages/PostRequirementPage';
import { CustomerQueriesPage } from './pages/dashboard/CustomerQueriesPage';
import { QueryDetailPage } from './pages/dashboard/QueryDetailPage';
import { AdminQueriesPage } from './pages/admin/AdminQueriesPage';

// Scroll to top helper on route change
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [pathname]);

  return null;
}

export default function App() {
  return (
    <PropertyProvider>
      <BrowserRouter>
        <ScrollToTop />
        <div className="min-h-screen flex flex-col bg-[#FAF9F5] text-stone-900 selection:bg-amber-200 selection:text-stone-950 font-sans">
          <Navbar />
          
          <div className="flex-1">
            <Routes>
              {/* Home */}
              <Route path="/" element={<HomePage />} />
              
              {/* All Properties & Search */}
              <Route path="/properties" element={<PropertiesPage />} />
              
              {/* Single Property Detail */}
              <Route path="/properties/:id" element={<PropertyDetailPage />} />
              
              {/* List Property Multi-Step Wizard */}
              <Route path="/list-property" element={<ListPropertyPage />} />
              
              {/* Auth Routes */}
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route path="/forgot-password" element={<ForgotPasswordPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              
              {/* Dashboard & User Centers */}
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/dashboard/leads" element={<OwnerLeadsPage />} />
              <Route path="/dashboard/leads/:id" element={<LeadDetailPage />} />
              <Route path="/dashboard/deals" element={<DealsPage />} />
              <Route path="/dashboard/deals/:id" element={<DealDetailPage />} />
              <Route path="/dashboard/queries" element={<CustomerQueriesPage />} />
              <Route path="/dashboard/queries/:id" element={<QueryDetailPage />} />
              <Route path="/saved-properties" element={<SavedPropertiesPage />} />
              
              {/* Production Admin Governance Routes (Protected) */}
              <Route path="/admin" element={<AdminRoute><AdminDashboardPage /></AdminRoute>} />
              <Route path="/admin/properties" element={<AdminRoute><AdminPropertiesPage /></AdminRoute>} />
              <Route path="/admin/properties/:id" element={<AdminRoute><AdminPropertyDetailPage /></AdminRoute>} />
              <Route path="/admin/leads" element={<AdminRoute><AdminLeadsPage /></AdminRoute>} />
              <Route path="/admin/queries" element={<AdminRoute><AdminQueriesPage /></AdminRoute>} />
              <Route path="/admin/deals" element={<AdminRoute><AdminDealsPage /></AdminRoute>} />
              <Route path="/admin/users" element={<AdminRoute><AdminUsersPage /></AdminRoute>} />
              <Route path="/admin/enquiries" element={<AdminRoute><AdminEnquiriesPage /></AdminRoute>} />
              <Route path="/admin/site-visits" element={<AdminRoute><AdminSiteVisitsPage /></AdminRoute>} />
              <Route path="/admin/audit-logs" element={<AdminRoute><AdminAuditLogsPage /></AdminRoute>} />
              <Route path="/admin/audit-log" element={<AdminRoute><AdminAuditLogsPage /></AdminRoute>} />
              <Route path="/admin/settings" element={<AdminRoute><AdminSettingsPage /></AdminRoute>} />

              {/* Post Your Requirement / Query Mode */}
              <Route path="/post-requirement" element={<PostRequirementPage />} />

              {/* Category & Transaction Pre-filtered Route Pages */}
              <Route 
                path="/buy" 
                element={
                  <PropertiesPage 
                    initialTransaction="buy" 
                    pageTitle="Properties for Sale in Mumbai"
                    pageSubtitle="Discover flats, apartments, penthouses, and commercial spaces available for direct purchase."
                  />
                } 
              />
              <Route 
                path="/rent" 
                element={
                  <PropertiesPage 
                    initialTransaction="rent" 
                    pageTitle="Properties for Rent in Mumbai"
                    pageSubtitle="Rent verified residential homes and commercial suites directly from owners across Mumbai."
                  />
                } 
              />
              <Route 
                path="/commercial" 
                element={
                  <PropertiesPage 
                    initialCategory="commercial" 
                    pageTitle="Commercial Real Estate in Mumbai"
                    pageSubtitle="Corporate offices, retail showrooms, co-working floors, and logistics warehouses in Mumbai CBDs."
                  />
                } 
              />
              <Route path="/sell" element={<SellPage />} />
              
              {/* Public Discovery & Information Pages */}
              <Route path="/property/:id" element={<PropertyDetailPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/privacy" element={<LegalPage forcedSlug="privacy" />} />
              <Route path="/terms" element={<LegalPage forcedSlug="terms" />} />
              <Route path="/brokerage-terms" element={<LegalPage forcedSlug="brokerage-terms" />} />
              <Route path="/refund-policy" element={<LegalPage forcedSlug="refund-policy" />} />
              <Route path="/verification-policy" element={<LegalPage forcedSlug="verification-policy" />} />
              
              {/* Fallback route */}
              <Route path="*" element={<PropertiesPage />} />
            </Routes>
          </div>

          <Footer />

          {/* Global Modals & Notifications */}
          <AuthModal />
          <Toast />
        </div>
      </BrowserRouter>
    </PropertyProvider>
  );
}

