const API_BASE = '/api';

export function getAuthToken(): string | null {
  try {
    return localStorage.getItem('p2p_auth_token_v2');
  } catch {
    return null;
  }
}

export function setAuthToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem('p2p_auth_token_v2', token);
    } else {
      localStorage.removeItem('p2p_auth_token_v2');
    }
  } catch {
    // ignore
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> || {})
  };

  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }

  return data as T;
}

export const api = {
  // Authentication
  auth: {
    signup: (data: { name: string; email: string; phone: string; password: string; role?: string }) =>
      request<{ token: string; user: any }>('/auth/signup', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    login: (credentials: { email: string; password: string }) =>
      request<{ token: string; user: any }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials)
      }),
    getMe: () => request<{ user: any }>('/auth/me'),
    updateProfile: (data: { name?: string; phone?: string; role?: string }) =>
      request<{ user: any }>('/auth/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    forgotPassword: (email: string) =>
      request<{ message: string }>('/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email })
      })
  },

  // Properties
  properties: {
    list: (params: Record<string, string | number | boolean | undefined> = {}) => {
      const cleanParams = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== '' && v !== null) {
          cleanParams.set(k, String(v));
        }
      });
      return request<{ properties: any[]; pagination: { page: number; limit: number; total: number; totalPages: number } }>(
        `/properties?${cleanParams.toString()}`
      );
    },
    getById: (id: string) => request<{ property: any }>(`/properties/${id}`),
    create: (propertyData: any) =>
      request<{ message: string; propertyId: string; status: string }>('/properties', {
        method: 'POST',
        body: JSON.stringify(propertyData)
      }),
    update: (id: string, propertyData: any) =>
      request<{ message: string }>(`/properties/${id}`, {
        method: 'PUT',
        body: JSON.stringify(propertyData)
      }),
    delete: (id: string) =>
      request<{ message: string }>(`/properties/${id}`, {
        method: 'DELETE'
      }),
    updateStatus: (id: string, status: string) =>
      request<{ message: string; status: string }>(`/properties/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      })
  },

  // Media / Upload
  media: {
    upload: async (file: File) => {
      const formData = new FormData();
      formData.append('image', file);
      return request<{ url: string; filename: string }>('/upload', {
        method: 'POST',
        body: formData
      });
    }
  },

  // Inquiries
  inquiries: {
    create: (propertyId: string, data: { message: string; preferred_contact_time?: string }) =>
      request<{ message: string; inquiryId: string }>(`/properties/${propertyId}/inquiries`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateStatus: (id: string, status: string) =>
      request<{ message: string; status: string }>(`/inquiries/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      })
  },

  // Site Visits
  siteVisits: {
    create: (propertyId: string, data: { preferred_date: string; preferred_time: string; message?: string }) =>
      request<{ message: string; visitId: string }>(`/properties/${propertyId}/site-visits`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateStatus: (id: string, status: string) =>
      request<{ message: string; status: string }>(`/site-visits/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      })
  },

  // Saved Properties
  savedProperties: {
    list: () => request<{ properties: any[] }>('/saved-properties'),
    save: (propertyId: string) =>
      request<{ message: string }>(`/saved-properties/${propertyId}`, {
        method: 'POST'
      }),
    unsave: (propertyId: string) =>
      request<{ message: string }>(`/saved-properties/${propertyId}`, {
        method: 'DELETE'
      })
  },

  // Dashboard
  dashboard: {
    myProperties: () => request<{ properties: any[] }>('/dashboard/my-properties'),
    myInquiries: () => request<{ received: any[]; sent: any[] }>('/dashboard/inquiries'),
    mySiteVisits: () => request<{ received: any[]; sent: any[] }>('/dashboard/site-visits')
  },

  // Admin
  admin: {
    metrics: () => request<{ metrics: any }>('/admin/metrics'),
    activity: () => request<{ activities: any[] }>('/admin/activity'),
    properties: (filters?: string | Record<string, string | number | undefined>) => {
      if (typeof filters === 'string') {
        return request<{ properties: any[] }>(`/admin/properties${filters ? `?status=${filters}` : ''}`);
      }
      const cleanParams = new URLSearchParams();
      if (filters) {
        Object.entries(filters).forEach(([k, v]) => {
          if (v !== undefined && v !== '' && v !== null) {
            cleanParams.set(k, String(v));
          }
        });
      }
      return request<{ properties: any[] }>(`/admin/properties?${cleanParams.toString()}`);
    },
    getProperty: (id: string) => request<{ property: any }>(`/admin/properties/${id}`),
    reviewProperty: (
      id: string,
      action: 'approve' | 'reject' | 'request_changes' | 'verify' | 'unverify' | 'under_review' | 'deactivate',
      reason?: string
    ) =>
      request<{ message: string; status?: string; verification_status?: string }>(`/admin/properties/${id}/review`, {
        method: 'PATCH',
        body: JSON.stringify({ action, reason })
      }),
    users: (filters?: Record<string, string | undefined>) => {
      const cleanParams = new URLSearchParams();
      if (filters) {
        Object.entries(filters).forEach(([k, v]) => {
          if (v !== undefined && v !== '' && v !== null) {
            cleanParams.set(k, String(v));
          }
        });
      }
      return request<{ users: any[] }>(`/admin/users?${cleanParams.toString()}`);
    },
    getUser: (id: string) => request<{ user: any }>(`/admin/users/${id}`),
    updateUserStatus: (id: string, data: { account_status?: string; verification_status?: string; role?: string }) =>
      request<{ message: string }>(`/admin/users/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      }),
    updateUserRole: (id: string, data: { role?: string; is_verified?: boolean }) =>
      request<{ message: string }>(`/admin/users/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({
          role: data.role,
          verification_status: data.is_verified !== undefined ? (data.is_verified ? 'VERIFIED' : 'UNVERIFIED') : undefined
        })
      }),
    enquiries: (params?: { status?: string; search?: string }) => {
      const cleanParams = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== '' && v !== null) cleanParams.set(k, String(v));
        });
      }
      return request<{ enquiries: any[] }>(`/admin/enquiries?${cleanParams.toString()}`);
    },
    updateEnquiryStatus: (id: string, status: string) =>
      request<{ message: string; status: string }>(`/admin/enquiries/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),
    siteVisits: (params?: { status?: string; search?: string }) => {
      const cleanParams = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== '' && v !== null) cleanParams.set(k, String(v));
        });
      }
      return request<{ visits: any[] }>(`/admin/site-visits?${cleanParams.toString()}`);
    },
    updateSiteVisitStatus: (id: string, status: string) =>
      request<{ message: string; status: string }>(`/admin/site-visits/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),
    auditLogs: (params?: { entity_type?: string; limit?: number }) => {
      const cleanParams = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== '' && v !== null) cleanParams.set(k, String(v));
        });
      }
      return request<{ logs: any[] }>(`/admin/audit-logs?${cleanParams.toString()}`);
    },
    settings: () => request<{ system: any }>('/admin/settings'),
    leads: (filters?: Record<string, string | undefined>) => {
      const cleanParams = new URLSearchParams();
      if (filters) {
        Object.entries(filters).forEach(([k, v]) => {
          if (v !== undefined && v !== '' && v !== null) cleanParams.set(k, String(v));
        });
      }
      return request<{ leads: any[]; kpis: any }>(`/admin/leads?${cleanParams.toString()}`);
    },
    assignLead: (id: string, assignedToId: string, notes?: string) =>
      request<{ message: string; assignedTo: any }>(`/admin/leads/${id}/assign`, {
        method: 'PATCH',
        body: JSON.stringify({ assigned_to_id: assignedToId, notes })
      }),
    agentsList: () => request<{ agents: any[] }>('/admin/agents-list')
  },

  // Phase 4: Lead & Customer Management System
  leads: {
    list: (filters?: Record<string, string | undefined>) => {
      const cleanParams = new URLSearchParams();
      if (filters) {
        Object.entries(filters).forEach(([k, v]) => {
          if (v !== undefined && v !== '' && v !== null) cleanParams.set(k, String(v));
        });
      }
      return request<{ leads: any[]; stats: any }>(`/leads?${cleanParams.toString()}`);
    },
    get: (id: string) => request<{ lead: any }>(`/leads/${id}`),
    create: (data: any) =>
      request<{ message: string; leadId: string }>('/leads', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateStatus: (id: string, status: string, reason?: string) =>
      request<{ message: string; status: string }>(`/leads/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status, reason })
      }),
    update: (id: string, data: any) =>
      request<{ message: string }>(`/leads/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      }),
    addNote: (id: string, note: string) =>
      request<{ message: string }>(`/leads/${id}/notes`, {
        method: 'POST',
        body: JSON.stringify({ note })
      }),
    recordContact: (id: string, data: { method: string; details?: string; outcome?: string }) =>
      request<{ message: string; lastContactedAt: string; status: string }>(`/leads/${id}/contact`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    timeline: (id: string) => request<{ activities: any[] }>(`/leads/${id}/timeline`),
    scheduleFollowUp: (id: string, data: { follow_up_date: string; follow_up_time?: string; note: string; assigned_to?: string }) =>
      request<{ message: string; followUpId: string }>(`/leads/${id}/follow-ups`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateFollowUp: (followUpId: string, status: string) =>
      request<{ message: string; status: string }>(`/leads/follow-ups/${followUpId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),
    myFollowUps: () => request<{ followUps: any[] }>('/dashboard/follow-ups'),
    scheduleSiteVisit: (id: string, data: { preferred_date: string; preferred_time: string; message?: string }) =>
      request<{ message: string; visitId: string }>(`/leads/${id}/site-visits`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    getWhatsAppConfig: () => request<{ businessNumber: string }>('/settings/whatsapp'),
    convertToDeal: (id: string, data: any) =>
      request<{ message: string; dealId: string; dealNumber: string; dealStatus: string; commissionAmount: number }>(`/leads/${id}/convert-to-deal`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    getDeal: (id: string) => request<{ deal: any | null }>(`/leads/${id}/deal`)
  },

  // Deals, Brokerage & Commission Management (Phase 5)
  deals: {
    list: (params?: {
      status?: string;
      commission_status?: string;
      transaction_type?: string;
      category?: string;
      lead_id?: string;
      search?: string;
    }) => {
      const searchParams = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v && v !== 'ALL') searchParams.append(k, String(v));
        });
      }
      const queryStr = searchParams.toString();
      return request<{ deals: any[]; stats: any }>(`/deals${queryStr ? `?${queryStr}` : ''}`);
    },
    get: (id: string) => request<{ deal: any }>(`/deals/${id}`),
    update: (id: string, data: any) =>
      request<{ message: string; status: string }>(`/deals/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      }),
    updateCommission: (id: string, data: any) =>
      request<{ message: string; commissionAmount: number; commissionStatus: string; commissionPayer: string }>(`/deals/${id}/commission`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      }),
    recordPayment: (id: string, data: {
      amount: number;
      payment_method?: string;
      transaction_reference?: string;
      payment_date?: string;
      payer_name?: string;
      notes?: string;
    }) =>
      request<{ message: string; payment: any }>(`/deals/${id}/payments`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    generateInvoice: (id: string, data: {
      issue_date?: string;
      due_date?: string;
      subtotal?: number;
      gst_rate?: number;
      notes?: string;
    }) =>
      request<{ message: string; invoice: any }>(`/deals/${id}/invoices`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    addNote: (id: string, note: string) =>
      request<{ message: string }>(`/deals/${id}/notes`, {
        method: 'POST',
        body: JSON.stringify({ note })
      })
  },

  // Property Documents (Part 5)
  propertyDocuments: {
    list: (propertyId: string) =>
      request<{ documents: any[] }>(`/properties/${propertyId}/documents`),
    upload: (propertyId: string, data: {
      document_type: string;
      title: string;
      file_url: string;
      file_name?: string;
      file_size?: number;
      mime_type?: string;
    }) =>
      request<{ message: string; document: any }>(`/properties/${propertyId}/documents`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateStatus: (propertyId: string, docId: string, status: string, adminNotes?: string) =>
      request<{ message: string; document: any }>(`/properties/${propertyId}/documents/${docId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ verification_status: status, admin_notes: adminNotes })
      }),
    delete: (propertyId: string, docId: string) =>
      request<{ message: string }>(`/properties/${propertyId}/documents/${docId}`, {
        method: 'DELETE'
      })
  },

  // Internal Notifications (Part 17)
  notifications: {
    list: () =>
      request<{ notifications: any[]; unreadCount: number }>('/notifications'),
    markRead: (id: string) =>
      request<{ success: boolean }>(`/notifications/${id}/read`, {
        method: 'PATCH'
      }),
    markAllRead: () =>
      request<{ success: boolean }>('/notifications/mark-all-read', {
        method: 'POST'
      })
  },

  // System & MahaRERA Compliance Settings (Part 6 & Part 33)
  settings: {
    getPublic: () =>
      request<{
        businessName: string;
        brandTagline: string;
        brokerName: string;
        mahareraRegNumber: string;
        certificateOfCompetency: string;
        businessPhone: string;
        businessEmail: string;
        officeAddress: string;
        whatsappNumber: string;
        currency: string;
        defaultGstRate: number;
        razorpayConfigured: boolean;
        razorpayKeyId: string | null;
      }>('/settings/public'),
    getAdmin: () =>
      request<{ settings: any[]; paymentGateway: any }>('/admin/system-settings'),
    updateAdmin: (settings: Record<string, string>) =>
      request<{ message: string }>('/admin/system-settings', {
        method: 'PATCH',
        body: JSON.stringify({ settings })
      })
  },

  // Legal Pages (Part 29)
  legal: {
    get: (slug: string) =>
      request<{ slug: string; title: string; content: string; updatedAt: string; updatedBy?: string }>(`/legal/${slug}`),
    update: (slug: string, data: { title?: string; content: string }) =>
      request<{ message: string }>(`/admin/legal/${slug}`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      })
  },

  // Contact / Business Enquiries (Part 32)
  contact: {
    submit: (data: { name: string; email: string; phone: string; enquiry_type?: string; message: string }) =>
      request<{ message: string; id: string }>('/contact', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    listAdmin: (params?: { status?: string; search?: string }) => {
      const q = new URLSearchParams();
      if (params?.status) q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString() ? `?${q.toString()}` : '';
      return request<{ enquiries: any[] }>(`/admin/contact-enquiries${qs}`);
    },
    updateStatus: (id: string, status: string) =>
      request<{ message: string }>(`/admin/contact-enquiries/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      })
  },

  // Online Payments (Part 13)
  payments: {
    createRazorpayOrder: (data: { dealId: string; amount: number }) =>
      request<{
        configured: boolean;
        message?: string;
        orderId?: string;
        amount?: number;
        currency?: string;
        keyId?: string;
        receipt?: string;
      }>('/payments/razorpay/create-order', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    verifyRazorpay: (data: {
      dealId: string;
      razorpay_order_id: string;
      razorpay_payment_id: string;
      razorpay_signature: string;
      amount: number;
      payer_name?: string;
      notes?: string;
    }) =>
      request<{ success: boolean; message: string; payment?: any }>('/payments/razorpay/verify', {
        method: 'POST',
        body: JSON.stringify(data)
      })
  },

  // Internal Analytics (Part 31)
  analytics: {
    logEvent: (data: { event_name: string; entity_type?: string; entity_id?: string; metadata?: any }) =>
      request<{ success: boolean }>('/analytics/events', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    getSummary: () =>
      request<{ analytics: any }>('/admin/analytics/summary')
  },

  // Property Requirements / Query Mode & Off-Market Matching
  queries: {
    create: (data: {
      transaction_type: string;
      category: string;
      preferred_locations?: string;
      budget_min?: number;
      budget_max?: number;
      property_type?: string;
      bhk?: string;
      area_min?: number;
      area_max?: number;
      furnishing?: string;
      parking_required?: string;
      business_type?: string;
      lease_duration?: string;
      possession_date?: string;
      requirements_text?: string;
      priority?: string;
    }) =>
      request<{ message: string; queryId: string; queryNumber: string; leadId: string; customerId: string }>('/queries', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    list: (params?: { status?: string; priority?: string; search?: string }) => {
      const q = new URLSearchParams();
      if (params?.status) q.append('status', params.status);
      if (params?.priority) q.append('priority', params.priority);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString() ? `?${q.toString()}` : '';
      return request<{ queries: any[] }>(`/queries${qs}`);
    },
    get: (id: string) =>
      request<{ query: any }>(`/queries/${id}`),
    updateStatus: (id: string, data: { status?: string; priority?: string; assigned_agent_id?: string; follow_up_date?: string }) =>
      request<{ message: string }>(`/queries/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      }),
    addOffMarketMatch: (queryId: string, data: {
      source?: string;
      location: string;
      property_type: string;
      transaction_type: string;
      asking_price?: number;
      expected_rent?: number;
      area?: number;
      bhk?: string;
      availability?: string;
      owner_or_representative_name?: string;
      owner_or_representative_contact_reference?: string;
      match_notes?: string;
      status?: string;
    }) =>
      request<{ message: string; matchId: string; queryId: string }>(`/queries/${queryId}/matches`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateOffMarketMatch: (queryId: string, matchId: string, data: {
      status?: string;
      match_notes?: string;
      asking_price?: number;
      expected_rent?: number;
      availability?: string;
      owner_or_representative_name?: string;
      owner_or_representative_contact_reference?: string;
    }) =>
      request<{ message: string }>(`/queries/${queryId}/matches/${matchId}`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      }),
    scheduleMatchVisit: (queryId: string, matchId: string, data: {
      preferred_date: string;
      preferred_time: string;
      notes?: string;
    }) =>
      request<{ message: string; visitId: string; status: string }>(`/queries/${queryId}/matches/${matchId}/schedule-visit`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    convertMatchToListing: (queryId: string, matchId: string) =>
      request<{ message: string; propertyId: string; status: string; verificationStatus: string }>(`/queries/${queryId}/matches/${matchId}/convert-to-listing`, {
        method: 'POST'
      })
  }
};
