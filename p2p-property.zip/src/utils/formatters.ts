/**
 * Formats an amount in INR to clean Indian denomination string (Cr, L, or thousands)
 */
export function formatPriceINR(amount: number, priceDisplayType: 'total' | 'per_month' | 'per_year' = 'total'): string {
  if (isNaN(amount) || amount === 0) return 'Price on Request';

  let formatted = '';
  if (amount >= 10000000) {
    const cr = amount / 10000000;
    formatted = `₹${cr % 1 === 0 ? cr.toFixed(0) : cr.toFixed(2)} Cr`;
  } else if (amount >= 100000) {
    const l = amount / 100000;
    formatted = `₹${l % 1 === 0 ? l.toFixed(0) : l.toFixed(1)} L`;
  } else {
    formatted = new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  }

  if (priceDisplayType === 'per_month') {
    return `${formatted}/mo`;
  }
  if (priceDisplayType === 'per_year') {
    return `${formatted}/yr`;
  }
  return formatted;
}

/**
 * Formats a currency amount in INR with standard comma separators
 */
export function formatCurrency(amount: number): string {
  if (isNaN(amount) || amount === 0) return '₹0';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Formats square feet area with comma separator
 */
export function formatArea(sqft: number): string {
  return `${sqft.toLocaleString('en-IN')} sq.ft`;
}

/**
 * Basic HTML/script sanitization for user-entered text
 */
export function sanitizeText(input: string): string {
  if (!input) return '';
  return input
    .replace(/[<>]/g, '') // strip tag openers/closers
    .trim();
}

/**
 * Format Indian phone number display safely
 */
export function maskPhoneNumber(phone: string): string {
  const clean = phone.replace(/\D/g, '');
  if (clean.length >= 10) {
    return `+91 ${clean.slice(0, 2)}••••••${clean.slice(-2)}`;
  }
  return '+91 ••••••••••';
}
