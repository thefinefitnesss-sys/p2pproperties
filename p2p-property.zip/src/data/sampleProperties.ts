import { Property } from '../types/property';

export const SAMPLE_PROPERTIES: Property[] = [
  {
    id: 'prop-mum-01',
    title: 'Sea-Facing 3 BHK Luxury Residence at Carter Road',
    slug: 'sea-facing-3-bhk-carter-road-bandra',
    category: 'residential',
    transactionType: 'buy',
    propertyType: '3 BHK',
    location: {
      buildingName: 'Sea Crest Towers',
      area: 'Carter Road',
      locality: 'Bandra West',
      city: 'Mumbai',
      pincode: '400050',
      landmark: 'Near Joggers Park',
      coordinates: { lat: 19.0657, lng: 72.8258 }
    },
    pricing: {
      price: 87500000, // ₹8.75 Cr
      priceDisplayType: 'total',
      maintenanceAmount: 18500,
      isNegotiable: true
    },
    images: [
      {
        id: 'img-1-1',
        url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg',
        caption: 'Spacious sea-view living room with Italian marble floor',
        isPrimary: true
      },
      {
        id: 'img-1-2',
        url: '/src/assets/images/worli_seaface_residence_1791457653070.jpg',
        caption: 'Master bedroom balcony view'
      },
      {
        id: 'img-1-3',
        url: '/src/assets/images/hero_mumbai_skyline_1791457614725.jpg',
        caption: 'Coastal evening view from tower terrace'
      }
    ],
    description: 'An exceptional high-floor 3 BHK apartment directly overlooking the Arabian Sea on Carter Road, Bandra West. Designed with expansive floor-to-ceiling soundproof glass, continuous Italian Statuario marble flooring, custom modular kitchen, and double-height private deck. Directly offered by verified owner with clear title documents and OC received.',
    amenities: [
      'Arabian Sea View',
      '2 Dedicated Covered Parkings',
      'High-Speed Mitsubishi Elevators',
      '24/7 Biometric Security',
      'Rooftop Infinity Pool',
      'Full DG Power Backup',
      'Clubhouse & Gymnasium',
      'EV Charging Bay'
    ],
    nearbyPlaces: [
      { name: 'Bandra Railway Station', type: 'railway', distanceKm: 2.4 },
      { name: 'BKC Connector via Bandra', type: 'highway', distanceKm: 4.5 },
      { name: 'Lilavati Hospital & Research Centre', type: 'hospital', distanceKm: 1.8 },
      { name: 'Chhatrapati Shivaji Maharaj Airport (BOM)', type: 'airport', distanceKm: 9.2 }
    ],
    isVerified: true,
    isFeatured: true,
    ownerId: 'user-own-101',
    ownerType: 'owner',
    maskedContact: {
      nameInitials: 'R. K.',
      verifiedPhoneEnding: '84'
    },
    residentialDetails: {
      bhk: '3 BHK',
      bedrooms: 3,
      bathrooms: 3,
      balconies: 2,
      carpetArea: 1480,
      builtUpArea: 1950,
      floor: 14,
      totalFloors: 22,
      furnishing: 'semi-furnished',
      parking: { covered: 2, open: 0 },
      facing: 'West (Sea facing)',
      ageOfProperty: '2 years'
    },
    createdAt: '2026-09-15T10:00:00Z',
    updatedAt: '2026-10-01T12:30:00Z'
  },
  {
    id: 'prop-mum-02',
    title: 'Grade-A Corporate Headquarters Office in BKC',
    slug: 'grade-a-office-bkc-bandra-kurla-complex',
    category: 'commercial',
    transactionType: 'rent',
    propertyType: 'Office',
    location: {
      buildingName: 'The Capital Centre',
      area: 'G Block, BKC',
      locality: 'Bandra Kurla Complex',
      city: 'Mumbai',
      pincode: '400051',
      landmark: 'Opposite ICICI Bank Tower',
      coordinates: { lat: 19.0664, lng: 72.8687 }
    },
    pricing: {
      price: 650000, // ₹6.5 L / month
      priceDisplayType: 'per_month',
      maintenanceAmount: 48000,
      securityDeposit: 3900000, // 6 months deposit
      isNegotiable: true
    },
    images: [
      {
        id: 'img-2-1',
        url: '/src/assets/images/bkc_commercial_office_1791457642520.jpg',
        caption: 'Fully plug & play corporate office workstations',
        isPrimary: true
      },
      {
        id: 'img-2-2',
        url: '/src/assets/images/mumbai_retail_showroom_1791457664965.jpg',
        caption: 'Executive boardroom and reception lobby'
      }
    ],
    description: 'Plug-and-play Grade A commercial office suite situated in the heart of Mumbai’s premier central business district (BKC G Block). Features 48 ergonomic workstations, 2 director cabins, 12-seater AV board room, pantry, server room with independent VRF air conditioning, and 100% DG backup. Suitable for financial institutions, law firms, tech enterprises, and multinationals.',
    amenities: [
      'Plug & Play Ready',
      'Central VRF Chilled Water HVAC',
      '100% Full Power Backup',
      '4 Reserved Basement Parkings',
      'LEED Platinum Certified Building',
      'Multi-Tier Security & Turnstiles',
      'Executive Board Room with VC',
      'Cafeteria & Food Court in Complex'
    ],
    nearbyPlaces: [
      { name: 'BKC Metro Station (Line 3 Aqua Line)', type: 'metro', distanceKm: 0.3 },
      { name: 'Santacruz Chembur Link Road (SCLR)', type: 'highway', distanceKm: 1.2 },
      { name: 'Eastern Express Highway', type: 'highway', distanceKm: 2.1 },
      { name: 'Mumbai Domestic & Intl Airport', type: 'airport', distanceKm: 6.8 }
    ],
    isVerified: true,
    isFeatured: true,
    ownerId: 'user-own-102',
    ownerType: 'authorized_representative',
    maskedContact: {
      nameInitials: 'M. S.',
      verifiedPhoneEnding: '19'
    },
    commercialDetails: {
      commercialType: 'Office',
      carpetArea: 3200,
      builtUpArea: 4400,
      floor: 8,
      totalFloors: 16,
      furnishing: 'fully-furnished',
      parking: { covered: 4, open: 1 },
      washrooms: 4,
      powerBackup: true,
      loadingUnloadingAvailability: true,
      suitableBusinessType: ['Fintech & Banking', 'Corporate Headquarters', 'Consulting & Legal', 'Tech Hub']
    },
    createdAt: '2026-09-20T08:30:00Z',
    updatedAt: '2026-10-02T15:45:00Z'
  },
  {
    id: 'prop-mum-03',
    title: 'Signature Sea-Link View 4+ BHK Penthouse in Worli',
    slug: 'sea-link-view-4-bhk-penthouse-worli',
    category: 'residential',
    transactionType: 'buy',
    propertyType: '4+ BHK',
    location: {
      buildingName: 'Ahuja Horizons',
      area: 'Worli Sea Face',
      locality: 'Worli',
      city: 'Mumbai',
      pincode: '400030',
      landmark: 'Near Worli Dairy',
      coordinates: { lat: 19.0178, lng: 72.8152 }
    },
    pricing: {
      price: 165000000, // ₹16.50 Cr
      priceDisplayType: 'total',
      maintenanceAmount: 32000,
      isNegotiable: false
    },
    images: [
      {
        id: 'img-3-1',
        url: '/src/assets/images/worli_seaface_residence_1791457653070.jpg',
        caption: 'Expansive private terrace looking onto the Arabian Sea',
        isPrimary: true
      },
      {
        id: 'img-3-2',
        url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg',
        caption: 'Grand living room with 12-foot clear ceiling'
      },
      {
        id: 'img-3-3',
        url: '/src/assets/images/hero_mumbai_skyline_1791457614725.jpg',
        caption: 'Bandra-Worli Sea Link twilight panorama'
      }
    ],
    description: 'An elite trophy penthouse on the 38th floor in Worli Sea Face with unhindered 270-degree vistas of the Bandra-Worli Sea Link and Mumbai skyline. Features private elevator lobby, expansive wrap-around sky terrace, four en-suite bedrooms, family lounge, separate staff quarters, and 4 stilt parking spaces. Direct verified deal with owner.',
    amenities: [
      'Private High-Speed Elevator',
      'Wrap-Around Sea Deck',
      '4 Covered Stilt Parkings',
      'Olympic Length Lap Pool',
      'Private Spa & Sauna',
      'Concierge & Valet Service',
      'Servant Quarters with Bath',
      'Double Height Grand Lobby'
    ],
    nearbyPlaces: [
      { name: 'Bandra-Worli Sea Link Entry', type: 'highway', distanceKm: 0.6 },
      { name: 'Worli Metro Station', type: 'metro', distanceKm: 1.1 },
      { name: 'Podar International School', type: 'school', distanceKm: 2.3 },
      { name: 'Four Seasons & St. Regis Mumbai', type: 'commercial_hub', distanceKm: 2.8 }
    ],
    isVerified: true,
    isFeatured: true,
    ownerId: 'user-own-103',
    ownerType: 'owner',
    maskedContact: {
      nameInitials: 'A. P.',
      verifiedPhoneEnding: '92'
    },
    residentialDetails: {
      bhk: '4+ BHK',
      bedrooms: 4,
      bathrooms: 5,
      balconies: 3,
      carpetArea: 2850,
      builtUpArea: 3800,
      floor: 38,
      totalFloors: 42,
      furnishing: 'unfurnished',
      parking: { covered: 4, open: 0 },
      facing: 'North-West (Sea facing)',
      ageOfProperty: 'Brand New (Under 1 year)'
    },
    createdAt: '2026-09-18T14:15:00Z',
    updatedAt: '2026-10-04T09:10:00Z'
  },
  {
    id: 'prop-mum-04',
    title: 'Double-Height High-Street Flagship Showroom in Lower Parel',
    slug: 'flagship-retail-showroom-lower-parel',
    category: 'commercial',
    transactionType: 'lease',
    propertyType: 'Showroom',
    location: {
      buildingName: 'One World Palladium Promenade',
      area: 'Senapati Bapat Marg',
      locality: 'Lower Parel',
      city: 'Mumbai',
      pincode: '400013',
      landmark: 'Near Phoenix Palladium',
      coordinates: { lat: 18.9953, lng: 72.8274 }
    },
    pricing: {
      price: 380000, // ₹3.8 L / month
      priceDisplayType: 'per_month',
      maintenanceAmount: 22000,
      securityDeposit: 2280000,
      isNegotiable: true
    },
    images: [
      {
        id: 'img-4-1',
        url: '/src/assets/images/mumbai_retail_showroom_1791457664965.jpg',
        caption: 'Double height high-visibility glass frontage',
        isPrimary: true
      },
      {
        id: 'img-4-2',
        url: '/src/assets/images/bkc_commercial_office_1791457642520.jpg',
        caption: 'Mezzanine design and back office area'
      }
    ],
    description: 'Prominent ground-floor commercial showroom boasting 45 feet of clear street frontage along main Senapati Bapat Marg in Lower Parel. Features 18-foot clear ceiling height, approved mezzanine level, 3-phase commercial electrical sanction (45 kW), dedicated customer valet drop-off, and rear service entry for inventory loading.',
    amenities: [
      '45 ft Wide Frontage',
      '18 ft Double Height Ceiling',
      'Approved Mezzanine Floor',
      'High Footfall Commercial Hub',
      'Heavy Loading Dock',
      'Dedicated Valet Parking Slots',
      '3-Phase 45kW Power',
      'Central Fire Sprinkler System'
    ],
    nearbyPlaces: [
      { name: 'Lower Parel Monorail & Railway', type: 'railway', distanceKm: 0.4 },
      { name: 'Phoenix Palladium Mall', type: 'commercial_hub', distanceKm: 0.2 },
      { name: 'Coastal Road Connector', type: 'highway', distanceKm: 1.5 },
      { name: 'KEM Hospital Parel', type: 'hospital', distanceKm: 2.1 }
    ],
    isVerified: true,
    isFeatured: true,
    ownerId: 'user-own-104',
    ownerType: 'owner',
    maskedContact: {
      nameInitials: 'D. J.',
      verifiedPhoneEnding: '55'
    },
    commercialDetails: {
      commercialType: 'Showroom',
      carpetArea: 1850,
      builtUpArea: 2400,
      floor: 0,
      totalFloors: 12,
      furnishing: 'unfurnished',
      parking: { covered: 2, open: 2 },
      washrooms: 2,
      powerBackup: true,
      loadingUnloadingAvailability: true,
      suitableBusinessType: ['Luxury Fashion & Jewelry', 'Automobile Boutique', 'Interior & Furniture Gallery', 'High-End Electronics']
    },
    createdAt: '2026-09-22T11:00:00Z',
    updatedAt: '2026-10-05T16:20:00Z'
  },
  {
    id: 'prop-mum-05',
    title: 'Spacious 2 BHK Lakeview Apartment in Hiranandani Powai',
    slug: '2-bhk-lakeview-hiranandani-powai',
    category: 'residential',
    transactionType: 'rent',
    propertyType: '2 BHK',
    location: {
      buildingName: 'Castello Heritage',
      area: 'Hiranandani Gardens',
      locality: 'Powai',
      city: 'Mumbai',
      pincode: '400076',
      landmark: 'Near Galleria Shopping Mall',
      coordinates: { lat: 19.1197, lng: 72.9051 }
    },
    pricing: {
      price: 75000, // ₹75,000 / month
      priceDisplayType: 'per_month',
      maintenanceAmount: 6500,
      securityDeposit: 300000,
      isNegotiable: true
    },
    images: [
      {
        id: 'img-5-1',
        url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg',
        caption: 'Neoclassical architectural interior with garden view',
        isPrimary: true
      },
      {
        id: 'img-5-2',
        url: '/src/assets/images/hero_mumbai_skyline_1791457614725.jpg',
        caption: 'Powai lake and hills backdrop'
      }
    ],
    description: 'Immaculately maintained 2 BHK apartment in the neoclassical township of Hiranandani Gardens, Powai. Features natural ventilation, open garden outlook, fully modular kitchen with built-in hob and chimney, split ACs in all rooms, and covered podium parking. Walking distance to Haiko supermarket, Galleria, and international schools.',
    amenities: [
      'Powai Lake & Hills Outlook',
      'Podium Covered Parking',
      'Township Clubhouse Access',
      '24/7 Piped Natural Gas',
      'Round-the-Clock Gated Security',
      'Kids Play Area & Jogging Track',
      'Tennis & Badminton Courts',
      'Walking Distance to Cafes'
    ],
    nearbyPlaces: [
      { name: 'IIT Bombay Main Gate', type: 'school', distanceKm: 1.2 },
      { name: 'Kanjurmarg Railway Station', type: 'railway', distanceKm: 2.8 },
      { name: 'JVLR (Jogeshwari-Vikhroli Link Road)', type: 'highway', distanceKm: 0.9 },
      { name: 'Dr L H Hiranandani Hospital', type: 'hospital', distanceKm: 0.7 }
    ],
    isVerified: true,
    isFeatured: false,
    ownerId: 'user-own-105',
    ownerType: 'owner',
    maskedContact: {
      nameInitials: 'V. N.',
      verifiedPhoneEnding: '73'
    },
    residentialDetails: {
      bhk: '2 BHK',
      bedrooms: 2,
      bathrooms: 2,
      balconies: 1,
      carpetArea: 880,
      builtUpArea: 1140,
      floor: 11,
      totalFloors: 18,
      furnishing: 'fully-furnished',
      parking: { covered: 1, open: 0 },
      facing: 'East',
      ageOfProperty: '5 years'
    },
    createdAt: '2026-09-25T16:00:00Z',
    updatedAt: '2026-10-06T10:00:00Z'
  },
  {
    id: 'prop-mum-06',
    title: 'Modern Boutique Co-Working & Managed Office Floor in Andheri West',
    slug: 'managed-coworking-office-andheri-west',
    category: 'commercial',
    transactionType: 'rent',
    propertyType: 'Co-working Space',
    location: {
      buildingName: 'Lotus Link Corporate Park',
      area: 'Link Road',
      locality: 'Andheri West',
      city: 'Mumbai',
      pincode: '400053',
      landmark: 'Near D.N. Nagar Metro Station',
      coordinates: { lat: 19.1308, lng: 72.8336 }
    },
    pricing: {
      price: 220000, // ₹2.2 L / month
      priceDisplayType: 'per_month',
      maintenanceAmount: 18000,
      securityDeposit: 1320000,
      isNegotiable: true
    },
    images: [
      {
        id: 'img-6-1',
        url: '/src/assets/images/bkc_commercial_office_1791457642520.jpg',
        caption: 'Contemporary collaborative desk pods',
        isPrimary: true
      },
      {
        id: 'img-6-2',
        url: '/src/assets/images/mumbai_retail_showroom_1791457664965.jpg',
        caption: 'Shared cafe lounge and event breakout zone'
      }
    ],
    description: 'Fully furnished independent collaborative floor ideal for modern creative agencies, media production houses, or growing startups. Features 32 dedicated hot/fixed desks, 2 soundproof podcast/call booths, 8-seater conference room with Smart TV, barista counter, and high-speed enterprise lease line connectivity.',
    amenities: [
      'Soundproof Call Booths',
      'Dual High-Speed Fiber Internet',
      'Coffee & Tea Pantry Counter',
      'Biometric Access Control',
      'Conference Room with TV',
      '2 Covered Car Parkings',
      'Full Central Air Conditioning',
      'Metro Station 3-Min Walk'
    ],
    nearbyPlaces: [
      { name: 'DN Nagar Metro Interchange', type: 'metro', distanceKm: 0.2 },
      { name: 'Andheri Railway Station', type: 'railway', distanceKm: 1.8 },
      { name: 'Infinity Mall Andheri', type: 'commercial_hub', distanceKm: 0.9 },
      { name: 'Kokilaben Dhirubhai Ambani Hospital', type: 'hospital', distanceKm: 1.4 }
    ],
    isVerified: true,
    isFeatured: false,
    ownerId: 'user-own-106',
    ownerType: 'owner',
    maskedContact: {
      nameInitials: 'S. G.',
      verifiedPhoneEnding: '41'
    },
    commercialDetails: {
      commercialType: 'Co-working Space',
      carpetArea: 1600,
      builtUpArea: 2200,
      floor: 4,
      totalFloors: 9,
      furnishing: 'fully-furnished',
      parking: { covered: 2, open: 1 },
      washrooms: 2,
      powerBackup: true,
      loadingUnloadingAvailability: false,
      suitableBusinessType: ['Media & Production', 'Digital Agencies', 'Software Startups', 'Design Studios']
    },
    createdAt: '2026-09-28T09:40:00Z',
    updatedAt: '2026-10-06T14:20:00Z'
  },
  {
    id: 'prop-mum-07',
    title: 'Sunlit 1 BHK Contemporary Flat near Metro in Malad West',
    slug: '1-bhk-contemporary-flat-malad-west',
    category: 'residential',
    transactionType: 'buy',
    propertyType: '1 BHK',
    location: {
      buildingName: 'Green Crest Heights',
      area: 'Chincholi Bunder',
      locality: 'Malad West',
      city: 'Mumbai',
      pincode: '400064',
      landmark: 'Near Inorbit Mall',
      coordinates: { lat: 19.1824, lng: 72.8398 }
    },
    pricing: {
      price: 9800000, // ₹98 L
      priceDisplayType: 'total',
      maintenanceAmount: 3200,
      isNegotiable: true
    },
    images: [
      {
        id: 'img-7-1',
        url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg',
        caption: 'Smartly designed living & dining space',
        isPrimary: true
      },
      {
        id: 'img-7-2',
        url: '/src/assets/images/hero_mumbai_skyline_1791457614725.jpg',
        caption: 'City skyline views from balcony'
      }
    ],
    description: 'Vastu-compliant 1 BHK apartment situated on the 16th floor in a well-maintained gated high-rise complex. Efficient layout with zero space wastage, dry balcony attached to kitchen, vitrified tile flooring, and excellent natural sunlight. Walking distance to Metro Line 2A station and Mindspace business district.',
    amenities: [
      'Metro Station 500m',
      'Covered Mechanical Stilt Parking',
      'Rooftop Walking Track',
      'Fire Fighting System',
      'Intercom & 24/7 Security Guards',
      'Piped Gas Connection',
      'Rainwater Harvesting'
    ],
    nearbyPlaces: [
      { name: 'Malad West Metro (Line 2A)', type: 'metro', distanceKm: 0.5 },
      { name: 'Inorbit Mall Malad', type: 'commercial_hub', distanceKm: 0.8 },
      { name: 'Mindspace IT Hub', type: 'commercial_hub', distanceKm: 1.1 },
      { name: 'Thunga Hospital', type: 'hospital', distanceKm: 0.6 }
    ],
    isVerified: true,
    isFeatured: false,
    ownerId: 'user-own-107',
    ownerType: 'owner',
    maskedContact: {
      nameInitials: 'T. M.',
      verifiedPhoneEnding: '38'
    },
    residentialDetails: {
      bhk: '1 BHK',
      bedrooms: 1,
      bathrooms: 2,
      balconies: 1,
      carpetArea: 465,
      builtUpArea: 620,
      floor: 16,
      totalFloors: 21,
      furnishing: 'semi-furnished',
      parking: { covered: 1, open: 0 },
      facing: 'North-East',
      ageOfProperty: '3 years'
    },
    createdAt: '2026-09-29T11:20:00Z',
    updatedAt: '2026-10-07T08:15:00Z'
  },
  {
    id: 'prop-mum-08',
    title: 'High-Ceiling Logistics Warehouse & Distribution Godown',
    slug: 'logistics-warehouse-godown-bhiwandi-thane',
    category: 'commercial',
    transactionType: 'rent',
    propertyType: 'Warehouse',
    location: {
      buildingName: 'Apex Logistics Hub Zone B',
      area: 'Mankoli Bypass',
      locality: 'Thane - Bhiwandi Corridor',
      city: 'Mumbai',
      pincode: '421302',
      landmark: 'Near Mumbai-Nashik Highway Junction',
      coordinates: { lat: 19.2965, lng: 73.0631 }
    },
    pricing: {
      price: 175000, // ₹1.75 L / month
      priceDisplayType: 'per_month',
      maintenanceAmount: 9000,
      securityDeposit: 1050000,
      isNegotiable: true
    },
    images: [
      {
        id: 'img-8-1',
        url: '/src/assets/images/mumbai_retail_showroom_1791457664965.jpg',
        caption: 'Column-free high storage bay with heavy load flooring',
        isPrimary: true
      },
      {
        id: 'img-8-2',
        url: '/src/assets/images/bkc_commercial_office_1791457642520.jpg',
        caption: 'Attached dispatch office and inspection area'
      }
    ],
    description: 'Pre-engineered PEB warehouse with 28-foot clear center height, laser-screed FM2 high-load flooring (5 tonnes/sqm), and 2 dedicated hydraulic dock levellers for 40-foot container trucks. Complete fire NOC with hydrants and sprinkler lines in place. Prime highway positioning ensures non-stop toll connectivity directly into Mumbai city limits.',
    amenities: [
      '28 ft Clear Height PEB Structure',
      'FM2 High-Load Industrial Floor',
      '2 Hydraulic Dock Levellers',
      '24/7 Gated Security & Weighbridge',
      'Fire Hydrant & Smoke Extractor',
      'Dedicated Driver Restrooms',
      'Ample Container Trailer Turning Radius',
      'Separate On-Site Admin Office Cabin'
    ],
    nearbyPlaces: [
      { name: 'Mumbai-Nashik Expressway', type: 'highway', distanceKm: 0.8 },
      { name: 'Thane Majiwada Junction', type: 'highway', distanceKm: 12.0 },
      { name: 'JNPT Port Container Route', type: 'highway', distanceKm: 48.0 },
      { name: 'Bhiwandi Goods Depot', type: 'railway', distanceKm: 4.5 }
    ],
    isVerified: true,
    isFeatured: false,
    ownerId: 'user-own-108',
    ownerType: 'authorized_representative',
    maskedContact: {
      nameInitials: 'H. B.',
      verifiedPhoneEnding: '66'
    },
    commercialDetails: {
      commercialType: 'Warehouse',
      carpetArea: 6500,
      builtUpArea: 7200,
      floor: 0,
      totalFloors: 1,
      furnishing: 'unfurnished',
      parking: { covered: 0, open: 6 },
      washrooms: 3,
      powerBackup: true,
      loadingUnloadingAvailability: true,
      suitableBusinessType: ['E-Commerce Fulfillment', 'FMCG Logistics', 'Pharma Storage', 'Cold Chain Distribution']
    },
    createdAt: '2026-09-30T15:10:00Z',
    updatedAt: '2026-10-07T12:00:00Z'
  }
];

export const POPULAR_MUMBAI_AREAS = [
  'Bandra West',
  'Bandra Kurla Complex (BKC)',
  'Worli',
  'Lower Parel',
  'Powai',
  'Juhu',
  'Andheri West',
  'Andheri East',
  'Dadar',
  'Malad West',
  'Goregaon West',
  'Thane West',
  'Navi Mumbai (Vashi)',
  'Colaba'
];

export const RESIDENTIAL_TYPE_OPTIONS = [
  '1 BHK',
  '2 BHK',
  '3 BHK',
  '4+ BHK',
  'Apartment',
  'Villa',
  'Independent House',
  'Plot'
];

export const COMMERCIAL_TYPE_OPTIONS = [
  'Office',
  'Shop',
  'Showroom',
  'Warehouse',
  'Godown',
  'Restaurant/Cafe',
  'Clinic',
  'Commercial Building',
  'Industrial Unit',
  'Commercial Land',
  'Co-working Space'
];
