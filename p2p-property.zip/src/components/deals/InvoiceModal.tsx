import React from 'react';
import { X, Printer, Download, Building2, CheckCircle2, FileText } from 'lucide-react';
import { DealInvoice, Deal } from '../../types/deal';
import { formatCurrency } from '../../utils/formatters';

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: DealInvoice | null;
  deal: Deal;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  isOpen,
  onClose,
  invoice,
  deal
}) => {
  if (!isOpen || !invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  const isPaid = invoice.status === 'PAID' || deal.commissionStatus === 'PAID';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-stone-200 overflow-hidden my-8 print:border-none print:shadow-none print:m-0 print:max-w-full">
        
        {/* Action Header - Hidden during print */}
        <div className="px-6 py-4 bg-stone-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <span className="font-semibold text-sm">Tax Invoice & Brokerage Receipt</span>
            <span className="text-xs bg-stone-800 px-2 py-0.5 rounded font-mono text-stone-300">
              {invoice.invoiceNumber}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Document Body */}
        <div className="p-8 sm:p-10 space-y-8 text-stone-800 bg-white" id="printable-invoice">
          
          {/* Header & Company Brand */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-6 border-b border-stone-200 pb-8">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-stone-900 text-amber-400 flex items-center justify-center font-serif font-black text-lg">
                  P
                </div>
                <span className="text-xl font-bold font-serif tracking-tight text-stone-950">
                  P2P Property
                </span>
              </div>
              <p className="text-xs text-stone-500">
                P2P Property Advisory & Real Estate Services LLP
              </p>
              <div className="text-[11px] text-stone-500 leading-relaxed font-mono">
                BKC Corporate Center, G-Block, Bandra Kurla Complex<br />
                Mumbai, Maharashtra — 400051<br />
                MahaRERA Reg No: A51900038491 · GSTIN: 27AABCP9928M1Z8
              </div>
            </div>

            <div className="text-left sm:text-right space-y-1">
              <div className="inline-block px-3 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider mb-2 border border-stone-300 bg-stone-50">
                TAX INVOICE
              </div>
              <div className="text-sm font-bold font-mono text-stone-900">
                {invoice.invoiceNumber}
              </div>
              <div className="text-xs text-stone-500">
                Issue Date: <span className="font-mono text-stone-700 font-semibold">{invoice.issueDate}</span>
              </div>
              <div className="text-xs text-stone-500">
                Due Date: <span className="font-mono text-stone-700 font-semibold">{invoice.dueDate}</span>
              </div>
              <div className="text-xs text-stone-500">
                Deal Ref: <span className="font-mono text-stone-700 font-semibold">{deal.dealNumber}</span>
              </div>
            </div>
          </div>

          {/* Billed To & Property Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
            <div className="bg-stone-50 rounded-xl p-4 border border-stone-200 space-y-1.5">
              <span className="text-[10px] font-bold uppercase font-mono text-stone-400 block tracking-wider">
                Billed To (Client / Payer)
              </span>
              <div className="text-sm font-bold text-stone-900">
                {deal.customer?.name || 'Valued Client'}
              </div>
              <div className="text-stone-600">
                Role: <span className="font-semibold">{deal.commissionPayer}</span>
              </div>
              <div className="text-stone-600">
                Phone: <span className="font-mono">{deal.customer?.mobile || 'N/A'}</span>
              </div>
              <div className="text-stone-600">
                Email: {deal.customer?.email || 'N/A'}
              </div>
            </div>

            <div className="bg-stone-50 rounded-xl p-4 border border-stone-200 space-y-1.5">
              <span className="text-[10px] font-bold uppercase font-mono text-stone-400 block tracking-wider">
                Transaction & Property Reference
              </span>
              <div className="text-sm font-bold text-stone-900">
                {deal.property?.title || 'Mumbai Real Estate Property'}
              </div>
              <div className="text-stone-600">
                Location: {deal.property?.locality || 'Mumbai'}, {deal.property?.city || 'Mumbai'}
              </div>
              <div className="text-stone-600">
                Transaction: <span className="font-semibold uppercase">{deal.transactionType} ({deal.category})</span>
              </div>
              <div className="text-stone-600">
                Agreed Valuation: <span className="font-mono font-semibold">
                  {formatCurrency(deal.agreedPropertyValue || deal.agreedRent || deal.agreedLeaseValue || 0)}
                </span>
              </div>
            </div>
          </div>

          {/* Fee Breakdown Table */}
          <div className="overflow-hidden rounded-xl border border-stone-200">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-100 text-stone-600 uppercase font-mono text-[10px] border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4">Description of Service</th>
                  <th className="py-3 px-4 text-center">HSN/SAC</th>
                  <th className="py-3 px-4 text-center">Rate</th>
                  <th className="py-3 px-4 text-right">Taxable Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                <tr>
                  <td className="py-4 px-4">
                    <p className="font-bold text-stone-900 text-xs">
                      Professional Real Estate Brokerage & Advisory Fee
                    </p>
                    <p className="text-[11px] text-stone-500 mt-0.5">
                      Facilitation, negotiation, documentation & transaction closure for {deal.property?.title}
                    </p>
                  </td>
                  <td className="py-4 px-4 text-center font-mono text-stone-600">
                    997222
                  </td>
                  <td className="py-4 px-4 text-center font-mono text-stone-600">
                    {deal.commissionType === 'PERCENTAGE' ? `${deal.commissionRate}%` : 'Fixed'}
                  </td>
                  <td className="py-4 px-4 text-right font-mono font-semibold text-stone-900">
                    {formatCurrency(invoice.subtotal)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Total Calculation & Status */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-6 pt-2">
            
            {/* Payment & Banking Information */}
            <div className="w-full sm:w-1/2 space-y-2 text-xs">
              <span className="text-[10px] font-bold uppercase font-mono text-stone-400 block tracking-wider">
                Remittance & Payment Details
              </span>
              <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200/60 text-[11px] text-stone-700 space-y-1 font-mono">
                <div>Bank: <span className="font-bold">HDFC Bank Limited</span></div>
                <div>Account Name: <span className="font-bold">P2P Property Realty Advisors LLP</span></div>
                <div>A/C Number: <span className="font-bold">50200084920184</span></div>
                <div>IFSC Code: <span className="font-bold">HDFC0000060</span> (BKC Branch)</div>
                <div>UPI ID: <span className="font-bold">p2pproperty@hdfcbank</span></div>
              </div>

              {isPaid && (
                <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-xl text-xs font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Paid in Full · Payment Receipt Acknowledged</span>
                </div>
              )}
            </div>

            {/* Price Calculations */}
            <div className="w-full sm:w-1/2 max-w-xs ml-auto space-y-2 text-xs">
              <div className="flex justify-between py-1 text-stone-600">
                <span>Subtotal (Brokerage)</span>
                <span className="font-mono">{formatCurrency(invoice.subtotal)}</span>
              </div>
              <div className="flex justify-between py-1 text-stone-600">
                <span>CGST (9%)</span>
                <span className="font-mono">{formatCurrency(invoice.gstAmount / 2)}</span>
              </div>
              <div className="flex justify-between py-1 text-stone-600">
                <span>SGST (9%)</span>
                <span className="font-mono">{formatCurrency(invoice.gstAmount / 2)}</span>
              </div>
              <div className="flex justify-between py-2.5 border-t-2 border-stone-900 text-stone-950 font-bold text-sm">
                <span>Total Amount Due</span>
                <span className="font-mono text-base">{formatCurrency(invoice.totalAmount)}</span>
              </div>

              {deal.paidAmount ? (
                <div className="flex justify-between py-1 text-emerald-700 font-semibold border-t border-stone-200 pt-2">
                  <span>Amount Received</span>
                  <span className="font-mono">{formatCurrency(deal.paidAmount)}</span>
                </div>
              ) : null}

              {deal.remainingAmount !== undefined ? (
                <div className="flex justify-between py-1 text-stone-700 font-semibold">
                  <span>Balance Outstanding</span>
                  <span className="font-mono">{formatCurrency(deal.remainingAmount)}</span>
                </div>
              ) : null}
            </div>
          </div>

          {/* Terms & Footer */}
          <div className="border-t border-stone-200 pt-6 text-[10px] text-stone-500 space-y-1">
            <p className="font-bold uppercase tracking-wider text-stone-700">Terms & Conditions:</p>
            <p>1. Invoices are due and payable within 15 calendar days from the date of issue or upon execution of registered agreements.</p>
            <p>2. Payment should be made strictly through RTGS/NEFT/Cheque or authorized UPI gateway in favor of P2P Property Advisory & Real Estate Services LLP.</p>
            <p>3. This is a computer-generated tax invoice and requires no physical signature under Indian GST and IT Act provisions.</p>
          </div>

        </div>

      </div>
    </div>
  );
};
