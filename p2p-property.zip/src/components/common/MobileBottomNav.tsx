import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  Search, 
  Bookmark, 
  LayoutDashboard, 
  User, 
  Users, 
  Briefcase, 
  Building2, 
  ShieldCheck,
  PlusSquare
} from 'lucide-react';
import { useProperty } from '../../context/PropertyContext';

export const MobileBottomNav: React.FC = () => {
  const { currentUser, savedPropertyIds, openAuthModal } = useProperty();

  // Role-customized navigation items matching Part 23 specifications
  let navItems = [
    { label: 'Home', to: '/', icon: Home },
    { label: 'Search', to: '/properties', icon: Search },
    { label: 'Saved', to: '/saved-properties', icon: Bookmark, badge: savedPropertyIds.length },
    { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard },
    { label: 'Profile', to: '/profile', icon: User, requiresAuth: true }
  ];

  if (currentUser?.role === 'owner' || currentUser?.role === 'agent') {
    navItems = [
      { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard },
      { label: 'Properties', to: '/dashboard', icon: Building2 },
      { label: 'Leads', to: '/dashboard/leads', icon: Users },
      { label: 'Deals', to: '/dashboard/deals', icon: Briefcase },
      { label: 'Profile', to: '/profile', icon: User }
    ];
  } else if (currentUser?.role === 'admin') {
    navItems = [
      { label: 'Admin', to: '/admin', icon: ShieldCheck },
      { label: 'Properties', to: '/admin/properties', icon: Building2 },
      { label: 'Leads', to: '/admin/leads', icon: Users },
      { label: 'Deals', to: '/admin/deals', icon: Briefcase },
      { label: 'Profile', to: '/profile', icon: User }
    ];
  }

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF9F5]/95 backdrop-blur-md border-t border-stone-200/90 pb-safe shadow-lg">
      <div className="grid grid-cols-5 h-14 max-w-lg mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.label}
              to={item.to}
              onClick={(e) => {
                if (item.requiresAuth && !currentUser) {
                  e.preventDefault();
                  openAuthModal('login');
                }
              }}
              className={({ isActive }) =>
                `flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${
                  isActive
                    ? 'text-amber-800 font-bold'
                    : 'text-stone-500 hover:text-stone-900'
                }`
              }
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {Boolean(item.badge && item.badge > 0) && (
                  <span className="absolute -top-1 -right-2.5 w-4 h-4 rounded-full bg-amber-700 text-white text-[9px] font-bold flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="truncate max-w-[56px] text-center">{item.label}</span>
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
};
