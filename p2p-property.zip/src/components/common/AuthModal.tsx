import React, { useState } from 'react';
import { X, ShieldCheck, Mail, Lock, Phone, User as UserIcon } from 'lucide-react';
import { useProperty } from '../../context/PropertyContext';
import { UserRole } from '../../types/property';

export const AuthModal: React.FC = () => {
  const { 
    authModalOpen, 
    authModalMode, 
    closeAuthModal, 
    loginUser, 
    signupUser,
    showToast 
  } = useProperty();

  const [mode, setMode] = useState<'login' | 'signup'>(authModalMode);
  const [role, setRole] = useState<UserRole>('buyer');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!authModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode === 'signup') {
      if (!name.trim()) {
        setError('Please enter your full name');
        return;
      }
      if (!phone.trim() || phone.replace(/\D/g, '').length < 10) {
        setError('Please provide a valid 10-digit mobile number');
        return;
      }
    }

    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid email address');
      return;
    }

    if (!password || password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'signup') {
        await signupUser({
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          password,
          role
        });
      } else {
        await loginUser(email.trim(), password);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = async (demoEmail: string, demoPass: string) => {
    setError('');
    setLoading(true);
    try {
      await loginUser(demoEmail, demoPass);
    } catch (err: any) {
      setError(err.message || 'Demo login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-stone-200 overflow-hidden relative"
        role="dialog"
        aria-modal="true"
      >
        {/* Close button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="p-6 pb-4 border-b border-stone-100 bg-[#FAF9F5]">
          <div className="flex items-center gap-2 mb-2">
            <span className="font-serif text-lg font-bold text-stone-900">P2P Property</span>
            <span className="text-stone-400">·</span>
            <span className="text-xs text-stone-500 font-medium">Mumbai</span>
          </div>
          <h3 className="text-xl font-bold text-stone-900">
            {mode === 'login' ? 'Welcome Back' : 'Create an Account'}
          </h3>
          <p className="text-xs text-stone-600 mt-1">
            {mode === 'login' 
              ? 'Sign in to contact verified owners and manage your saved listings.' 
              : 'Directly connect with property owners and list your Mumbai property.'}
          </p>

          {/* Mode Switcher */}
          <div className="grid grid-cols-2 gap-1 p-1 bg-stone-200/60 rounded-lg mt-4">
            <button
              type="button"
              onClick={() => { setMode('login'); setError(''); }}
              className={`py-1.5 text-xs font-semibold rounded-md transition-all ${
                mode === 'login' 
                  ? 'bg-white text-stone-900 shadow-xs' 
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setMode('signup'); setError(''); }}
              className={`py-1.5 text-xs font-semibold rounded-md transition-all ${
                mode === 'signup' 
                  ? 'bg-white text-stone-900 shadow-xs' 
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Create Account
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-2.5 text-xs text-red-700 bg-red-50 border border-red-200 rounded-md">
              {error}
            </div>
          )}

          {mode === 'signup' && (
            <>
              {/* Account role */}
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1.5">
                  I am interested in:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['buyer', 'owner', 'tenant'] as UserRole[]).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      className={`py-1.5 px-2 text-xs font-medium capitalize rounded-md border text-center transition-colors ${
                        role === r 
                          ? 'border-stone-900 bg-stone-900 text-white' 
                          : 'border-stone-200 text-stone-700 hover:border-stone-400'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Vikram Singhania"
                    className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">
                  Mobile Number (India)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="98200 XXXXX"
                    className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                    required
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-medium text-stone-700 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@domain.com"
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-stone-700 mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-md shadow-xs transition-colors"
          >
            {mode === 'login' ? 'Sign In to Account' : 'Register & Continue'}
          </button>

          {/* Quick Demo Logins for effortless testing */}
          <div className="pt-3 border-t border-stone-100 text-center">
            <span className="text-[11px] text-stone-500 font-medium">
              Fast test login:
            </span>
            <div className="flex items-center justify-center gap-2 mt-2">
              <button
                type="button"
                onClick={() => handleQuickDemo('admin@p2pproperty.in', 'Admin@12345')}
                className="px-2.5 py-1 text-[11px] bg-stone-100 hover:bg-stone-200 text-stone-800 rounded transition-colors font-medium"
              >
                Admin
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('sameer.merchant@mumbai.in', 'Owner@12345')}
                className="px-2.5 py-1 text-[11px] bg-stone-100 hover:bg-stone-200 text-stone-800 rounded transition-colors font-medium"
              >
                Owner
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('ananya.deshmukh@mumbai.in', 'Buyer@12345')}
                className="px-2.5 py-1 text-[11px] bg-stone-100 hover:bg-stone-200 text-stone-800 rounded transition-colors font-medium"
              >
                Buyer
              </button>
            </div>
          </div>

          <div className="flex items-center justify-center gap-1.5 text-[11px] text-stone-500 pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Encrypted Credentials · No Spammers</span>
          </div>
        </form>
      </div>
    </div>
  );
};
