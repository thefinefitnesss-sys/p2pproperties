import React, { useState } from 'react';
import { X, Copy, Check, MessageSquare, Mail, Share2 } from 'lucide-react';
import { Property } from '../../types/property';
import { formatPriceINR } from '../../utils/formatters';

interface ShareModalProps {
  property: Property;
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ property, isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}/properties/${property.id}`
    : `https://p2pproperty.in/properties/${property.id}`;

  const shareText = `Check out this direct listing on P2P Property Mumbai: ${property.title} in ${property.location.locality} (${formatPriceINR(property.pricing.price, property.pricing.priceDisplayType)}). Direct owner deal: ${currentUrl}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleEmail = () => {
    const subject = encodeURIComponent(`Property in ${property.location.locality}: ${property.title}`);
    const body = encodeURIComponent(shareText);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-stone-200 overflow-hidden relative"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 border-b border-stone-100 bg-[#FAF9F5]">
          <div className="flex items-center gap-1.5 text-stone-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <Share2 className="w-4 h-4 text-stone-700" />
            <span>Share Listing</span>
          </div>
          <h3 className="text-lg font-bold text-stone-900 leading-snug">
            {property.title}
          </h3>
          <p className="text-xs text-stone-500 mt-0.5">
            {property.location.locality}, Mumbai
          </p>
        </div>

        <div className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-medium text-stone-700 mb-1">
              Direct Property URL
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={currentUrl}
                className="w-full px-3 py-2 border border-stone-200 bg-stone-50 rounded-md text-stone-700 select-all font-mono text-[11px]"
              />
              <button
                type="button"
                onClick={handleCopy}
                className="px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-md shrink-0 flex items-center gap-1.5 transition-colors font-medium"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <div className="pt-2">
            <span className="block font-medium text-stone-700 mb-2">
              Share directly via:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleWhatsApp}
                className="flex items-center justify-center gap-2 py-2 px-3 border border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 rounded-md transition-colors font-medium"
              >
                <MessageSquare className="w-4 h-4 text-emerald-600" />
                <span>WhatsApp</span>
              </button>
              <button
                type="button"
                onClick={handleEmail}
                className="flex items-center justify-center gap-2 py-2 px-3 border border-stone-200 hover:bg-stone-50 rounded-md transition-colors font-medium text-stone-700"
              >
                <Mail className="w-4 h-4 text-stone-600" />
                <span>Email</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
