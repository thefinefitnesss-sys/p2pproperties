import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { 
  Building2, 
  Bookmark, 
  Menu, 
  X, 
  User as UserIcon, 
  PlusCircle, 
  LogOut,
  ChevronDown,
  ShieldCheck
} from 'lucide-react';
import { useProperty } from '../../context/PropertyContext';
import { NotificationDropdown } from './NotificationDropdown';

export const Navbar: React.FC = () => {
  const { 
    currentUser, 
    savedPropertyIds, 
    openAuthModal, 
    logoutUser 
  } = useProperty();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const navLinks = [
    { label: 'Properties', to: '/properties' },
    { label: 'Buy', to: '/buy' },
    { label: 'Rent', to: '/rent' },
    { label: 'Commercial', to: '/commercial' },
    { label: 'Post Requirement', to: '/post-requirement' },
    { label: 'Sell / List', to: '/sell' },
  ];

  const handleNavClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F5]/95 backdrop-blur-md border-b border-stone-200/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Zone 1: Single text wordmark */}
          <Link 
            to="/" 
            className="flex items-center gap-2.5 text-stone-900 group shrink-0"
            onClick={handleNavClick}
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-stone-900 text-stone-50 flex items-center justify-center font-serif text-lg font-bold shadow-sm transition-transform group-hover:scale-105">
              P2P
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-stone-900 leading-none">
                P2P Property
              </span>
              <span className="text-[10px] uppercase tracking-widest text-stone-500 font-medium mt-0.5">
                Mumbai Direct
              </span>
            </div>
          </Link>

          {/* Zone 2: 4-6 clean text navigation links */}
          <nav className="hidden md:flex items-center gap-7 lg:gap-8 text-[14px] font-medium text-stone-600">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `transition-colors duration-150 py-1 border-b-2 whitespace-nowrap ${
                    isActive 
                      ? 'border-stone-900 text-stone-950 font-semibold' 
                      : 'border-transparent hover:text-stone-900 hover:border-stone-300'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </nav>

          {/* Zone 3: Primary actions */}
          <div className="flex items-center gap-3 sm:gap-4">
            
            {/* Admin Badge button for Admins */}
            {currentUser?.role === 'admin' && (
              <Link
                to="/admin"
                className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-amber-950 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-md transition-colors shadow-2xs"
                title="Admin Moderation Portal"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-800" />
                <span>Admin</span>
              </Link>
            )}

            {/* Notifications dropdown */}
            <NotificationDropdown />

            {/* Saved properties button */}
            <Link
              to="/saved-properties"
              className="relative p-2 text-stone-600 hover:text-stone-900 transition-colors"
              title="Saved Properties"
              aria-label="Saved Properties"
            >
              <Bookmark className="w-5 h-5" />
              {savedPropertyIds.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-700 text-white text-[10px] font-semibold flex items-center justify-center">
                  {savedPropertyIds.length}
                </span>
              )}
            </Link>

            {/* List Property CTA */}
            <Link
              to="/list-property"
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold uppercase tracking-wider text-stone-900 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-md transition-colors whitespace-nowrap shadow-xs"
            >
              <PlusCircle className="w-4 h-4 text-amber-800" />
              <span>List Property</span>
            </Link>

            {/* Auth Profile / Login */}
            {currentUser ? (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 text-xs font-medium text-stone-700 hover:text-stone-900 rounded-lg hover:bg-stone-100 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-stone-900 text-stone-100 flex items-center justify-center text-xs font-semibold">
                    {currentUser.name.charAt(0)}
                  </div>
                  <span className="hidden lg:inline-block max-w-[100px] truncate font-medium">
                    {currentUser.name}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
                </button>

                {userDropdownOpen && (
                  <div 
                    className="absolute right-0 mt-2 w-52 bg-white rounded-lg shadow-lg border border-stone-200 py-1.5 z-50 text-xs"
                    onMouseLeave={() => setUserDropdownOpen(false)}
                  >
                    <div className="px-3.5 py-2 border-b border-stone-100">
                      <p className="font-semibold text-stone-900 truncate">{currentUser.name}</p>
                      <p className="text-stone-500 truncate text-[11px]">{currentUser.email}</p>
                      <span className="inline-block mt-1 text-[10px] px-1.5 py-0.5 bg-stone-100 text-stone-700 rounded font-mono uppercase">
                        {currentUser.role}
                      </span>
                    </div>

                    <Link
                      to="/dashboard"
                      className="block px-3.5 py-2 font-medium text-stone-900 hover:bg-stone-50 transition-colors"
                      onClick={() => setUserDropdownOpen(false)}
                    >
                      My Dashboard
                    </Link>

                    <Link
                      to="/dashboard/queries"
                      className="block px-3.5 py-2 font-medium text-stone-900 hover:bg-stone-50 transition-colors"
                      onClick={() => setUserDropdownOpen(false)}
                    >
                      My Requirements / Queries
                    </Link>

                    {(currentUser.role === 'owner' || currentUser.role === 'agent' || currentUser.role === 'admin') && (
                      <>
                        <Link
                          to="/dashboard/leads"
                          className="block px-3.5 py-2 font-medium text-stone-900 hover:bg-stone-50 transition-colors"
                          onClick={() => setUserDropdownOpen(false)}
                        >
                          Leads & Pipeline
                        </Link>
                        <Link
                          to="/dashboard/deals"
                          className="block px-3.5 py-2 font-medium text-stone-900 hover:bg-stone-50 transition-colors"
                          onClick={() => setUserDropdownOpen(false)}
                        >
                          Deals & Brokerage
                        </Link>
                      </>
                    )}

                    {currentUser.role === 'admin' && (
                      <Link
                        to="/admin"
                        className="block px-3.5 py-2 font-medium text-amber-900 bg-amber-50/50 hover:bg-amber-100/60 transition-colors"
                        onClick={() => setUserDropdownOpen(false)}
                      >
                        Admin Console
                      </Link>
                    )}

                    <Link
                      to="/profile"
                      className="block px-3.5 py-2 text-stone-700 hover:bg-stone-50 transition-colors"
                      onClick={() => setUserDropdownOpen(false)}
                    >
                      Account Profile
                    </Link>

                    <Link
                      to="/saved-properties"
                      className="block px-3.5 py-2 text-stone-700 hover:bg-stone-50 transition-colors"
                      onClick={() => setUserDropdownOpen(false)}
                    >
                      Saved Watchlist ({savedPropertyIds.length})
                    </Link>

                    <Link
                      to="/list-property"
                      className="block px-3.5 py-2 text-stone-700 hover:bg-stone-50 transition-colors"
                      onClick={() => setUserDropdownOpen(false)}
                    >
                      Post New Listing
                    </Link>

                    <button
                      type="button"
                      onClick={() => {
                        logoutUser();
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3.5 py-2 text-red-700 hover:bg-red-50 flex items-center gap-2 transition-colors border-t border-stone-100 mt-1"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <Link
                  to="/login"
                  className="px-3 py-1.5 text-xs font-semibold text-stone-700 hover:text-stone-950 transition-colors"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-md transition-colors shadow-xs"
                >
                  Sign Up
                </Link>
              </div>
            )}

            {/* Mobile menu toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-stone-700 hover:text-stone-950"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-stone-200 bg-[#FAF9F5] px-4 pt-3 pb-6 space-y-3">
          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                onClick={handleNavClick}
                className={({ isActive }) =>
                  `px-3 py-2.5 text-base font-medium rounded-md transition-colors ${
                    isActive 
                      ? 'bg-stone-200 text-stone-950 font-semibold' 
                      : 'text-stone-700 hover:bg-stone-100'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </div>

          <div className="pt-2 border-t border-stone-200">
            <Link
              to="/list-property"
              onClick={handleNavClick}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 text-sm font-semibold uppercase tracking-wider text-stone-900 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-md shadow-xs transition-colors"
            >
              <PlusCircle className="w-4 h-4 text-amber-800" />
              List Property Directly
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
