import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, MapPin, ArrowUpRight, Phone, Mail } from 'lucide-react';
import { POPULAR_MUMBAI_AREAS } from '../../data/sampleProperties';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-900 text-stone-300 border-t border-stone-800 pt-16 pb-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top summary row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-stone-800">
          
          {/* Brand & mission */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-stone-950 flex items-center justify-center font-serif text-base font-bold">
                P2P
              </div>
              <span className="font-serif text-xl font-bold tracking-tight text-stone-100">
                P2P Property
              </span>
            </div>
            <p className="text-sm text-stone-400 leading-relaxed max-w-sm">
              Mumbai’s dedicated peer-to-peer real-estate marketplace. Enabling residential and commercial property owners to deal directly with buyers and tenants without arbitrary friction.
            </p>
            <div className="flex items-center gap-2 pt-2 text-xs text-stone-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Verified Direct Listings · Privacy-Masked Owner Contacts</span>
            </div>
          </div>

          {/* Quick links: Residential */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-200">
              Residential
            </h4>
            <ul className="space-y-2 text-sm text-stone-400">
              <li>
                <Link to="/buy?category=residential" className="hover:text-amber-400 transition-colors">
                  Buy Flats & Apartments
                </Link>
              </li>
              <li>
                <Link to="/rent?category=residential" className="hover:text-amber-400 transition-colors">
                  Rent Residential Homes
                </Link>
              </li>
              <li>
                <Link to="/properties?bhk=2+BHK" className="hover:text-amber-400 transition-colors">
                  2 BHK Flats in Mumbai
                </Link>
              </li>
              <li>
                <Link to="/properties?bhk=3+BHK" className="hover:text-amber-400 transition-colors">
                  3 BHK Sea-View Residences
                </Link>
              </li>
              <li>
                <Link to="/list-property" className="hover:text-amber-400 transition-colors">
                  List Your Flat (Free)
                </Link>
              </li>
            </ul>
          </div>

          {/* Quick links: Commercial */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-200">
              Commercial
            </h4>
            <ul className="space-y-2 text-sm text-stone-400">
              <li>
                <Link to="/commercial" className="hover:text-amber-400 transition-colors">
                  All Commercial Spaces
                </Link>
              </li>
              <li>
                <Link to="/properties?category=commercial&propertyType=Office" className="hover:text-amber-400 transition-colors">
                  Corporate Offices & Suites
                </Link>
              </li>
              <li>
                <Link to="/properties?category=commercial&propertyType=Showroom" className="hover:text-amber-400 transition-colors">
                  Retail Showrooms & Shops
                </Link>
              </li>
              <li>
                <Link to="/properties?category=commercial&propertyType=Warehouse" className="hover:text-amber-400 transition-colors">
                  Warehouses & Godowns
                </Link>
              </li>
              <li>
                <Link to="/properties?category=commercial&propertyType=Co-working+Space" className="hover:text-amber-400 transition-colors">
                  Co-Working & Managed Floors
                </Link>
              </li>
            </ul>
          </div>

          {/* Direct Deal Support */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-200">
              Direct Deal Desk
            </h4>
            <div className="space-y-2.5 text-sm text-stone-400">
              <p className="text-xs text-stone-400 leading-normal">
                Need guidance navigating direct property verification in Mumbai?
              </p>
              <div className="flex items-center gap-2 text-stone-300 text-xs">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>+91 (022) 6820-0022</span>
              </div>
              <div className="flex items-center gap-2 text-stone-300 text-xs">
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <span>concierge@p2pproperty.in</span>
              </div>
              <div className="pt-2">
                <span className="inline-block text-[11px] px-2 py-0.5 bg-stone-800 text-stone-400 rounded">
                  Operating across MMRDA
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Popular Mumbai Localities Bar */}
        <div className="py-6 border-b border-stone-800 text-xs">
          <p className="text-stone-400 mb-2 font-medium">Top Mumbai Localities:</p>
          <div className="flex flex-wrap gap-x-4 gap-y-2 text-stone-400">
            {POPULAR_MUMBAI_AREAS.slice(0, 10).map((area) => (
              <Link 
                key={area}
                to={`/properties?location=${encodeURIComponent(area)}`}
                className="hover:text-amber-400 transition-colors"
              >
                {area}
              </Link>
            ))}
          </div>
        </div>

        {/* Bottom copyright row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 gap-4">
          <p>© {new Date().getFullYear()} P2P Property India Technologies Pvt. Ltd. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <Link to="/about" className="hover:text-amber-400 transition-colors">About Direct Deal</Link>
            <Link to="/contact" className="hover:text-amber-400 transition-colors">Contact Concierge</Link>
            <Link to="/verification-policy" className="hover:text-amber-400 transition-colors">Verification Policy</Link>
            <Link to="/privacy" className="hover:text-amber-400 transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-amber-400 transition-colors">Terms of Direct Deal</Link>
            <Link to="/brokerage-terms" className="hover:text-amber-400 transition-colors">Brokerage Terms</Link>
            <Link to="/refund-policy" className="hover:text-amber-400 transition-colors">Refund Policy</Link>
          </div>
        </div>

      </div>
    </footer>
  );
};
