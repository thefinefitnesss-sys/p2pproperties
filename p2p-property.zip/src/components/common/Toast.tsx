import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { useProperty } from '../../context/PropertyContext';

export const Toast: React.FC = () => {
  const { toastMessage } = useProperty();

  if (!toastMessage) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200 pointer-events-none">
      <div className="bg-stone-900 text-white text-xs font-medium py-3 px-4 rounded-xl shadow-xl border border-stone-700 flex items-center gap-2.5 max-w-sm pointer-events-auto">
        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
        <span className="leading-snug">{toastMessage}</span>
      </div>
    </div>
  );
};
