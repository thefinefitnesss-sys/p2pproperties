import React, { useState } from 'react';
import { X, ShieldCheck, Send, Lock, MessageSquare, Phone, Mail } from 'lucide-react';
import { Property } from '../../types/property';
import { useProperty } from '../../context/PropertyContext';
import { sanitizeText } from '../../utils/formatters';

interface InquiryModalProps {
  property: Property;
  isOpen: boolean;
  onClose: () => void;
}

export const InquiryModal: React.FC<InquiryModalProps> = ({ property, isOpen, onClose }) => {
  const { createInquiry, currentUser } = useProperty();

  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [message, setMessage] = useState(
    `Hello, I am interested in your property "${property.title}" in ${property.location.locality}. Please let me know your availability for discussion.`
  );
  const [preferredContactMethod, setPreferredContactMethod] = useState<'PHONE' | 'WHATSAPP' | 'EMAIL'>('PHONE');
  const [preferredTime, setPreferredTime] = useState('Anytime');
  const [budget, setBudget] = useState(property.pricing.price ? String(property.pricing.price) : '');
  
  // Specific requirements for Commercial vs Residential
  const [businessType, setBusinessType] = useState(
    property.category === 'commercial' ? (property.commercialDetails?.suitableBusinessType?.[0] || 'Office') : ''
  );
  const [bhk, setBhk] = useState(property.category === 'residential' ? property.residentialDetails?.bhk || '2 BHK' : '');
  const [requiredCarpetArea, setRequiredCarpetArea] = useState(
    property.category === 'residential' 
      ? String(property.residentialDetails?.carpetArea || '')
      : String(property.commercialDetails?.carpetArea || '')
  );

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setLoading(true);
    setError('');
    try {
      await createInquiry(property.id, sanitizeText(message), preferredTime, {
        name,
        mobile: phone,
        email,
        preferred_contact_method: preferredContactMethod,
        budget: budget ? Number(budget) : undefined,
        bhk: property.category === 'residential' ? bhk : undefined,
        business_type: property.category === 'commercial' ? businessType : undefined,
        required_carpet_area: requiredCarpetArea ? Number(requiredCarpetArea) : undefined,
        preferred_locations: property.location.locality
      });
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        onClose();
      }, 2200);
    } catch (err: any) {
      setError(err.message || 'Error sending inquiry.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-xl shadow-2xl max-w-lg w-full border border-stone-200 overflow-hidden relative max-h-[90vh] flex flex-col"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors z-10"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-5 sm:p-6 border-b border-stone-100 bg-[#FAF9F5] shrink-0">
          <div className="flex items-center gap-1.5 text-emerald-800 text-xs font-semibold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Direct Owner Connection</span>
          </div>
          <h3 className="text-lg font-bold text-stone-900 leading-snug">
            Contact Verified Property Owner
          </h3>
          <p className="text-xs text-stone-600 mt-1 line-clamp-1">
            Re: {property.title} · {property.location.locality}
          </p>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-stone-900">Inquiry & Lead Registered</h4>
            <p className="text-xs text-stone-600 max-w-xs mx-auto">
              Your inquiry has been relayed directly to the owner. You will be contacted via {preferredContactMethod.toLowerCase()} shortly.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs overflow-y-auto flex-1">
            
            {/* Privacy security callout */}
            <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-lg flex items-start gap-2.5 text-stone-700">
              <Lock className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
              <p className="leading-relaxed text-[11px]">
                <strong className="text-stone-900">Zero Middlemen:</strong> Your contact is shared strictly with Owner {property.maskedContact.nameInitials} (ending in {property.maskedContact.verifiedPhoneEnding}). We never sell your number to telecallers.
              </p>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-700 border border-red-200 rounded-md text-xs">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Vikram Singhania"
                  className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Mobile Number (India) *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98200 XXXXX"
                  className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Preferred Contact Method
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setPreferredContactMethod('PHONE')}
                    className={`py-1.5 px-2 rounded-md border text-[11px] font-medium flex items-center justify-center gap-1 transition-colors ${
                      preferredContactMethod === 'PHONE'
                        ? 'bg-stone-900 text-white border-stone-900'
                        : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <Phone className="w-3 h-3" />
                    <span>Call</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreferredContactMethod('WHATSAPP')}
                    className={`py-1.5 px-2 rounded-md border text-[11px] font-medium flex items-center justify-center gap-1 transition-colors ${
                      preferredContactMethod === 'WHATSAPP'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>WhatsApp</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreferredContactMethod('EMAIL')}
                    className={`py-1.5 px-2 rounded-md border text-[11px] font-medium flex items-center justify-center gap-1 transition-colors ${
                      preferredContactMethod === 'EMAIL'
                        ? 'bg-stone-900 text-white border-stone-900'
                        : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <Mail className="w-3 h-3" />
                    <span>Email</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Commercial vs Residential requirement inputs */}
            {property.category === 'commercial' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-stone-50 border border-stone-200 rounded-lg">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    Your Business Type
                  </label>
                  <select
                    value={businessType}
                    onChange={(e) => setBusinessType(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900 bg-white"
                  >
                    <option value="Office">Corporate Office</option>
                    <option value="Shop">Retail Shop</option>
                    <option value="Showroom">Commercial Showroom</option>
                    <option value="Warehouse">Warehouse / Godown</option>
                    <option value="Restaurant">Restaurant / Cafe</option>
                    <option value="Clinic">Medical Clinic / Wellness</option>
                    <option value="Industrial">Industrial Unit</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    Budget (₹ Max)
                  </label>
                  <input
                    type="number"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                    placeholder="e.g. 500000"
                    className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900 bg-white"
                  />
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-stone-50 border border-stone-200 rounded-lg">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    Desired Configuration
                  </label>
                  <select
                    value={bhk}
                    onChange={(e) => setBhk(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900 bg-white"
                  >
                    <option value="1 BHK">1 BHK</option>
                    <option value="2 BHK">2 BHK</option>
                    <option value="3 BHK">3 BHK</option>
                    <option value="4+ BHK">4+ BHK</option>
                    <option value="Penthouse">Penthouse</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    Estimated Budget (₹)
                  </label>
                  <input
                    type="number"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                    placeholder="e.g. 85000000"
                    className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900 bg-white"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block font-medium text-stone-700 mb-1">
                Your Direct Message to Owner *
              </label>
              <textarea
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                required
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-stone-200 text-stone-700 hover:bg-stone-50 rounded-md transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-1.5 px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-md transition-colors font-semibold shadow-xs disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{loading ? 'Sending...' : 'Send Direct Inquiry'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
