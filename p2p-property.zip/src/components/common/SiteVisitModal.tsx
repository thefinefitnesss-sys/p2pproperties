import React, { useState } from 'react';
import { X, Calendar, Clock, MapPin, CheckCircle2 } from 'lucide-react';
import { Property } from '../../types/property';
import { useProperty } from '../../context/PropertyContext';
import { sanitizeText } from '../../utils/formatters';

interface SiteVisitModalProps {
  property: Property;
  isOpen: boolean;
  onClose: () => void;
}

export const SiteVisitModal: React.FC<SiteVisitModalProps> = ({ property, isOpen, onClose }) => {
  const { requestSiteVisit, currentUser } = useProperty();

  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  
  // Tomorrow's date default
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDateStr = tomorrow.toISOString().split('T')[0];

  const [date, setDate] = useState(minDateStr);
  const [timeSlot, setTimeSlot] = useState('11:00 AM - 01:00 PM (Morning)');
  const [notes, setNotes] = useState('');
  const [confirmed, setConfirmed] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !timeSlot) return;

    setLoading(true);
    setError('');
    try {
      await requestSiteVisit(property.id, date, timeSlot, sanitizeText(notes));
      setConfirmed(true);
      setTimeout(() => {
        setConfirmed(false);
        onClose();
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Error booking site visit.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-xl shadow-2xl max-w-lg w-full border border-stone-200 overflow-hidden relative"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 border-b border-stone-100 bg-[#FAF9F5]">
          <div className="flex items-center gap-1.5 text-amber-900 text-xs font-semibold uppercase tracking-wider mb-1">
            <Calendar className="w-4 h-4 text-amber-700" />
            <span>Schedule Physical Walkthrough</span>
          </div>
          <h3 className="text-lg font-bold text-stone-900">
            Request Site Visit
          </h3>
          <p className="text-xs text-stone-600 mt-1 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span className="truncate">{property.location.buildingName}, {property.location.locality}</span>
          </p>
        </div>

        {confirmed ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-stone-900">Visit Request Sent</h4>
            <p className="text-xs text-stone-600 max-w-xs mx-auto">
              Owner confirmation and building security gate pass coordinates have been triggered for {date} ({timeSlot}).
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Preferred Date *
                </label>
                <div className="relative">
                  <input
                    type="date"
                    min={minDateStr}
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900 bg-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Time Window *
                </label>
                <select
                  value={timeSlot}
                  onChange={(e) => setTimeSlot(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900 bg-white"
                >
                  <option value="10:00 AM - 12:00 PM (Morning)">10:00 AM - 12:00 PM (Morning)</option>
                  <option value="12:00 PM - 02:00 PM (Noon)">12:00 PM - 02:00 PM (Noon)</option>
                  <option value="02:00 PM - 04:00 PM (Afternoon)">02:00 PM - 04:00 PM (Afternoon)</option>
                  <option value="04:00 PM - 06:30 PM (Evening / Golden Hour)">04:00 PM - 06:30 PM (Evening)</option>
                  <option value="Weekend Special Slot">Weekend Special Slot</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Priyanshu Mehta"
                  className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Mobile Number (India) *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98200 XXXXX"
                  className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="priyanshu@example.com"
                className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
              />
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">
                Any specific areas to inspect? (Optional)
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Want to check car parking access and terrace view with family"
                className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-stone-200 text-stone-700 hover:bg-stone-50 rounded-md transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-md transition-colors font-semibold shadow-xs"
              >
                Confirm Visit Request
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
