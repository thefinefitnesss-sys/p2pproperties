import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Trash2, 
  ShieldCheck, 
  ExternalLink,
  Plus,
  X
} from 'lucide-react';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';

interface PropertyDocumentsCardProps {
  propertyId: string;
  isOwnerOrAdmin: boolean;
  isAdmin?: boolean;
}

const DOCUMENT_CATEGORIES = [
  { value: 'OWNERSHIP_DEED', label: 'Ownership / Title Deed (Index II)' },
  { value: 'SALE_AGREEMENT', label: 'Registered Sale Deed / Agreement' },
  { value: 'SOCIETY_SHARE_CERTIFICATE', label: 'Society Share Certificate' },
  { value: 'PROPERTY_TAX_RECEIPT', label: 'Property Tax Assessment Receipt' },
  { value: 'ELECTRICITY_BILL', label: 'Electricity / Utility Bill' },
  { value: 'OC_CC', label: 'Occupancy Certificate (OC / CC)' },
  { value: 'RERA_CERTIFICATE', label: 'MahaRERA Registration / Certificate' },
  { value: 'AUTHORIZATION_LETTER', label: 'Owner Authorization / POA Letter' },
  { value: 'OWNER_ID_PROOF', label: 'Owner Identity Proof' },
  { value: 'OTHER', label: 'Other Supporting Document' }
];

export const PropertyDocumentsCard: React.FC<PropertyDocumentsCardProps> = ({
  propertyId,
  isOwnerOrAdmin,
  isAdmin = false
}) => {
  const { currentUser } = useProperty();
  const [documents, setDocuments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [verifyModalOpen, setVerifyModalOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<any | null>(null);

  // Form states for upload
  const [docType, setDocType] = useState('OWNERSHIP_DEED');
  const [docTitle, setDocTitle] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [fileName, setFileName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Form states for admin review
  const [newStatus, setNewStatus] = useState('VERIFIED');
  const [adminNotes, setAdminNotes] = useState('');

  useEffect(() => {
    if (isOwnerOrAdmin) {
      loadDocuments();
    }
  }, [propertyId, isOwnerOrAdmin]);

  const loadDocuments = async () => {
    setLoading(true);
    try {
      const res = await api.propertyDocuments.list(propertyId);
      setDocuments(res.documents || []);
    } catch {
      // not authorized or empty
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim()) {
      setErrorMsg('Document title is required.');
      return;
    }

    setSubmitting(true);
    setErrorMsg('');
    try {
      const simulatedUrl = fileUrl.trim() || `/uploads/documents/${docType.toLowerCase()}_${Date.now()}.pdf`;
      const simulatedName = fileName.trim() || `${docTitle.toLowerCase().replace(/\s+/g, '_')}.pdf`;

      await api.propertyDocuments.upload(propertyId, {
        document_type: docType,
        title: docTitle.trim(),
        file_url: simulatedUrl,
        file_name: simulatedName,
        file_size: 1540000,
        mime_type: 'application/pdf'
      });

      setUploadModalOpen(false);
      setDocTitle('');
      setFileUrl('');
      setFileName('');
      loadDocuments();
    } catch (err: any) {
      setErrorMsg(err.message || 'Error uploading document.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAdminVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDoc) return;

    setSubmitting(true);
    try {
      await api.propertyDocuments.updateStatus(propertyId, selectedDoc.id, newStatus, adminNotes);
      setVerifyModalOpen(false);
      setSelectedDoc(null);
      setAdminNotes('');
      loadDocuments();
    } catch (err: any) {
      setErrorMsg(err.message || 'Error updating status.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (docId: string) => {
    if (!window.confirm('Are you sure you want to delete this document?')) return;
    try {
      await api.propertyDocuments.delete(propertyId, docId);
      setDocuments(prev => prev.filter(d => d.id !== docId));
    } catch {
      // ignore
    }
  };

  if (!isOwnerOrAdmin) return null;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'VERIFIED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800">
            <CheckCircle2 className="w-3 h-3 text-emerald-700" />
            Verified
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-red-100 text-red-800">
            <AlertCircle className="w-3 h-3 text-red-700" />
            Rejected
          </span>
        );
      case 'NOT_REQUIRED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-stone-100 text-stone-700">
            Not Required
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800">
            <Clock className="w-3 h-3 text-amber-700" />
            Pending Review
          </span>
        );
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200/90 shadow-sm p-6 sm:p-8 mt-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-stone-100">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-700" />
            <h3 className="font-serif text-lg font-bold text-stone-900">
              Property Verification Documents
            </h3>
          </div>
          <p className="text-xs text-stone-500 mt-1">
            Official title and municipal documents submitted for due diligence. Kept private and masked from public indexing.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setErrorMsg('');
            setUploadModalOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg transition-colors shadow-2xs"
        >
          <Plus className="w-4 h-4" />
          <span>Upload Document</span>
        </button>
      </div>

      {loading ? (
        <div className="py-8 text-center text-xs text-stone-400">Loading documents...</div>
      ) : documents.length === 0 ? (
        <div className="py-10 text-center text-stone-400">
          <FileText className="w-10 h-10 mx-auto mb-2 opacity-30 text-stone-500" />
          <p className="text-sm font-medium text-stone-600">No documents uploaded yet</p>
          <p className="text-xs text-stone-400 mt-1 max-w-sm mx-auto">
            Upload ownership Index II, Occupancy Certificate, or electricity bill to accelerate verification approval.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-stone-100 mt-2">
          {documents.map((doc) => (
            <div key={doc.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-stone-900 text-sm">{doc.title}</span>
                  {getStatusBadge(doc.verificationStatus)}
                </div>
                <div className="flex items-center gap-3 text-xs text-stone-500 flex-wrap">
                  <span className="font-mono text-[11px] px-1.5 py-0.5 bg-stone-100 rounded text-stone-600">
                    {doc.documentType}
                  </span>
                  <span>Uploaded {new Date(doc.createdAt).toLocaleDateString('en-IN')}</span>
                  {doc.verifierName && doc.verificationStatus === 'VERIFIED' && (
                    <span className="text-emerald-700">Verified by {doc.verifierName}</span>
                  )}
                </div>
                {doc.adminNotes && (
                  <p className="text-xs text-stone-600 bg-stone-50 border border-stone-200/60 p-2 rounded mt-2">
                    <span className="font-semibold text-stone-700">Verification Note:</span> {doc.adminNotes}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedDoc(doc);
                      setNewStatus(doc.verificationStatus || 'VERIFIED');
                      setAdminNotes(doc.adminNotes || '');
                      setVerifyModalOpen(true);
                    }}
                    className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded text-xs font-semibold transition-colors"
                  >
                    Review Status
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => handleDelete(doc.id)}
                  className="p-1.5 text-stone-400 hover:text-red-700 rounded transition-colors"
                  title="Delete Document"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Upload Modal */}
      {uploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-serif text-lg font-bold text-stone-900">Upload Property Document</h3>
              <button
                type="button"
                onClick={() => setUploadModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 bg-red-50 text-red-800 text-xs rounded border border-red-200">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleUpload} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1.5">
                  Document Category *
                </label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                >
                  {DOCUMENT_CATEGORIES.map((c) => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1.5">
                  Document Title / Description *
                </label>
                <input
                  type="text"
                  required
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  placeholder="e.g. Registered Index II 2024"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1.5">
                  File Document Name
                </label>
                <input
                  type="text"
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  placeholder="e.g. index2_carterroad.pdf"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                />
                <p className="text-[11px] text-stone-400 mt-1">Accepts PDF, JPG, PNG up to 15MB.</p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setUploadModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {submitting ? 'Uploading...' : 'Submit for Verification'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Admin Review Modal */}
      {verifyModalOpen && selectedDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-serif text-lg font-bold text-stone-900">Admin Document Verification</h3>
              <button
                type="button"
                onClick={() => setVerifyModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-stone-50 rounded text-xs space-y-1">
              <p className="font-semibold text-stone-900">{selectedDoc.title}</p>
              <p className="text-stone-500 font-mono">{selectedDoc.documentType}</p>
            </div>

            <form onSubmit={handleAdminVerify} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1.5">
                  Verification Decision *
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-xs bg-white font-medium"
                >
                  <option value="VERIFIED">VERIFIED (Valid & Approved)</option>
                  <option value="PENDING">PENDING (Further Review Required)</option>
                  <option value="REJECTED">REJECTED (Illegible or Invalid)</option>
                  <option value="NOT_REQUIRED">NOT REQUIRED (Waived)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-1.5">
                  Verification Notes / Audit Remarks
                </label>
                <textarea
                  rows={3}
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="e.g. Cross-checked with Sub-Registrar Bandra registration index. Valid chain of title."
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-xs resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setVerifyModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {submitting ? 'Saving...' : 'Save Decision'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
