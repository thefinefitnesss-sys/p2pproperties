import React from 'react';
import { Link, Navigate } from 'react-router-dom';
import { ShieldAlert, ArrowLeft, LogIn } from 'lucide-react';
import { useProperty } from '../../context/PropertyContext';

interface AdminRouteProps {
  children: React.ReactNode;
}

export const AdminRoute: React.FC<AdminRouteProps> = ({ children }) => {
  const { currentUser } = useProperty();

  if (!currentUser) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl border border-stone-200 p-8 max-w-md w-full text-center space-y-4 shadow-sm">
          <div className="w-14 h-14 bg-amber-50 text-amber-800 rounded-full flex items-center justify-center mx-auto border border-amber-200">
            <LogIn className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold font-serif text-stone-900">Authentication Required</h2>
          <p className="text-xs text-stone-600 leading-relaxed">
            You must be logged in as a verified administrator to access the P2P Property governance console.
          </p>
          <div className="pt-2">
            <Link
              to="/login?redirect=/admin"
              className="inline-flex items-center justify-center w-full px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs"
            >
              Sign In to Admin Portal
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (currentUser.role !== 'admin') {
    return (
      <div className="min-h-[70vh] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl border border-red-200 p-8 max-w-md w-full text-center space-y-4 shadow-sm">
          <div className="w-14 h-14 bg-red-50 text-red-700 rounded-full flex items-center justify-center mx-auto border border-red-200">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold font-serif text-stone-900">403 Unauthorized Access</h2>
          <p className="text-xs text-stone-600 leading-relaxed">
            Your account (<span className="font-mono text-stone-800">{currentUser.email}</span>) has role{' '}
            <span className="font-semibold uppercase text-stone-900">{currentUser.role}</span>. Administrative privileges are required.
          </p>
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <Link
              to="/dashboard"
              className="flex-1 inline-flex items-center justify-center px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-medium transition-colors"
            >
              Go to User Dashboard
            </Link>
            <Link
              to="/"
              className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Home</span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
