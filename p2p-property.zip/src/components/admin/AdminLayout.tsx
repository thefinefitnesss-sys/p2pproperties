import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  LayoutDashboard, 
  Building2, 
  Users, 
  MessageSquare, 
  Calendar, 
  History, 
  Settings, 
  ExternalLink,
  RefreshCw,
  UserCheck,
  Briefcase
} from 'lucide-react';

interface AdminLayoutProps {
  title?: string;
  subtitle?: string;
  activeTab?: string;
  children: React.ReactNode;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  title = 'Administrative Console',
  subtitle,
  children,
  onRefresh,
  isRefreshing
}) => {
  const navItems = [
    { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
    { to: '/admin/properties', label: 'Properties', icon: Building2 },
    { to: '/admin/leads', label: 'Leads Pipeline', icon: UserCheck },
    { to: '/admin/queries', label: 'Queries & Matches', icon: MessageSquare },
    { to: '/admin/deals', label: 'Deals & Revenue', icon: Briefcase },
    { to: '/admin/users', label: 'Users', icon: Users },
    { to: '/admin/enquiries', label: 'Enquiries', icon: MessageSquare },
    { to: '/admin/site-visits', label: 'Site Visits', icon: Calendar },
    { to: '/admin/audit-logs', label: 'Audit Log', icon: History },
    { to: '/admin/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8 space-y-6 min-h-screen">
      
      {/* Admin Top Banner */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-7 flex flex-col md:flex-row md:items-center justify-between gap-5 shadow-sm border border-stone-800">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-400/10 text-amber-400 border border-amber-400/20">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              Governance & Moderation
            </span>
            <span className="text-[11px] text-stone-400 font-mono">Mumbai Marketplace</span>
          </div>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold font-serif text-white tracking-tight">
            {title}
          </h1>
          {subtitle && (
            <p className="text-xs text-stone-400 max-w-2xl leading-relaxed">
              {subtitle}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
          {onRefresh && (
            <button
              type="button"
              onClick={onRefresh}
              disabled={isRefreshing}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-lg transition-colors border border-stone-700 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          )}

          <Link
            to="/"
            target="_blank"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-amber-400 hover:bg-amber-300 text-stone-950 rounded-lg transition-colors shadow-xs"
          >
            <span>Live Portal</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* Admin Navigation Bar */}
      <div className="bg-white rounded-xl border border-stone-200 p-1.5 shadow-2xs overflow-x-auto scrollbar-none">
        <nav className="flex items-center gap-1 min-w-max">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-950 hover:bg-stone-100/80'
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Main Content Body */}
      <div>
        {children}
      </div>

    </div>
  );
};
