import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Maximize2, X, Image as ImageIcon } from 'lucide-react';
import { PropertyImage } from '../../types/property';

interface ImageGalleryProps {
  images: PropertyImage[];
  title: string;
}

export const ImageGallery: React.FC<ImageGalleryProps> = ({ images, title }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [errorMap, setErrorMap] = useState<Record<string, boolean>>({});

  const validImages = images && images.length > 0
    ? images
    : [{ id: 'def', url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg', caption: title }];

  const currentImg = validImages[currentIndex] || validImages[0];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % validImages.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + validImages.length) % validImages.length);
  };

  return (
    <div className="space-y-3">
      {/* Primary Display Frame */}
      <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full bg-stone-900 rounded-xl overflow-hidden shadow-sm">
        {!errorMap[currentImg.id] ? (
          <img
            src={currentImg.url}
            alt={currentImg.caption || title}
            referrerPolicy="no-referrer"
            onError={() => setErrorMap((prev) => ({ ...prev, [currentImg.id]: true }))}
            className="w-full h-full object-cover transition-opacity duration-300"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-stone-400 p-6">
            <ImageIcon className="w-12 h-12 mb-2 stroke-1" />
            <p className="text-sm font-medium">{currentImg.caption || 'Property Photographic View'}</p>
          </div>
        )}

        {/* Ambient bottom scrim */}
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/75 to-transparent pointer-events-none" />

        {/* Navigation overlay buttons */}
        {validImages.length > 1 && (
          <>
            <button
              type="button"
              onClick={handlePrev}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition-colors"
              aria-label="Previous photo"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={handleNext}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition-colors"
              aria-label="Next photo"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Fullscreen Button */}
        <button
          type="button"
          onClick={() => setFullscreen(true)}
          className="absolute top-3 right-3 p-2 rounded-lg bg-black/40 hover:bg-black/70 text-white transition-colors"
          title="View Fullscreen"
          aria-label="Expand image to fullscreen"
        >
          <Maximize2 className="w-4 h-4" />
        </button>

        {/* Caption & Counter */}
        <div className="absolute bottom-3 inset-x-4 flex items-center justify-between text-white text-xs">
          <p className="font-medium text-stone-200 truncate max-w-md">
            {currentImg.caption || title}
          </p>
          <span className="font-mono bg-black/50 px-2 py-0.5 rounded text-[11px] shrink-0">
            {currentIndex + 1} / {validImages.length}
          </span>
        </div>
      </div>

      {/* Thumbnails strip */}
      {validImages.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {validImages.map((img, idx) => (
            <button
              key={img.id || idx}
              type="button"
              onClick={() => setCurrentIndex(idx)}
              className={`relative aspect-[4/3] w-20 sm:w-24 shrink-0 rounded-lg overflow-hidden border-2 transition-all ${
                currentIndex === idx 
                  ? 'border-stone-900 ring-2 ring-stone-900/20' 
                  : 'border-transparent opacity-70 hover:opacity-100'
              }`}
            >
              <img
                src={img.url}
                alt={`Thumbnail ${idx + 1}`}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>
      )}

      {/* Fullscreen Modal View */}
      {fullscreen && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-4">
          <button
            type="button"
            onClick={() => setFullscreen(false)}
            className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="max-w-5xl max-h-[80vh] relative">
            <img
              src={currentImg.url}
              alt={title}
              className="max-h-[80vh] w-auto max-w-full object-contain mx-auto rounded-md"
            />
            {currentImg.caption && (
              <p className="text-stone-300 text-center text-sm mt-3 font-medium">
                {currentImg.caption}
              </p>
            )}
          </div>

          <div className="flex items-center gap-4 mt-6">
            <button
              type="button"
              onClick={handlePrev}
              className="p-2 rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <span className="text-stone-300 font-mono text-sm">
              {currentIndex + 1} of {validImages.length}
            </span>
            <button
              type="button"
              onClick={handleNext}
              className="p-2 rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
