import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Bookmark, 
  MapPin, 
  ChevronLeft, 
  ChevronRight, 
  ShieldCheck, 
  Maximize2,
  Building,
  Car
} from 'lucide-react';
import { Property } from '../../types/property';
import { formatPriceINR, formatArea } from '../../utils/formatters';
import { useProperty } from '../../context/PropertyContext';

interface PropertyCardProps {
  property: Property;
  className?: string;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, className = '' }) => {
  const { isSaved, toggleSaveProperty } = useProperty();
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [imageError, setImageError] = useState(false);

  const images = property.images && property.images.length > 0
    ? property.images
    : [{ id: 'default', url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg', caption: 'Property Photo' }];

  const currentImage = images[activeImageIndex] || images[0];
  const saved = isSaved(property.id);

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setActiveImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setActiveImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const handleToggleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleSaveProperty(property.id);
  };

  // Determine carpet area and BHK
  const carpetArea = property.category === 'residential'
    ? property.residentialDetails.carpetArea
    : property.commercialDetails.carpetArea;

  const bhkLabel = property.category === 'residential'
    ? property.residentialDetails.bhk
    : null;

  const furnishing = property.category === 'residential'
    ? property.residentialDetails.furnishing
    : property.commercialDetails.furnishing;

  return (
    <article 
      className={`group bg-white rounded-xl border border-stone-200/90 hover:border-stone-400/80 shadow-xs hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col justify-between ${className}`}
    >
      <div>
        {/* Image Container */}
        <div className="relative aspect-[4/3] w-full bg-stone-100 overflow-hidden">
          {!imageError ? (
            <img
              src={currentImage.url}
              alt={currentImage.caption || property.title}
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-stone-200 text-stone-500 p-4 text-center">
              <Building className="w-8 h-8 mb-1 text-stone-400" />
              <span className="text-xs font-medium">Mumbai Property Image</span>
            </div>
          )}

          {/* Scrim gradient for contrast */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-black/20 pointer-events-none" />

          {/* Top Row: Direct Verification tag & Bookmark */}
          <div className="absolute top-3 inset-x-3 flex items-center justify-between pointer-events-auto">
            {property.isVerified ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold tracking-wide text-stone-900 bg-white/95 backdrop-blur-xs rounded shadow-xs">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Verified Direct
              </span>
            ) : (
              <span className="inline-block px-2 py-0.5 text-[11px] text-stone-700 bg-white/80 rounded">
                Direct Listing
              </span>
            )}

            <button
              type="button"
              onClick={handleToggleSave}
              className={`p-1.5 rounded-full backdrop-blur-xs transition-colors shadow-xs ${
                saved 
                  ? 'bg-amber-600 text-white' 
                  : 'bg-black/40 hover:bg-black/60 text-white'
              }`}
              title={saved ? 'Remove from saved' : 'Save property'}
              aria-label="Save listing"
            >
              <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
            </button>
          </div>

          {/* Transaction & Category chip in photo corner */}
          <div className="absolute bottom-3 left-3 text-white">
            <span className="text-xs font-medium uppercase tracking-wider text-stone-200">
              {property.category} · For {property.transactionType}
            </span>
          </div>

          {/* Image carousel arrows (if multiple images) */}
          {images.length > 1 && (
            <>
              <button
                type="button"
                onClick={prevImage}
                className="opacity-0 group-hover:opacity-100 transition-opacity absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/50 hover:bg-black/75 text-white flex items-center justify-center text-xs"
                aria-label="Previous image"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={nextImage}
                className="opacity-0 group-hover:opacity-100 transition-opacity absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/50 hover:bg-black/75 text-white flex items-center justify-center text-xs"
                aria-label="Next image"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              {/* Photo dot counter */}
              <div className="absolute bottom-3 right-3 px-1.5 py-0.5 rounded bg-black/60 text-[10px] font-mono text-white">
                {activeImageIndex + 1}/{images.length}
              </div>
            </>
          )}
        </div>

        {/* Card Content */}
        <div className="p-4 sm:p-5 space-y-3">
          
          {/* Price header */}
          <div className="flex items-baseline justify-between gap-2">
            <div className="text-xl sm:text-2xl font-bold font-serif text-stone-900 tabular-nums">
              {formatPriceINR(property.pricing.price, property.pricing.priceDisplayType)}
            </div>
            {property.pricing.maintenanceAmount ? (
              <span className="text-[11px] text-stone-500 font-medium">
                +₹{property.pricing.maintenanceAmount.toLocaleString('en-IN')} maint
              </span>
            ) : null}
          </div>

          {/* Title */}
          <h3 className="text-base font-semibold text-stone-900 line-clamp-1 group-hover:text-amber-800 transition-colors">
            <Link to={`/properties/${property.id}`} className="hover:underline">
              {property.title}
            </Link>
          </h3>

          {/* Location */}
          <div className="flex items-center gap-1.5 text-xs text-stone-600">
            <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span className="truncate">
              {property.location.locality}, Mumbai
            </span>
          </div>

          {/* Unboxed Metadata with · separator */}
          <div className="flex items-center flex-wrap gap-2 text-xs text-stone-600 pt-1 border-t border-stone-100">
            {bhkLabel && (
              <>
                <span className="font-medium text-stone-900">{bhkLabel}</span>
                <span className="text-stone-300">·</span>
              </>
            )}
            <span>{property.propertyType}</span>
            <span className="text-stone-300">·</span>
            <span className="tabular-nums font-medium text-stone-900">{formatArea(carpetArea)} carpet</span>
            {furnishing && (
              <>
                <span className="text-stone-300">·</span>
                <span className="capitalize">{furnishing.replace('-', ' ')}</span>
              </>
            )}
          </div>

          {/* Short description */}
          <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
            {property.description}
          </p>

        </div>
      </div>

      {/* Card Footer: View Property Button */}
      <div className="px-4 pb-4 sm:px-5 sm:pb-5 pt-1">
        <Link
          to={`/properties/${property.id}`}
          className="w-full inline-flex items-center justify-center py-2.5 px-4 text-xs font-semibold uppercase tracking-wider text-stone-900 bg-stone-100 hover:bg-stone-900 hover:text-white rounded-lg transition-colors border border-stone-200"
        >
          View Property
        </Link>
      </div>
    </article>
  );
};
