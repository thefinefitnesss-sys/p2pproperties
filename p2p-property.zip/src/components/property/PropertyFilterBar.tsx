import React, { useState } from 'react';
import { 
  SlidersHorizontal, 
  X, 
  Search, 
  MapPin, 
  Check, 
  RotateCcw,
  Building2,
  Home
} from 'lucide-react';
import { 
  PropertyCategory, 
  TransactionType, 
  PropertyFilterState 
} from '../../types/property';
import { 
  POPULAR_MUMBAI_AREAS, 
  RESIDENTIAL_TYPE_OPTIONS, 
  COMMERCIAL_TYPE_OPTIONS 
} from '../../data/sampleProperties';

interface PropertyFilterBarProps {
  filters: PropertyFilterState;
  onFilterChange: <K extends keyof PropertyFilterState>(key: K, value: PropertyFilterState[K]) => void;
  onReset: () => void;
  totalResults: number;
}

export const PropertyFilterBar: React.FC<PropertyFilterBarProps> = ({
  filters,
  onFilterChange,
  onReset,
  totalResults
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const isResidential = filters.category === 'residential';
  const isCommercial = filters.category === 'commercial';

  const typeOptions = isCommercial ? COMMERCIAL_TYPE_OPTIONS : RESIDENTIAL_TYPE_OPTIONS;

  // Active filter count for badge
  const activeCount = [
    filters.category !== 'all',
    filters.transactionType !== 'all',
    !!filters.location,
    filters.minPrice !== undefined,
    filters.maxPrice !== undefined,
    !!filters.bhk,
    !!filters.propertyType,
    filters.minCarpetArea !== undefined,
    filters.maxCarpetArea !== undefined,
    !!filters.furnishing,
    filters.hasParking,
    filters.verifiedOnly,
    !!filters.searchQuery
  ].filter(Boolean).length;

  return (
    <div className="bg-white border-y border-stone-200 py-3 px-4 sm:px-6 sticky top-16 sm:top-20 z-30 shadow-2xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        
        {/* Row 1: Search input + Category switcher */}
        <div className="flex items-center gap-2 flex-1">
          {/* Quick search input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={filters.searchQuery || ''}
              onChange={(e) => onFilterChange('searchQuery', e.target.value)}
              placeholder="Search Mumbai building, locality, or keyword..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-stone-50/50"
            />
            {filters.searchQuery && (
              <button
                type="button"
                onClick={() => onFilterChange('searchQuery', '')}
                className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Toggle Tabs */}
          <div className="flex items-center bg-stone-100 p-1 rounded-lg shrink-0">
            <button
              type="button"
              onClick={() => onFilterChange('category', 'all')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                filters.category === 'all'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              All
            </button>
            <button
              type="button"
              onClick={() => onFilterChange('category', 'residential')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors flex items-center gap-1 ${
                filters.category === 'residential'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Home className="w-3 h-3 text-stone-500" />
              <span>Residential</span>
            </button>
            <button
              type="button"
              onClick={() => onFilterChange('category', 'commercial')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors flex items-center gap-1 ${
                filters.category === 'commercial'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Building2 className="w-3 h-3 text-stone-500" />
              <span>Commercial</span>
            </button>
          </div>
        </div>

        {/* Row 2: Transaction quick select + Location + All Filters Drawer trigger */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          
          {/* Transaction dropdown */}
          <select
            value={filters.transactionType || 'all'}
            onChange={(e) => onFilterChange('transactionType', e.target.value as TransactionType | 'all')}
            className="px-2.5 py-1.5 text-xs font-medium border border-stone-200 rounded-lg bg-white text-stone-800 focus:outline-hidden focus:border-stone-900 shrink-0"
          >
            <option value="all">Any Deal (Buy/Rent)</option>
            <option value="buy">For Sale (Buy)</option>
            <option value="rent">For Rent</option>
            {isCommercial && <option value="lease">For Lease</option>}
          </select>

          {/* Location selector */}
          <select
            value={filters.location || ''}
            onChange={(e) => onFilterChange('location', e.target.value)}
            className="px-2.5 py-1.5 text-xs font-medium border border-stone-200 rounded-lg bg-white text-stone-800 focus:outline-hidden focus:border-stone-900 shrink-0 max-w-[140px] truncate"
          >
            <option value="">All Mumbai Localities</option>
            {POPULAR_MUMBAI_AREAS.map((loc) => (
              <option key={loc} value={loc}>{loc}</option>
            ))}
          </select>

          {/* BHK for residential */}
          {!isCommercial && (
            <select
              value={filters.bhk || ''}
              onChange={(e) => onFilterChange('bhk', e.target.value)}
              className="px-2.5 py-1.5 text-xs font-medium border border-stone-200 rounded-lg bg-white text-stone-800 focus:outline-hidden focus:border-stone-900 shrink-0"
            >
              <option value="">Any BHK</option>
              <option value="1 BHK">1 BHK</option>
              <option value="2 BHK">2 BHK</option>
              <option value="3 BHK">3 BHK</option>
              <option value="4+ BHK">4+ BHK</option>
            </select>
          )}

          {/* Sort By */}
          <select
            value={filters.sortBy || 'newest'}
            onChange={(e) => onFilterChange('sortBy', e.target.value as any)}
            className="px-2.5 py-1.5 text-xs font-medium border border-stone-200 rounded-lg bg-white text-stone-800 focus:outline-hidden focus:border-stone-900 shrink-0"
          >
            <option value="newest">Newest First</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="area_desc">Area: Largest First</option>
          </select>

          {/* More Filters Toggle */}
          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors shrink-0 ${
              activeCount > 0 
                ? 'border-stone-900 bg-stone-900 text-white' 
                : 'border-stone-200 hover:border-stone-400 text-stone-800 bg-white'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
            {activeCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-400 text-stone-950 text-[10px] flex items-center justify-center font-bold">
                {activeCount}
              </span>
            )}
          </button>

          {/* Reset button if active */}
          {activeCount > 0 && (
            <button
              type="button"
              onClick={onReset}
              className="p-1.5 text-stone-400 hover:text-stone-700 transition-colors"
              title="Reset all filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

      </div>

      {/* Expanded Filter Drawer / Modal */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-end bg-stone-950/50 backdrop-blur-xs">
          <div className="w-full max-w-md h-full bg-white shadow-2xl flex flex-col justify-between overflow-hidden animate-in slide-in-from-right duration-200">
            
            {/* Drawer Header */}
            <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-[#FAF9F5]">
              <div>
                <h3 className="text-base font-bold text-stone-900">
                  Filter Properties
                </h3>
                <p className="text-xs text-stone-500">
                  Refine {totalResults} available Mumbai properties
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="p-1.5 text-stone-400 hover:text-stone-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Drawer Scrollable Body */}
            <div className="p-5 space-y-6 overflow-y-auto flex-1 text-xs">
              
              {/* Category */}
              <div>
                <label className="block font-semibold text-stone-800 mb-2">
                  Property Category
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['all', 'residential', 'commercial'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => onFilterChange('category', cat)}
                      className={`py-2 px-3 rounded-lg border text-center capitalize font-medium transition-colors ${
                        filters.category === cat
                          ? 'border-stone-900 bg-stone-900 text-white'
                          : 'border-stone-200 hover:border-stone-400 text-stone-700'
                      }`}
                    >
                      {cat === 'all' ? 'All Types' : cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Transaction Type */}
              <div>
                <label className="block font-semibold text-stone-800 mb-2">
                  Transaction Type
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['all', 'buy', 'rent', 'lease'] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => onFilterChange('transactionType', t)}
                      className={`py-2 px-2 rounded-lg border text-center capitalize font-medium transition-colors text-[11px] ${
                        filters.transactionType === t
                          ? 'border-stone-900 bg-stone-900 text-white'
                          : 'border-stone-200 hover:border-stone-400 text-stone-700'
                      }`}
                    >
                      {t === 'all' ? 'Any' : t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Property Type */}
              <div>
                <label className="block font-semibold text-stone-800 mb-2">
                  Property Specific Type
                </label>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => onFilterChange('propertyType', '')}
                    className={`px-3 py-1.5 rounded-md border text-[11px] transition-colors ${
                      !filters.propertyType
                        ? 'border-stone-900 bg-stone-900 text-white'
                        : 'border-stone-200 text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    Any
                  </button>
                  {typeOptions.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => onFilterChange('propertyType', filters.propertyType === opt ? '' : opt)}
                      className={`px-3 py-1.5 rounded-md border text-[11px] transition-colors ${
                        filters.propertyType === opt
                          ? 'border-stone-900 bg-stone-900 text-white'
                          : 'border-stone-200 text-stone-700 hover:border-stone-300'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Carpet Area Range */}
              <div>
                <label className="block font-semibold text-stone-800 mb-2">
                  Carpet Area (sq.ft)
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-stone-500 mb-1 block">Min Carpet Area</span>
                    <input
                      type="number"
                      value={filters.minCarpetArea || ''}
                      onChange={(e) => onFilterChange('minCarpetArea', e.target.value ? Number(e.target.value) : undefined)}
                      placeholder="e.g. 500"
                      className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-stone-500 mb-1 block">Max Carpet Area</span>
                    <input
                      type="number"
                      value={filters.maxCarpetArea || ''}
                      onChange={(e) => onFilterChange('maxCarpetArea', e.target.value ? Number(e.target.value) : undefined)}
                      placeholder="e.g. 3500"
                      className="w-full px-3 py-2 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                    />
                  </div>
                </div>
              </div>

              {/* Furnishing Status */}
              <div>
                <label className="block font-semibold text-stone-800 mb-2">
                  Furnishing
                </label>
                <div className="grid grid-cols-4 gap-2 text-[11px]">
                  {[
                    { label: 'Any', value: '' },
                    { label: 'Unfurnished', value: 'unfurnished' },
                    { label: 'Semi-Furnished', value: 'semi-furnished' },
                    { label: 'Fully-Furnished', value: 'fully-furnished' },
                  ].map((f) => (
                    <button
                      key={f.value}
                      type="button"
                      onClick={() => onFilterChange('furnishing', f.value)}
                      className={`py-2 px-1 rounded-md border text-center transition-colors ${
                        filters.furnishing === f.value
                          ? 'border-stone-900 bg-stone-900 text-white'
                          : 'border-stone-200 text-stone-700 hover:border-stone-300'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggles: Parking & Verified */}
              <div className="space-y-3 pt-2 border-t border-stone-100">
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!filters.hasParking}
                    onChange={(e) => onFilterChange('hasParking', e.target.checked)}
                    className="w-4 h-4 rounded border-stone-300 text-stone-900 focus:ring-stone-900"
                  />
                  <span className="text-stone-800 font-medium">Reserved Car Parking only</span>
                </label>

                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!filters.verifiedOnly}
                    onChange={(e) => onFilterChange('verifiedOnly', e.target.checked)}
                    className="w-4 h-4 rounded border-stone-300 text-stone-900 focus:ring-stone-900"
                  />
                  <span className="text-stone-800 font-medium">Verified Direct Listings only</span>
                </label>
              </div>

            </div>

            {/* Drawer Footer Actions */}
            <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={onReset}
                className="px-4 py-2 text-xs font-semibold text-stone-700 hover:text-stone-900"
              >
                Clear All
              </button>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-xs"
              >
                Show {totalResults} Properties
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
