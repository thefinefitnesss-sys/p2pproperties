import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  ShieldCheck, 
  Save, 
  CheckCircle2, 
  Building2, 
  Key,
  BadgeCheck
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { UserRole } from '../types/property';

export const ProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, updateUserProfile, showToast } = useProperty();

  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [role, setRole] = useState<UserRole>(currentUser?.role || 'buyer');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
    } else {
      setName(currentUser.name);
      setPhone(currentUser.phone);
      setRole(currentUser.role);
    }
  }, [currentUser, navigate]);

  if (!currentUser) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateUserProfile({
        name: name.trim(),
        phone: phone.trim(),
        role
      });
    } catch (err: any) {
      showToast(err.message || 'Failed to update profile.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-10 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Title */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900">
          User Profile & Capabilities
        </h1>
        <p className="text-xs text-stone-600 mt-1">
          Manage your account credentials, contact numbers, and marketplace role permissions.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left card: Badge & Summary */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-5 text-center flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-stone-900 text-stone-50 flex items-center justify-center text-2xl font-bold font-serif shadow-xs">
            {currentUser.name.charAt(0)}
          </div>

          <div>
            <h3 className="text-base font-bold text-stone-900">{currentUser.name}</h3>
            <p className="text-xs text-stone-500">{currentUser.email}</p>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-[11px] font-semibold uppercase tracking-wider">
            <span>Primary Role: {currentUser.role}</span>
          </div>

          <div className="w-full pt-4 border-t border-stone-100 space-y-2 text-xs text-left">
            <div className="flex justify-between text-stone-600">
              <span>Account Status:</span>
              <span className="font-semibold text-emerald-700 flex items-center gap-1">
                <BadgeCheck className="w-3.5 h-3.5" />
                Active
              </span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Direct Verification:</span>
              <span className="font-semibold text-stone-900">
                {currentUser.isVerified ? 'Verified' : 'Pending Review'}
              </span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Capabilities:</span>
              <span className="font-mono text-[11px] text-stone-800">
                {currentUser.capabilities?.join(', ') || currentUser.role}
              </span>
            </div>
          </div>
        </div>

        {/* Right card: Form */}
        <div className="md:col-span-2 bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6">
          <h2 className="text-base font-bold text-stone-900">
            Edit Personal Details
          </h2>

          <form onSubmit={handleSave} className="space-y-4 text-xs">
            <div>
              <label className="block font-medium text-stone-700 mb-1">
                Full Legal Name
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">
                Verified Mobile Number
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">
                Email Address (Permanent Identifier)
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg bg-stone-100 text-stone-500 cursor-not-allowed"
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1.5">
                Marketplace Operating Role
              </label>
              <div className="grid grid-cols-4 gap-2">
                {(['buyer', 'tenant', 'owner', 'agent'] as UserRole[]).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRole(r)}
                    className={`py-2 px-1 text-[11px] font-semibold capitalize rounded-lg border text-center transition-colors ${
                      role === r 
                        ? 'border-stone-900 bg-stone-900 text-white' 
                        : 'border-stone-200 text-stone-700 hover:border-stone-400'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-stone-100 flex items-center justify-end">
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 disabled:bg-stone-400 rounded-lg shadow-xs transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{loading ? 'Saving...' : 'Save Profile Changes'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
