import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  MessageSquare, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  Send,
  AlertCircle
} from 'lucide-react';
import { api } from '../services/api';

export const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    enquiry_type: 'GENERAL',
    message: ''
  });
  const [settings, setSettings] = useState<any>({
    businessName: 'P2P Property Technologies Pvt. Ltd.',
    businessPhone: '+91 (022) 6820-0022',
    businessEmail: 'concierge@p2pproperty.in',
    officeAddress: 'Floor 8, Maker Maxity, Bandra Kurla Complex (BKC), Mumbai, Maharashtra 400051',
    whatsappNumber: '+919820098200',
    mahareraRegNumber: 'A51900034821',
    certificateOfCompetency: 'CoC-MAH-2024-99182'
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const res = await api.settings.getPublic();
      if (res) {
        setSettings(res);
      }
    } catch {
      // fallback to initial state
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!formData.name.trim() || !formData.email.trim() || !formData.phone.trim() || !formData.message.trim()) {
      setErrorMsg('Please fill in all required fields.');
      return;
    }

    setSubmitting(true);
    try {
      await api.contact.submit(formData);
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        enquiry_type: 'GENERAL',
        message: ''
      });
    } catch (err: any) {
      setErrorMsg(err.message || 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF9F5] py-12 sm:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-900 border border-amber-300 rounded-full text-xs font-semibold uppercase tracking-wider mb-4">
            <ShieldCheck className="w-4 h-4 text-amber-800" />
            <span>MahaRERA Reg: {settings.mahareraRegNumber}</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-stone-900 leading-tight">
            Contact Mumbai Direct Desk
          </h1>
          <p className="mt-4 text-base text-stone-600 leading-relaxed font-light">
            Connect directly with our Mumbai property verification officers, direct deal advisors, or support concierge.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: Direct Info Cards */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-white p-7 rounded-2xl border border-stone-200/90 shadow-sm space-y-6">
              <h2 className="font-serif text-xl font-bold text-stone-900">
                Operating Headquarters
              </h2>

              <div className="space-y-5 text-sm">
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-stone-100 text-stone-700 flex items-center justify-center shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4 text-amber-700" />
                  </div>
                  <div>
                    <p className="font-semibold text-stone-900">Mumbai Operating Office</p>
                    <p className="text-stone-600 leading-relaxed mt-0.5">{settings.officeAddress}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-stone-100 text-stone-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Phone className="w-4 h-4 text-amber-700" />
                  </div>
                  <div>
                    <p className="font-semibold text-stone-900">Direct Concierge Phone</p>
                    <a href={`tel:${settings.businessPhone.replace(/[^0-9+]/g, '')}`} className="text-amber-800 hover:text-amber-950 font-medium">
                      {settings.businessPhone}
                    </a>
                    <p className="text-stone-400 text-xs mt-0.5">Mon – Sat, 9:30 AM – 7:30 PM IST</p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-stone-100 text-stone-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Mail className="w-4 h-4 text-amber-700" />
                  </div>
                  <div>
                    <p className="font-semibold text-stone-900">Official Inquiries & Grievances</p>
                    <a href={`mailto:${settings.businessEmail}`} className="text-amber-800 hover:text-amber-950 font-medium">
                      {settings.businessEmail}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                    <MessageSquare className="w-4 h-4 text-emerald-700" />
                  </div>
                  <div>
                    <p className="font-semibold text-stone-900">WhatsApp Verified Desk</p>
                    <a 
                      href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=Hello%20P2P%20Property%20Desk,%20I%20have%20an%20enquiry.`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-emerald-700 hover:text-emerald-900 font-medium"
                    >
                      Chat on WhatsApp ({settings.whatsappNumber})
                    </a>
                    <p className="text-stone-400 text-xs mt-0.5">Instant response for verified listings</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Compliance Badge Card */}
            <div className="bg-stone-900 text-stone-200 p-7 rounded-2xl border border-stone-800 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4" />
                <span>Statutory Compliance</span>
              </div>
              <p className="font-serif text-lg font-bold text-white">{settings.businessName}</p>
              <div className="text-xs text-stone-400 space-y-1 pt-1 font-mono">
                <p>MahaRERA Agent Reg: <span className="text-stone-200">{settings.mahareraRegNumber}</span></p>
                <p>Certificate of Competency: <span className="text-stone-200">{settings.certificateOfCompetency}</span></p>
                <p>Jurisdiction: <span className="text-stone-200">Mumbai Metropolitan Region (MMRDA)</span></p>
              </div>
            </div>

          </div>

          {/* Right Column: Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-white p-8 sm:p-10 rounded-2xl border border-stone-200/90 shadow-sm">
              <h2 className="font-serif text-2xl font-bold text-stone-900 mb-2">
                Send Direct Message
              </h2>
              <p className="text-sm text-stone-600 mb-8 font-light">
                Fill in the details below. Our Mumbai verification and direct deal team will review your message promptly.
              </p>

              {submitted ? (
                <div className="p-8 text-center bg-emerald-50 border border-emerald-200 rounded-xl space-y-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-xl font-bold text-emerald-900">Message Received</h3>
                  <p className="text-sm text-emerald-800 max-w-md mx-auto leading-relaxed">
                    Thank you for reaching out. A P2P Property Mumbai representative will contact you shortly via phone or email.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSubmitted(false)}
                    className="mt-4 px-4 py-2 text-xs font-semibold text-emerald-900 hover:text-emerald-950 underline"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {errorMsg && (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-800 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-2">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Rahul Singhal"
                        className="w-full px-4 py-3 rounded-lg border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-2">
                        Mobile Number *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+91 98200 12345"
                        className="w-full px-4 py-3 rounded-lg border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="name@domain.com"
                        className="w-full px-4 py-3 rounded-lg border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-2">
                        Enquiry Type
                      </label>
                      <select
                        value={formData.enquiry_type}
                        onChange={(e) => setFormData({ ...formData, enquiry_type: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border border-stone-300 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                      >
                        <option value="GENERAL">General Property Enquiry</option>
                        <option value="RESIDENTIAL_BUY">Buy Residential Property</option>
                        <option value="COMMERCIAL_LEASE">Commercial Lease / Purchase</option>
                        <option value="SELL_LISTING">List & Sell My Property</option>
                        <option value="SITE_VERIFICATION">Property Document Verification</option>
                        <option value="BROKERAGE_QUERY">Brokerage & Agreement Queries</option>
                        <option value="GRIEVANCE">Grievance / Feedback</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-stone-700 mb-2">
                      Message / Requirement Details *
                    </label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Please specify property requirements, preferred Mumbai localities (e.g., Bandra, Worli, BKC, Andheri), budget, or questions regarding direct verification..."
                      className="w-full px-4 py-3 rounded-lg border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full sm:w-auto px-8 py-3.5 bg-stone-900 hover:bg-stone-800 disabled:opacity-60 text-white font-semibold rounded-lg text-sm tracking-wide transition-colors flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{submitting ? 'Submitting...' : 'Send Enquiry to Direct Desk'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
