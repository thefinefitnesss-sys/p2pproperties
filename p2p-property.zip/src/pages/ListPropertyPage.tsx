import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Check, 
  ChevronRight, 
  ChevronLeft, 
  Upload, 
  Building2, 
  Home, 
  MapPin, 
  ShieldCheck, 
  IndianRupee, 
  Image as ImageIcon, 
  X, 
  AlertCircle,
  Sparkles,
  Lock
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { api } from '../services/api';
import { 
  PropertyCategory, 
  TransactionType, 
  ResidentialType, 
  CommercialType,
  FurnishingStatus,
  PropertyImage
} from '../types/property';
import { 
  POPULAR_MUMBAI_AREAS, 
  RESIDENTIAL_TYPE_OPTIONS, 
  COMMERCIAL_TYPE_OPTIONS 
} from '../data/sampleProperties';
import { sanitizeText } from '../utils/formatters';

const STEPS = [
  { id: 1, name: 'Category' },
  { id: 2, name: 'Transaction' },
  { id: 3, name: 'Details' },
  { id: 4, name: 'Location' },
  { id: 5, name: 'Pricing' },
  { id: 6, name: 'Photos' },
  { id: 7, name: 'Description' },
  { id: 8, name: 'Contact' },
];

const COMMON_AMENITIES = [
  '24/7 Security & CCTV',
  'Covered Car Parking',
  'High-Speed Elevators',
  '100% DG Power Backup',
  'Piped Natural Gas (MGL)',
  'Clubhouse & Gym',
  'Swimming Pool',
  'Children Play Area',
  'Intercom Facility',
  'Fire Fighting System',
  'Vastu Compliant',
  'Rainwater Harvesting'
];

export const ListPropertyPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useProperty();

  const [currentStep, setCurrentStep] = useState(1);
  const [errorMessage, setErrorMessage] = useState('');
  const [submittedPropertyId, setSubmittedPropertyId] = useState<string | null>(null);

  // Form State
  // Step 1: Category
  const [category, setCategory] = useState<PropertyCategory>('residential');

  // Step 2: Transaction
  const [transactionType, setTransactionType] = useState<TransactionType>('buy');

  // Step 3: Residential Details
  const [residentialType, setResidentialType] = useState<ResidentialType>('2 BHK');
  const [bhk, setBhk] = useState('2 BHK');
  const [carpetArea, setCarpetArea] = useState<string>('950');
  const [builtUpArea, setBuiltUpArea] = useState<string>('1200');
  const [floor, setFloor] = useState<string>('8');
  const [totalFloors, setTotalFloors] = useState<string>('16');
  const [furnishing, setFurnishing] = useState<FurnishingStatus>('semi-furnished');
  const [coveredParking, setCoveredParking] = useState<string>('1');
  const [openParking, setOpenParking] = useState<string>('0');
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([
    '24/7 Security & CCTV',
    'Covered Car Parking',
    'High-Speed Elevators'
  ]);

  // Step 3: Commercial Details
  const [commercialType, setCommercialType] = useState<CommercialType>('Office');
  const [washrooms, setWashrooms] = useState<string>('2');
  const [powerBackup, setPowerBackup] = useState(true);
  const [loadingAvailable, setLoadingAvailable] = useState(false);
  const [suitableBusiness, setSuitableBusiness] = useState<string>('Corporate Offices, Startups, Financial Advisory');

  // Step 4: Location
  const [buildingName, setBuildingName] = useState('');
  const [area, setArea] = useState('');
  const [locality, setLocality] = useState(POPULAR_MUMBAI_AREAS[0]);
  const [city] = useState('Mumbai');
  const [pincode, setPincode] = useState('400050');
  const [landmark, setLandmark] = useState('');
  const [mapCoordinates, setMapCoordinates] = useState({ lat: 19.0760, lng: 72.8777 });

  // Step 5: Pricing
  const [price, setPrice] = useState<string>('');
  const [maintenance, setMaintenance] = useState<string>('');
  const [securityDeposit, setSecurityDeposit] = useState<string>('');
  const [isNegotiable, setIsNegotiable] = useState(true);

  // Step 6: Photos
  const [images, setImages] = useState<PropertyImage[]>([
    {
      id: 'img-pre-1',
      url: '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg',
      caption: 'Main Living Area',
      isPrimary: true
    }
  ]);
  const [photoCaption, setPhotoCaption] = useState('');

  // Step 7: Description
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  // Step 8: Contact
  const [ownerName, setOwnerName] = useState(currentUser?.name || '');
  const [ownerPhone, setOwnerPhone] = useState(currentUser?.phone || '');
  const [ownerEmail, setOwnerEmail] = useState(currentUser?.email || '');
  const [ownerType, setOwnerType] = useState<'owner' | 'authorized_representative'>('owner');

  // Step navigation validations
  const validateCurrentStep = (): boolean => {
    setErrorMessage('');

    if (currentStep === 1) {
      return true;
    }

    if (currentStep === 2) {
      if (category === 'residential' && (transactionType === 'lease')) {
        setErrorMessage('Lease transaction is typically applicable for commercial properties.');
        return false;
      }
      return true;
    }

    if (currentStep === 3) {
      if (!carpetArea || Number(carpetArea) <= 0) {
        setErrorMessage('Please provide a valid carpet area in square feet.');
        return false;
      }
      return true;
    }

    if (currentStep === 4) {
      if (!buildingName.trim()) {
        setErrorMessage('Please enter the building, project or commercial complex name.');
        return false;
      }
      if (!locality.trim()) {
        setErrorMessage('Please specify the Mumbai locality.');
        return false;
      }
      if (!pincode.trim() || pincode.length !== 6) {
        setErrorMessage('Please enter a valid 6-digit Mumbai postal pincode.');
        return false;
      }
      return true;
    }

    if (currentStep === 5) {
      if (!price || Number(price) <= 0) {
        setErrorMessage('Please enter a valid price / rent amount.');
        return false;
      }
      return true;
    }

    if (currentStep === 6) {
      if (images.length === 0) {
        setErrorMessage('Please upload or keep at least one property photo.');
        return false;
      }
      return true;
    }

    if (currentStep === 7) {
      if (!title.trim() || title.length < 10) {
        setErrorMessage('Please write a descriptive property title (minimum 10 characters).');
        return false;
      }
      if (!description.trim() || description.length < 20) {
        setErrorMessage('Please write a helpful description for prospective buyers/tenants (minimum 20 characters).');
        return false;
      }
      return true;
    }

    if (currentStep === 8) {
      if (!ownerName.trim()) {
        setErrorMessage('Please enter the owner / representative name.');
        return false;
      }
      if (!ownerPhone.trim() || ownerPhone.replace(/\D/g, '').length < 10) {
        setErrorMessage('Please provide a valid 10-digit Indian mobile number.');
        return false;
      }
      if (!ownerEmail.trim() || !ownerEmail.includes('@')) {
        setErrorMessage('Please provide a valid email address.');
        return false;
      }
      return true;
    }

    return true;
  };

  const handleNext = () => {
    if (validateCurrentStep()) {
      setCurrentStep((prev) => Math.min(prev + 1, STEPS.length));
      window.scrollTo({ top: 100, behavior: 'smooth' });
    }
  };

  const handleBack = () => {
    setErrorMessage('');
    setCurrentStep((prev) => Math.max(prev - 1, 1));
    window.scrollTo({ top: 100, behavior: 'smooth' });
  };

  // Image Upload handler with real backend storage
  const [uploadingImage, setUploadingImage] = useState(false);

  const handleImageFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploadingImage(true);
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const uploadRes = await api.media.upload(file);
        const newImage: PropertyImage = {
          id: `usr-img-${Date.now()}-${Math.random()}`,
          url: uploadRes.url,
          caption: photoCaption.trim() || file.name.replace(/\.[^/.]+$/, ''),
          isPrimary: images.length === 0
        };
        setImages((prev) => [...prev, newImage]);
      } catch {
        // Fallback to FileReader if offline
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            const fallbackImage: PropertyImage = {
              id: `usr-img-${Date.now()}-${Math.random()}`,
              url: event.target.result as string,
              caption: photoCaption.trim() || file.name.replace(/\.[^/.]+$/, ''),
              isPrimary: images.length === 0
            };
            setImages((prev) => [...prev, fallbackImage]);
          }
        };
        reader.readAsDataURL(file);
      }
    }
    setUploadingImage(false);
    setPhotoCaption('');
  };

  const handleSetPrimaryImage = (imgId: string) => {
    setImages((prev) =>
      prev.map((img) => ({
        ...img,
        isPrimary: img.id === imgId
      }))
    );
  };

  const handleMoveImage = (idx: number, direction: 'up' | 'down') => {
    setImages((prev) => {
      const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
      if (targetIdx < 0 || targetIdx >= prev.length) return prev;
      const copy = [...prev];
      const temp = copy[idx];
      copy[idx] = copy[targetIdx];
      copy[targetIdx] = temp;
      return copy;
    });
  };

  const handleAddSampleImage = (url: string, caption: string) => {
    setImages((prev) => [
      ...prev,
      {
        id: `sample-img-${Date.now()}-${Math.random()}`,
        url,
        caption,
        isPrimary: prev.length === 0
      }
    ]);
  };

  const handleRemoveImage = (imgId: string) => {
    setImages((prev) => prev.filter((im) => im.id !== imgId));
  };

  const handleToggleAmenity = (amenity: string) => {
    setSelectedAmenities((prev) =>
      prev.includes(amenity) ? prev.filter((a) => a !== amenity) : [...prev, amenity]
    );
  };

  // Final Form Submission
  const [submitting, setSubmitting] = useState(false);

  const handleSubmitProperty = async (e: React.FormEvent, submitStatus: 'DRAFT' | 'PENDING_APPROVAL' = 'PENDING_APPROVAL') => {
    e.preventDefault();
    if (!validateCurrentStep()) return;

    if (!currentUser) {
      setErrorMessage('You must be signed in to list a property. Please log in or create an account.');
      return;
    }

    setSubmitting(true);
    setErrorMessage('');

    try {
      const priceNum = Number(price);
      const carpetNum = Number(carpetArea);
      const builtUpNum = builtUpArea ? Number(builtUpArea) : Math.round(carpetNum * 1.3);

      const payload = {
        title: sanitizeText(title),
        description: sanitizeText(description),
        category,
        transaction_type: transactionType,
        property_type: category === 'residential' ? residentialType : commercialType,
        price: priceNum,
        rent: transactionType === 'rent' || transactionType === 'lease' ? priceNum : undefined,
        security_deposit: securityDeposit ? Number(securityDeposit) : undefined,
        maintenance: maintenance ? Number(maintenance) : undefined,
        carpet_area: carpetNum,
        built_up_area: builtUpNum,
        bedrooms: category === 'residential' ? (bhk === '1 BHK' ? 1 : bhk === '2 BHK' ? 2 : bhk === '3 BHK' ? 3 : 4) : undefined,
        bathrooms: category === 'residential' ? (bhk === '1 BHK' ? 1 : 2) : Number(washrooms) || 1,
        floor: Number(floor) || 0,
        total_floors: Number(totalFloors) || 10,
        furnishing,
        parking: `${coveredParking} Covered${Number(openParking) > 0 ? `, ${openParking} Open` : ''}`,
        address: sanitizeText(buildingName),
        locality: sanitizeText(locality),
        city: 'Mumbai',
        pincode: sanitizeText(pincode),
        latitude: mapCoordinates.lat,
        longitude: mapCoordinates.lng,
        status: submitStatus,
        washrooms: category === 'commercial' ? Number(washrooms) || 1 : undefined,
        power_backup: category === 'commercial' ? (powerBackup ? 1 : 0) : undefined,
        loading_unloading: category === 'commercial' ? (loadingAvailable ? 1 : 0) : undefined,
        business_type: category === 'commercial' ? suitableBusiness : undefined,
        images: images.map((img, i) => ({
          url: img.url,
          caption: img.caption,
          display_order: i,
          isPrimary: img.isPrimary
        })),
        amenities: selectedAmenities
      };

      const res = await api.properties.create(payload);
      setSubmittedPropertyId(res.propertyId);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error submitting listing to database.');
    } finally {
      setSubmitting(false);
    }
  };

  // SUCCESS CONFIRMATION STATE
  if (submittedPropertyId) {
    return (
      <div className="max-w-2xl mx-auto py-16 px-4 sm:px-6">
        <div className="bg-white rounded-2xl border border-stone-200 p-8 sm:p-10 shadow-lg text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
            <Check className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900">
              Property Successfully Listed!
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 max-w-md mx-auto">
              Your property is live on the P2P Property marketplace for Mumbai. Genuine buyers and tenants can now request verified direct inquiries and schedule site visits.
            </p>
          </div>

          <div className="p-4 bg-[#FAF9F5] rounded-xl border border-stone-200 text-xs text-left space-y-2 max-w-md mx-auto">
            <div className="flex justify-between">
              <span className="text-stone-500">Property:</span>
              <span className="font-semibold text-stone-900 truncate max-w-[200px]">{title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500">Location:</span>
              <span className="font-semibold text-stone-900">{locality}, Mumbai</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500">Privacy Status:</span>
              <span className="text-emerald-700 font-semibold">Contact Masked & Protected</span>
            </div>
          </div>

          {/* Architecture note adhering to Phase 1 instruction */}
          <p className="text-[11px] text-stone-400 italic">
            * Phase 1 Note: Listing stored in local state repository. Ready for Phase 2 database integration.
          </p>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to={`/properties/${submittedPropertyId}`}
              className="w-full sm:w-auto px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
            >
              View Your Live Listing
            </Link>
            <button
              type="button"
              onClick={() => {
                setSubmittedPropertyId(null);
                setCurrentStep(1);
                setTitle('');
                setDescription('');
                setPrice('');
              }}
              className="w-full sm:w-auto px-5 py-3 text-xs font-semibold uppercase tracking-wider text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
            >
              List Another Property
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24">
      
      {/* Page Header */}
      <div className="bg-[#FAF9F5] border-b border-stone-200 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-800">
            <Building2 className="w-4 h-4 text-amber-700" />
            <span>Direct Mumbai Property Listing</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-serif font-bold text-stone-950">
            List Your Property Directly
          </h1>
          <p className="text-xs sm:text-sm text-stone-600">
            Connect with verified buyers and tenants without arbitrary brokerage interference.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Step Progression Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between overflow-x-auto pb-2 scrollbar-none gap-2">
            {STEPS.map((step) => {
              const isPassed = step.id < currentStep;
              const isCurrent = step.id === currentStep;

              return (
                <div key={step.id} className="flex items-center shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      if (step.id < currentStep) setCurrentStep(step.id);
                    }}
                    disabled={step.id > currentStep}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                      isCurrent
                        ? 'bg-stone-900 text-white shadow-xs'
                        : isPassed
                          ? 'bg-stone-100 text-stone-800 hover:bg-stone-200'
                          : 'text-stone-400 cursor-not-allowed'
                    }`}
                  >
                    <span className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-bold ${
                      isCurrent ? 'bg-amber-400 text-stone-950' : isPassed ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-500'
                    }`}>
                      {isPassed ? <Check className="w-2.5 h-2.5" /> : step.id}
                    </span>
                    <span>{step.name}</span>
                  </button>
                  {step.id < STEPS.length && (
                    <ChevronRight className="w-3.5 h-3.5 text-stone-300 mx-1" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Error Banner */}
        {errorMessage && (
          <div className="mb-6 p-3.5 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2.5 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Form Container */}
        <form onSubmit={handleSubmitProperty} className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 shadow-xs space-y-8">
          
          {/* STEP 1: CATEGORY */}
          {currentStep === 1 && (
            <div className="space-y-6 animate-in fade-in">
              <div>
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Step 1 of 8</span>
                <h2 className="text-xl font-bold font-serif text-stone-900 mt-1">
                  Select Property Category
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  Choose whether your property is intended for living or commercial operations.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setCategory('residential')}
                  className={`p-6 rounded-xl border-2 text-left transition-all flex flex-col justify-between ${
                    category === 'residential'
                      ? 'border-stone-900 bg-amber-50/30 ring-1 ring-stone-900'
                      : 'border-stone-200 hover:border-stone-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-lg bg-stone-100 flex items-center justify-center text-stone-900">
                      <Home className="w-6 h-6" />
                    </div>
                    {category === 'residential' && (
                      <span className="w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-stone-900">Residential Property</h3>
                    <p className="text-xs text-stone-500 mt-1">
                      Apartments, Flats, Penthouses, Villas, Builder Floors & Residential Plots.
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setCategory('commercial')}
                  className={`p-6 rounded-xl border-2 text-left transition-all flex flex-col justify-between ${
                    category === 'commercial'
                      ? 'border-stone-900 bg-amber-50/30 ring-1 ring-stone-900'
                      : 'border-stone-200 hover:border-stone-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-lg bg-stone-100 flex items-center justify-center text-stone-900">
                      <Building2 className="w-6 h-6" />
                    </div>
                    {category === 'commercial' && (
                      <span className="w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-stone-900">Commercial Property</h3>
                    <p className="text-xs text-stone-500 mt-1">
                      Corporate Offices, Retail Showrooms, Shops, Warehouses, Godowns, Clinics & Land.
                    </p>
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: TRANSACTION */}
          {currentStep === 2 && (
            <div className="space-y-6 animate-in fade-in">
              <div>
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Step 2 of 8</span>
                <h2 className="text-xl font-bold font-serif text-stone-900 mt-1">
                  Select Transaction Type
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  How would you like to deal this {category} property?
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { type: 'buy', label: 'For Sale (Buy)', desc: 'Direct outright sale' },
                  { type: 'rent', label: 'For Rent', desc: 'Monthly residential/commercial lease' },
                  ...(category === 'commercial' 
                    ? [
                        { type: 'lease', label: 'Long-term Lease', desc: '3-9 years commercial registered' },
                        { type: 'sell', label: 'Sell Outright', desc: 'Commercial investment exit' }
                      ]
                    : [
                        { type: 'sell', label: 'Sell', desc: 'Owner looking for buyers' }
                      ]
                  )
                ].map((item) => (
                  <button
                    key={item.type}
                    type="button"
                    onClick={() => setTransactionType(item.type as TransactionType)}
                    className={`p-4 rounded-xl border-2 text-left transition-all ${
                      transactionType === item.type
                        ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-900'
                        : 'border-stone-200 hover:border-stone-400'
                    }`}
                  >
                    <span className="block font-bold text-stone-900 text-sm">
                      {item.label}
                    </span>
                    <span className="text-[11px] text-stone-500 mt-1 block">
                      {item.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 3: PROPERTY DETAILS (RESIDENTIAL VS COMMERCIAL) */}
          {currentStep === 3 && (
            <div className="space-y-6 animate-in fade-in">
              <div>
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Step 3 of 8</span>
                <h2 className="text-xl font-bold font-serif text-stone-900 mt-1">
                  Property Specifications ({category})
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  Enter carpet area, floor height, and key property attributes.
                </p>
              </div>

              {category === 'residential' ? (
                /* Residential Form Fields */
                <div className="space-y-5 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Property Configuration (BHK) *
                      </label>
                      <select
                        value={bhk}
                        onChange={(e) => {
                          setBhk(e.target.value);
                          setResidentialType(e.target.value as ResidentialType);
                        }}
                        className="w-full px-3 py-2.5 border border-stone-200 rounded-lg bg-white"
                      >
                        <option value="1 BHK">1 BHK</option>
                        <option value="2 BHK">2 BHK</option>
                        <option value="3 BHK">3 BHK</option>
                        <option value="4+ BHK">4+ BHK</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Residential Type *
                      </label>
                      <select
                        value={residentialType}
                        onChange={(e) => setResidentialType(e.target.value as ResidentialType)}
                        className="w-full px-3 py-2.5 border border-stone-200 rounded-lg bg-white"
                      >
                        {RESIDENTIAL_TYPE_OPTIONS.map((opt) => (
                          <option key={opt} value={opt}>{opt}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Carpet Area (sq.ft) *
                      </label>
                      <input
                        type="number"
                        value={carpetArea}
                        onChange={(e) => setCarpetArea(e.target.value)}
                        placeholder="e.g. 950"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Built-Up Area (sq.ft)
                      </label>
                      <input
                        type="number"
                        value={builtUpArea}
                        onChange={(e) => setBuiltUpArea(e.target.value)}
                        placeholder="e.g. 1250"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Property Floor
                      </label>
                      <input
                        type="number"
                        value={floor}
                        onChange={(e) => setFloor(e.target.value)}
                        placeholder="e.g. 8"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Total Floors
                      </label>
                      <input
                        type="number"
                        value={totalFloors}
                        onChange={(e) => setTotalFloors(e.target.value)}
                        placeholder="e.g. 18"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Furnishing Status
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['unfurnished', 'semi-furnished', 'fully-furnished'] as FurnishingStatus[]).map((f) => (
                          <button
                            key={f}
                            type="button"
                            onClick={() => setFurnishing(f)}
                            className={`py-2 px-1 text-[11px] rounded-lg border text-center capitalize ${
                              furnishing === f 
                                ? 'border-stone-900 bg-stone-900 text-white' 
                                : 'border-stone-200 text-stone-700'
                            }`}
                          >
                            {f.replace('-', ' ')}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Car Parking (Covered / Open)
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="number"
                          value={coveredParking}
                          onChange={(e) => setCoveredParking(e.target.value)}
                          placeholder="Covered slots"
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                        />
                        <input
                          type="number"
                          value={openParking}
                          onChange={(e) => setOpenParking(e.target.value)}
                          placeholder="Open slots"
                          className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Amenities Multi-Select */}
                  <div className="pt-2">
                    <label className="block font-medium text-stone-700 mb-2">
                      Society & Flat Amenities
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {COMMON_AMENITIES.map((amenity) => {
                        const selected = selectedAmenities.includes(amenity);
                        return (
                          <button
                            key={amenity}
                            type="button"
                            onClick={() => handleToggleAmenity(amenity)}
                            className={`p-2 rounded-lg border text-left flex items-center justify-between transition-colors ${
                              selected 
                                ? 'border-stone-900 bg-amber-50/50 text-stone-950 font-medium' 
                                : 'border-stone-200 text-stone-600 hover:border-stone-300'
                            }`}
                          >
                            <span>{amenity}</span>
                            {selected && <Check className="w-3.5 h-3.5 text-stone-900 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : (
                /* Commercial Form Fields */
                <div className="space-y-5 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Commercial Property Type *
                      </label>
                      <select
                        value={commercialType}
                        onChange={(e) => setCommercialType(e.target.value as CommercialType)}
                        className="w-full px-3 py-2.5 border border-stone-200 rounded-lg bg-white"
                      >
                        {COMMERCIAL_TYPE_OPTIONS.map((opt) => (
                          <option key={opt} value={opt}>{opt}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Furnishing / Fitout Status
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['unfurnished', 'semi-furnished', 'fully-furnished'] as FurnishingStatus[]).map((f) => (
                          <button
                            key={f}
                            type="button"
                            onClick={() => setFurnishing(f)}
                            className={`py-2 px-1 text-[11px] rounded-lg border text-center capitalize ${
                              furnishing === f 
                                ? 'border-stone-900 bg-stone-900 text-white' 
                                : 'border-stone-200 text-stone-700'
                            }`}
                          >
                            {f.replace('-', ' ')}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Carpet Area (sq.ft) *
                      </label>
                      <input
                        type="number"
                        value={carpetArea}
                        onChange={(e) => setCarpetArea(e.target.value)}
                        placeholder="e.g. 2400"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Built-Up Area (sq.ft)
                      </label>
                      <input
                        type="number"
                        value={builtUpArea}
                        onChange={(e) => setBuiltUpArea(e.target.value)}
                        placeholder="e.g. 3100"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Floor Level
                      </label>
                      <input
                        type="number"
                        value={floor}
                        onChange={(e) => setFloor(e.target.value)}
                        placeholder="e.g. 4"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Total Floors
                      </label>
                      <input
                        type="number"
                        value={totalFloors}
                        onChange={(e) => setTotalFloors(e.target.value)}
                        placeholder="e.g. 12"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Dedicated Washrooms
                      </label>
                      <input
                        type="number"
                        value={washrooms}
                        onChange={(e) => setWashrooms(e.target.value)}
                        placeholder="e.g. 2"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Covered Parkings
                      </label>
                      <input
                        type="number"
                        value={coveredParking}
                        onChange={(e) => setCoveredParking(e.target.value)}
                        placeholder="e.g. 2"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>

                    <div className="space-y-2 pt-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={powerBackup}
                          onChange={(e) => setPowerBackup(e.target.checked)}
                          className="w-4 h-4 rounded text-stone-900"
                        />
                        <span className="text-stone-800 font-medium">100% DG Power Backup</span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={loadingAvailable}
                          onChange={(e) => setLoadingAvailable(e.target.checked)}
                          className="w-4 h-4 rounded text-stone-900"
                        />
                        <span className="text-stone-800 font-medium">Loading / Unloading Bay</span>
                      </label>
                    </div>
                  </div>

                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Suitable Business Types
                    </label>
                    <input
                      type="text"
                      value={suitableBusiness}
                      onChange={(e) => setSuitableBusiness(e.target.value)}
                      placeholder="e.g. IT Startups, Banking, Medical Clinic, Boutique Showroom"
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 4: LOCATION */}
          {currentStep === 4 && (
            <div className="space-y-6 animate-in fade-in">
              <div>
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Step 4 of 8</span>
                <h2 className="text-xl font-bold font-serif text-stone-900 mt-1">
                  Property Location (Mumbai)
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  Pinpoint your building or commercial complex across Mumbai.
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Building / Complex / Project Name *
                    </label>
                    <input
                      type="text"
                      value={buildingName}
                      onChange={(e) => setBuildingName(e.target.value)}
                      placeholder="e.g. Sea Crest Towers / The Capital BKC"
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Street / Sub-Area
                    </label>
                    <input
                      type="text"
                      value={area}
                      onChange={(e) => setArea(e.target.value)}
                      placeholder="e.g. Carter Road / G Block"
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Mumbai Locality *
                    </label>
                    <select
                      value={locality}
                      onChange={(e) => setLocality(e.target.value)}
                      className="w-full px-3 py-2.5 border border-stone-200 rounded-lg bg-white"
                    >
                      {POPULAR_MUMBAI_AREAS.map((loc) => (
                        <option key={loc} value={loc}>{loc}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      City
                    </label>
                    <input
                      type="text"
                      value={city}
                      disabled
                      className="w-full px-3 py-2 border border-stone-200 bg-stone-100 rounded-lg text-stone-500 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Postal Pincode *
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value)}
                      placeholder="400050"
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    Prominent Landmark (Optional)
                  </label>
                  <input
                    type="text"
                    value={landmark}
                    onChange={(e) => setLandmark(e.target.value)}
                    placeholder="e.g. Near Joggers Park / Opposite Metro Station"
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                  />
                </div>

                {/* Map Location Placeholder */}
                <div className="pt-2">
                  <label className="block font-medium text-stone-700 mb-1">
                    Interactive Map Location Coordinate (Mumbai)
                  </label>
                  <div className="border border-stone-300 rounded-xl p-4 bg-stone-100/70 text-center space-y-2">
                    <div className="flex items-center justify-center gap-2 text-stone-700 font-semibold text-xs">
                      <MapPin className="w-4 h-4 text-amber-700" />
                      <span>Mumbai Center Coordinate Pin: {mapCoordinates.lat.toFixed(4)}° N, {mapCoordinates.lng.toFixed(4)}° E</span>
                    </div>
                    <p className="text-[11px] text-stone-500 max-w-sm mx-auto">
                      Building geometry and satellite pin for "{buildingName || 'Your Building'}, {locality}" will be linked to Mumbai Geographic Information System.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: PRICING */}
          {currentStep === 5 && (
            <div className="space-y-6 animate-in fade-in">
              <div>
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Step 5 of 8</span>
                <h2 className="text-xl font-bold font-serif text-stone-900 mt-1">
                  Pricing & Commercial Terms
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  Set direct owner pricing in Indian Rupees (INR).
                </p>
              </div>

              <div className="space-y-5 text-xs">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    {transactionType === 'buy' || transactionType === 'sell'
                      ? 'Total Expected Sale Price (₹ INR) *'
                      : 'Expected Monthly Rent / Lease (₹ INR/mo) *'}
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 font-semibold text-stone-500">₹</span>
                    <input
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      placeholder={transactionType === 'buy' || transactionType === 'sell' ? 'e.g. 25000000 (2.5 Cr)' : 'e.g. 85000'}
                      className="w-full pl-8 pr-3 py-2.5 border border-stone-200 rounded-lg text-sm font-semibold"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Monthly Society Maintenance (₹/month)
                    </label>
                    <input
                      type="number"
                      value={maintenance}
                      onChange={(e) => setMaintenance(e.target.value)}
                      placeholder="e.g. 8500"
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                    />
                  </div>

                  {(transactionType === 'rent' || transactionType === 'lease') && (
                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Security Deposit (₹ INR)
                      </label>
                      <input
                        type="number"
                        value={securityDeposit}
                        onChange={(e) => setSecurityDeposit(e.target.value)}
                        placeholder="e.g. 400000"
                        className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer pt-2">
                    <input
                      type="checkbox"
                      checked={isNegotiable}
                      onChange={(e) => setIsNegotiable(e.target.checked)}
                      className="w-4 h-4 rounded text-stone-900"
                    />
                    <span className="text-stone-800 font-medium">
                      Pricing is open to genuine discussion / negotiation
                    </span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* STEP 6: PHOTOS */}
          {currentStep === 6 && (
            <div className="space-y-6 animate-in fade-in">
              <div>
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Step 6 of 8</span>
                <h2 className="text-xl font-bold font-serif text-stone-900 mt-1">
                  Property Photographs
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  High-quality photos increase serious buyer & tenant inquiries by 300%.
                </p>
              </div>

              {/* Upload Drag & Drop Area */}
              <div className="border-2 border-dashed border-stone-300 rounded-2xl p-6 sm:p-8 text-center bg-[#FAF9F5] hover:bg-stone-100/60 transition-colors">
                <input
                  type="file"
                  id="photo-upload"
                  accept="image/*"
                  multiple
                  onChange={handleImageFileUpload}
                  className="hidden"
                />
                <label htmlFor="photo-upload" className="cursor-pointer block space-y-3">
                  <div className="w-12 h-12 rounded-full bg-white shadow-xs border border-stone-200 flex items-center justify-center mx-auto text-stone-700">
                    <Upload className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-stone-900 block">
                      Click to upload photos from your device
                    </span>
                    <span className="text-[11px] text-stone-500">
                      Supports JPG, PNG, WebP up to 15MB each
                    </span>
                  </div>
                </label>
              </div>

              {/* Quick Sample Presets (for rapid testing) */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-xs">
                <span className="font-semibold text-stone-800 block mb-2">
                  Or add realistic sample property photos:
                </span>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => handleAddSampleImage('/src/assets/images/luxury_bandra_apartment_1791457626031.jpg', 'Modern Living Room')}
                    className="px-2.5 py-1 bg-white border border-stone-300 hover:border-stone-900 rounded-md text-[11px] font-medium"
                  >
                    + Add Modern Apartment Shot
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddSampleImage('/src/assets/images/bkc_commercial_office_1791457642520.jpg', 'Commercial Office Space')}
                    className="px-2.5 py-1 bg-white border border-stone-300 hover:border-stone-900 rounded-md text-[11px] font-medium"
                  >
                    + Add Corporate Office Shot
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddSampleImage('/src/assets/images/worli_seaface_residence_1791457653070.jpg', 'Sea-Facing Balcony')}
                    className="px-2.5 py-1 bg-white border border-stone-300 hover:border-stone-900 rounded-md text-[11px] font-medium"
                  >
                    + Add Sea View Terrace Shot
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddSampleImage('/src/assets/images/mumbai_retail_showroom_1791457664965.jpg', 'Showroom / Retail Floor')}
                    className="px-2.5 py-1 bg-white border border-stone-300 hover:border-stone-900 rounded-md text-[11px] font-medium"
                  >
                    + Add Retail Showroom Shot
                  </button>
                </div>
              </div>

              {/* Current Photos Gallery Grid */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-stone-700">
                  Uploaded Photos ({images.length})
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {images.map((img, idx) => (
                    <div 
                      key={img.id}
                      className={`relative aspect-[4/3] rounded-lg overflow-hidden border-2 bg-stone-100 group ${
                        img.isPrimary ? 'border-amber-500 ring-2 ring-amber-400/40' : 'border-stone-200'
                      }`}
                    >
                      <img
                        src={img.url}
                        alt={img.caption || `Photo ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                      
                      {/* Top Action Bar */}
                      <div className="absolute top-1.5 inset-x-1.5 flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => handleSetPrimaryImage(img.id)}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            img.isPrimary 
                              ? 'bg-amber-500 text-stone-950' 
                              : 'bg-black/60 text-white hover:bg-black/80'
                          }`}
                          title="Click to set as primary cover photo"
                        >
                          {img.isPrimary ? '★ Primary' : 'Make Cover'}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleRemoveImage(img.id)}
                          className="w-6 h-6 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center transition-colors"
                          title="Remove photo"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Reorder Buttons */}
                      <div className="absolute bottom-6 right-1.5 flex items-center gap-1 opacity-80 hover:opacity-100">
                        {idx > 0 && (
                          <button
                            type="button"
                            onClick={() => handleMoveImage(idx, 'up')}
                            className="px-1 py-0.5 bg-black/60 text-white text-[9px] rounded hover:bg-black/80"
                            title="Move photo earlier"
                          >
                            ◀
                          </button>
                        )}
                        {idx < images.length - 1 && (
                          <button
                            type="button"
                            onClick={() => handleMoveImage(idx, 'down')}
                            className="px-1 py-0.5 bg-black/60 text-white text-[9px] rounded hover:bg-black/80"
                            title="Move photo later"
                          >
                            ▶
                          </button>
                        )}
                      </div>

                      <div className="absolute bottom-1 inset-x-1 px-1.5 py-0.5 bg-black/50 text-white text-[10px] truncate rounded">
                        {img.caption || `Photo ${idx + 1}`}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 7: DESCRIPTION */}
          {currentStep === 7 && (
            <div className="space-y-6 animate-in fade-in">
              <div>
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Step 7 of 8</span>
                <h2 className="text-xl font-bold font-serif text-stone-900 mt-1">
                  Title & Description
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  Highlight key selling points, ventilation, views, and society features.
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    Listing Headline / Title *
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Vastu Compliant 3 BHK Sea-Facing Residence in Bandra West"
                    className="w-full px-3 py-2.5 border border-stone-200 rounded-lg text-sm font-semibold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    Comprehensive Property Description *
                  </label>
                  <textarea
                    rows={6}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe the unit layout, natural ventilation, flooring, view, society infrastructure, power backup, and walking distance to nearby stations or hubs..."
                    className="w-full px-3 py-2.5 border border-stone-200 rounded-lg leading-relaxed"
                    required
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 8: CONTACT */}
          {currentStep === 8 && (
            <div className="space-y-6 animate-in fade-in">
              <div>
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Step 8 of 8</span>
                <h2 className="text-xl font-bold font-serif text-stone-900 mt-1">
                  Contact Information
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  Your identity details remain guarded from public spam scrapers.
                </p>
              </div>

              <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl flex items-start gap-3 text-xs text-stone-700">
                <Lock className="w-5 h-5 text-amber-800 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-bold text-stone-900 block">Owner Privacy Commitment</span>
                  <p className="text-[11px] leading-relaxed">
                    We will display only your initials and phone ending publicly. When genuine interested buyers or tenants submit an inquiry or site visit request, you receive full verified contact details directly.
                  </p>
                </div>
              </div>

              <div className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Your Role
                    </label>
                    <select
                      value={ownerType}
                      onChange={(e) => setOwnerType(e.target.value as any)}
                      className="w-full px-3 py-2.5 border border-stone-200 rounded-lg bg-white"
                    >
                      <option value="owner">Direct Property Owner</option>
                      <option value="authorized_representative">Authorized Family / Representative</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={ownerName}
                      onChange={(e) => setOwnerName(e.target.value)}
                      placeholder="e.g. Rajesh Merchant"
                      className="w-full px-3 py-2.5 border border-stone-200 rounded-lg"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Mobile Number (India) *
                    </label>
                    <input
                      type="tel"
                      value={ownerPhone}
                      onChange={(e) => setOwnerPhone(e.target.value)}
                      placeholder="+91 98200 XXXXX"
                      className="w-full px-3 py-2.5 border border-stone-200 rounded-lg"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-stone-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={ownerEmail}
                      onChange={(e) => setOwnerEmail(e.target.value)}
                      placeholder="owner@domain.com"
                      className="w-full px-3 py-2.5 border border-stone-200 rounded-lg"
                      required
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Bottom Navigation Buttons */}
          <div className="pt-6 border-t border-stone-200 flex items-center justify-between gap-4">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={handleBack}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-stone-700 border border-stone-300 hover:bg-stone-50 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Previous Step</span>
              </button>
            ) : (
              <div />
            )}

            {currentStep < STEPS.length ? (
              <button
                type="button"
                onClick={handleNext}
                className="inline-flex items-center gap-1.5 px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
              >
                <span>Continue to Step {currentStep + 1}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={(e) => handleSubmitProperty(e, 'DRAFT')}
                  className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-stone-800 bg-stone-100 hover:bg-stone-200 border border-stone-300 rounded-lg transition-colors"
                >
                  Save as Draft
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={(e) => handleSubmitProperty(e, 'PENDING_APPROVAL')}
                  className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-bold uppercase tracking-wider text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-md transition-all"
                >
                  <Sparkles className="w-4 h-4 text-stone-900" />
                  <span>{submitting ? 'Submitting...' : 'Submit for Approval'}</span>
                </button>
              </div>
            )}
          </div>

        </form>

      </div>

    </div>
  );
};
