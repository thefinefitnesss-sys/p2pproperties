import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Building2, 
  MapPin, 
  Send, 
  CheckCircle2, 
  Search, 
  Layers, 
  ShieldCheck, 
  Sparkles,
  ArrowRight,
  Info
} from 'lucide-react';
import { api } from '../services/api';
import { useProperty } from '../context/PropertyContext';
import { POPULAR_MUMBAI_AREAS } from '../data/sampleProperties';

export const PostRequirementPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, openAuthModal, showToast } = useProperty();

  const [transactionType, setTransactionType] = useState<'BUY' | 'RENT' | 'LEASE'>('BUY');
  const [category, setCategory] = useState<'RESIDENTIAL' | 'COMMERCIAL'>('RESIDENTIAL');
  const [preferredLocations, setPreferredLocations] = useState<string>('');
  const [propertyType, setPropertyType] = useState<string>('Apartment');
  const [bhk, setBhk] = useState<string>('2 BHK');
  const [budgetMin, setBudgetMin] = useState<string>('');
  const [budgetMax, setBudgetMax] = useState<string>('');
  const [areaMin, setAreaMin] = useState<string>('');
  const [areaMax, setAreaMax] = useState<string>('');
  const [furnishing, setFurnishing] = useState<string>('any');
  const [parkingRequired, setParkingRequired] = useState<string>('1 Covered');
  const [businessType, setBusinessType] = useState<string>('');
  const [leaseDuration, setLeaseDuration] = useState<string>('3 Years');
  const [possessionDate, setPossessionDate] = useState<string>('');
  const [requirementsText, setRequirementsText] = useState<string>('');
  const [priority, setPriority] = useState<string>('MEDIUM');

  const [loading, setLoading] = useState(false);
  const [submittedQuery, setSubmittedQuery] = useState<{ queryNumber: string; queryId: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentUser) {
      openAuthModal('login');
      showToast('Please log in or create a quick account to post your property requirement.');
      return;
    }

    if (!preferredLocations.trim()) {
      showToast('Please enter your preferred Mumbai location(s).');
      return;
    }

    setLoading(true);
    try {
      const res = await api.queries.create({
        transaction_type: transactionType,
        category,
        preferred_locations: preferredLocations,
        budget_min: budgetMin ? Number(budgetMin) : undefined,
        budget_max: budgetMax ? Number(budgetMax) : undefined,
        property_type: propertyType,
        bhk: category === 'RESIDENTIAL' ? bhk : undefined,
        area_min: areaMin ? Number(areaMin) : undefined,
        area_max: areaMax ? Number(areaMax) : undefined,
        furnishing,
        parking_required: parkingRequired,
        business_type: category === 'COMMERCIAL' ? businessType : undefined,
        lease_duration: transactionType !== 'BUY' ? leaseDuration : undefined,
        possession_date: possessionDate,
        requirements_text: requirementsText,
        priority
      });

      setSubmittedQuery({
        queryNumber: res.queryNumber,
        queryId: res.queryId
      });
      showToast(`Requirement successfully registered! Reference: ${res.queryNumber}`);
    } catch (err: any) {
      showToast(err.message || 'Error submitting requirement.');
    } finally {
      setLoading(false);
    }
  };

  if (submittedQuery) {
    return (
      <div className="max-w-3xl mx-auto py-16 px-4 sm:px-6">
        <div className="bg-white rounded-2xl border border-stone-200 p-8 sm:p-10 text-center space-y-6 shadow-sm">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <span className="text-xs font-mono uppercase tracking-wider text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
              Query Registered: {submittedQuery.queryNumber}
            </span>
            <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900">
              Your Requirement is Active
            </h1>
            <p className="text-sm text-stone-600 max-w-lg mx-auto">
              Our automated matching system is scanning approved Mumbai listings. Additionally, authorized brokers will source private off-market matches that match your criteria.
            </p>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200/80 text-xs text-left max-w-md mx-auto space-y-2">
            <div className="flex justify-between">
              <span className="text-stone-500">Query Reference:</span>
              <span className="font-mono font-bold text-stone-900">{submittedQuery.queryNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500">Requirement Type:</span>
              <span className="font-semibold text-stone-900">{transactionType} · {category}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500">Target Locality:</span>
              <span className="font-semibold text-stone-900">{preferredLocations}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500">Status:</span>
              <span className="font-bold text-emerald-700">ACTIVE / SCANNING</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
            <button
              type="button"
              onClick={() => navigate(`/dashboard/queries/${submittedQuery.queryId}`)}
              className="w-full sm:w-auto px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
            >
              View Matches in Query Dashboard
            </button>
            <button
              type="button"
              onClick={() => {
                setSubmittedQuery(null);
                setPreferredLocations('');
                setRequirementsText('');
              }}
              className="w-full sm:w-auto px-6 py-3 text-xs font-semibold uppercase tracking-wider text-stone-700 bg-white hover:bg-stone-50 border border-stone-200 rounded-lg transition-colors"
            >
              Submit Another Requirement
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-10 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Header */}
      <div className="space-y-3 text-center sm:text-left">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300">
          <Sparkles className="w-3.5 h-3.5 text-amber-700" />
          Query Mode · Mumbai Direct
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold font-serif text-stone-900 tracking-tight">
          Post Your Property Requirement
        </h1>
        <p className="text-sm text-stone-600 max-w-2xl">
          Can’t find the right property listed publicly? Post your exact requirement. Our platform connects you with direct verified listings and authorized brokers sourcing private, off-market Mumbai properties.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6 sm:p-8 space-y-8">
        
        {/* Transaction Type & Category */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">1</span>
            Transaction & Category
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Looking To *</label>
              <div className="grid grid-cols-3 gap-2">
                {(['BUY', 'RENT', 'LEASE'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTransactionType(t)}
                    className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                      transactionType === t
                        ? 'bg-stone-900 text-white border-stone-900'
                        : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Property Category *</label>
              <div className="grid grid-cols-2 gap-2">
                {(['RESIDENTIAL', 'COMMERCIAL'] as const).map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      setCategory(c);
                      setPropertyType(c === 'RESIDENTIAL' ? 'Apartment' : 'Office');
                    }}
                    className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                      category === c
                        ? 'bg-stone-900 text-white border-stone-900'
                        : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Location & Preferred Property Type */}
        <div className="space-y-4 pt-6 border-t border-stone-100">
          <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">2</span>
            Location & Configuration
          </h2>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Preferred Mumbai Localities * (e.g. Bandra West, Worli, BKC, Khar)
              </label>
              <input
                type="text"
                value={preferredLocations}
                onChange={(e) => setPreferredLocations(e.target.value)}
                placeholder="Enter areas, buildings, or landmark hubs..."
                required
                className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>

            {/* Quick area suggestions */}
            <div className="flex flex-wrap gap-1.5 items-center">
              <span className="text-[11px] text-stone-500 mr-1">Popular:</span>
              {POPULAR_MUMBAI_AREAS.slice(0, 6).map((area) => (
                <button
                  key={area}
                  type="button"
                  onClick={() => {
                    if (!preferredLocations.includes(area)) {
                      setPreferredLocations(preferredLocations ? `${preferredLocations}, ${area}` : area);
                    }
                  }}
                  className="text-[10px] px-2 py-0.5 rounded bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
                >
                  + {area}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Property Type</label>
              <select
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              >
                {category === 'RESIDENTIAL' ? (
                  <>
                    <option value="Apartment">Apartment</option>
                    <option value="Independent House">Independent House</option>
                    <option value="Villa">Villa</option>
                    <option value="Penthouse">Penthouse</option>
                    <option value="Plot">Plot</option>
                  </>
                ) : (
                  <>
                    <option value="Office">Office</option>
                    <option value="Shop">Shop</option>
                    <option value="Showroom">Showroom</option>
                    <option value="Warehouse">Warehouse</option>
                    <option value="Industrial">Industrial</option>
                    <option value="Commercial Land">Commercial Land</option>
                  </>
                )}
              </select>
            </div>

            {category === 'RESIDENTIAL' ? (
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">BHK Configuration</label>
                <select
                  value={bhk}
                  onChange={(e) => setBhk(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
                >
                  <option value="1 RK">1 RK</option>
                  <option value="1 BHK">1 BHK</option>
                  <option value="2 BHK">2 BHK</option>
                  <option value="3 BHK">3 BHK</option>
                  <option value="4+ BHK">4+ BHK</option>
                </select>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">Business / Industry Type</label>
                <input
                  type="text"
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value)}
                  placeholder="e.g. BFSI, Clinic, Tech HQ, Retail"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Furnishing Preference</label>
              <select
                value={furnishing}
                onChange={(e) => setFurnishing(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              >
                <option value="any">Any Furnishing</option>
                <option value="unfurnished">Unfurnished</option>
                <option value="semi-furnished">Semi-Furnished</option>
                <option value="fully-furnished">Fully-Furnished</option>
              </select>
            </div>
          </div>
        </div>

        {/* Budget & Area Specifications */}
        <div className="space-y-4 pt-6 border-t border-stone-100">
          <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">3</span>
            Budget & Area Range
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Budget Min (₹ INR) {transactionType === 'BUY' ? 'e.g. 15000000 (1.5 Cr)' : 'Monthly Rent'}
              </label>
              <input
                type="number"
                value={budgetMin}
                onChange={(e) => setBudgetMin(e.target.value)}
                placeholder="Min budget in Rupees"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Budget Max (₹ INR) {transactionType === 'BUY' ? 'e.g. 25000000 (2.5 Cr)' : 'Monthly Rent'}
              </label>
              <input
                type="number"
                value={budgetMax}
                onChange={(e) => setBudgetMax(e.target.value)}
                placeholder="Max budget in Rupees"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Min Carpet Area (sq.ft)</label>
              <input
                type="number"
                value={areaMin}
                onChange={(e) => setAreaMin(e.target.value)}
                placeholder="e.g. 750"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Max Carpet Area (sq.ft)</label>
              <input
                type="number"
                value={areaMax}
                onChange={(e) => setAreaMax(e.target.value)}
                placeholder="e.g. 1400"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>
          </div>
        </div>

        {/* Requirements Narrative & Priority */}
        <div className="space-y-4 pt-6 border-t border-stone-100">
          <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">4</span>
            Specific Requirements & Timing
          </h2>

          <div>
            <label className="block text-xs font-medium text-stone-700 mb-1">
              Detailed Notes / Special Preferences (Floor preference, Vastu, Gated society, Sea-view, etc.)
            </label>
            <textarea
              rows={3}
              value={requirementsText}
              onChange={(e) => setRequirementsText(e.target.value)}
              placeholder="Provide any specific preferences to help match the ideal property..."
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Urgency / Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              >
                <option value="LOW">Flexible Timeline (3+ months)</option>
                <option value="MEDIUM">Standard (1-2 months)</option>
                <option value="HIGH">Immediate / Urgent (within 30 days)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Car Parking Requirement</label>
              <select
                value={parkingRequired}
                onChange={(e) => setParkingRequired(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              >
                <option value="Not Required">Not Required</option>
                <option value="1 Covered">1 Covered Car Park</option>
                <option value="2 Covered">2+ Covered Car Parks</option>
                <option value="Open Parking">Open Parking Sufficient</option>
              </select>
            </div>
          </div>
        </div>

        {/* Trust Notice */}
        <div className="p-4 bg-amber-50/60 rounded-xl border border-amber-200/80 flex items-start gap-3 text-xs text-amber-900">
          <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-semibold">Direct & Masked Connection</p>
            <p className="text-amber-800 text-[11px] leading-relaxed">
              Your contact details are protected under P2P Property’s DPDP-compliant governance. Private off-market property candidates are curated by authorized brokers and shared through your secure Query Dashboard.
            </p>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-6 text-xs font-bold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 disabled:opacity-50 rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>{loading ? 'Submitting Requirement...' : 'Register Requirement & Activate Search'}</span>
          </button>
        </div>

      </form>
    </div>
  );
};
