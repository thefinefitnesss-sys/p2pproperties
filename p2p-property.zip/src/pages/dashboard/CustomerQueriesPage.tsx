import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Search, 
  PlusCircle, 
  MapPin, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  Eye, 
  FileText, 
  Briefcase, 
  Building2,
  Filter,
  ArrowRight,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';
import { formatPriceINR } from '../../utils/formatters';

export const CustomerQueriesPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, showToast } = useProperty();

  const [queries, setQueries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [search, setSearch] = useState<string>('');

  const loadQueries = async () => {
    setLoading(true);
    try {
      const res = await api.queries.list({
        status: filterStatus === 'ALL' ? undefined : filterStatus,
        search: search ? search : undefined
      });
      setQueries(res.queries || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading property requirements.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQueries();
  }, [filterStatus]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadQueries();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'NEW':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800 border border-blue-200">New Requirement</span>;
      case 'IN_PROGRESS':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-200">Matching in Progress</span>;
      case 'MATCHED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200">Matches Available</span>;
      case 'SITE_VISIT':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800 border border-purple-200">Site Visit Scheduled</span>;
      case 'FULFILLED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-900 border border-emerald-300">Fulfilled</span>;
      case 'CLOSED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-stone-100 text-stone-700 border border-stone-200">Closed</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-stone-100 text-stone-700">{status}</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-6">
      
      {/* Header Banner */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-5 shadow-sm border border-stone-800">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-400/10 text-amber-400 border border-amber-400/20">
              <Sparkles className="w-3 h-3 text-amber-400" />
              Query Mode & Matching Desk
            </span>
            <span className="text-[11px] text-stone-400 font-mono">Mumbai Direct</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-white tracking-tight">
            {currentUser?.role === 'agent' ? 'Assigned Property Requirements' : 'My Property Requirements'}
          </h1>
          <p className="text-xs text-stone-400 max-w-xl">
            Track submitted property requirements, active matching status against verified listings, and curated private off-market property candidates.
          </p>
        </div>

        <Link
          to="/post-requirement"
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold uppercase tracking-wider text-stone-950 bg-amber-400 hover:bg-amber-300 transition-colors shadow-xs shrink-0"
        >
          <PlusCircle className="w-4 h-4 text-stone-950" />
          <span>Post New Requirement</span>
        </Link>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-stone-200 shadow-2xs">
        <form onSubmit={handleSearch} className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Query ID (P2P-Q-...), location, or notes..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
          />
        </form>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-stone-500 font-medium">Status:</span>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
          >
            <option value="ALL">All Statuses</option>
            <option value="NEW">New</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="MATCHED">Matched</option>
            <option value="SITE_VISIT">Site Visit</option>
            <option value="FULFILLED">Fulfilled</option>
            <option value="CLOSED">Closed</option>
          </select>
        </div>
      </div>

      {/* Queries List */}
      {loading ? (
        <div className="py-20 text-center text-xs text-stone-500">
          Loading requirements and active matches...
        </div>
      ) : queries.length === 0 ? (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center space-y-4">
          <Building2 className="w-12 h-12 text-stone-300 mx-auto" />
          <div className="space-y-1">
            <h3 className="text-base font-bold text-stone-900 font-serif">No Requirements Found</h3>
            <p className="text-xs text-stone-500 max-w-md mx-auto">
              You haven't posted any custom property requirements yet. Submit what you are looking for to trigger automated and off-market broker matching.
            </p>
          </div>
          <Link
            to="/post-requirement"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Post Your Requirement</span>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {queries.map((q) => (
            <div
              key={q.id}
              className="bg-white rounded-xl border border-stone-200 p-5 hover:border-stone-300 transition-all shadow-2xs space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-stone-100">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs font-bold text-stone-900 px-2.5 py-1 bg-stone-100 rounded-md border border-stone-200">
                    {q.queryNumber}
                  </span>
                  {getStatusBadge(q.status)}
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-stone-600 bg-stone-50 px-2 py-0.5 rounded">
                    {q.transactionType} · {q.category}
                  </span>
                </div>
                
                <span className="text-[11px] text-stone-400">
                  Posted on {new Date(q.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                <div>
                  <span className="text-stone-400 block text-[10px] uppercase font-semibold">Preferred Locations</span>
                  <p className="font-semibold text-stone-900 mt-0.5">{q.preferredLocations || 'Mumbai General'}</p>
                </div>

                <div>
                  <span className="text-stone-400 block text-[10px] uppercase font-semibold">Target Configuration</span>
                  <p className="font-semibold text-stone-900 mt-0.5">
                    {q.bhk ? `${q.bhk} ${q.propertyType}` : q.propertyType}
                    {q.areaMin || q.areaMax ? ` (${q.areaMin || ''}-${q.areaMax || ''} sq.ft)` : ''}
                  </p>
                </div>

                <div>
                  <span className="text-stone-400 block text-[10px] uppercase font-semibold">Budget Range</span>
                  <p className="font-semibold text-stone-900 mt-0.5">
                    {q.budgetMin ? formatPriceINR(q.budgetMin) : 'Any'} – {q.budgetMax ? formatPriceINR(q.budgetMax) : 'Open'}
                  </p>
                </div>

                <div>
                  <span className="text-stone-400 block text-[10px] uppercase font-semibold">Off-Market Matches</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className={`font-bold ${q.offMarketMatchCount > 0 ? 'text-amber-700' : 'text-stone-500'}`}>
                      {q.offMarketMatchCount} Candidate{q.offMarketMatchCount === 1 ? '' : 's'}
                    </span>
                    {q.offMarketMatchCount > 0 && (
                      <span className="text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.2 rounded font-semibold">
                        Private
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {q.requirementsText && (
                <p className="text-xs text-stone-600 bg-stone-50 p-3 rounded-lg border border-stone-100 italic">
                  "{q.requirementsText}"
                </p>
              )}

              <div className="flex items-center justify-between pt-2">
                <div className="text-[11px] text-stone-500">
                  {q.assignedAgentName ? (
                    <span>Assigned Broker: <strong className="text-stone-800">{q.assignedAgentName}</strong></span>
                  ) : (
                    <span className="text-amber-700 font-medium">Awaiting broker allocation</span>
                  )}
                </div>

                <Link
                  to={`/dashboard/queries/${q.id}`}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-md transition-colors"
                >
                  <span>Open Matches & Timeline</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
};
