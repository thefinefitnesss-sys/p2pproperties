import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Briefcase, 
  ArrowLeft, 
  Building2, 
  Users, 
  IndianRupee, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  FileText, 
  CreditCard, 
  Plus, 
  Printer, 
  Edit3, 
  ChevronRight,
  TrendingUp,
  FileCheck2,
  X,
  ExternalLink,
  ShieldCheck,
  Send
} from 'lucide-react';
import { api } from '../../services/api';
import { usePropertyContext } from '../../context/PropertyContext';
import { Deal, DealStatus, CommissionStatus, PaymentMethod, DealInvoice } from '../../types/deal';
import { formatCurrency } from '../../utils/formatters';
import { InvoiceModal } from '../../components/deals/InvoiceModal';

export const DealDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { currentUser, showToast } = usePropertyContext();
  const navigate = useNavigate();

  const [deal, setDeal] = useState<Deal | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Selected invoice for preview modal
  const [activeInvoice, setActiveInvoice] = useState<DealInvoice | null>(null);
  const [invoiceModalOpen, setInvoiceModalOpen] = useState(false);

  // Modals state
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [newDealStatus, setNewDealStatus] = useState<DealStatus>('NEGOTIATION');

  const [commissionModalOpen, setCommissionModalOpen] = useState(false);
  const [commissionType, setCommissionType] = useState<'PERCENTAGE' | 'FIXED_AMOUNT'>('PERCENTAGE');
  const [commissionRate, setCommissionRate] = useState<number>(1.0);
  const [commissionAmount, setCommissionAmount] = useState<number>(0);
  const [commissionPayer, setCommissionPayer] = useState<string>('BUYER');
  const [commissionStatus, setCommissionStatus] = useState<CommissionStatus>('AGREED');

  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [payerName, setPayerName] = useState<string>('');
  const [paymentNotes, setPaymentNotes] = useState<string>('');

  const [generateInvoiceModalOpen, setGenerateInvoiceModalOpen] = useState(false);
  const [invoiceIssueDate, setInvoiceIssueDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [invoiceDueDate, setInvoiceDueDate] = useState<string>(
    new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [invoiceSubtotal, setInvoiceSubtotal] = useState<string>('');
  const [invoiceNotes, setInvoiceNotes] = useState<string>('');

  const [newNote, setNewNote] = useState('');
  const [savingNote, setSavingNote] = useState(false);

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    if (id) {
      loadDeal(id);
    }
  }, [id, currentUser]);

  const loadDeal = async (dealId: string) => {
    setLoading(true);
    setError('');
    try {
      const res = await api.deals.get(dealId);
      setDeal(res.deal);
      setNewDealStatus(res.deal.dealStatus);
      setCommissionType(res.deal.commissionType || 'PERCENTAGE');
      setCommissionRate(res.deal.commissionRate || 1.0);
      setCommissionAmount(res.deal.commissionAmount || 0);
      setCommissionPayer(res.deal.commissionPayer || 'BUYER');
      setCommissionStatus(res.deal.commissionStatus || 'AGREED');
      setPayerName(res.deal.customer?.name || '');
      setInvoiceSubtotal(String(res.deal.commissionAmount || 0));
    } catch (err: any) {
      setError(err.message || 'Error loading deal workspace.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (statusToSet: DealStatus) => {
    if (!deal) return;
    try {
      await api.deals.update(deal.id, { deal_status: statusToSet });
      showToast(`Deal stage updated to ${statusToSet}`);
      loadDeal(deal.id);
      setStatusModalOpen(false);
    } catch (err: any) {
      showToast(err.message || 'Error updating deal stage.');
    }
  };

  const handleUpdateCommission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deal) return;
    try {
      await api.deals.updateCommission(deal.id, {
        commission_type: commissionType,
        commission_rate: commissionType === 'PERCENTAGE' ? Number(commissionRate) : undefined,
        commission_amount: commissionType === 'FIXED_AMOUNT' ? Number(commissionAmount) : undefined,
        commission_payer: commissionPayer,
        commission_status: commissionStatus
      });
      showToast('Commission agreement updated successfully.');
      loadDeal(deal.id);
      setCommissionModalOpen(false);
    } catch (err: any) {
      showToast(err.message || 'Error updating commission.');
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deal) return;
    const amountNum = Number(paymentAmount);
    if (!amountNum || amountNum <= 0) {
      showToast('Please enter a valid payment amount.');
      return;
    }

    try {
      await api.deals.recordPayment(deal.id, {
        amount: amountNum,
        payment_method: paymentMethod,
        transaction_reference: transactionRef,
        payment_date: paymentDate,
        payer_name: payerName,
        notes: paymentNotes
      });
      showToast(`Payment of ${formatCurrency(amountNum)} recorded successfully.`);
      loadDeal(deal.id);
      setPaymentModalOpen(false);
      setPaymentAmount('');
      setTransactionRef('');
      setPaymentNotes('');
    } catch (err: any) {
      showToast(err.message || 'Error recording payment.');
    }
  };

  const handleGenerateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deal) return;
    try {
      const res = await api.deals.generateInvoice(deal.id, {
        issue_date: invoiceIssueDate,
        due_date: invoiceDueDate,
        subtotal: invoiceSubtotal ? Number(invoiceSubtotal) : undefined,
        gst_rate: 18,
        notes: invoiceNotes
      });
      showToast(`Invoice ${res.invoice.invoiceNumber} generated.`);
      loadDeal(deal.id);
      setGenerateInvoiceModalOpen(false);
      // Open preview modal
      setActiveInvoice(res.invoice);
      setInvoiceModalOpen(true);
    } catch (err: any) {
      showToast(err.message || 'Error generating invoice.');
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deal || !newNote.trim()) return;
    setSavingNote(true);
    try {
      await api.deals.addNote(deal.id, newNote);
      showToast('Note added to deal history.');
      setNewNote('');
      loadDeal(deal.id);
    } catch (err: any) {
      showToast(err.message || 'Error adding note.');
    } finally {
      setSavingNote(false);
    }
  };

  // Base value for commission calculations
  const dealBaseValue = deal 
    ? (deal.agreedPropertyValue || deal.agreedRent || deal.agreedLeaseValue || 0)
    : 0;

  const previewCommission = commissionType === 'PERCENTAGE'
    ? (dealBaseValue * (Number(commissionRate) || 0)) / 100
    : (Number(commissionAmount) || 0);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto py-12 px-4 text-center text-xs text-stone-500">
        Loading transaction deal records and ledger...
      </div>
    );
  }

  if (error || !deal) {
    return (
      <div className="max-w-3xl mx-auto py-12 px-4 text-center space-y-4">
        <AlertCircle className="w-10 h-10 text-rose-500 mx-auto" />
        <h2 className="text-xl font-bold text-stone-900">Deal Not Found or Access Denied</h2>
        <p className="text-xs text-stone-600">{error || 'You do not have authorization to view this deal.'}</p>
        <Link 
          to="/dashboard/deals"
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-md"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Deals Pipeline</span>
        </Link>
      </div>
    );
  }

  const paidAmount = deal.paidAmount || 0;
  const remainingAmount = deal.remainingAmount !== undefined ? deal.remainingAmount : Math.max(0, deal.commissionAmount - paidAmount);
  const paymentPercentage = deal.commissionAmount > 0 
    ? Math.min(100, Math.round((paidAmount / deal.commissionAmount) * 100))
    : 0;

  return (
    <div className="max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8 space-y-6 min-h-screen">
      
      {/* Breadcrumb Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-stone-500 border-b border-stone-200 pb-3">
        <div className="flex items-center gap-2">
          <Link to="/dashboard" className="hover:text-stone-900">Dashboard</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link to="/dashboard/deals" className="hover:text-stone-900">Deals Pipeline</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-stone-900 font-semibold font-mono">{deal.dealNumber}</span>
        </div>

        <div className="flex items-center gap-3">
          {deal.leadId && (
            <Link 
              to={`/dashboard/leads/${deal.leadId}`}
              className="inline-flex items-center gap-1 text-amber-700 hover:text-amber-800 font-semibold"
            >
              <Users className="w-3.5 h-3.5" />
              <span>View Source Lead</span>
            </Link>
          )}

          <Link 
            to="/dashboard/deals"
            className="inline-flex items-center gap-1 hover:text-stone-900 font-medium"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Deals</span>
          </Link>
        </div>
      </div>

      {/* Hero Deal Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                {deal.dealNumber}
              </span>
              <span className="text-stone-300">·</span>
              <span className="text-[10px] font-mono uppercase bg-stone-100 text-stone-700 px-2 py-0.5 rounded font-bold">
                {deal.transactionType} ({deal.category})
              </span>
              <span className="text-stone-300">·</span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                deal.commissionStatus === 'PAID' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                deal.commissionStatus === 'PARTIALLY_PAID' ? 'bg-blue-100 text-blue-800 border border-blue-200' :
                deal.commissionStatus === 'INVOICED' ? 'bg-purple-100 text-purple-800 border border-purple-200' :
                deal.commissionStatus === 'AGREED' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                'bg-stone-100 text-stone-700'
              }`}>
                Brokerage: {deal.commissionStatus}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900">
              {deal.property?.title || 'Transaction Deal Workspace'}
            </h1>
            <p className="text-xs text-stone-500">
              Customer: <span className="font-semibold text-stone-900">{deal.customer?.name}</span> · Location: <span className="font-semibold text-stone-900">{deal.property?.locality}</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold font-mono uppercase bg-stone-900 text-white shadow-2xs">
              Stage: {deal.dealStatus}
            </span>

            <button
              onClick={() => setStatusModalOpen(true)}
              className="px-3 py-1.5 border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-50 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Change Stage</span>
            </button>
          </div>
        </div>

        {/* Quick Progression Bar */}
        <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider mr-1">Direct Progression:</span>
          
          <button
            type="button"
            onClick={() => handleUpdateStatus('AGREED')}
            className={`px-3 py-1 rounded-lg border font-semibold transition-colors cursor-pointer ${
              deal.dealStatus === 'AGREED' ? 'bg-blue-600 text-white border-blue-600' : 'border-stone-200 hover:bg-stone-50'
            }`}
          >
            Mark Agreed
          </button>

          <button
            type="button"
            onClick={() => handleUpdateStatus('AGREEMENT_SIGNED')}
            className={`px-3 py-1 rounded-lg border font-semibold transition-colors cursor-pointer ${
              deal.dealStatus === 'AGREEMENT_SIGNED' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-stone-200 hover:bg-stone-50'
            }`}
          >
            Agreement Signed
          </button>

          <button
            type="button"
            onClick={() => handleUpdateStatus('PAYMENT_PENDING')}
            className={`px-3 py-1 rounded-lg border font-semibold transition-colors cursor-pointer ${
              deal.dealStatus === 'PAYMENT_PENDING' ? 'bg-orange-600 text-white border-orange-600' : 'border-stone-200 hover:bg-stone-50'
            }`}
          >
            Payment Pending
          </button>

          <button
            type="button"
            onClick={() => handleUpdateStatus('COMPLETED')}
            className="px-3.5 py-1 rounded-lg font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Mark Won & Closed</span>
          </button>

          <button
            type="button"
            onClick={() => handleUpdateStatus('CANCELLED')}
            className="px-3 py-1 rounded-lg border border-rose-200 text-rose-700 hover:bg-rose-50 font-semibold transition-colors ml-auto cursor-pointer"
          >
            Cancel Deal
          </button>
        </div>
      </div>

      {/* Main Grid: Left Financials & Ledger; Right Property & Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 Cols wide on desktop) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* 1. Transaction Overview & Agreed Values */}
          <div className="bg-white rounded-xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-stone-700" />
                <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                  Transaction Valuation & Terms
                </h3>
              </div>
              <span className="text-xs px-2.5 py-0.5 rounded bg-stone-100 font-mono font-bold text-stone-800">
                {deal.transactionType}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/60">
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Agreed Property Value</span>
                <span className="text-base font-bold font-mono text-stone-900 mt-1 block">
                  {formatCurrency(deal.agreedPropertyValue || deal.agreedRent || deal.agreedLeaseValue || 0)}
                </span>
                <span className="text-[10px] text-stone-500">
                  {deal.transactionType === 'RENT' ? 'Monthly rental consideration' : 'Total deal consideration'}
                </span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/60">
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Expected Closing</span>
                <span className="text-sm font-bold font-mono text-stone-900 mt-1 block">
                  {deal.expectedClosingDate || 'Not specified'}
                </span>
                <span className="text-[10px] text-stone-500">Target registration date</span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/60">
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Actual Closing</span>
                <span className="text-sm font-bold font-mono text-stone-900 mt-1 block">
                  {deal.actualClosingDate || 'Pending execution'}
                </span>
                <span className="text-[10px] text-stone-500">Execution / Handover</span>
              </div>
            </div>

            {deal.notes && (
              <div className="p-3 bg-stone-50/60 rounded-xl text-xs text-stone-700 border border-stone-200/60">
                <span className="text-[10px] font-bold uppercase text-stone-400 block mb-1">Deal Terms & Notes</span>
                <p className="whitespace-pre-line">{deal.notes}</p>
              </div>
            )}
          </div>

          {/* 2. Brokerage & Commission Management Engine */}
          <div className="bg-white rounded-xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-5">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <IndianRupee className="w-4 h-4 text-amber-600" />
                <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                  Brokerage & Commission Management
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setCommissionModalOpen(true)}
                className="px-3 py-1 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Adjust Commission</span>
              </button>
            </div>

            {/* Commission Numbers */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
              <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-200/60">
                <span className="text-[10px] font-bold uppercase text-amber-800 block">Total Brokerage</span>
                <span className="text-lg font-bold font-mono text-amber-950 mt-1 block">
                  {formatCurrency(deal.commissionAmount)}
                </span>
                <span className="text-[10px] text-amber-700">
                  {deal.commissionType === 'PERCENTAGE' ? `${deal.commissionRate}% of base` : 'Fixed amount'}
                </span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/60">
                <span className="text-[10px] font-bold uppercase text-stone-500 block">Commission Payer</span>
                <span className="text-sm font-bold text-stone-900 mt-1 block">
                  {deal.commissionPayer}
                </span>
                <span className="text-[10px] text-stone-500">Designated liable party</span>
              </div>

              <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-200/60">
                <span className="text-[10px] font-bold uppercase text-emerald-800 block">Amount Collected</span>
                <span className="text-base font-bold font-mono text-emerald-700 mt-1 block">
                  {formatCurrency(paidAmount)}
                </span>
                <span className="text-[10px] text-emerald-700">{paymentPercentage}% settled</span>
              </div>

              <div className="p-3 bg-rose-50/50 rounded-xl border border-rose-200/60">
                <span className="text-[10px] font-bold uppercase text-rose-800 block">Balance Due</span>
                <span className="text-base font-bold font-mono text-rose-700 mt-1 block">
                  {formatCurrency(remainingAmount)}
                </span>
                <span className="text-[10px] text-rose-700">Outstanding fee</span>
              </div>
            </div>

            {/* Payment Progress Bar */}
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-xs font-semibold text-stone-600">
                <span>Fee Collection Progress</span>
                <span className="font-mono">{paymentPercentage}%</span>
              </div>
              <div className="w-full h-2.5 bg-stone-100 rounded-full overflow-hidden border border-stone-200/60">
                <div 
                  className="h-full bg-emerald-500 transition-all duration-500" 
                  style={{ width: `${paymentPercentage}%` }}
                />
              </div>
            </div>
          </div>

          {/* 3. Invoices & Receipts Section */}
          <div className="bg-white rounded-xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-purple-600" />
                <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                  Tax Invoices & Billing
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setGenerateInvoiceModalOpen(true)}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Generate Invoice</span>
              </button>
            </div>

            {deal.invoices && deal.invoices.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 text-stone-500 uppercase font-mono text-[10px] border-b border-stone-200">
                    <tr>
                      <th className="py-2.5 px-3">Invoice Number</th>
                      <th className="py-2.5 px-3">Issue Date</th>
                      <th className="py-2.5 px-3">Due Date</th>
                      <th className="py-2.5 px-3 text-right">Subtotal</th>
                      <th className="py-2.5 px-3 text-right">GST (18%)</th>
                      <th className="py-2.5 px-3 text-right">Total Payable</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                      <th className="py-2.5 px-3 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {deal.invoices.map(inv => (
                      <tr key={inv.id} className="hover:bg-stone-50/50">
                        <td className="py-3 px-3 font-mono font-bold text-stone-900">
                          {inv.invoiceNumber}
                        </td>
                        <td className="py-3 px-3 font-mono text-stone-600">{inv.issueDate}</td>
                        <td className="py-3 px-3 font-mono text-stone-600">{inv.dueDate}</td>
                        <td className="py-3 px-3 text-right font-mono">{formatCurrency(inv.subtotal)}</td>
                        <td className="py-3 px-3 text-right font-mono text-stone-600">{formatCurrency(inv.gstAmount)}</td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-stone-900">
                          {formatCurrency(inv.totalAmount)}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                            inv.status === 'PAID' ? 'bg-emerald-100 text-emerald-800' : 'bg-purple-100 text-purple-800'
                          }`}>
                            {inv.status}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center">
                          <button
                            onClick={() => {
                              setActiveInvoice(inv);
                              setInvoiceModalOpen(true);
                            }}
                            className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded text-xs font-semibold flex items-center gap-1 mx-auto cursor-pointer"
                          >
                            <Printer className="w-3 h-3" />
                            <span>Print / View</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-6 border border-dashed border-stone-200 rounded-xl text-stone-500 space-y-2">
                <FileText className="w-6 h-6 mx-auto text-stone-300" />
                <p className="text-xs">No invoices generated yet for this deal.</p>
                <button
                  onClick={() => setGenerateInvoiceModalOpen(true)}
                  className="text-xs text-purple-700 hover:underline font-semibold cursor-pointer"
                >
                  Generate Tax Invoice for ₹{deal.commissionAmount.toLocaleString('en-IN')}
                </button>
              </div>
            )}
          </div>

          {/* 4. Payment Ledger & Receipts */}
          <div className="bg-white rounded-xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                  Payments & Receipts Ledger
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setPaymentModalOpen(true)}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Record Payment</span>
              </button>
            </div>

            {deal.payments && deal.payments.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 text-stone-500 uppercase font-mono text-[10px] border-b border-stone-200">
                    <tr>
                      <th className="py-2.5 px-3">Receipt No</th>
                      <th className="py-2.5 px-3">Date</th>
                      <th className="py-2.5 px-3">Method</th>
                      <th className="py-2.5 px-3">Reference / UTR</th>
                      <th className="py-2.5 px-3">Payer</th>
                      <th className="py-2.5 px-3 text-right">Amount Received</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {deal.payments.map(pay => (
                      <tr key={pay.id} className="hover:bg-stone-50/50">
                        <td className="py-3 px-3 font-mono font-bold text-stone-900">
                          {pay.receiptNumber}
                        </td>
                        <td className="py-3 px-3 font-mono text-stone-600">{pay.paymentDate}</td>
                        <td className="py-3 px-3 font-mono uppercase text-stone-700">
                          {pay.paymentMethod}
                        </td>
                        <td className="py-3 px-3 font-mono text-stone-600">
                          {pay.transactionReference || 'N/A'}
                        </td>
                        <td className="py-3 px-3 text-stone-800">{pay.payerName || 'N/A'}</td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-emerald-700">
                          {formatCurrency(pay.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-6 border border-dashed border-stone-200 rounded-xl text-stone-500 space-y-2">
                <CreditCard className="w-6 h-6 mx-auto text-stone-300" />
                <p className="text-xs">No payments recorded yet for this transaction.</p>
                <button
                  onClick={() => setPaymentModalOpen(true)}
                  className="text-xs text-emerald-700 hover:underline font-semibold cursor-pointer"
                >
                  Record first installment or full settlement
                </button>
              </div>
            )}
          </div>

        </div>

        {/* Right Column: Cards & Timeline */}
        <div className="space-y-6">
          
          {/* Property Summary Card */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5" />
                <span>Property Details</span>
              </span>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-stone-100 text-stone-700">
                {deal.property?.category}
              </span>
            </div>

            {deal.property && (
              <div className="space-y-2 text-xs">
                <h4 className="font-bold text-stone-900 line-clamp-2">
                  {deal.property.title}
                </h4>
                <p className="text-stone-500">
                  {deal.property.locality}, {deal.property.city}
                </p>

                <div className="flex justify-between py-1 border-t border-stone-100 text-stone-600">
                  <span>Listing Price</span>
                  <span className="font-mono font-bold text-stone-900">
                    {formatCurrency(deal.property.price || deal.property.monthly_rent || 0)}
                  </span>
                </div>

                <Link
                  to={`/properties/${deal.property.id}`}
                  target="_blank"
                  className="inline-flex items-center gap-1 text-xs text-amber-700 hover:text-amber-800 font-semibold pt-1"
                >
                  <span>Open Public Property Page</span>
                  <ExternalLink className="w-3 h-3" />
                </Link>
              </div>
            )}
          </div>

          {/* Customer / Client Card */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                <span>Client Information</span>
              </span>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-stone-100 text-stone-700 font-bold">
                {deal.customer?.customerType}
              </span>
            </div>

            {deal.customer && (
              <div className="space-y-2 text-xs">
                <div className="font-bold text-stone-900 text-sm">
                  {deal.customer.name}
                </div>
                <div className="text-stone-600">
                  Mobile: <span className="font-mono font-semibold">{deal.customer.mobile}</span>
                </div>
                <div className="text-stone-600">
                  Email: <span>{deal.customer.email}</span>
                </div>

                {deal.leadId && (
                  <Link
                    to={`/dashboard/leads/${deal.leadId}`}
                    className="inline-flex items-center gap-1 text-xs text-amber-700 hover:text-amber-800 font-semibold pt-1"
                  >
                    <span>View Customer's Lead Dossier</span>
                    <ArrowLeft className="w-3 h-3 rotate-180" />
                  </Link>
                )}
              </div>
            )}
          </div>

          {/* Owner & Assigned Broker Card */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-2xs space-y-3 text-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 block border-b border-stone-100 pb-2">
              Stakeholders & Facilitation
            </span>

            <div>
              <span className="text-[10px] uppercase font-bold text-stone-400 block">Property Owner / Landlord</span>
              <p className="font-bold text-stone-900">{deal.owner?.name}</p>
              <p className="text-stone-500">{deal.owner?.email}</p>
            </div>

            <div className="pt-2 border-t border-stone-100">
              <span className="text-[10px] uppercase font-bold text-stone-400 block">Assigned Broker / Agent</span>
              <p className="font-bold text-stone-900">{deal.assignedAgent?.name || 'Direct Owner Deal (Self-Facilitated)'}</p>
              {deal.assignedAgent?.email && <p className="text-stone-500">{deal.assignedAgent?.email}</p>}
            </div>
          </div>

          {/* Deal Activity History Timeline */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-2xs space-y-4">
            <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 block border-b border-stone-100 pb-2">
              Deal Activity Audit Trail
            </span>

            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {deal.activities && deal.activities.length > 0 ? (
                deal.activities.map(act => (
                  <div key={act.id} className="text-xs border-l-2 border-amber-400 pl-3 py-1 space-y-0.5">
                    <div className="flex items-center justify-between text-[10px] text-stone-400">
                      <span className="font-bold text-stone-700 font-mono">{act.action.replace('_', ' ')}</span>
                      <span>{new Date(act.createdAt).toLocaleDateString('en-IN')}</span>
                    </div>
                    <p className="text-stone-700 text-[11px] leading-relaxed">{act.details}</p>
                    <span className="text-[10px] text-stone-400">
                      By {act.performedByName || 'User'} ({act.performedByRole || 'Agent'})
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-xs text-stone-400 italic">No timeline entries yet.</div>
              )}
            </div>
          </div>

          {/* Add Internal Note */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-2xs space-y-3">
            <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 block border-b border-stone-100 pb-2">
              Add Deal Note
            </span>
            <form onSubmit={handleAddNote} className="space-y-2">
              <textarea
                rows={3}
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Log internal note, draft progress, legal remarks..."
                className="w-full p-2 border border-stone-200 rounded-lg text-xs focus:outline-hidden focus:ring-1 focus:ring-amber-500"
              />
              <button
                type="submit"
                disabled={savingNote || !newNote.trim()}
                className="w-full py-1.5 bg-stone-900 hover:bg-stone-800 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3 h-3" />
                <span>Save Note</span>
              </button>
            </form>
          </div>

        </div>

      </div>

      {/* MODAL 1: Change Deal Stage */}
      {statusModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Update Deal Stage</h3>
              <button onClick={() => setStatusModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-stone-600">Select the current progression stage for this transaction:</p>
              <select
                value={newDealStatus}
                onChange={(e: any) => setNewDealStatus(e.target.value)}
                className="w-full p-2 border border-stone-200 rounded-lg bg-stone-50 font-medium"
              >
                <option value="NEGOTIATION">NEGOTIATION — Parties actively negotiating terms</option>
                <option value="AGREED">AGREED — Terms agreed, preparing documentation</option>
                <option value="AGREEMENT_PENDING">AGREEMENT_PENDING — Agreement being drafted / reviewed</option>
                <option value="AGREEMENT_SIGNED">AGREEMENT_SIGNED — Execution & Registration complete</option>
                <option value="PAYMENT_PENDING">PAYMENT_PENDING — Token / Brokerage payment pending</option>
                <option value="COMPLETED">COMPLETED — Fully executed & all consideration paid</option>
                <option value="CANCELLED">CANCELLED — Transaction called off</option>
                <option value="FAILED">FAILED — Failed due to loan / title rejection</option>
              </select>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setStatusModalOpen(false)} className="px-3 py-1.5 border border-stone-200 rounded-lg">
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleUpdateStatus(newDealStatus)}
                  className="px-4 py-1.5 bg-stone-900 text-white rounded-lg font-semibold cursor-pointer"
                >
                  Save Stage
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Adjust Commission & Brokerage Rate */}
      {commissionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Adjust Commission & Brokerage</h3>
              <button onClick={() => setCommissionModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateCommission} className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-700 font-medium mb-1">Commission Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCommissionType('PERCENTAGE')}
                    className={`p-2 border rounded-lg font-semibold text-center ${
                      commissionType === 'PERCENTAGE' ? 'border-amber-500 bg-amber-50 text-amber-900' : 'border-stone-200'
                    }`}
                  >
                    Percentage (%)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCommissionType('FIXED_AMOUNT')}
                    className={`p-2 border rounded-lg font-semibold text-center ${
                      commissionType === 'FIXED_AMOUNT' ? 'border-amber-500 bg-amber-50 text-amber-900' : 'border-stone-200'
                    }`}
                  >
                    Fixed Amount (₹)
                  </button>
                </div>
              </div>

              {commissionType === 'PERCENTAGE' ? (
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Commission Rate (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="10"
                    value={commissionRate}
                    onChange={(e) => setCommissionRate(parseFloat(e.target.value) || 0)}
                    className="w-full p-2 border border-stone-200 rounded-lg font-mono"
                  />
                  <span className="text-[11px] text-stone-500 mt-1 block">
                    Calculated on base ₹{dealBaseValue.toLocaleString('en-IN')}: <span className="font-bold font-mono text-amber-700">{formatCurrency(previewCommission)}</span>
                  </span>
                </div>
              ) : (
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Fixed Amount (₹)</label>
                  <input
                    type="number"
                    min="0"
                    value={commissionAmount}
                    onChange={(e) => setCommissionAmount(parseFloat(e.target.value) || 0)}
                    className="w-full p-2 border border-stone-200 rounded-lg font-mono"
                  />
                </div>
              )}

              <div>
                <label className="block text-stone-700 font-medium mb-1">Commission Payer</label>
                <select
                  value={commissionPayer}
                  onChange={(e) => setCommissionPayer(e.target.value)}
                  className="w-full p-2 border border-stone-200 rounded-lg bg-stone-50"
                >
                  <option value="BUYER">BUYER</option>
                  <option value="TENANT">TENANT</option>
                  <option value="OWNER">OWNER</option>
                  <option value="LANDLORD">LANDLORD</option>
                  <option value="BOTH_PARTIES">BOTH PARTIES</option>
                  <option value="OTHER">OTHER</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Commission Status</label>
                <select
                  value={commissionStatus}
                  onChange={(e: any) => setCommissionStatus(e.target.value)}
                  className="w-full p-2 border border-stone-200 rounded-lg bg-stone-50"
                >
                  <option value="AGREED">AGREED</option>
                  <option value="INVOICED">INVOICED</option>
                  <option value="PARTIALLY_PAID">PARTIALLY_PAID</option>
                  <option value="PAID">PAID</option>
                  <option value="WAIVED">WAIVED</option>
                  <option value="CANCELLED">CANCELLED</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setCommissionModalOpen(false)} className="px-3 py-1.5 border border-stone-200 rounded-lg">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 bg-stone-900 text-white rounded-lg font-semibold cursor-pointer">
                  Save Commission
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Record Payment */}
      {paymentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Record Commission Payment</h3>
              <button onClick={() => setPaymentModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleRecordPayment} className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-700 font-medium mb-1">Amount Received (₹) *</label>
                <input
                  type="number"
                  required
                  min="1"
                  placeholder={String(remainingAmount || 50000)}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  className="w-full p-2 border border-stone-200 rounded-lg font-mono text-sm font-bold"
                />
                <span className="text-[11px] text-stone-500 mt-0.5 block">
                  Remaining balance due: <span className="font-bold font-mono text-rose-700">{formatCurrency(remainingAmount)}</span>
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e: any) => setPaymentMethod(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-lg bg-stone-50"
                  >
                    <option value="UPI">UPI Transfer</option>
                    <option value="NEFT_RTGS">NEFT / RTGS</option>
                    <option value="BANK_TRANSFER">Direct Bank Transfer</option>
                    <option value="CHEQUE">Cheque</option>
                    <option value="CASH">Cash</option>
                    <option value="ONLINE">Online Gateway</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Payment Date</label>
                  <input
                    type="date"
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">UTR / Cheque / Transaction Ref</label>
                <input
                  type="text"
                  placeholder="e.g. CMS98218941 or Cheque # 001928"
                  value={transactionRef}
                  onChange={(e) => setTransactionRef(e.target.value)}
                  className="w-full p-2 border border-stone-200 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Payer Name</label>
                <input
                  type="text"
                  value={payerName}
                  onChange={(e) => setPayerName(e.target.value)}
                  placeholder="Client / Payer full name"
                  className="w-full p-2 border border-stone-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Notes & Remarks</label>
                <input
                  type="text"
                  placeholder="e.g. 50% advance token received upon registration"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  className="w-full p-2 border border-stone-200 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setPaymentModalOpen(false)} className="px-3 py-1.5 border border-stone-200 rounded-lg">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold cursor-pointer">
                  Confirm Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: Generate Invoice */}
      {generateInvoiceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Generate Professional Tax Invoice</h3>
              <button onClick={() => setGenerateInvoiceModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleGenerateInvoice} className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-700 font-medium mb-1">Subtotal (Taxable Brokerage) ₹ *</label>
                <input
                  type="number"
                  required
                  value={invoiceSubtotal}
                  onChange={(e) => setInvoiceSubtotal(e.target.value)}
                  className="w-full p-2 border border-stone-200 rounded-lg font-mono text-sm font-bold"
                />
                <span className="text-[11px] text-stone-500 mt-1 block">
                  18% GST (₹{((Number(invoiceSubtotal) || 0) * 0.18).toLocaleString('en-IN')}) will be applied automatically. Total: <span className="font-bold text-stone-900">₹{((Number(invoiceSubtotal) || 0) * 1.18).toLocaleString('en-IN')}</span>
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Issue Date</label>
                  <input
                    type="date"
                    value={invoiceIssueDate}
                    onChange={(e) => setInvoiceIssueDate(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-stone-700 font-medium mb-1">Due Date</label>
                  <input
                    type="date"
                    value={invoiceDueDate}
                    onChange={(e) => setInvoiceDueDate(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Invoice Notes / Description</label>
                <textarea
                  rows={2}
                  value={invoiceNotes}
                  onChange={(e) => setInvoiceNotes(e.target.value)}
                  placeholder="Professional advisory and facilitation fee for Mumbai property transaction..."
                  className="w-full p-2 border border-stone-200 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setGenerateInvoiceModalOpen(false)} className="px-3 py-1.5 border border-stone-200 rounded-lg">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-semibold cursor-pointer">
                  Generate & View Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 5: Printable Invoice Modal */}
      {invoiceModalOpen && (
        <InvoiceModal
          isOpen={invoiceModalOpen}
          onClose={() => setInvoiceModalOpen(false)}
          invoice={activeInvoice}
          deal={deal}
        />
      )}

    </div>
  );
};
