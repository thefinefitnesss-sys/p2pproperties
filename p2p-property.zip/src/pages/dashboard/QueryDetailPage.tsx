import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Building2, 
  MapPin, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  ArrowLeft, 
  PlusCircle, 
  ShieldCheck, 
  Lock, 
  ExternalLink,
  ChevronRight,
  Eye,
  AlertCircle,
  Sparkles,
  Phone,
  User,
  X
} from 'lucide-react';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';
import { formatPriceINR, formatArea } from '../../utils/formatters';

export const QueryDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { currentUser, showToast } = useProperty();

  const [query, setQuery] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  // Modal for Agent/Admin adding Off-Market Match
  const [showAddMatchModal, setShowAddMatchModal] = useState(false);
  const [matchForm, setMatchForm] = useState({
    location: '',
    property_type: 'Apartment',
    transaction_type: 'BUY',
    asking_price: '',
    expected_rent: '',
    area: '',
    bhk: '2 BHK',
    availability: 'IMMEDIATE',
    owner_or_representative_name: '',
    owner_or_representative_contact_reference: '',
    match_notes: '',
    status: 'IDENTIFIED'
  });
  const [submittingMatch, setSubmittingMatch] = useState(false);

  // Modal for scheduling site visit for an off-market match
  const [visitMatchModal, setVisitMatchModal] = useState<any | null>(null);
  const [visitDate, setVisitDate] = useState('');
  const [visitTime, setVisitTime] = useState('11:00 AM');
  const [visitNotes, setVisitNotes] = useState('');
  const [schedulingVisit, setSchedulingVisit] = useState(false);

  const loadQuery = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const res = await api.queries.get(id);
      setQuery(res.query);
      if (res.query) {
        setMatchForm((prev) => ({
          ...prev,
          transaction_type: res.query.transactionType || 'BUY',
          property_type: res.query.propertyType || 'Apartment',
          location: res.query.preferredLocations?.split(',')[0]?.trim() || 'Bandra West'
        }));
      }
    } catch (err: any) {
      showToast(err.message || 'Error fetching query detail.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQuery();
  }, [id]);

  const handleCreateMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query) return;

    if (!matchForm.location) {
      showToast('Please enter the off-market property location.');
      return;
    }

    setSubmittingMatch(true);
    try {
      await api.queries.addOffMarketMatch(query.id, {
        location: matchForm.location,
        property_type: matchForm.property_type,
        transaction_type: matchForm.transaction_type,
        asking_price: matchForm.asking_price ? Number(matchForm.asking_price) : undefined,
        expected_rent: matchForm.expected_rent ? Number(matchForm.expected_rent) : undefined,
        area: matchForm.area ? Number(matchForm.area) : undefined,
        bhk: matchForm.bhk,
        availability: matchForm.availability,
        owner_or_representative_name: matchForm.owner_or_representative_name,
        owner_or_representative_contact_reference: matchForm.owner_or_representative_contact_reference,
        match_notes: matchForm.match_notes,
        status: matchForm.status
      });

      showToast('Off-market property candidate successfully added.');
      setShowAddMatchModal(false);
      loadQuery();
    } catch (err: any) {
      showToast(err.message || 'Error adding off-market match.');
    } finally {
      setSubmittingMatch(false);
    }
  };

  const handleScheduleVisit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query || !visitMatchModal) return;

    if (!visitDate) {
      showToast('Please select a visit date.');
      return;
    }

    setSchedulingVisit(true);
    try {
      await api.queries.scheduleMatchVisit(query.id, visitMatchModal.id, {
        preferred_date: visitDate,
        preferred_time: visitTime,
        notes: visitNotes
      });

      showToast('Site visit scheduled for off-market match.');
      setVisitMatchModal(null);
      loadQuery();
    } catch (err: any) {
      showToast(err.message || 'Error scheduling site visit.');
    } finally {
      setSchedulingVisit(false);
    }
  };

  const handleConvertToListing = async (matchId: string) => {
    if (!query) return;
    if (!window.confirm('Convert this off-market property into a standard DRAFT listing? It will require normal verification before becoming public.')) return;

    try {
      const res = await api.queries.convertMatchToListing(query.id, matchId);
      showToast(`Property initiated as DRAFT listing (#${res.propertyId}). Pending moderation.`);
      loadQuery();
    } catch (err: any) {
      showToast(err.message || 'Error initiating listing.');
    }
  };

  const isBrokerOrAdmin = currentUser?.role === 'admin' || currentUser?.role === 'agent';

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto py-24 px-4 text-center text-xs text-stone-500">
        Loading property requirement & match engine...
      </div>
    );
  }

  if (!query) {
    return (
      <div className="max-w-md mx-auto py-24 px-4 text-center space-y-4">
        <h2 className="text-lg font-bold text-stone-900 font-serif">Requirement Not Found</h2>
        <p className="text-xs text-stone-500">The requested query reference could not be located or you lack access permission.</p>
        <button
          onClick={() => navigate('/dashboard/queries')}
          className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-md"
        >
          Return to Queries
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      
      {/* Top Breadcrumb & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div className="flex items-center gap-2">
          <Link
            to={currentUser?.role === 'admin' ? '/admin/queries' : '/dashboard/queries'}
            className="inline-flex items-center gap-1.5 text-xs text-stone-500 hover:text-stone-900 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Requirements</span>
          </Link>
          <span className="text-stone-300">/</span>
          <span className="font-mono text-xs font-bold text-stone-900 bg-stone-100 px-2 py-0.5 rounded">
            {query.queryNumber}
          </span>
        </div>

        {isBrokerOrAdmin && (
          <button
            type="button"
            onClick={() => setShowAddMatchModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
          >
            <PlusCircle className="w-4 h-4 text-amber-400" />
            <span>Add Off-Market Match</span>
          </button>
        )}
      </div>

      {/* Query Master Overview Card */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider bg-stone-900 text-white px-2.5 py-1 rounded">
                {query.transactionType} · {query.category}
              </span>
              <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                STATUS: {query.status}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-950">
              {query.preferredLocations || 'Mumbai Metropolitan Area'}
            </h1>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase tracking-wider text-stone-400 font-semibold block">Target Budget</span>
            <div className="text-xl sm:text-2xl font-bold font-serif text-stone-900">
              {query.budgetMin ? formatPriceINR(query.budgetMin) : 'Flexible'} – {query.budgetMax ? formatPriceINR(query.budgetMax) : 'Open'}
            </div>
          </div>
        </div>

        {/* Specifications Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-stone-50 rounded-xl border border-stone-200/80 text-xs">
          <div>
            <span className="text-stone-400 block text-[10px] uppercase font-semibold">Configuration</span>
            <p className="font-bold text-stone-900 mt-0.5">{query.bhk || query.propertyType}</p>
          </div>
          <div>
            <span className="text-stone-400 block text-[10px] uppercase font-semibold">Area Range</span>
            <p className="font-bold text-stone-900 mt-0.5">
              {query.areaMin || query.areaMax ? `${query.areaMin || 0} - ${query.areaMax || 0} sq.ft` : 'Any Area'}
            </p>
          </div>
          <div>
            <span className="text-stone-400 block text-[10px] uppercase font-semibold">Furnishing</span>
            <p className="font-bold text-stone-900 mt-0.5 capitalize">{query.furnishing || 'Any'}</p>
          </div>
          <div>
            <span className="text-stone-400 block text-[10px] uppercase font-semibold">Parking</span>
            <p className="font-bold text-stone-900 mt-0.5">{query.parkingRequired || 'Not Specified'}</p>
          </div>
        </div>

        {query.requirementsText && (
          <div className="text-xs text-stone-700 bg-amber-50/50 p-4 rounded-xl border border-amber-200/60 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 block">Specific Customer Preferences</span>
            <p className="leading-relaxed">"{query.requirementsText}"</p>
          </div>
        )}
      </div>

      {/* SECTION A: P2P Listed Matches */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold font-serif text-stone-900 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              A. P2P Listed Verified Matches
            </h2>
            <p className="text-xs text-stone-500">Public listings from the verified Mumbai database matching this requirement.</p>
          </div>
          <span className="text-xs font-semibold text-stone-500">
            {query.listedMatches?.length || 0} Listed Match{(query.listedMatches?.length || 0) === 1 ? '' : 'es'}
          </span>
        </div>

        {(!query.listedMatches || query.listedMatches.length === 0) ? (
          <div className="bg-white rounded-xl border border-stone-200 p-8 text-center text-xs text-stone-500 space-y-2">
            <Building2 className="w-8 h-8 text-stone-300 mx-auto" />
            <p>No exact approved public listings matched this precise filter right now.</p>
            <p className="text-[11px] text-stone-400">Requirement remains active for new matching listings or private off-market candidates.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {query.listedMatches.map((p: any) => (
              <div key={p.id} className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs hover:shadow-sm transition-all flex flex-col justify-between">
                <div>
                  <div className="aspect-16/9 bg-stone-100 relative overflow-hidden">
                    <img src={p.primaryImage} alt={p.title} className="w-full h-full object-cover" />
                    <span className="absolute top-2 left-2 text-[10px] font-bold uppercase tracking-wider bg-emerald-600 text-white px-2 py-0.5 rounded shadow-xs">
                      P2P VERIFIED
                    </span>
                  </div>
                  <div className="p-4 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-serif font-bold text-stone-900 text-base">
                        {p.transactionType === 'buy' ? formatPriceINR(p.price) : `₹${Number(p.rent).toLocaleString('en-IN')}/mo`}
                      </span>
                      <span className="text-[11px] text-stone-500">{p.bedrooms ? `${p.bedrooms} BHK` : p.propertyType}</span>
                    </div>
                    <h3 className="font-serif font-bold text-sm text-stone-950 line-clamp-1">{p.title}</h3>
                    <p className="text-xs text-stone-500 flex items-center gap-1">
                      <MapPin className="w-3 h-3 shrink-0" />
                      <span className="truncate">{p.locality}, Mumbai</span>
                    </p>
                  </div>
                </div>
                <div className="p-4 pt-0">
                  <Link
                    to={`/property/${p.id}`}
                    className="w-full inline-flex items-center justify-center gap-1.5 py-2 text-xs font-semibold uppercase tracking-wider text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-md transition-colors"
                  >
                    <span>View Property Details</span>
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECTION B: Off-Market Matches (Private) */}
      <div className="space-y-4 pt-4 border-t border-stone-200">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold font-serif text-stone-900">
                B. Off-Market Private Matches
              </h2>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded">
                OFF-MARKET — PRIVATE
              </span>
            </div>
            <p className="text-xs text-stone-500">Unlisted private properties sourced directly by authorized brokers for this requirement.</p>
          </div>

          {isBrokerOrAdmin && (
            <button
              type="button"
              onClick={() => setShowAddMatchModal(true)}
              className="text-xs font-semibold text-amber-800 hover:text-amber-900 transition-colors"
            >
              + Add Match
            </button>
          )}
        </div>

        {(!query.offMarketMatches || query.offMarketMatches.length === 0) ? (
          <div className="bg-amber-50/40 rounded-xl border border-amber-200/80 p-8 text-center text-xs text-stone-600 space-y-2">
            <Lock className="w-8 h-8 text-amber-600 mx-auto" />
            <p className="font-semibold text-stone-900">No Off-Market Candidates Logged Yet</p>
            <p className="text-[11px] text-stone-500 max-w-md mx-auto">
              Authorized brokers are searching direct unlisted inventory across Mumbai. Once a matching off-market property is identified, it will appear here privately.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {query.offMarketMatches.map((m: any, idx: number) => (
              <div
                key={m.id}
                className="bg-white rounded-xl border border-amber-200/80 p-5 shadow-2xs space-y-4 relative"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-mono">
                        Match #{idx + 1}
                      </span>
                      <span className="text-[10px] font-bold uppercase tracking-wider bg-stone-900 text-white px-2 py-0.5 rounded">
                        {m.status}
                      </span>
                    </div>
                    <h3 className="font-serif font-bold text-base text-stone-950 mt-1">
                      {m.bhk ? `${m.bhk} ` : ''}{m.propertyType} in {m.location}
                    </h3>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-stone-400 uppercase font-semibold block">Asking Valuation</span>
                    <span className="font-serif font-bold text-base text-stone-900">
                      {m.askingPrice ? formatPriceINR(m.askingPrice) : m.expectedRent ? `₹${Number(m.expectedRent).toLocaleString('en-IN')}/mo` : 'Negotiable'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 p-3 bg-stone-50 rounded-lg text-xs">
                  <div>
                    <span className="text-stone-400 block text-[10px] uppercase font-semibold">Area</span>
                    <p className="font-bold text-stone-800 mt-0.5">{m.area ? `${m.area} sq.ft` : 'Standard'}</p>
                  </div>
                  <div>
                    <span className="text-stone-400 block text-[10px] uppercase font-semibold">Availability</span>
                    <p className="font-bold text-stone-800 mt-0.5">{m.availability || 'Immediate'}</p>
                  </div>
                  <div>
                    <span className="text-stone-400 block text-[10px] uppercase font-semibold">Transaction</span>
                    <p className="font-bold text-stone-800 mt-0.5">{m.transactionType}</p>
                  </div>
                </div>

                {/* Sourcing / Private Notes (Internal Only) */}
                {isBrokerOrAdmin && (
                  <div className="p-3 bg-amber-50 rounded-lg text-xs text-amber-900 space-y-1.5 border border-amber-200/80">
                    <div className="flex items-center justify-between font-semibold">
                      <span className="flex items-center gap-1">
                        <Lock className="w-3 h-3 text-amber-700" />
                        Internal Broker Reference
                      </span>
                      <span className="text-[10px] font-mono text-amber-800">{m.source || 'Direct Sourcing'}</span>
                    </div>
                    {m.ownerOrRepresentativeName && (
                      <p className="text-[11px]">Representative: <strong>{m.ownerOrRepresentativeName}</strong> ({m.ownerOrRepresentativeContactReference || 'Ref Masked'})</p>
                    )}
                    {m.matchNotes && (
                      <p className="text-[11px] italic">Notes: "{m.matchNotes}"</p>
                    )}
                  </div>
                )}

                {/* Actions: Schedule Visit & Convert to Listing */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-100">
                  <button
                    type="button"
                    onClick={() => setVisitMatchModal(m)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-stone-900 bg-amber-100 hover:bg-amber-200 rounded-md transition-colors"
                  >
                    <Calendar className="w-3.5 h-3.5 text-amber-800" />
                    <span>Schedule Site Visit</span>
                  </button>

                  {isBrokerOrAdmin && m.status !== 'CONVERTED' && (
                    <button
                      type="button"
                      onClick={() => handleConvertToListing(m.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-md transition-colors"
                    >
                      <span>Convert to Public Listing</span>
                    </button>
                  )}

                  {m.status === 'CONVERTED' && (
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                      Listing Initiated (DRAFT)
                    </span>
                  )}
                </div>

              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECTION C: Activity Timeline */}
      <div className="space-y-4 pt-4 border-t border-stone-200">
        <h2 className="text-lg font-bold font-serif text-stone-900">
          Query Activity Timeline
        </h2>

        {(!query.activities || query.activities.length === 0) ? (
          <p className="text-xs text-stone-500">No activity logged yet.</p>
        ) : (
          <div className="space-y-3">
            {query.activities.map((a: any) => (
              <div key={a.id} className="flex items-start gap-3 p-3 bg-white rounded-lg border border-stone-200 text-xs">
                <Clock className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
                <div className="flex-1 space-y-0.5">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-stone-900">{a.action}</span>
                    <span className="text-[10px] text-stone-400">
                      {new Date(a.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                    </span>
                  </div>
                  <p className="text-stone-600">{a.details}</p>
                  <span className="text-[10px] text-stone-400">By {a.performedByName} ({a.performedByRole})</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal: Add Off-Market Match */}
      {showAddMatchModal && (
        <div className="fixed inset-0 z-50 bg-stone-950/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="text-base font-bold font-serif text-stone-900">
                Add Private Off-Market Match
              </h3>
              <button
                type="button"
                onClick={() => setShowAddMatchModal(false)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateMatch} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-stone-700 mb-1">Locality / Landmark *</label>
                <input
                  type="text"
                  value={matchForm.location}
                  onChange={(e) => setMatchForm({ ...matchForm, location: e.target.value })}
                  placeholder="e.g. Bandra West, Pali Hill"
                  required
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Property Type</label>
                  <select
                    value={matchForm.property_type}
                    onChange={(e) => setMatchForm({ ...matchForm, property_type: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                  >
                    <option value="Apartment">Apartment</option>
                    <option value="Penthouse">Penthouse</option>
                    <option value="Villa">Villa</option>
                    <option value="Office">Office</option>
                    <option value="Showroom">Showroom</option>
                    <option value="Warehouse">Warehouse</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">BHK / Config</label>
                  <input
                    type="text"
                    value={matchForm.bhk}
                    onChange={(e) => setMatchForm({ ...matchForm, bhk: e.target.value })}
                    placeholder="e.g. 2 BHK, 3 BHK"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Asking Price (₹ INR)</label>
                  <input
                    type="number"
                    value={matchForm.asking_price}
                    onChange={(e) => setMatchForm({ ...matchForm, asking_price: e.target.value })}
                    placeholder="e.g. 16500000"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">Carpet Area (sq.ft)</label>
                  <input
                    type="number"
                    value={matchForm.area}
                    onChange={(e) => setMatchForm({ ...matchForm, area: e.target.value })}
                    placeholder="e.g. 950"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Owner / Representative Name</label>
                  <input
                    type="text"
                    value={matchForm.owner_or_representative_name}
                    onChange={(e) => setMatchForm({ ...matchForm, owner_or_representative_name: e.target.value })}
                    placeholder="e.g. R. K. Singhania"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">Contact Reference (Protected)</label>
                  <input
                    type="text"
                    value={matchForm.owner_or_representative_contact_reference}
                    onChange={(e) => setMatchForm({ ...matchForm, owner_or_representative_contact_reference: e.target.value })}
                    placeholder="e.g. Ref #8829 / Direct owner phone"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Internal Match Notes</label>
                <textarea
                  rows={2}
                  value={matchForm.match_notes}
                  onChange={(e) => setMatchForm({ ...matchForm, match_notes: e.target.value })}
                  placeholder="Key features, owner willingness, key handover status..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddMatchModal(false)}
                  className="px-4 py-2 border border-stone-200 rounded-lg text-stone-700 hover:bg-stone-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingMatch}
                  className="px-4 py-2 bg-stone-900 text-white rounded-lg hover:bg-stone-800 disabled:opacity-50"
                >
                  {submittingMatch ? 'Saving Match...' : 'Save Off-Market Match'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Schedule Site Visit for Off-Market Match */}
      {visitMatchModal && (
        <div className="fixed inset-0 z-50 bg-stone-950/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="text-base font-bold font-serif text-stone-900">
                Schedule Site Visit for Off-Market Match
              </h3>
              <button
                type="button"
                onClick={() => setVisitMatchModal(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-stone-600">
              Booking physical inspection for candidate in <strong>{visitMatchModal.location}</strong>.
            </p>

            <form onSubmit={handleScheduleVisit} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-stone-700 mb-1">Preferred Date *</label>
                <input
                  type="date"
                  value={visitDate}
                  onChange={(e) => setVisitDate(e.target.value)}
                  required
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Preferred Time *</label>
                <select
                  value={visitTime}
                  onChange={(e) => setVisitTime(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                >
                  <option value="10:00 AM">10:00 AM - Morning Slot</option>
                  <option value="11:30 AM">11:30 AM - Mid-day Slot</option>
                  <option value="03:00 PM">03:00 PM - Afternoon Slot</option>
                  <option value="05:00 PM">05:00 PM - Evening Golden Hour</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Notes for Inspection</label>
                <textarea
                  rows={2}
                  value={visitNotes}
                  onChange={(e) => setVisitNotes(e.target.value)}
                  placeholder="Accompanying members, entry gate instructions..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setVisitMatchModal(null)}
                  className="px-4 py-2 border border-stone-200 rounded-lg text-stone-700 hover:bg-stone-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={schedulingVisit}
                  className="px-4 py-2 bg-stone-900 text-white rounded-lg hover:bg-stone-800 disabled:opacity-50"
                >
                  {schedulingVisit ? 'Scheduling...' : 'Confirm Site Visit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
