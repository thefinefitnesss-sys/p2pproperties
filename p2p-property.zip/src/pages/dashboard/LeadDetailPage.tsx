import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Users, 
  ArrowLeft, 
  Phone, 
  MessageSquare, 
  Mail, 
  Calendar, 
  Building2, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Send, 
  Plus, 
  ShieldCheck, 
  Check, 
  X, 
  ExternalLink, 
  Activity, 
  FileText, 
  Sparkles,
  Award,
  ChevronRight,
  TrendingUp,
  MapPin,
  Tag,
  DollarSign,
  Briefcase,
  ArrowRight,
  IndianRupee
} from 'lucide-react';
import { useProperty } from '../../context/PropertyContext';
import { api } from '../../services/api';
import { Lead, LeadStatus, LeadPriority } from '../../types/lead';
import { formatPriceINR } from '../../utils/formatters';

export const LeadDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { currentUser, showToast } = useProperty();

  const [lead, setLead] = useState<Lead | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Linked Deal (Phase 5)
  const [linkedDeal, setLinkedDeal] = useState<any | null>(null);
  const [convertModalOpen, setConvertModalOpen] = useState(false);
  const [dealTransactionType, setDealTransactionType] = useState<'BUY' | 'RENT' | 'LEASE'>('BUY');
  const [dealCategory, setDealCategory] = useState<'RESIDENTIAL' | 'COMMERCIAL'>('RESIDENTIAL');
  const [dealAgreedValue, setDealAgreedValue] = useState<string>('');
  const [dealCommissionType, setDealCommissionType] = useState<'PERCENTAGE' | 'FIXED_AMOUNT'>('PERCENTAGE');
  const [dealCommissionRate, setDealCommissionRate] = useState<number>(1.0);
  const [dealCommissionAmount, setDealCommissionAmount] = useState<string>('');
  const [dealCommissionPayer, setDealCommissionPayer] = useState<string>('BUYER');
  const [dealClosingDate, setDealClosingDate] = useState<string>('');
  const [dealNotes, setDealNotes] = useState<string>('');
  const [converting, setConverting] = useState(false);

  // WhatsApp business desk number
  const [businessWhatsApp, setBusinessWhatsApp] = useState('+919820098200');

  // Interactive forms state
  const [newNote, setNewNote] = useState('');
  const [noteSaving, setNoteSaving] = useState(false);

  // Follow-up modal
  const [followUpModalOpen, setFollowUpModalOpen] = useState(false);
  const [followUpDate, setFollowUpDate] = useState(new Date().toISOString().split('T')[0]);
  const [followUpTime, setFollowUpTime] = useState('11:00 AM');
  const [followUpAgenda, setFollowUpAgenda] = useState('');

  // Site visit modal
  const [visitModalOpen, setVisitModalOpen] = useState(false);
  const [visitDate, setVisitDate] = useState('');
  const [visitTime, setVisitTime] = useState('02:00 PM - 03:00 PM');
  const [visitMessage, setVisitMessage] = useState('');

  // Contact attempt modal
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [contactMethod, setContactMethod] = useState<'PHONE' | 'WHATSAPP' | 'EMAIL'>('PHONE');
  const [contactOutcome, setContactOutcome] = useState('CONNECTED');
  const [contactDetails, setContactDetails] = useState('');

  // Rejection/Lost modal
  const [lostModalOpen, setLostModalOpen] = useState(false);
  const [lostReason, setLostReason] = useState('Budget mismatch');

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    if (id) {
      loadLead(id);
      loadWhatsAppConfig();
    }
  }, [id, currentUser]);

  const loadLead = async (leadId: string) => {
    setLoading(true);
    setError('');
    try {
      const res = await api.leads.get(leadId);
      setLead(res.lead);

      // Pre-fill deal values
      const p = res.lead.property;
      const defaultTrans = p?.transaction_type ? (p.transaction_type.toUpperCase() as any) : 'BUY';
      setDealTransactionType(defaultTrans);
      setDealCategory(p?.category ? (p.category.toUpperCase() as any) : 'RESIDENTIAL');
      const val = defaultTrans === 'RENT' ? (p?.monthly_rent || 0) : (p?.price || res.lead.budget || 0);
      setDealAgreedValue(String(val || ''));
      setDealCommissionPayer(defaultTrans === 'RENT' || defaultTrans === 'LEASE' ? 'TENANT' : 'BUYER');

      // Check if active deal already created for this lead
      const dealRes = await api.leads.getDeal(leadId).catch(() => ({ deal: null }));
      setLinkedDeal(dealRes?.deal || null);
    } catch (err: any) {
      setError(err.message || 'Error loading lead.');
    } finally {
      setLoading(false);
    }
  };

  const handleConvertToDeal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lead) return;
    setConverting(true);
    try {
      const numVal = Number(dealAgreedValue) || 0;
      const res = await api.leads.convertToDeal(lead.id, {
        transaction_type: dealTransactionType,
        category: dealCategory,
        agreed_property_value: dealTransactionType === 'BUY' ? numVal : undefined,
        agreed_rent: dealTransactionType === 'RENT' ? numVal : undefined,
        agreed_lease_value: dealTransactionType === 'LEASE' ? numVal : undefined,
        commission_type: dealCommissionType,
        commission_rate: dealCommissionType === 'PERCENTAGE' ? Number(dealCommissionRate) : undefined,
        commission_amount: dealCommissionType === 'FIXED_AMOUNT' ? Number(dealCommissionAmount) : undefined,
        commission_payer: dealCommissionPayer,
        expected_closing_date: dealClosingDate || undefined,
        notes: dealNotes || undefined
      });
      showToast(`Lead successfully converted to deal ${res.dealNumber}!`);
      setConvertModalOpen(false);
      navigate(`/dashboard/deals/${res.dealId}`);
    } catch (err: any) {
      showToast(err.message || 'Error converting lead to deal.');
    } finally {
      setConverting(false);
    }
  };

  const loadWhatsAppConfig = async () => {
    try {
      const cfg = await api.leads.getWhatsAppConfig();
      if (cfg?.businessNumber) setBusinessWhatsApp(cfg.businessNumber);
    } catch {}
  };

  const handleStatusChange = async (newStatus: LeadStatus, reason?: string) => {
    if (!lead) return;
    try {
      await api.leads.updateStatus(lead.id, newStatus, reason);
      showToast(`Lead stage updated to ${newStatus}`);
      loadLead(lead.id);
      setLostModalOpen(false);
    } catch (err: any) {
      showToast(err.message || 'Error updating status.');
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lead || !newNote.trim()) return;
    setNoteSaving(true);
    try {
      await api.leads.addNote(lead.id, newNote);
      showToast('Note added to timeline.');
      setNewNote('');
      loadLead(lead.id);
    } catch (err: any) {
      showToast(err.message || 'Error saving note.');
    } finally {
      setNoteSaving(false);
    }
  };

  const handleScheduleFollowUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lead || !followUpDate || !followUpAgenda.trim()) return;
    try {
      await api.leads.scheduleFollowUp(lead.id, {
        follow_up_date: followUpDate,
        follow_up_time: followUpTime,
        note: followUpAgenda
      });
      showToast('Follow-up scheduled.');
      setFollowUpModalOpen(false);
      setFollowUpAgenda('');
      loadLead(lead.id);
    } catch (err: any) {
      showToast(err.message || 'Error scheduling follow-up.');
    }
  };

  const handleUpdateFollowUp = async (followUpId: string, status: string) => {
    if (!lead) return;
    try {
      await api.leads.updateFollowUp(followUpId, status);
      showToast(`Follow-up marked as ${status}.`);
      loadLead(lead.id);
    } catch (err: any) {
      showToast(err.message || 'Error updating follow-up.');
    }
  };

  const handleScheduleSiteVisit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lead || !visitDate) return;
    try {
      await api.leads.scheduleSiteVisit(lead.id, {
        preferred_date: visitDate,
        preferred_time: visitTime,
        message: visitMessage
      });
      showToast('Site visit scheduled.');
      setVisitModalOpen(false);
      setVisitMessage('');
      loadLead(lead.id);
    } catch (err: any) {
      showToast(err.message || 'Error creating site visit.');
    }
  };

  const handleLogContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lead) return;
    try {
      await api.leads.recordContact(lead.id, {
        method: contactMethod,
        outcome: contactOutcome,
        details: contactDetails
      });
      showToast('Contact logged.');
      setContactModalOpen(false);
      setContactDetails('');
      loadLead(lead.id);
    } catch (err: any) {
      showToast(err.message || 'Error logging contact.');
    }
  };

  const openWhatsAppChat = () => {
    if (!lead) return;
    const phoneClean = lead.customer?.mobile ? lead.customer.mobile.replace(/[^0-9]/g, '') : '';
    const propTitle = lead.property?.title || 'Mumbai property listing';
    const loc = lead.property?.locality || 'Mumbai';
    const text = encodeURIComponent(
      `Hello ${lead.customer?.name || 'Customer'}, thank you for inquiring about "${propTitle}" in ${loc} on P2P Property Mumbai. Would you like to schedule a call or site walk-through?`
    );
    const target = phoneClean && phoneClean.length >= 10 ? phoneClean : businessWhatsApp.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${target}?text=${text}`, '_blank');
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto py-12 px-4 text-center text-xs text-stone-500">
        Loading lead dossier and activity timeline...
      </div>
    );
  }

  if (error || !lead) {
    return (
      <div className="max-w-3xl mx-auto py-12 px-4 text-center space-y-4">
        <AlertCircle className="w-10 h-10 text-rose-500 mx-auto" />
        <h2 className="text-xl font-bold text-stone-900">Lead Not Found or Access Denied</h2>
        <p className="text-xs text-stone-600">{error || 'You do not have authorization to view this lead.'}</p>
        <Link 
          to="/dashboard/leads"
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-md"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Lead Inbox</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8 space-y-6 min-h-screen">
      
      {/* Breadcrumb Navigation */}
      <div className="flex items-center justify-between text-xs text-stone-500 border-b border-stone-200 pb-3">
        <div className="flex items-center gap-2">
          <Link to="/dashboard" className="hover:text-stone-900">Dashboard</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link to="/dashboard/leads" className="hover:text-stone-900">Leads Pipeline</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-stone-900 font-semibold">{lead.customer?.name}</span>
        </div>

        <Link 
          to="/dashboard/leads"
          className="inline-flex items-center gap-1 hover:text-stone-900 font-medium"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Pipeline</span>
        </Link>
      </div>

      {/* Linked Active Deal Notification Banner (Phase 5) */}
      {linkedDeal && (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-2xs">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
              <Briefcase className="w-6 h-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-sm text-stone-950 font-serif">
                  Active Deal: {linkedDeal.deal_number}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-amber-200 text-amber-900 border border-amber-300">
                  Stage: {linkedDeal.deal_status}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-stone-200 text-stone-800">
                  Brokerage: {linkedDeal.commission_status}
                </span>
              </div>
              <p className="text-xs text-stone-600 mt-1">
                Agreed Valuation: <span className="font-bold font-mono text-stone-900">{formatPriceINR(linkedDeal.agreed_property_value || linkedDeal.agreed_rent || 0)}</span> · Commission: <span className="font-bold font-mono text-amber-800">{formatPriceINR(linkedDeal.commission_amount || 0)}</span> ({linkedDeal.commission_payer})
              </p>
            </div>
          </div>

          <Link
            to={`/dashboard/deals/${linkedDeal.id}`}
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shrink-0 transition-colors shadow-2xs cursor-pointer"
          >
            <span>Open Deal Workspace & Ledger</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      )}

      {/* Hero Lead Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono text-stone-400">ID: {lead.id}</span>
              <span className="text-stone-300">·</span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                lead.priority === 'URGENT' ? 'bg-rose-100 text-rose-800 border border-rose-200' :
                lead.priority === 'HIGH' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                'bg-stone-100 text-stone-700'
              }`}>
                {lead.priority} Priority
              </span>
              <span className="text-stone-300">·</span>
              <span className="text-[10px] font-mono uppercase bg-stone-100 text-stone-600 px-2 py-0.5 rounded">
                Source: {lead.source.replace('_', ' ')}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900">
              {lead.customer?.name}
            </h1>
            <p className="text-xs text-stone-500">
              Inquiry registered on {new Date(lead.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>

          {/* Current Stage Badge */}
          <div className="flex items-center gap-3 self-start md:self-auto">
            <div className="text-right">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block">Current Stage</span>
              <span className={`inline-block px-3 py-1 rounded-md text-xs font-bold font-mono uppercase tracking-wider ${
                lead.status === 'WON' ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' :
                lead.status === 'NEGOTIATING' ? 'bg-orange-100 text-orange-800 border border-orange-300' :
                lead.status === 'SITE_VISIT' ? 'bg-indigo-100 text-indigo-800 border border-indigo-300' :
                lead.status === 'QUALIFIED' ? 'bg-amber-100 text-amber-800 border border-amber-300' :
                lead.status === 'CONTACTED' ? 'bg-purple-100 text-purple-800 border border-purple-300' :
                lead.status === 'LOST' ? 'bg-stone-100 text-stone-500 line-through' :
                'bg-blue-100 text-blue-800 border border-blue-300'
              }`}>
                {lead.status.replace('_', ' ')}
              </span>
            </div>
          </div>
        </div>

        {/* One-Click Stage Progression Bar */}
        <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider mr-1">Move Stage:</span>
          
          <button
            type="button"
            onClick={() => handleStatusChange('CONTACTED')}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-colors ${
              lead.status === 'CONTACTED'
                ? 'bg-purple-600 text-white border-purple-600'
                : 'border-stone-200 text-stone-700 hover:bg-stone-50'
            }`}
          >
            Mark Contacted
          </button>

          <button
            type="button"
            onClick={() => handleStatusChange('QUALIFIED')}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-colors ${
              lead.status === 'QUALIFIED'
                ? 'bg-amber-600 text-white border-amber-600'
                : 'border-stone-200 text-stone-700 hover:bg-stone-50'
            }`}
          >
            Mark Qualified
          </button>

          <button
            type="button"
            onClick={() => setVisitModalOpen(true)}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-colors ${
              lead.status === 'SITE_VISIT'
                ? 'bg-indigo-600 text-white border-indigo-600'
                : 'border-stone-200 text-stone-700 hover:bg-stone-50'
            }`}
          >
            Schedule Site Visit
          </button>

          <button
            type="button"
            onClick={() => handleStatusChange('NEGOTIATING')}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-colors ${
              lead.status === 'NEGOTIATING'
                ? 'bg-orange-600 text-white border-orange-600'
                : 'border-stone-200 text-stone-700 hover:bg-stone-50'
            }`}
          >
            Mark Negotiating
          </button>

          <button
            type="button"
            onClick={() => handleStatusChange('WON')}
            className="px-3.5 py-1.5 rounded-lg font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors flex items-center gap-1 shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Mark Won Deal</span>
          </button>

          {/* Convert to Deal Button (Phase 5) */}
          <button
            type="button"
            onClick={() => setConvertModalOpen(true)}
            className="px-3.5 py-1.5 rounded-lg font-semibold bg-amber-600 hover:bg-amber-700 text-white transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Convert to Deal</span>
          </button>

          <button
            type="button"
            onClick={() => setLostModalOpen(true)}
            className="px-3 py-1.5 rounded-lg border border-rose-200 text-rose-700 hover:bg-rose-50 font-semibold transition-colors ml-auto"
          >
            Mark Lost
          </button>
        </div>
      </div>

      {/* Main Grid: Left Details & Right Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 Cols wide on desktop) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Customer Profile & Demographics Card */}
          <div className="bg-white rounded-xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-stone-700" />
                <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                  Customer Profile & Criteria
                </h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded bg-stone-100 text-stone-700 font-mono font-bold uppercase">
                {lead.customer?.customerType}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Mobile Phone</span>
                <span className="font-semibold text-stone-900">{lead.customer?.mobile}</span>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Email Address</span>
                <span className="font-semibold text-stone-900 truncate block">{lead.customer?.email}</span>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Preferred Contact</span>
                <span className="font-semibold text-stone-900">{lead.preferredContactMethod || 'Phone Call'}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs pt-3 border-t border-stone-100">
              <div>
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Transaction Intent</span>
                <span className="font-semibold text-stone-900 uppercase">{lead.customer?.preferredTransaction || lead.property?.transactionType || 'Direct Buy'}</span>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Budget Ceiling</span>
                <span className="font-semibold text-stone-900 font-serif">
                  {lead.budget ? formatPriceINR(lead.budget, 'total') : 'Open to terms'}
                </span>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Preferred Locations</span>
                <span className="font-semibold text-stone-900">
                  {lead.customer?.preferredLocations || lead.property?.locality || 'Mumbai Prime'}
                </span>
              </div>
            </div>

            {/* Commercial vs Residential specifics */}
            <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200/80 text-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
              {lead.requirementType === 'commercial' ? (
                <>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-stone-500 block">Business Category</span>
                    <span className="font-semibold text-stone-900">{lead.businessType || lead.customer?.businessType || 'Corporate Office'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-stone-500 block">Required Carpet Area</span>
                    <span className="font-semibold text-stone-900">{lead.requiredCarpetArea ? `${lead.requiredCarpetArea} sq.ft.` : 'Flexible'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-stone-500 block">Commercial Use</span>
                    <span className="font-semibold text-stone-900">Grade A Corporate / Retail</span>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-stone-500 block">Configuration</span>
                    <span className="font-semibold text-stone-900">{lead.bhk || lead.customer?.bhk || 'Residential 2-3 BHK'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-stone-500 block">Carpet Area</span>
                    <span className="font-semibold text-stone-900">{lead.requiredCarpetArea ? `${lead.requiredCarpetArea} sq.ft.` : 'As per listing'}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-stone-500 block">Furnishing Preference</span>
                    <span className="font-semibold text-stone-900 capitalize">{lead.furnishingPreference || 'Semi-furnished'}</span>
                  </div>
                </>
              )}
            </div>

            {lead.customerMessage && (
              <div className="p-3 bg-amber-50/60 border border-amber-200/80 rounded-lg text-xs space-y-1">
                <span className="text-[10px] font-bold uppercase text-amber-800 tracking-wider block">Customer's Initial Message</span>
                <p className="text-stone-800 italic leading-relaxed">
                  "{lead.customerMessage}"
                </p>
              </div>
            )}
          </div>

          {/* Associated Property Card */}
          {lead.property && (
            <div className="bg-white rounded-xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-4">
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-stone-700" />
                  <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                    Associated Listing
                  </h3>
                </div>
                <Link
                  to={`/properties/${lead.property.id}`}
                  target="_blank"
                  className="text-xs font-semibold text-amber-800 hover:text-amber-900 inline-flex items-center gap-1"
                >
                  <span>Public Listing</span>
                  <ExternalLink className="w-3 h-3" />
                </Link>
              </div>

              <div className="flex flex-col sm:flex-row items-start gap-4">
                <img 
                  src={lead.property.primaryImage || '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg'} 
                  alt="" 
                  className="w-full sm:w-36 h-28 object-cover rounded-lg border border-stone-200 shrink-0" 
                />
                <div className="space-y-1.5 min-w-0 flex-1 text-xs">
                  <span className="text-[10px] font-mono uppercase bg-stone-100 text-stone-700 px-2 py-0.5 rounded">
                    {lead.property.category} · {lead.property.transactionType}
                  </span>
                  <h4 className="text-sm font-bold text-stone-900 leading-snug">
                    {lead.property.title}
                  </h4>
                  <p className="text-stone-600 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                    <span>{lead.property.locality}</span>
                  </p>
                  <p className="font-serif font-bold text-stone-900 text-sm">
                    {formatPriceINR(lead.property.price, 'total')}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Activity Timeline Card */}
          <div className="bg-white rounded-xl p-5 sm:p-6 border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-stone-700" />
                <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                  Activity Timeline & Audit Log
                </h3>
              </div>
              <span className="text-xs text-stone-500 font-mono">
                {lead.activities?.length || 0} events
              </span>
            </div>

            {/* Quick Add Note Form */}
            <form onSubmit={handleAddNote} className="space-y-2 pb-4 border-b border-stone-100">
              <label className="block text-[11px] font-bold uppercase text-stone-700">
                Log New Note or Conversation Update
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Record call discussion, negotiation progress, or client feedback..."
                  className="flex-1 px-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
                />
                <button
                  type="submit"
                  disabled={noteSaving || !newNote.trim()}
                  className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg disabled:opacity-50 inline-flex items-center gap-1.5"
                >
                  <Send className="w-3 h-3" />
                  <span>Log Note</span>
                </button>
              </div>
            </form>

            {/* Chronological Timeline */}
            <div className="relative pl-6 space-y-5 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-200">
              {lead.activities && lead.activities.length > 0 ? (
                lead.activities.map((act) => (
                  <div key={act.id} className="relative group text-xs">
                    {/* Dot icon */}
                    <div className="absolute -left-6 top-0.5 w-5 h-5 rounded-full bg-white border-2 border-stone-700 flex items-center justify-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-stone-900" />
                    </div>

                    <div className="space-y-0.5">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-stone-900 uppercase tracking-wider font-mono">
                          {act.action.replace(/_/g, ' ')}
                        </span>
                        <span className="text-stone-400 font-mono text-[10px]">
                          {new Date(act.createdAt).toLocaleDateString('en-IN', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                      
                      <p className="text-stone-700 leading-relaxed bg-stone-50/80 p-2.5 rounded-md border border-stone-200/60">
                        {act.details}
                      </p>

                      <div className="text-[10px] text-stone-400 flex items-center gap-1 pt-0.5">
                        <span>Performed by:</span>
                        <span className="font-medium text-stone-600">{act.performedByName || 'System'}</span>
                        <span>({act.performedByRole || 'user'})</span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-stone-400 italic">No timeline events recorded.</p>
              )}
            </div>

          </div>

        </div>

        {/* Right Column: Communication, Follow-ups, Site Visits */}
        <div className="space-y-6">
          
          {/* Quick Communication Box */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-2xs space-y-3.5">
            <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider border-b border-stone-100 pb-2">
              Direct Contact Channels
            </h3>

            {/* WhatsApp Integration Button */}
            <button
              type="button"
              onClick={openWhatsAppChat}
              className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Connect on WhatsApp</span>
            </button>

            {/* Direct Phone Call */}
            {lead.customer?.mobile && (
              <a
                href={`tel:${lead.customer.mobile}`}
                className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-3 border border-stone-300 text-stone-800 hover:bg-stone-50 rounded-lg text-xs font-semibold transition-colors"
              >
                <Phone className="w-4 h-4 text-stone-600" />
                <span>Call {lead.customer.mobile}</span>
              </a>
            )}

            {/* Log Contact Attempt */}
            <button
              type="button"
              onClick={() => setContactModalOpen(true)}
              className="w-full inline-flex items-center justify-center gap-2 py-2 px-3 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-xs font-medium transition-colors"
            >
              <span>Log Call / Outreach</span>
            </button>

            {lead.lastContactedAt && (
              <p className="text-[10px] text-stone-400 text-center pt-1">
                Last contacted on {new Date(lead.lastContactedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
              </p>
            )}
          </div>

          {/* Follow-up Tasks Box */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-2xs space-y-3.5">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                Scheduled Follow-ups
              </h3>
              <button
                type="button"
                onClick={() => setFollowUpModalOpen(true)}
                className="text-[11px] font-bold text-amber-800 hover:text-amber-900 inline-flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Schedule</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {lead.followUps && lead.followUps.length > 0 ? (
                lead.followUps.map((fol) => (
                  <div 
                    key={fol.id}
                    className={`p-3 rounded-lg border text-xs space-y-1.5 ${
                      fol.status === 'COMPLETED' ? 'bg-stone-50 border-stone-200 opacity-60' :
                      fol.status === 'CANCELLED' ? 'bg-rose-50/50 border-rose-200 opacity-60' :
                      'bg-amber-50/60 border-amber-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-stone-900 flex items-center gap-1 text-[11px]">
                        <Calendar className="w-3.5 h-3.5 text-stone-600" />
                        <span>{fol.followUpDate}</span>
                        {fol.followUpTime && <span className="text-stone-500 font-normal">({fol.followUpTime})</span>}
                      </span>
                      <span className="text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded bg-white text-stone-700 border border-stone-200">
                        {fol.status}
                      </span>
                    </div>

                    <p className="text-stone-700 text-[11px] leading-snug">
                      {fol.note}
                    </p>

                    {fol.status === 'PENDING' && (
                      <div className="flex items-center gap-2 pt-1 border-t border-stone-200/60 text-[10px]">
                        <button
                          type="button"
                          onClick={() => handleUpdateFollowUp(fol.id, 'COMPLETED')}
                          className="font-bold text-emerald-700 hover:underline inline-flex items-center gap-0.5"
                        >
                          <Check className="w-3 h-3" />
                          <span>Mark Done</span>
                        </button>
                        <span className="text-stone-300">·</span>
                        <button
                          type="button"
                          onClick={() => handleUpdateFollowUp(fol.id, 'CANCELLED')}
                          className="text-stone-500 hover:underline"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>
                ))
              ) : (
                <div className="py-4 text-center text-xs text-stone-400">
                  No follow-ups pending.
                </div>
              )}
            </div>
          </div>

          {/* Linked Site Visits Box */}
          <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-2xs space-y-3.5">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                Site Visits
              </h3>
              <button
                type="button"
                onClick={() => setVisitModalOpen(true)}
                className="text-[11px] font-bold text-amber-800 hover:text-amber-900 inline-flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Book Visit</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {lead.siteVisits && lead.siteVisits.length > 0 ? (
                lead.siteVisits.map((v) => (
                  <div key={v.id} className="p-3 bg-stone-50 rounded-lg border border-stone-200 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-stone-900 text-[11px]">
                        {v.preferred_date} · {v.preferred_time}
                      </span>
                      <span className={`text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                        v.status === 'CONFIRMED' ? 'bg-emerald-100 text-emerald-800' :
                        v.status === 'COMPLETED' ? 'bg-blue-100 text-blue-800' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {v.status}
                      </span>
                    </div>
                    {v.message && (
                      <p className="text-stone-600 text-[11px] italic">
                        "{v.message}"
                      </p>
                    )}
                  </div>
                ))
              ) : (
                <div className="py-4 text-center text-xs text-stone-400">
                  No site visits booked yet.
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* Follow-up Modal */}
      {followUpModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Schedule Follow-up Task</h3>
              <button onClick={() => setFollowUpModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleScheduleFollowUp} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Target Date *</label>
                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    required
                    className="w-full p-2 border border-stone-200 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Time Slot</label>
                  <input
                    type="text"
                    value={followUpTime}
                    onChange={(e) => setFollowUpTime(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-md"
                  />
                </div>
              </div>
              <div>
                <label className="block text-stone-700 font-medium mb-1">Task Agenda *</label>
                <textarea
                  rows={3}
                  value={followUpAgenda}
                  onChange={(e) => setFollowUpAgenda(e.target.value)}
                  required
                  placeholder="e.g. Call to discuss token amount and share building OC clearance."
                  className="w-full p-2 border border-stone-200 rounded-md"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={() => setFollowUpModalOpen(false)} className="px-3 py-1.5 border border-stone-200 rounded-md">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 bg-stone-900 text-white rounded-md font-semibold">
                  Save Follow-up
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Site Visit Modal */}
      {visitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Schedule Physical Site Inspection</h3>
              <button onClick={() => setVisitModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleScheduleSiteVisit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Inspection Date *</label>
                  <input
                    type="date"
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    required
                    className="w-full p-2 border border-stone-200 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Time Slot *</label>
                  <input
                    type="text"
                    value={visitTime}
                    onChange={(e) => setVisitTime(e.target.value)}
                    required
                    placeholder="e.g. 11:00 AM - 12:00 PM"
                    className="w-full p-2 border border-stone-200 rounded-md"
                  />
                </div>
              </div>
              <div>
                <label className="block text-stone-700 font-medium mb-1">Notes / Instructions</label>
                <textarea
                  rows={2}
                  value={visitMessage}
                  onChange={(e) => setVisitMessage(e.target.value)}
                  placeholder="Key gate access details, architect accompanying, etc."
                  className="w-full p-2 border border-stone-200 rounded-md"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={() => setVisitModalOpen(false)} className="px-3 py-1.5 border border-stone-200 rounded-md">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 bg-stone-900 text-white rounded-md font-semibold">
                  Confirm Site Visit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Contact Log Modal */}
      {contactModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Log Communication Outreach</h3>
              <button onClick={() => setContactModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleLogContact} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Channel</label>
                  <select
                    value={contactMethod}
                    onChange={(e: any) => setContactMethod(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-md bg-white"
                  >
                    <option value="PHONE">Phone Call</option>
                    <option value="WHATSAPP">WhatsApp Message</option>
                    <option value="EMAIL">Email</option>
                  </select>
                </div>
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Outcome</label>
                  <select
                    value={contactOutcome}
                    onChange={(e) => setContactOutcome(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-md bg-white"
                  >
                    <option value="CONNECTED">Connected / Discussed</option>
                    <option value="LEFT_MESSAGE">Left WhatsApp Message</option>
                    <option value="NO_ANSWER">No Answer / Call Back Requested</option>
                    <option value="NOT_INTERESTED">Not Interested</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-stone-700 font-medium mb-1">Details & Feedback</label>
                <textarea
                  rows={2}
                  value={contactDetails}
                  onChange={(e) => setContactDetails(e.target.value)}
                  placeholder="Summarize key points discussed..."
                  className="w-full p-2 border border-stone-200 rounded-md"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={() => setContactModalOpen(false)} className="px-3 py-1.5 border border-stone-200 rounded-md">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 bg-stone-900 text-white rounded-md font-semibold">
                  Record Outreach
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lost Reason Modal */}
      {lostModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Mark Lead as Lost</h3>
              <button onClick={() => setLostModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3 text-xs">
              <p className="text-stone-600">
                Please select the reason for closing this lead:
              </p>
              <select
                value={lostReason}
                onChange={(e) => setLostReason(e.target.value)}
                className="w-full p-2 border border-stone-200 rounded-md bg-white"
              >
                <option value="Budget mismatch">Budget mismatch</option>
                <option value="Purchased another property">Purchased another property</option>
                <option value="Location unsuitable">Location unsuitable</option>
                <option value="Carpet area insufficient">Carpet area insufficient</option>
                <option value="Financing unapproved">Financing unapproved</option>
                <option value="Unresponsive customer">Unresponsive customer</option>
                <option value="Other">Other</option>
              </select>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setLostModalOpen(false)} className="px-3 py-1.5 border border-stone-200 rounded-md">
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleStatusChange('LOST', lostReason)}
                  className="px-4 py-1.5 bg-rose-600 text-white rounded-md font-semibold"
                >
                  Confirm Lost
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Convert to Deal Modal (Phase 5) */}
      {convertModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/65 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-stone-200 p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-stone-900 text-sm font-serif">Convert Lead to Transaction Deal</h3>
              </div>
              <button onClick={() => setConvertModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConvertToDeal} className="space-y-4 text-xs">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/80 space-y-1">
                <div className="font-bold text-stone-900">{lead.customer?.name}</div>
                <div className="text-stone-500">{lead.property?.title || 'Mumbai property'}</div>
              </div>

              {/* Transaction Type & Category */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-700 font-semibold mb-1">Transaction Type</label>
                  <select
                    value={dealTransactionType}
                    onChange={(e: any) => setDealTransactionType(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-lg bg-white"
                  >
                    <option value="BUY">BUY (Outright Sale)</option>
                    <option value="RENT">RENT (Residential Lease)</option>
                    <option value="LEASE">LEASE (Commercial)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-700 font-semibold mb-1">Property Category</label>
                  <select
                    value={dealCategory}
                    onChange={(e: any) => setDealCategory(e.target.value)}
                    className="w-full p-2 border border-stone-200 rounded-lg bg-white"
                  >
                    <option value="RESIDENTIAL">RESIDENTIAL</option>
                    <option value="COMMERCIAL">COMMERCIAL</option>
                  </select>
                </div>
              </div>

              {/* Agreed Valuation */}
              <div>
                <label className="block text-stone-700 font-semibold mb-1">
                  {dealTransactionType === 'RENT' ? 'Agreed Monthly Rent (₹) *' : 'Agreed Transaction Value (₹) *'}
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={dealAgreedValue}
                  onChange={(e) => setDealAgreedValue(e.target.value)}
                  placeholder="e.g. 10000000"
                  className="w-full p-2.5 border border-stone-200 rounded-lg font-mono text-sm font-bold"
                />
              </div>

              {/* Commission Brokerage Settings */}
              <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-200/70 space-y-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900 block">
                  Brokerage & Commission Terms
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDealCommissionType('PERCENTAGE')}
                    className={`p-2 border rounded-lg font-semibold text-center cursor-pointer ${
                      dealCommissionType === 'PERCENTAGE'
                        ? 'border-amber-600 bg-amber-100/70 text-amber-950 font-bold'
                        : 'border-stone-200 bg-white text-stone-600'
                    }`}
                  >
                    Percentage (%)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDealCommissionType('FIXED_AMOUNT')}
                    className={`p-2 border rounded-lg font-semibold text-center cursor-pointer ${
                      dealCommissionType === 'FIXED_AMOUNT'
                        ? 'border-amber-600 bg-amber-100/70 text-amber-950 font-bold'
                        : 'border-stone-200 bg-white text-stone-600'
                    }`}
                  >
                    Fixed Fee (₹)
                  </button>
                </div>

                {dealCommissionType === 'PERCENTAGE' ? (
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Agreed Brokerage Rate (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="10"
                      value={dealCommissionRate}
                      onChange={(e) => setDealCommissionRate(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 border border-stone-200 rounded-lg bg-white font-mono"
                    />
                    <span className="text-[11px] text-stone-600 mt-1 block">
                      Estimated Brokerage: <span className="font-bold font-mono text-amber-900">
                        {formatPriceINR(((Number(dealAgreedValue) || 0) * (Number(dealCommissionRate) || 0)) / 100)}
                      </span>
                    </span>
                  </div>
                ) : (
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Fixed Brokerage Amount (₹)</label>
                    <input
                      type="number"
                      min="0"
                      value={dealCommissionAmount}
                      onChange={(e) => setDealCommissionAmount(e.target.value)}
                      placeholder="e.g. 150000"
                      className="w-full p-2 border border-stone-200 rounded-lg bg-white font-mono font-bold"
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Commission Payer</label>
                    <select
                      value={dealCommissionPayer}
                      onChange={(e) => setDealCommissionPayer(e.target.value)}
                      className="w-full p-2 border border-stone-200 rounded-lg bg-white"
                    >
                      <option value="BUYER">BUYER</option>
                      <option value="TENANT">TENANT</option>
                      <option value="OWNER">OWNER</option>
                      <option value="LANDLORD">LANDLORD</option>
                      <option value="BOTH_PARTIES">BOTH PARTIES</option>
                      <option value="OTHER">OTHER</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Expected Closing Date</label>
                    <input
                      type="date"
                      value={dealClosingDate}
                      onChange={(e) => setDealClosingDate(e.target.value)}
                      className="w-full p-2 border border-stone-200 rounded-lg bg-white font-mono"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">Deal Notes / Special Conditions</label>
                <textarea
                  rows={2}
                  value={dealNotes}
                  onChange={(e) => setDealNotes(e.target.value)}
                  placeholder="e.g. 10% token received, draft agreement submitted for legal vetting..."
                  className="w-full p-2 border border-stone-200 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setConvertModalOpen(false)}
                  className="px-4 py-2 border border-stone-200 rounded-xl font-semibold text-stone-700 hover:bg-stone-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={converting || !dealAgreedValue}
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer"
                >
                  <Briefcase className="w-4 h-4" />
                  <span>{converting ? 'Converting...' : 'Create Deal & Open Workspace'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
