import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Briefcase, 
  Search, 
  Filter, 
  ArrowRight, 
  TrendingUp, 
  IndianRupee, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Building2, 
  ChevronRight,
  LayoutGrid,
  List,
  Sparkles,
  Receipt,
  FileCheck2,
  Users
} from 'lucide-react';
import { api } from '../../services/api';
import { usePropertyContext } from '../../context/PropertyContext';
import { Deal, DealStatus, CommissionStatus, DealStats } from '../../types/deal';
import { formatCurrency } from '../../utils/formatters';

const STAGES: { id: DealStatus; label: string; color: string; badge: string }[] = [
  { id: 'NEGOTIATION', label: 'Negotiation', color: 'border-amber-400 bg-amber-50/50', badge: 'bg-amber-100 text-amber-800' },
  { id: 'AGREED', label: 'Terms Agreed', color: 'border-blue-400 bg-blue-50/50', badge: 'bg-blue-100 text-blue-800' },
  { id: 'AGREEMENT_PENDING', label: 'Agreement Drafting', color: 'border-purple-400 bg-purple-50/50', badge: 'bg-purple-100 text-purple-800' },
  { id: 'AGREEMENT_SIGNED', label: 'Agreement Signed', color: 'border-indigo-400 bg-indigo-50/50', badge: 'bg-indigo-100 text-indigo-800' },
  { id: 'PAYMENT_PENDING', label: 'Payment Pending', color: 'border-orange-400 bg-orange-50/50', badge: 'bg-orange-100 text-orange-800' },
  { id: 'COMPLETED', label: 'Closed & Won', color: 'border-emerald-500 bg-emerald-50/50', badge: 'bg-emerald-100 text-emerald-800' },
  { id: 'CANCELLED', label: 'Cancelled / Lost', color: 'border-rose-400 bg-rose-50/50', badge: 'bg-rose-100 text-rose-800' }
];

export const DealsPage: React.FC = () => {
  const { currentUser, showToast } = usePropertyContext();
  const navigate = useNavigate();

  const [deals, setDeals] = useState<Deal[]>([]);
  const [stats, setStats] = useState<DealStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // View mode: 'kanban' or 'list'
  const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [commissionStatusFilter, setCommissionStatusFilter] = useState('ALL');
  const [transactionTypeFilter, setTransactionTypeFilter] = useState('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    loadDeals();
  }, [currentUser, statusFilter, commissionStatusFilter, transactionTypeFilter, categoryFilter]);

  const loadDeals = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.deals.list({
        status: statusFilter,
        commission_status: commissionStatusFilter,
        transaction_type: transactionTypeFilter,
        category: categoryFilter,
        search: search.trim() || undefined
      });
      setDeals(res.deals || []);
      setStats(res.stats || null);
    } catch (err: any) {
      setError(err.message || 'Error loading transaction deals.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadDeals();
  };

  const filteredDeals = deals.filter(deal => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      deal.dealNumber.toLowerCase().includes(q) ||
      deal.property?.title.toLowerCase().includes(q) ||
      deal.property?.locality.toLowerCase().includes(q) ||
      deal.customer?.name.toLowerCase().includes(q) ||
      deal.customer?.mobile.includes(q)
    );
  });

  return (
    <div className="max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8 space-y-6 min-h-screen">
      
      {/* Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
            <Link to="/dashboard" className="hover:text-stone-900">Dashboard</Link>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="text-stone-900 font-semibold">Deals & Brokerage</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900 flex items-center gap-2.5">
            <Briefcase className="w-7 h-7 text-amber-600" />
            <span>Transaction Deals & Commission</span>
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Track deal stages, registered sale/lease agreements, brokerage fee calculations, and payments.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/dashboard/leads"
            className="px-3.5 py-2 border border-stone-300 rounded-xl text-xs font-semibold text-stone-700 hover:bg-stone-50 flex items-center gap-1.5 transition-colors"
          >
            <Users className="w-4 h-4 text-stone-500" />
            <span>View Leads Inbox</span>
          </Link>

          {/* View Mode Toggle */}
          <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200">
            <button
              onClick={() => setViewMode('kanban')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                viewMode === 'kanban' ? 'bg-white text-stone-950 shadow-2xs font-bold' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Pipeline</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                viewMode === 'list' ? 'bg-white text-stone-950 shadow-2xs font-bold' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Table</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>Active Pipeline</span>
              <TrendingUp className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-stone-900">
              {stats.activeDeals} Deals
            </div>
            <div className="text-[11px] text-stone-500">
              Total Deals: <span className="font-semibold">{stats.totalDeals}</span> ({stats.completedDeals} won)
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>Transaction Volume</span>
              <Building2 className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-stone-900">
              {formatCurrency(stats.totalVolume)}
            </div>
            <div className="text-[11px] text-stone-500">
              Agreed Sale & Lease values
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>Commission Booked</span>
              <IndianRupee className="w-4 h-4 text-purple-600" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-stone-900">
              {formatCurrency(stats.totalCommissionBooked)}
            </div>
            <div className="text-[11px] text-stone-500">
              Total brokerage agreed
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>Brokerage Collected</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-emerald-700">
              {formatCurrency(stats.totalCommissionCollected)}
            </div>
            <div className="text-[11px] text-amber-700 font-semibold">
              Due: {formatCurrency(stats.totalOutstandingCommission)}
            </div>
          </div>
        </div>
      )}

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              placeholder="Search by deal number, client name, mobile, property title or locality..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-stone-200 rounded-lg text-xs focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
          >
            Search
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-stone-100 text-xs">
          <div className="flex items-center gap-1.5 text-stone-500 font-semibold">
            <Filter className="w-3.5 h-3.5" />
            <span>Filters:</span>
          </div>

          {/* Transaction Type */}
          <select
            value={transactionTypeFilter}
            onChange={(e) => setTransactionTypeFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-stone-200 rounded-lg bg-stone-50 text-stone-700 font-medium"
          >
            <option value="ALL">All Transactions</option>
            <option value="BUY">Buy / Sale</option>
            <option value="RENT">Rent</option>
            <option value="LEASE">Commercial Lease</option>
          </select>

          {/* Category */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-stone-200 rounded-lg bg-stone-50 text-stone-700 font-medium"
          >
            <option value="ALL">All Categories</option>
            <option value="RESIDENTIAL">Residential</option>
            <option value="COMMERCIAL">Commercial</option>
          </select>

          {/* Commission Status */}
          <select
            value={commissionStatusFilter}
            onChange={(e) => setCommissionStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-stone-200 rounded-lg bg-stone-50 text-stone-700 font-medium"
          >
            <option value="ALL">All Commission Statuses</option>
            <option value="NOT_SET">Not Set</option>
            <option value="AGREED">Agreed</option>
            <option value="INVOICED">Invoiced</option>
            <option value="PARTIALLY_PAID">Partially Paid</option>
            <option value="PAID">Paid</option>
            <option value="WAIVED">Waived</option>
          </select>

          {/* Deal Status */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-stone-200 rounded-lg bg-stone-50 text-stone-700 font-medium"
          >
            <option value="ALL">All Deal Stages</option>
            <option value="NEGOTIATION">Negotiation</option>
            <option value="AGREED">Terms Agreed</option>
            <option value="AGREEMENT_PENDING">Agreement Pending</option>
            <option value="AGREEMENT_SIGNED">Agreement Signed</option>
            <option value="PAYMENT_PENDING">Payment Pending</option>
            <option value="COMPLETED">Completed</option>
            <option value="CANCELLED">Cancelled</option>
          </select>

          {(statusFilter !== 'ALL' || commissionStatusFilter !== 'ALL' || transactionTypeFilter !== 'ALL' || categoryFilter !== 'ALL' || search) && (
            <button
              onClick={() => {
                setStatusFilter('ALL');
                setCommissionStatusFilter('ALL');
                setTransactionTypeFilter('ALL');
                setCategoryFilter('ALL');
                setSearch('');
              }}
              className="text-[11px] text-amber-700 hover:underline font-semibold ml-auto cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="py-12 text-center text-xs text-stone-500">
          Loading deals and commission records...
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      ) : filteredDeals.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border border-stone-200 space-y-3">
          <Briefcase className="w-10 h-10 text-stone-400 mx-auto" />
          <h3 className="text-base font-bold text-stone-900">No Deals Found</h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            Deals are created when you convert qualified leads into active transactions from the Lead Detail page.
          </p>
          <Link
            to="/dashboard/leads"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 transition-colors"
          >
            <span>Open Leads Pipeline</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      ) : viewMode === 'kanban' ? (
        /* KANBAN / PIPELINE BOARD VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 overflow-x-auto pb-4">
          {STAGES.map(stage => {
            const stageDeals = filteredDeals.filter(d => d.dealStatus === stage.id);
            return (
              <div 
                key={stage.id} 
                className={`rounded-xl border ${stage.color} p-3 space-y-3 min-w-[280px] flex flex-col`}
              >
                <div className="flex items-center justify-between pb-2 border-b border-stone-200/60">
                  <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                    {stage.label}
                  </span>
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${stage.badge}`}>
                    {stageDeals.length}
                  </span>
                </div>

                <div className="space-y-3 flex-1 overflow-y-auto max-h-[650px] pr-1">
                  {stageDeals.length === 0 ? (
                    <div className="text-[11px] text-stone-400 italic text-center py-6">
                      No deals in this stage
                    </div>
                  ) : (
                    stageDeals.map(deal => (
                      <Link
                        key={deal.id}
                        to={`/dashboard/deals/${deal.id}`}
                        className="block bg-white p-3.5 rounded-xl border border-stone-200/80 shadow-2xs hover:border-amber-400 hover:shadow-xs transition-all space-y-2.5 group"
                      >
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-mono font-bold text-stone-500 group-hover:text-amber-700">
                            {deal.dealNumber}
                          </span>
                          <span className="text-[10px] font-bold uppercase font-mono px-1.5 py-0.5 rounded bg-stone-100 text-stone-700">
                            {deal.transactionType}
                          </span>
                        </div>

                        <div>
                          <h4 className="font-bold text-xs text-stone-900 line-clamp-1 group-hover:text-amber-800">
                            {deal.property?.title}
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            {deal.property?.locality}
                          </p>
                        </div>

                        <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                          <span className="text-[11px] text-stone-600 font-medium">
                            Client: {deal.customer?.name}
                          </span>
                          <span className="font-mono font-bold text-stone-900">
                            {formatCurrency(deal.agreedPropertyValue || deal.agreedRent || deal.agreedLeaseValue || 0)}
                          </span>
                        </div>

                        <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-[11px]">
                          <span className="text-stone-500">Commission:</span>
                          <div className="text-right">
                            <span className="font-mono font-bold text-amber-700">
                              {formatCurrency(deal.commissionAmount)}
                            </span>
                            <span className={`block text-[9px] font-mono uppercase font-bold ${
                              deal.commissionStatus === 'PAID' ? 'text-emerald-600' :
                              deal.commissionStatus === 'PARTIALLY_PAID' ? 'text-blue-600' :
                              'text-stone-500'
                            }`}>
                              {deal.commissionStatus}
                            </span>
                          </div>
                        </div>
                      </Link>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* TABLE / LIST VIEW */
        <div className="bg-white rounded-xl border border-stone-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 text-stone-600 font-mono text-[10px] uppercase border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4">Deal Number</th>
                  <th className="py-3 px-4">Property</th>
                  <th className="py-3 px-4">Client</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4 text-right">Agreed Valuation</th>
                  <th className="py-3 px-4 text-right">Commission</th>
                  <th className="py-3 px-4 text-center">Commission Status</th>
                  <th className="py-3 px-4 text-center">Deal Stage</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredDeals.map(deal => (
                  <tr key={deal.id} className="hover:bg-amber-50/30 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-stone-800">
                      <Link to={`/dashboard/deals/${deal.id}`} className="hover:text-amber-700">
                        {deal.dealNumber}
                      </Link>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="font-bold text-stone-900 line-clamp-1">{deal.property?.title}</p>
                      <p className="text-[11px] text-stone-500">{deal.property?.locality}</p>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="font-semibold text-stone-900">{deal.customer?.name}</p>
                      <p className="text-[11px] text-stone-500 font-mono">{deal.customer?.mobile}</p>
                    </td>

                    <td className="py-3.5 px-4 font-mono uppercase text-[11px]">
                      <span className="px-2 py-0.5 rounded bg-stone-100 text-stone-700 font-semibold">
                        {deal.transactionType}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-stone-900">
                      {formatCurrency(deal.agreedPropertyValue || deal.agreedRent || deal.agreedLeaseValue || 0)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-semibold text-amber-700">
                      {formatCurrency(deal.commissionAmount)}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                        deal.commissionStatus === 'PAID' ? 'bg-emerald-100 text-emerald-800' :
                        deal.commissionStatus === 'PARTIALLY_PAID' ? 'bg-blue-100 text-blue-800' :
                        deal.commissionStatus === 'INVOICED' ? 'bg-purple-100 text-purple-800' :
                        deal.commissionStatus === 'AGREED' ? 'bg-amber-100 text-amber-800' :
                        'bg-stone-100 text-stone-600'
                      }`}>
                        {deal.commissionStatus}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-stone-100 text-stone-700 border border-stone-200">
                        {deal.dealStatus}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <Link
                        to={`/dashboard/deals/${deal.id}`}
                        className="inline-flex items-center gap-1 px-3 py-1 bg-stone-900 hover:bg-stone-800 text-white rounded-md text-[11px] font-semibold transition-colors"
                      >
                        <span>Workspace</span>
                        <ArrowRight className="w-3 h-3" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
};
