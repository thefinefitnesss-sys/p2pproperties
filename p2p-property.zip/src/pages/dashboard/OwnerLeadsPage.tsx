import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Users, 
  Plus, 
  Search, 
  Filter, 
  Kanban, 
  List, 
  ArrowRight, 
  Clock, 
  Phone, 
  MessageSquare, 
  Calendar, 
  Building2, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  ChevronRight, 
  TrendingUp, 
  Sparkles,
  ArrowUpRight,
  ExternalLink,
  RefreshCw,
  PlusCircle,
  X,
  FileText
} from 'lucide-react';
import { useProperty } from '../../context/PropertyContext';
import { api } from '../../services/api';
import { Lead, LeadStatus, LeadPriority } from '../../types/lead';
import { formatPriceINR } from '../../utils/formatters';

const STAGES: { key: LeadStatus; label: string; color: string; border: string; bg: string }[] = [
  { key: 'NEW', label: 'New Inquiries', color: 'text-blue-700', border: 'border-blue-200', bg: 'bg-blue-50/60' },
  { key: 'CONTACTED', label: 'Contacted', color: 'text-purple-700', border: 'border-purple-200', bg: 'bg-purple-50/60' },
  { key: 'QUALIFIED', label: 'Qualified', color: 'text-amber-700', border: 'border-amber-200', bg: 'bg-amber-50/60' },
  { key: 'SITE_VISIT', label: 'Site Visits', color: 'text-indigo-700', border: 'border-indigo-200', bg: 'bg-indigo-50/60' },
  { key: 'NEGOTIATING', label: 'Negotiating', color: 'text-orange-700', border: 'border-orange-200', bg: 'bg-orange-50/60' },
  { key: 'WON', label: 'Won Deals', color: 'text-emerald-700', border: 'border-emerald-200', bg: 'bg-emerald-50/60' },
];

export const OwnerLeadsPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, showToast } = useProperty();

  const [leads, setLeads] = useState<Lead[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [priorityFilter, setPriorityFilter] = useState('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  // WhatsApp business number
  const [businessWhatsApp, setBusinessWhatsApp] = useState('+919820098200');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [noteModalLead, setNoteModalLead] = useState<Lead | null>(null);
  const [noteText, setNoteText] = useState('');
  const [followUpModalLead, setFollowUpModalLead] = useState<Lead | null>(null);
  const [followUpDate, setFollowUpDate] = useState('');
  const [followUpTime, setFollowUpTime] = useState('11:00 AM');
  const [followUpNote, setFollowUpNote] = useState('');

  // New Lead form state
  const [newLeadForm, setNewLeadForm] = useState({
    name: '',
    mobile: '',
    email: '',
    requirement_type: 'residential',
    bhk: '2 BHK',
    business_type: 'Office',
    budget: '',
    source: 'PHONE',
    priority: 'MEDIUM',
    notes: '',
    preferred_contact_method: 'PHONE'
  });

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    if (currentUser.role === 'buyer' || currentUser.role === 'tenant') {
      showToast('Lead Inbox is reserved for property owners and verified agents.');
      navigate('/dashboard');
      return;
    }
    loadLeads();
    loadWhatsAppConfig();
  }, [currentUser]);

  const loadLeads = async () => {
    setLoading(true);
    try {
      const res = await api.leads.list({
        status: statusFilter,
        priority: priorityFilter,
        category: categoryFilter,
        search
      });
      setLeads(res.leads || []);
      setStats(res.stats || null);
    } catch (err: any) {
      showToast(err.message || 'Error loading leads.');
    } finally {
      setLoading(false);
    }
  };

  const loadWhatsAppConfig = async () => {
    try {
      const cfg = await api.leads.getWhatsAppConfig();
      if (cfg?.businessNumber) setBusinessWhatsApp(cfg.businessNumber);
    } catch {}
  };

  const handleStatusChange = async (leadId: string, newStatus: string) => {
    try {
      await api.leads.updateStatus(leadId, newStatus);
      showToast(`Lead moved to ${newStatus}`);
      loadLeads();
    } catch (err: any) {
      showToast(err.message || 'Error updating status.');
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteModalLead || !noteText.trim()) return;
    try {
      await api.leads.addNote(noteModalLead.id, noteText);
      showToast('Internal note saved to timeline.');
      setNoteModalLead(null);
      setNoteText('');
      loadLeads();
    } catch (err: any) {
      showToast(err.message || 'Error adding note.');
    }
  };

  const handleScheduleFollowUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!followUpModalLead || !followUpDate || !followUpNote.trim()) return;
    try {
      await api.leads.scheduleFollowUp(followUpModalLead.id, {
        follow_up_date: followUpDate,
        follow_up_time: followUpTime,
        note: followUpNote
      });
      showToast('Follow-up scheduled.');
      setFollowUpModalLead(null);
      setFollowUpDate('');
      setFollowUpNote('');
      loadLeads();
    } catch (err: any) {
      showToast(err.message || 'Error scheduling follow-up.');
    }
  };

  const handleCreateLead = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.leads.create({
        ...newLeadForm,
        budget: newLeadForm.budget ? Number(newLeadForm.budget) : undefined
      });
      showToast('New lead added to pipeline.');
      setCreateModalOpen(false);
      setNewLeadForm({
        name: '',
        mobile: '',
        email: '',
        requirement_type: 'residential',
        bhk: '2 BHK',
        business_type: 'Office',
        budget: '',
        source: 'PHONE',
        priority: 'MEDIUM',
        notes: '',
        preferred_contact_method: 'PHONE'
      });
      loadLeads();
    } catch (err: any) {
      showToast(err.message || 'Error creating lead.');
    }
  };

  const openWhatsAppChat = (lead: Lead) => {
    const phoneClean = lead.customer?.mobile ? lead.customer.mobile.replace(/[^0-9]/g, '') : '';
    const propTitle = lead.property?.title || 'Mumbai listing';
    const text = encodeURIComponent(
      `Hello ${lead.customer?.name || 'Customer'}, this is regarding your inquiry for "${propTitle}" on P2P Property Mumbai. Are you available for a quick discussion?`
    );
    // Use customer's phone if available, or official business WhatsApp desk
    const target = phoneClean && phoneClean.length >= 10 ? phoneClean : businessWhatsApp.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${target}?text=${text}`, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8 space-y-6 min-h-screen">
      
      {/* Top Breadcrumb & Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
            <Link to="/dashboard" className="hover:text-stone-900 transition-colors">Dashboard</Link>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="text-stone-800 font-medium">Leads & Pipeline</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900">
            Prospect & Deal Pipeline
          </h1>
          <p className="text-xs text-stone-600 mt-0.5">
            Real-time inquiries, site visits, qualification milestones, and buyer follow-ups.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Inbound Lead</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          <div className="bg-white p-3.5 rounded-xl border border-stone-200 shadow-2xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500 block">Total Leads</span>
            <span className="text-xl font-bold text-stone-900 font-serif">{stats.totalLeads}</span>
          </div>
          <div className="bg-blue-50/60 p-3.5 rounded-xl border border-blue-200/80 shadow-2xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block">New Enquiries</span>
            <span className="text-xl font-bold text-blue-900 font-serif">{stats.newLeads}</span>
          </div>
          <div className="bg-purple-50/60 p-3.5 rounded-xl border border-purple-200/80 shadow-2xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700 block">Contacted</span>
            <span className="text-xl font-bold text-purple-900 font-serif">{stats.contacted}</span>
          </div>
          <div className="bg-indigo-50/60 p-3.5 rounded-xl border border-indigo-200/80 shadow-2xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 block">Site Visits</span>
            <span className="text-xl font-bold text-indigo-900 font-serif">{stats.siteVisits}</span>
          </div>
          <div className="bg-orange-50/60 p-3.5 rounded-xl border border-orange-200/80 shadow-2xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-orange-700 block">Negotiating</span>
            <span className="text-xl font-bold text-orange-900 font-serif">{stats.negotiating}</span>
          </div>
          <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200/80 shadow-2xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block">Deals Won</span>
            <span className="text-xl font-bold text-emerald-900 font-serif">{stats.won}</span>
          </div>
          <div className="bg-amber-50/60 p-3.5 rounded-xl border border-amber-200/80 shadow-2xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 block">Pending Tasks</span>
            <span className="text-xl font-bold text-amber-950 font-serif">{stats.upcomingFollowUps}</span>
          </div>
        </div>
      )}

      {/* Filter and View Controls Bar */}
      <div className="bg-white p-3 sm:p-4 rounded-xl border border-stone-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          {/* Search box */}
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadLeads()}
              placeholder="Search name, phone, property..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
            />
          </div>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); }}
            className="text-xs py-1.5 px-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
          >
            <option value="ALL">All Statuses</option>
            <option value="NEW">New</option>
            <option value="CONTACTED">Contacted</option>
            <option value="QUALIFIED">Qualified</option>
            <option value="SITE_VISIT">Site Visit</option>
            <option value="NEGOTIATING">Negotiating</option>
            <option value="WON">Won</option>
            <option value="LOST">Lost</option>
          </select>

          {/* Priority filter */}
          <select
            value={priorityFilter}
            onChange={(e) => { setPriorityFilter(e.target.value); }}
            className="text-xs py-1.5 px-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
          >
            <option value="ALL">All Priorities</option>
            <option value="URGENT">Urgent</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>

          {/* Category filter */}
          <select
            value={categoryFilter}
            onChange={(e) => { setCategoryFilter(e.target.value); }}
            className="text-xs py-1.5 px-2.5 bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
          >
            <option value="ALL">All Categories</option>
            <option value="residential">Residential</option>
            <option value="commercial">Commercial</option>
          </select>

          <button
            type="button"
            onClick={loadLeads}
            className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
            title="Refresh list"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center gap-1 bg-stone-100 p-0.5 rounded-lg border border-stone-200 shrink-0 self-end md:self-auto">
          <button
            type="button"
            onClick={() => setViewMode('kanban')}
            className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
              viewMode === 'kanban' 
                ? 'bg-white text-stone-900 shadow-2xs' 
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Kanban className="w-3.5 h-3.5" />
            <span>Kanban</span>
          </button>
          <button
            type="button"
            onClick={() => setViewMode('table')}
            className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
              viewMode === 'table' 
                ? 'bg-white text-stone-900 shadow-2xs' 
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <List className="w-3.5 h-3.5" />
            <span>Table</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {loading ? (
        <div className="p-12 text-center text-xs text-stone-500 bg-white rounded-xl border border-stone-200">
          <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-stone-400" />
          Loading Mumbai leads pipeline...
        </div>
      ) : leads.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-stone-200 space-y-3">
          <Users className="w-10 h-10 text-stone-300 mx-auto" />
          <h3 className="font-bold text-stone-800">No leads match criteria</h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            When buyers or tenants submit inquiries on your Mumbai properties, they will automatically appear here.
          </p>
          <button
            onClick={() => setCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-stone-900 rounded-md"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Register First Inbound Lead</span>
          </button>
        </div>
      ) : viewMode === 'kanban' ? (
        /* Kanban Pipeline View */
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 overflow-x-auto pb-6">
          {STAGES.map((st) => {
            const stageLeads = leads.filter((l) => l.status === st.key);
            return (
              <div key={st.key} className="flex flex-col bg-stone-100/70 rounded-xl p-3 border border-stone-200/90 min-w-[270px]">
                {/* Column Header */}
                <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-stone-200">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${
                      st.key === 'WON' ? 'bg-emerald-500' : 
                      st.key === 'SITE_VISIT' ? 'bg-indigo-500' :
                      st.key === 'NEGOTIATING' ? 'bg-orange-500' : 'bg-blue-500'
                    }`} />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-stone-800">
                      {st.label}
                    </h3>
                  </div>
                  <span className="text-[11px] font-bold px-1.5 py-0.5 rounded-full bg-white text-stone-700 border border-stone-200 shadow-2xs font-mono">
                    {stageLeads.length}
                  </span>
                </div>

                {/* Cards Container */}
                <div className="space-y-3 flex-1 overflow-y-auto max-h-[70vh] pr-0.5">
                  {stageLeads.map((lead) => (
                    <div 
                      key={lead.id}
                      className="bg-white rounded-lg p-3 border border-stone-200 shadow-2xs hover:shadow-xs transition-shadow space-y-2.5 text-xs"
                    >
                      {/* Priority and Source row */}
                      <div className="flex items-center justify-between text-[10px]">
                        <span className={`px-1.5 py-0.5 rounded-sm font-semibold uppercase tracking-wider font-mono ${
                          lead.priority === 'URGENT' ? 'bg-rose-100 text-rose-800 border border-rose-200' :
                          lead.priority === 'HIGH' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                          'bg-stone-100 text-stone-600'
                        }`}>
                          {lead.priority}
                        </span>
                        <span className="text-stone-400 font-mono text-[9px] uppercase">
                          {lead.source.replace('_', ' ')}
                        </span>
                      </div>

                      {/* Customer Name & Requirement */}
                      <div>
                        <Link 
                          to={`/dashboard/leads/${lead.id}`}
                          className="font-bold text-stone-900 hover:text-amber-800 transition-colors block text-[13px] leading-tight"
                        >
                          {lead.customer?.name}
                        </Link>
                        <div className="text-[11px] text-stone-500 mt-0.5 flex items-center gap-1.5">
                          <span className="font-medium text-stone-700">{lead.customer?.customerType}</span>
                          <span>·</span>
                          <span>{lead.bhk || lead.businessType || 'Listing Inquiry'}</span>
                        </div>
                      </div>

                      {/* Property badge / thumbnail */}
                      {lead.property && (
                        <div className="flex items-center gap-2 p-1.5 rounded-md bg-stone-50 border border-stone-200/80">
                          <img 
                            src={lead.property.primaryImage || '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg'} 
                            alt="" 
                            className="w-8 h-8 rounded-sm object-cover shrink-0" 
                          />
                          <div className="min-w-0 flex-1">
                            <p className="text-[11px] font-medium text-stone-800 truncate leading-tight">
                              {lead.property.title}
                            </p>
                            <p className="text-[10px] text-stone-500 font-serif">
                              {formatPriceINR(lead.property.price, 'total')}
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Next follow up info if present */}
                      {lead.nextFollowUp && (
                        <div className="text-[10px] flex items-center gap-1 text-amber-800 bg-amber-50 px-2 py-1 rounded border border-amber-200/60">
                          <Calendar className="w-3 h-3 shrink-0" />
                          <span className="truncate">Next: {lead.nextFollowUp.followUpDate} ({lead.nextFollowUp.followUpTime || 'TBD'})</span>
                        </div>
                      )}

                      {/* Quick Communication Actions */}
                      <div className="pt-1 border-t border-stone-100 flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          {lead.customer?.mobile && (
                            <button
                              type="button"
                              onClick={() => openWhatsAppChat(lead)}
                              className="p-1 text-emerald-700 hover:bg-emerald-50 rounded transition-colors"
                              title="Chat on WhatsApp"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {lead.customer?.mobile && (
                            <a
                              href={`tel:${lead.customer.mobile}`}
                              className="p-1 text-stone-700 hover:bg-stone-100 rounded transition-colors"
                              title="Direct Phone Call"
                            >
                              <Phone className="w-3.5 h-3.5" />
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={() => { setFollowUpModalLead(lead); setFollowUpDate(new Date().toISOString().split('T')[0]); }}
                            className="p-1 text-stone-700 hover:bg-stone-100 rounded transition-colors"
                            title="Schedule Follow-up"
                          >
                            <Calendar className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setNoteModalLead(lead)}
                            className="p-1 text-stone-700 hover:bg-stone-100 rounded transition-colors"
                            title="Add Note"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Stage Progression Selector */}
                        <select
                          value={lead.status}
                          onChange={(e) => handleStatusChange(lead.id, e.target.value)}
                          className="text-[10px] font-medium py-0.5 px-1 bg-stone-50 border border-stone-200 rounded text-stone-700 focus:outline-hidden"
                        >
                          <option value="NEW">New</option>
                          <option value="CONTACTED">Contacted</option>
                          <option value="QUALIFIED">Qualified</option>
                          <option value="SITE_VISIT">Site Visit</option>
                          <option value="NEGOTIATING">Negotiate</option>
                          <option value="WON">Won Deal</option>
                          <option value="LOST">Mark Lost</option>
                        </select>
                      </div>

                    </div>
                  ))}

                  {stageLeads.length === 0 && (
                    <div className="py-6 text-center text-[11px] text-stone-400 italic">
                      Empty stage
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Table View */
        <div className="bg-white rounded-xl border border-stone-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-600 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Property</th>
                  <th className="py-3 px-4">Requirement</th>
                  <th className="py-3 px-4">Stage</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Next Follow-up</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {leads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-stone-50/70 transition-colors">
                    <td className="py-3.5 px-4">
                      <Link 
                        to={`/dashboard/leads/${lead.id}`}
                        className="font-bold text-stone-900 hover:text-amber-800 transition-colors text-[13px] block"
                      >
                        {lead.customer?.name}
                      </Link>
                      <div className="text-[11px] text-stone-500 flex items-center gap-2 mt-0.5">
                        <span>{lead.customer?.mobile}</span>
                        <span>·</span>
                        <span>{lead.customer?.email}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 max-w-[220px]">
                      {lead.property ? (
                        <div>
                          <p className="font-medium text-stone-900 truncate">{lead.property.title}</p>
                          <p className="text-[11px] text-stone-500 font-serif">
                            {lead.property.locality} · {formatPriceINR(lead.property.price, 'total')}
                          </p>
                        </div>
                      ) : (
                        <span className="text-stone-400 italic">General Inquiry</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-[11px]">
                        <span className="font-semibold text-stone-800">{lead.bhk || lead.businessType || lead.requirementType}</span>
                        <p className="text-stone-500 text-[10px]">
                          Budget: {lead.budget ? formatPriceINR(lead.budget, 'total') : 'Open'}
                        </p>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <select
                        value={lead.status}
                        onChange={(e) => handleStatusChange(lead.id, e.target.value)}
                        className={`text-[11px] font-bold py-1 px-2 rounded-md border text-stone-800 ${
                          lead.status === 'WON' ? 'bg-emerald-50 border-emerald-300 text-emerald-800' :
                          lead.status === 'NEGOTIATING' ? 'bg-orange-50 border-orange-300 text-orange-800' :
                          lead.status === 'SITE_VISIT' ? 'bg-indigo-50 border-indigo-300 text-indigo-800' :
                          'bg-stone-50 border-stone-200'
                        }`}
                      >
                        <option value="NEW">NEW</option>
                        <option value="CONTACTED">CONTACTED</option>
                        <option value="QUALIFIED">QUALIFIED</option>
                        <option value="SITE_VISIT">SITE VISIT</option>
                        <option value="NEGOTIATING">NEGOTIATING</option>
                        <option value="WON">WON</option>
                        <option value="LOST">LOST</option>
                      </select>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 rounded-sm font-semibold uppercase text-[10px] font-mono ${
                        lead.priority === 'URGENT' ? 'bg-rose-100 text-rose-800' :
                        lead.priority === 'HIGH' ? 'bg-amber-100 text-amber-800' :
                        'bg-stone-100 text-stone-700'
                      }`}>
                        {lead.priority}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-stone-600 text-[11px]">
                      {lead.nextFollowUp ? (
                        <span className="text-amber-800 font-medium">
                          {lead.nextFollowUp.followUpDate} ({lead.nextFollowUp.followUpTime || 'TBD'})
                        </span>
                      ) : (
                        <span className="text-stone-400">None scheduled</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => openWhatsAppChat(lead)}
                          className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors"
                          title="WhatsApp Direct"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </button>
                        <Link
                          to={`/dashboard/leads/${lead.id}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md border border-stone-200 text-stone-700 hover:bg-stone-50 transition-colors"
                        >
                          <span>View</span>
                          <ArrowRight className="w-3 h-3" />
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Lead Modal */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full border border-stone-200 overflow-hidden relative max-h-[90vh] flex flex-col">
            <button
              onClick={() => setCreateModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="p-5 border-b border-stone-100 bg-[#FAF9F5]">
              <h3 className="text-base font-bold text-stone-900 font-serif">
                Register Inbound Lead
              </h3>
              <p className="text-xs text-stone-600 mt-0.5">
                Record a walk-in, phone caller, referral, or off-market buyer inquiry.
              </p>
            </div>

            <form onSubmit={handleCreateLead} className="p-5 space-y-3.5 text-xs overflow-y-auto flex-1">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Customer Full Name *</label>
                  <input
                    type="text"
                    value={newLeadForm.name}
                    onChange={(e) => setNewLeadForm({ ...newLeadForm, name: e.target.value })}
                    required
                    placeholder="e.g. Anand Piramal"
                    className="w-full px-3 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  />
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    value={newLeadForm.mobile}
                    onChange={(e) => setNewLeadForm({ ...newLeadForm, mobile: e.target.value })}
                    required
                    placeholder="+91 98200 XXXXX"
                    className="w-full px-3 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={newLeadForm.email}
                    onChange={(e) => setNewLeadForm({ ...newLeadForm, email: e.target.value })}
                    placeholder="buyer@domain.com"
                    className="w-full px-3 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  />
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Lead Source</label>
                  <select
                    value={newLeadForm.source}
                    onChange={(e) => setNewLeadForm({ ...newLeadForm, source: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md bg-white focus:outline-hidden"
                  >
                    <option value="PHONE">Phone Call</option>
                    <option value="WHATSAPP">WhatsApp</option>
                    <option value="WEBSITE">Website</option>
                    <option value="REFERRAL">Referral</option>
                    <option value="PROPERTY_ENQUIRY">Property Listing</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Requirement Type</label>
                  <select
                    value={newLeadForm.requirement_type}
                    onChange={(e) => setNewLeadForm({ ...newLeadForm, requirement_type: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md bg-white focus:outline-hidden"
                  >
                    <option value="residential">Residential</option>
                    <option value="commercial">Commercial</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">
                    {newLeadForm.requirement_type === 'commercial' ? 'Business Type' : 'Desired BHK'}
                  </label>
                  {newLeadForm.requirement_type === 'commercial' ? (
                    <select
                      value={newLeadForm.business_type}
                      onChange={(e) => setNewLeadForm({ ...newLeadForm, business_type: e.target.value })}
                      className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md bg-white focus:outline-hidden"
                    >
                      <option value="Office">Office</option>
                      <option value="Shop">Shop</option>
                      <option value="Showroom">Showroom</option>
                      <option value="Warehouse">Warehouse</option>
                      <option value="Restaurant">Restaurant</option>
                      <option value="Clinic">Clinic</option>
                    </select>
                  ) : (
                    <select
                      value={newLeadForm.bhk}
                      onChange={(e) => setNewLeadForm({ ...newLeadForm, bhk: e.target.value })}
                      className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md bg-white focus:outline-hidden"
                    >
                      <option value="1 BHK">1 BHK</option>
                      <option value="2 BHK">2 BHK</option>
                      <option value="3 BHK">3 BHK</option>
                      <option value="4+ BHK">4+ BHK</option>
                      <option value="Penthouse">Penthouse</option>
                    </select>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Budget (₹ INR)</label>
                  <input
                    type="number"
                    value={newLeadForm.budget}
                    onChange={(e) => setNewLeadForm({ ...newLeadForm, budget: e.target.value })}
                    placeholder="e.g. 85000000"
                    className="w-full px-3 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                  />
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Priority</label>
                  <select
                    value={newLeadForm.priority}
                    onChange={(e) => setNewLeadForm({ ...newLeadForm, priority: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-stone-200 rounded-md bg-white focus:outline-hidden"
                  >
                    <option value="LOW">Low</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="HIGH">High</option>
                    <option value="URGENT">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Initial Discussion Notes</label>
                <textarea
                  rows={2}
                  value={newLeadForm.notes}
                  onChange={(e) => setNewLeadForm({ ...newLeadForm, notes: e.target.value })}
                  placeholder="Key buyer criteria, financing readiness, timeline..."
                  className="w-full px-3 py-1.5 border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 border border-stone-200 text-stone-700 hover:bg-stone-50 rounded-md font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-md font-semibold"
                >
                  Save Lead
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Note Modal */}
      {noteModalLead && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-stone-900 text-sm">Add Note for {noteModalLead.customer?.name}</h3>
              <button onClick={() => setNoteModalLead(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddNote} className="space-y-3">
              <textarea
                rows={3}
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                required
                placeholder="Log discussion notes, buyer feedback, price proposal..."
                className="w-full p-2.5 text-xs border border-stone-200 rounded-md focus:outline-hidden focus:border-stone-900"
              />
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setNoteModalLead(null)} className="px-3 py-1.5 text-xs border border-stone-200 rounded-md">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 text-xs bg-stone-900 text-white rounded-md font-semibold">
                  Save Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Follow-up Modal */}
      {followUpModalLead && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-stone-900 text-sm">Schedule Follow-up: {followUpModalLead.customer?.name}</h3>
              <button onClick={() => setFollowUpModalLead(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleScheduleFollowUp} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Date *</label>
                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    required
                    className="w-full p-2 border border-stone-200 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Time Slot</label>
                  <input
                    type="text"
                    value={followUpTime}
                    onChange={(e) => setFollowUpTime(e.target.value)}
                    placeholder="e.g. 11:30 AM"
                    className="w-full p-2 border border-stone-200 rounded-md"
                  />
                </div>
              </div>
              <div>
                <label className="block text-stone-700 font-medium mb-1">Follow-up Agenda *</label>
                <textarea
                  rows={2}
                  value={followUpNote}
                  onChange={(e) => setFollowUpNote(e.target.value)}
                  required
                  placeholder="e.g. Call to discuss revised token amount and share floor plan."
                  className="w-full p-2 border border-stone-200 rounded-md"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={() => setFollowUpModalLead(null)} className="px-3 py-1.5 border border-stone-200 rounded-md">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 bg-stone-900 text-white rounded-md font-semibold">
                  Schedule Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
