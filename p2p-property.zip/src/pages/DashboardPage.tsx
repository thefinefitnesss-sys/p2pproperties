import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Building2, 
  PlusCircle, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  MessageSquare, 
  Calendar, 
  Bookmark, 
  Edit3, 
  Trash2, 
  ExternalLink,
  ChevronRight,
  Filter,
  Check,
  X,
  Phone,
  Mail,
  User as UserIcon,
  Users,
  Eye,
  Briefcase
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { api } from '../services/api';
import { formatPriceINR, formatArea } from '../utils/formatters';

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, showToast } = useProperty();

  const [activeTab, setActiveTab] = useState<'properties' | 'inquiries' | 'visits' | 'saved'>('properties');
  const [propertyFilter, setPropertyFilter] = useState<'ALL' | 'APPROVED' | 'PENDING_APPROVAL' | 'DRAFT' | 'REJECTED'>('ALL');

  const [myProperties, setMyProperties] = useState<any[]>([]);
  const [inquiries, setInquiries] = useState<{ received: any[]; sent: any[] }>({ received: [], sent: [] });
  const [siteVisits, setSiteVisits] = useState<{ received: any[]; sent: any[] }>({ received: [], sent: [] });
  const [savedProperties, setSavedProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Quick edit modal state
  const [editModalProperty, setEditModalProperty] = useState<any | null>(null);
  const [editPrice, setEditPrice] = useState<string>('');
  const [editTitle, setEditTitle] = useState<string>('');
  const [editSaving, setEditSaving] = useState(false);

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    loadDashboardData();
  }, [currentUser, navigate]);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const [propsRes, inqRes, visitsRes, savedRes] = await Promise.all([
        api.dashboard.myProperties(),
        api.dashboard.myInquiries(),
        api.dashboard.mySiteVisits(),
        api.savedProperties.list()
      ]);

      setMyProperties(propsRes.properties || []);
      setInquiries(inqRes || { received: [], sent: [] });
      setSiteVisits(visitsRes || { received: [], sent: [] });
      setSavedProperties(savedRes.properties || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading dashboard data.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (propId: string, status: string) => {
    try {
      await api.properties.updateStatus(propId, status);
      showToast(`Property status updated to ${status}.`);
      loadDashboardData();
    } catch (err: any) {
      showToast(err.message || 'Error updating status.');
    }
  };

  const handleDeleteProperty = async (propId: string) => {
    if (!window.confirm('Are you sure you want to delete this property listing? This action cannot be undone.')) {
      return;
    }
    try {
      await api.properties.delete(propId);
      showToast('Property listing deleted.');
      loadDashboardData();
    } catch (err: any) {
      showToast(err.message || 'Error deleting property.');
    }
  };

  const handleSaveQuickEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModalProperty) return;

    setEditSaving(true);
    try {
      await api.properties.update(editModalProperty.id, {
        title: editTitle,
        price: Number(editPrice)
      });
      showToast('Property details updated successfully.');
      setEditModalProperty(null);
      loadDashboardData();
    } catch (err: any) {
      showToast(err.message || 'Failed to update property.');
    } finally {
      setEditSaving(false);
    }
  };

  const handleUpdateInquiryStatus = async (inqId: string, status: string) => {
    try {
      await api.inquiries.updateStatus(inqId, status);
      showToast(`Inquiry marked as ${status}.`);
      loadDashboardData();
    } catch (err: any) {
      showToast(err.message || 'Failed to update inquiry status.');
    }
  };

  const handleUpdateVisitStatus = async (visitId: string, status: string) => {
    try {
      await api.siteVisits.updateStatus(visitId, status);
      showToast(`Site visit updated to ${status}.`);
      loadDashboardData();
    } catch (err: any) {
      showToast(err.message || 'Failed to update visit status.');
    }
  };

  // Counts for badge
  const pendingCount = myProperties.filter((p) => p.status === 'PENDING_APPROVAL').length;
  const approvedCount = myProperties.filter((p) => p.status === 'APPROVED').length;
  const draftCount = myProperties.filter((p) => p.status === 'DRAFT').length;
  const rejectedCount = myProperties.filter((p) => p.status === 'REJECTED').length;

  const filteredProperties = myProperties.filter((p) => {
    if (propertyFilter === 'ALL') return true;
    return p.status === propertyFilter;
  });

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8 min-h-screen">
      
      {/* Top Banner */}
      <div className="bg-[#FAF9F5] border border-stone-200 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-800">
              Workspace & Listings Hub
            </span>
            <span className="text-stone-300">·</span>
            <span className="capitalize font-mono text-[11px] text-stone-600 bg-stone-200/80 px-2 py-0.5 rounded">
              {currentUser?.role}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900">
            Welcome back, {currentUser?.name}
          </h1>
          <p className="text-xs text-stone-600">
            Manage your Mumbai property listings, direct inquiries, site visit requests, and saved watchlists.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {(currentUser?.role === 'owner' || currentUser?.role === 'agent' || currentUser?.role === 'admin') && (
            <Link
              to="/dashboard/leads"
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-amber-950 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-lg shadow-sm transition-colors"
            >
              <Users className="w-4 h-4 text-amber-800" />
              <span>Leads & Pipeline</span>
            </Link>
          )}
          <Link
            to="/list-property"
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
          >
            <PlusCircle className="w-4 h-4 text-amber-400" />
            <span>Post New Listing</span>
          </Link>
          {currentUser?.role === 'admin' && (
            <Link
              to="/admin"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-stone-900 bg-amber-200 hover:bg-amber-300 rounded-lg transition-colors"
            >
              <span>Admin Console</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          )}
        </div>
      </div>

      {/* Metric Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="bg-white p-4 rounded-xl border border-stone-200">
          <span className="text-[11px] text-stone-500 font-medium">My Listings</span>
          <p className="text-xl font-bold font-serif text-stone-900 mt-1">{myProperties.length}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-stone-200">
          <span className="text-[11px] text-amber-700 font-medium">Pending Review</span>
          <p className="text-xl font-bold font-serif text-amber-900 mt-1">{pendingCount}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-stone-200">
          <span className="text-[11px] text-emerald-700 font-medium">Live Approved</span>
          <p className="text-xl font-bold font-serif text-emerald-900 mt-1">{approvedCount}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-stone-200">
          <span className="text-[11px] text-stone-500 font-medium">Drafts</span>
          <p className="text-xl font-bold font-serif text-stone-900 mt-1">{draftCount}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-stone-200">
          <span className="text-[11px] text-stone-500 font-medium">Enquiries</span>
          <p className="text-xl font-bold font-serif text-stone-900 mt-1">{inquiries.received.length}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-stone-200">
          <span className="text-[11px] text-stone-500 font-medium">Site Visits</span>
          <p className="text-xl font-bold font-serif text-stone-900 mt-1">{siteVisits.received.length}</p>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="border-b border-stone-200 flex items-center gap-6 text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('properties')}
          className={`pb-3 border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'properties'
              ? 'border-stone-900 text-stone-950 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>My Properties ({myProperties.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('inquiries')}
          className={`pb-3 border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'inquiries'
              ? 'border-stone-900 text-stone-950 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Enquiries ({inquiries.received.length + inquiries.sent.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('visits')}
          className={`pb-3 border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'visits'
              ? 'border-stone-900 text-stone-950 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Site Visits ({siteVisits.received.length + siteVisits.sent.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('saved')}
          className={`pb-3 border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'saved'
              ? 'border-stone-900 text-stone-950 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>Saved ({savedProperties.length})</span>
        </button>

        {(currentUser?.role === 'owner' || currentUser?.role === 'agent' || currentUser?.role === 'admin') && (
          <>
            <Link
              to="/dashboard/leads"
              className="pb-3 border-b-2 border-transparent text-stone-600 hover:text-stone-950 transition-colors flex items-center gap-1.5 ml-auto font-semibold"
            >
              <Users className="w-4 h-4 text-purple-600" />
              <span>Leads Pipeline</span>
            </Link>

            <Link
              to="/dashboard/deals"
              className="pb-3 border-b-2 border-transparent text-stone-600 hover:text-stone-950 transition-colors flex items-center gap-1.5 font-semibold"
            >
              <Briefcase className="w-4 h-4 text-amber-600" />
              <span>Deals & Commission</span>
            </Link>
          </>
        )}
      </div>

      {/* TAB 1: PROPERTIES */}
      {activeTab === 'properties' && (
        <div className="space-y-6">
          {/* Sub-filters */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-lg">
              {(['ALL', 'APPROVED', 'PENDING_APPROVAL', 'DRAFT', 'REJECTED'] as const).map((filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setPropertyFilter(filter)}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                    propertyFilter === filter
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {filter.replace('_', ' ')}
                </button>
              ))}
            </div>

            <span className="text-stone-500 font-medium">
              Showing {filteredProperties.length} listings
            </span>
          </div>

          {filteredProperties.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProperties.map((prop) => {
                const isApproved = prop.status === 'APPROVED';
                const isPending = prop.status === 'PENDING_APPROVAL';
                const isDraft = prop.status === 'DRAFT';
                const isRejected = prop.status === 'REJECTED';

                return (
                  <div
                    key={prop.id}
                    className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs hover:border-stone-400 transition-all flex flex-col justify-between"
                  >
                    <div>
                      {/* Image header with status badge */}
                      <div className="relative aspect-[16/9] bg-stone-100 overflow-hidden">
                        <img
                          src={prop.primaryImage || '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg'}
                          alt={prop.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-3 left-3">
                          <span className={`px-2.5 py-1 text-[11px] font-bold rounded shadow-xs uppercase tracking-wider ${
                            isApproved 
                              ? 'bg-emerald-600 text-white' 
                              : isPending 
                                ? 'bg-amber-500 text-stone-950 font-bold' 
                                : isDraft
                                  ? 'bg-stone-800 text-white'
                                  : 'bg-red-600 text-white'
                          }`}>
                            {prop.status.replace('_', ' ')}
                          </span>
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-4 space-y-2.5">
                        <div className="flex items-baseline justify-between">
                          <span className="text-lg font-bold font-serif text-stone-900 tabular-nums">
                            {formatPriceINR(prop.price)}
                          </span>
                          <span className="text-[11px] text-stone-500 font-medium capitalize">
                            {prop.category} · {prop.transaction_type}
                          </span>
                        </div>

                        <h3 className="font-semibold text-stone-900 text-sm line-clamp-1">
                          {prop.title}
                        </h3>

                        <p className="text-xs text-stone-500">
                          {prop.locality}, Mumbai · {formatArea(prop.carpet_area)}
                        </p>

                        {prop.rejection_reason && (
                          <div className="p-2 bg-red-50 border border-red-200 rounded text-[11px] text-red-700">
                            <strong>Note:</strong> {prop.rejection_reason}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Card Actions */}
                    <div className="p-4 pt-2 border-t border-stone-100 flex items-center justify-between gap-2 text-xs">
                      {isApproved && (
                        <Link
                          to={`/properties/${prop.id}`}
                          className="inline-flex items-center gap-1 text-stone-700 hover:text-stone-950 font-medium"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Live</span>
                        </Link>
                      )}

                      {isDraft && (
                        <button
                          type="button"
                          onClick={() => handleUpdateStatus(prop.id, 'PENDING_APPROVAL')}
                          className="px-2.5 py-1 bg-amber-100 text-amber-900 hover:bg-amber-200 rounded font-semibold text-[11px]"
                        >
                          Submit for Review
                        </button>
                      )}

                      <div className="flex items-center gap-2 ml-auto">
                        <button
                          type="button"
                          onClick={() => {
                            setEditModalProperty(prop);
                            setEditTitle(prop.title);
                            setEditPrice(String(prop.price));
                          }}
                          className="p-1.5 text-stone-600 hover:text-stone-950 hover:bg-stone-100 rounded"
                          title="Edit details"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteProperty(prop.id)}
                          className="p-1.5 text-red-600 hover:text-red-800 hover:bg-red-50 rounded"
                          title="Delete listing"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center max-w-md mx-auto space-y-3">
              <Building2 className="w-10 h-10 text-stone-400 mx-auto" />
              <h3 className="text-base font-bold text-stone-900">No properties in this view</h3>
              <p className="text-xs text-stone-500">
                You haven't posted any property listings matching this filter yet.
              </p>
              <Link
                to="/list-property"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 rounded-md shadow-xs"
              >
                <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>List a Property Now</span>
              </Link>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: INQUIRIES */}
      {activeTab === 'inquiries' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Received Inquiries (Owner) */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-stone-900 text-sm">
                  Inquiries Received for My Properties ({inquiries.received.length})
                </h3>
              </div>

              {inquiries.received.length > 0 ? (
                <div className="space-y-3">
                  {inquiries.received.map((inq) => (
                    <div key={inq.id} className="bg-white p-4 rounded-xl border border-stone-200 space-y-3 text-xs">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-bold text-stone-900">{inq.buyer_name}</p>
                          <div className="flex items-center gap-3 text-stone-500 text-[11px] mt-0.5">
                            <span className="flex items-center gap-1"><Phone className="w-3 h-3 text-stone-400" /> {inq.buyer_phone}</span>
                            <span className="flex items-center gap-1"><Mail className="w-3 h-3 text-stone-400" /> {inq.buyer_email}</span>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 bg-amber-100 text-amber-900 rounded text-[10px] font-bold">
                          {inq.status}
                        </span>
                      </div>

                      <div className="p-2.5 bg-stone-50 rounded-lg text-stone-700">
                        <p className="font-medium text-stone-900 text-[11px] mb-1">
                          Re: {inq.property_title} ({inq.locality})
                        </p>
                        <p className="italic">"{inq.message}"</p>
                      </div>

                      {/* Status actions */}
                      <div className="flex items-center gap-2 pt-1">
                        <span className="text-[11px] text-stone-500 font-medium">Update Status:</span>
                        {(['CONTACTED', 'SITE_VISIT', 'NEGOTIATING', 'CLOSED'] as const).map((st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => handleUpdateInquiryStatus(inq.id, st)}
                            className={`px-2 py-0.5 text-[10px] rounded border font-medium ${
                              inq.status === st 
                                ? 'bg-stone-900 text-white border-stone-900' 
                                : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 bg-white rounded-xl border border-stone-200 text-center text-xs text-stone-500">
                  No inquiries received on your listings yet.
                </div>
              )}
            </div>

            {/* Sent Inquiries (Buyer) */}
            <div className="space-y-4">
              <h3 className="font-bold text-stone-900 text-sm">
                Inquiries I Have Sent ({inquiries.sent.length})
              </h3>

              {inquiries.sent.length > 0 ? (
                <div className="space-y-3">
                  {inquiries.sent.map((inq) => (
                    <div key={inq.id} className="bg-white p-4 rounded-xl border border-stone-200 space-y-2 text-xs">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-bold text-stone-900">{inq.property_title}</p>
                          <p className="text-[11px] text-stone-500">{inq.locality}</p>
                        </div>
                        <span className="px-2 py-0.5 bg-stone-100 text-stone-700 rounded text-[10px] font-bold">
                          {inq.status}
                        </span>
                      </div>
                      <p className="text-stone-600 bg-stone-50 p-2 rounded text-[11px]">
                        "{inq.message}"
                      </p>
                      <p className="text-[10px] text-stone-400">
                        Submitted: {new Date(inq.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 bg-white rounded-xl border border-stone-200 text-center text-xs text-stone-500">
                  You haven't contacted any property owners yet.
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* TAB 3: SITE VISITS */}
      {activeTab === 'visits' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Received Visits */}
            <div className="space-y-4">
              <h3 className="font-bold text-stone-900 text-sm">
                Site Visits Scheduled for My Properties ({siteVisits.received.length})
              </h3>

              {siteVisits.received.length > 0 ? (
                <div className="space-y-3">
                  {siteVisits.received.map((visit) => (
                    <div key={visit.id} className="bg-white p-4 rounded-xl border border-stone-200 space-y-3 text-xs">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-bold text-stone-900">{visit.visitor_name}</p>
                          <p className="text-stone-500 text-[11px]">Phone: {visit.visitor_phone}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          visit.status === 'CONFIRMED' 
                            ? 'bg-emerald-100 text-emerald-900' 
                            : visit.status === 'CANCELLED'
                              ? 'bg-red-100 text-red-900'
                              : 'bg-amber-100 text-amber-900'
                        }`}>
                          {visit.status}
                        </span>
                      </div>

                      <div className="p-2.5 bg-amber-50/60 border border-amber-200/60 rounded-lg">
                        <p className="font-semibold text-stone-900 text-[11px]">
                          Property: {visit.property_title}
                        </p>
                        <p className="text-stone-700 text-[11px] mt-0.5">
                          Requested Slot: <strong>{visit.preferred_date}</strong> ({visit.preferred_time})
                        </p>
                        {visit.message && <p className="italic text-stone-600 mt-1">"{visit.message}"</p>}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleUpdateVisitStatus(visit.id, 'CONFIRMED')}
                          className="px-2.5 py-1 text-[11px] font-medium bg-emerald-700 text-white rounded hover:bg-emerald-800"
                        >
                          Confirm Slot
                        </button>
                        <button
                          type="button"
                          onClick={() => handleUpdateVisitStatus(visit.id, 'COMPLETED')}
                          className="px-2.5 py-1 text-[11px] font-medium bg-stone-900 text-white rounded hover:bg-stone-800"
                        >
                          Mark Completed
                        </button>
                        <button
                          type="button"
                          onClick={() => handleUpdateVisitStatus(visit.id, 'CANCELLED')}
                          className="px-2.5 py-1 text-[11px] font-medium text-red-700 border border-red-200 hover:bg-red-50 rounded"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 bg-white rounded-xl border border-stone-200 text-center text-xs text-stone-500">
                  No site visits scheduled for your listings yet.
                </div>
              )}
            </div>

            {/* Visits I Requested */}
            <div className="space-y-4">
              <h3 className="font-bold text-stone-900 text-sm">
                Visits I Have Booked ({siteVisits.sent.length})
              </h3>

              {siteVisits.sent.length > 0 ? (
                <div className="space-y-3">
                  {siteVisits.sent.map((visit) => (
                    <div key={visit.id} className="bg-white p-4 rounded-xl border border-stone-200 space-y-2 text-xs">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-bold text-stone-900">{visit.property_title}</p>
                          <p className="text-[11px] text-stone-500">{visit.locality}</p>
                        </div>
                        <span className="px-2 py-0.5 bg-stone-100 text-stone-700 rounded text-[10px] font-bold">
                          {visit.status}
                        </span>
                      </div>
                      <p className="text-stone-700 text-[11px]">
                        Slot: {visit.preferred_date} · {visit.preferred_time}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 bg-white rounded-xl border border-stone-200 text-center text-xs text-stone-500">
                  You haven't scheduled any site visits yet.
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* TAB 4: SAVED PROPERTIES */}
      {activeTab === 'saved' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-stone-900 text-sm">
              My Saved Watchlist ({savedProperties.length})
            </h3>
            <Link to="/saved-properties" className="text-xs text-stone-700 hover:text-stone-950 underline">
              View dedicated saved properties page
            </Link>
          </div>

          {savedProperties.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {savedProperties.map((prop) => (
                <div key={prop.id} className="bg-white rounded-xl border border-stone-200 p-4 space-y-2 text-xs">
                  <span className="text-base font-bold font-serif text-stone-900 block tabular-nums">
                    {formatPriceINR(prop.price)}
                  </span>
                  <p className="font-semibold text-stone-900 truncate">{prop.title}</p>
                  <p className="text-stone-500 text-[11px]">{prop.locality}, Mumbai</p>
                  <Link
                    to={`/properties/${prop.id}`}
                    className="block text-center py-1.5 px-3 bg-stone-900 text-white rounded font-medium mt-2 hover:bg-stone-800"
                  >
                    View Listing
                  </Link>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 bg-white rounded-xl border border-stone-200 text-center text-xs text-stone-500">
              Your watchlist is empty. Save properties from search results to compare them here.
            </div>
          )}
        </div>
      )}

      {/* Quick Edit Modal */}
      {editModalProperty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl border border-stone-200 max-w-md w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-stone-900 text-sm">
                Quick Edit Property Details
              </h3>
              <button
                type="button"
                onClick={() => setEditModalProperty(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickEdit} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Property Title
                </label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Asking Price / Rent (₹ INR)
                </label>
                <input
                  type="number"
                  value={editPrice}
                  onChange={(e) => setEditPrice(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-lg"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setEditModalProperty(null)}
                  className="px-3 py-2 border border-stone-200 text-stone-700 rounded hover:bg-stone-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={editSaving}
                  className="px-4 py-2 bg-stone-900 text-white rounded hover:bg-stone-800 font-semibold"
                >
                  {editSaving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
