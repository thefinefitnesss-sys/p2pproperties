import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bookmark, ArrowLeft, Trash2, ExternalLink, Building2 } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { api } from '../services/api';
import { formatPriceINR, formatArea } from '../utils/formatters';

export const SavedPropertiesPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, toggleSaveProperty } = useProperty();

  const [savedProperties, setSavedProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    fetchSaved();
  }, [currentUser, navigate]);

  const fetchSaved = async () => {
    setLoading(true);
    try {
      const res = await api.savedProperties.list();
      setSavedProperties(res.properties || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  const handleUnsave = async (propId: string) => {
    await toggleSaveProperty(propId);
    setSavedProperties((prev) => prev.filter((p) => p.id !== propId));
  };

  return (
    <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8 space-y-8 min-h-[75vh]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
            <Link to="/" className="hover:text-stone-900">Home</Link>
            <span>/</span>
            <span className="text-stone-900 font-medium">Watchlist</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-900">
            My Saved Properties ({savedProperties.length})
          </h1>
          <p className="text-xs text-stone-600 mt-1">
            Saved direct listings stored on your account for comparison and site visit planning.
          </p>
        </div>

        <Link
          to="/properties"
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-stone-700 bg-white border border-stone-300 hover:bg-stone-50 rounded-lg shadow-2xs self-start sm:self-auto"
        >
          <span>Browse More Homes</span>
        </Link>
      </div>

      {loading ? (
        <div className="py-20 text-center text-xs text-stone-500">
          Loading your saved properties...
        </div>
      ) : savedProperties.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {savedProperties.map((prop) => (
            <div
              key={prop.id}
              className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs hover:border-stone-400 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="relative aspect-[16/10] bg-stone-100 overflow-hidden">
                  <img
                    src={prop.primaryImage || '/src/assets/images/luxury_bandra_apartment_1791457626031.jpg'}
                    alt={prop.title}
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => handleUnsave(prop.id)}
                    className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-black/60 hover:bg-black/80 text-white shadow-xs"
                    title="Remove from saved"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="p-4 space-y-2">
                  <div className="text-lg font-bold font-serif text-stone-900 tabular-nums">
                    {formatPriceINR(prop.price)}
                  </div>
                  <h3 className="font-semibold text-stone-900 text-sm line-clamp-1">
                    {prop.title}
                  </h3>
                  <p className="text-xs text-stone-500">
                    {prop.locality}, Mumbai · {formatArea(prop.carpet_area)}
                  </p>
                </div>
              </div>

              <div className="p-4 pt-1 border-t border-stone-100">
                <Link
                  to={`/properties/${prop.id}`}
                  className="w-full inline-flex items-center justify-center py-2 px-3 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg transition-colors"
                >
                  View Full Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center max-w-md mx-auto my-12 space-y-3">
          <Bookmark className="w-10 h-10 text-stone-400 mx-auto" />
          <h3 className="text-base font-bold text-stone-900">Your Watchlist is Empty</h3>
          <p className="text-xs text-stone-500">
            Save interesting properties from the search listings to easily compare them here.
          </p>
          <div className="pt-2">
            <Link
              to="/properties"
              className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg inline-block"
            >
              Explore Mumbai Properties
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};
