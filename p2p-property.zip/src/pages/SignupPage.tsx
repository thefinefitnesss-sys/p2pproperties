import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, Phone, User as UserIcon, ShieldCheck, ArrowRight, AlertCircle } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { UserRole } from '../types/property';

export const SignupPage: React.FC = () => {
  const navigate = useNavigate();
  const { signupUser } = useProperty();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please provide your full name.');
      return;
    }
    if (!phone.trim() || phone.replace(/\D/g, '').length < 10) {
      setError('Please provide a valid 10-digit Indian mobile number.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      await signupUser({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        password,
        role
      });
      navigate('/dashboard', { replace: true });
    } catch (err: any) {
      setError(err.message || 'Signup failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-2xl border border-stone-200/90 shadow-md p-6 sm:p-8 space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-stone-900 text-stone-50 font-serif text-xl font-bold shadow-xs">
            P2P
          </div>
          <h1 className="text-2xl font-bold font-serif text-stone-900 tracking-tight">
            Create P2P Property Account
          </h1>
          <p className="text-xs text-stone-600">
            Join Mumbai's peer-to-peer direct real-estate network
          </p>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          {/* User Type Selector */}
          <div>
            <label className="block font-medium text-stone-700 mb-1.5">
              I am joining as:
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['buyer', 'tenant', 'owner', 'agent'] as UserRole[]).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRole(r)}
                  className={`py-2 px-1 text-[11px] font-semibold capitalize rounded-lg border text-center transition-colors ${
                    role === r 
                      ? 'border-stone-900 bg-stone-900 text-white' 
                      : 'border-stone-200 text-stone-700 hover:border-stone-400'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">
              Full Legal Name *
            </label>
            <div className="relative">
              <UserIcon className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Rahul Shah"
                className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">
              Mobile Number (India) *
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98200 XXXXX"
                className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">
              Email Address *
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="rahul.shah@domain.com"
                className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">
              Secure Password (min 6 characters) *
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 disabled:bg-stone-400 rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2"
          >
            <span>{loading ? 'Creating Account...' : 'Complete Registration'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <div className="text-center pt-2 text-xs text-stone-600">
            Already have an account?{' '}
            <Link to="/login" className="font-semibold text-stone-900 underline hover:text-amber-800">
              Sign In
            </Link>
          </div>

          <div className="flex items-center justify-center gap-1.5 text-[11px] text-stone-500 pt-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Owner Contact Masking Guaranteed · No Middlemen Telemarketing</span>
          </div>
        </form>

      </div>
    </div>
  );
};
