import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  Building2, 
  Users, 
  MessageSquare, 
  Calendar, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Filter, 
  Check, 
  X, 
  Eye, 
  RefreshCw,
  Search,
  BadgeCheck
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { api } from '../services/api';
import { formatPriceINR, formatArea } from '../utils/formatters';

export const AdminPage: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, showToast } = useProperty();

  const [activeTab, setActiveTab] = useState<'metrics' | 'properties' | 'users'>('properties');
  const [statusFilter, setStatusFilter] = useState<string>('PENDING_APPROVAL');

  const [metrics, setMetrics] = useState<any>(null);
  const [properties, setProperties] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Reject modal state
  const [rejectModalId, setRejectModalId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState<string>('');

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    if (currentUser.role !== 'admin') {
      showToast('Admin privilege required.');
      navigate('/dashboard');
      return;
    }
    loadAdminData();
  }, [currentUser, navigate]);

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const [metRes, propsRes, usersRes] = await Promise.all([
        api.admin.metrics(),
        api.admin.properties(statusFilter === 'all' ? undefined : statusFilter),
        api.admin.users()
      ]);
      setMetrics(metRes.metrics);
      setProperties(propsRes.properties || []);
      setUsers(usersRes.users || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading admin data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser?.role === 'admin') {
      api.admin.properties(statusFilter === 'all' ? undefined : statusFilter)
        .then((res) => setProperties(res.properties || []))
        .catch(() => {});
    }
  }, [statusFilter, currentUser]);

  const handleReviewAction = async (id: string, action: 'approve' | 'reject' | 'request_changes' | 'verify' | 'deactivate', reason?: string) => {
    try {
      await api.admin.reviewProperty(id, action, reason);
      showToast(`Property action completed: ${action}.`);
      setRejectModalId(null);
      setRejectReason('');
      loadAdminData();
    } catch (err: any) {
      showToast(err.message || 'Failed to review property.');
    }
  };

  const handleUpdateUserRole = async (userId: string, newRole: string) => {
    try {
      await api.admin.updateUserRole(userId, { role: newRole });
      showToast('User role updated.');
      loadAdminData();
    } catch (err: any) {
      showToast(err.message || 'Error updating user.');
    }
  };

  const handleToggleUserVerify = async (userId: string, currentVal: boolean) => {
    try {
      await api.admin.updateUserRole(userId, { is_verified: !currentVal });
      showToast(`User verification toggled.`);
      loadAdminData();
    } catch (err: any) {
      showToast(err.message || 'Error toggling verification.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8 min-h-screen">
      
      {/* Admin Header */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-widest text-amber-400 flex items-center gap-1">
              <ShieldCheck className="w-4 h-4" />
              Super Admin Console
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-white">
            Marketplace Moderation & Governance
          </h1>
          <p className="text-xs text-stone-400">
            Audit Mumbai property listings, approve direct submissions, manage user roles, and enforce title verification.
          </p>
        </div>

        <button
          type="button"
          onClick={loadAdminData}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-lg self-start md:self-auto transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* Metrics Row */}
      {metrics && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-white p-4 rounded-xl border border-stone-200">
            <span className="text-[11px] text-stone-500 font-medium">Total Registered Users</span>
            <p className="text-2xl font-bold font-serif text-stone-900 mt-1">{metrics.totalUsers}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-stone-200">
            <span className="text-[11px] text-stone-500 font-medium">Total Properties</span>
            <p className="text-2xl font-bold font-serif text-stone-900 mt-1">{metrics.totalProps}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-amber-300 bg-amber-50/20">
            <span className="text-[11px] text-amber-800 font-bold">Needs Review (Pending)</span>
            <p className="text-2xl font-bold font-serif text-amber-950 mt-1">{metrics.pendingProps}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-emerald-300 bg-emerald-50/20">
            <span className="text-[11px] text-emerald-800 font-bold">Approved & Live</span>
            <p className="text-2xl font-bold font-serif text-emerald-950 mt-1">{metrics.approvedProps}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-stone-200">
            <span className="text-[11px] text-stone-500 font-medium">Buyer Inquiries</span>
            <p className="text-2xl font-bold font-serif text-stone-900 mt-1">{metrics.totalInquiries}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-stone-200">
            <span className="text-[11px] text-stone-500 font-medium">Site Visits</span>
            <p className="text-2xl font-bold font-serif text-stone-900 mt-1">{metrics.totalVisits}</p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-stone-200 flex items-center gap-6 text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('properties')}
          className={`pb-3 border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'properties'
              ? 'border-stone-900 text-stone-950 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Listing Moderation</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('users')}
          className={`pb-3 border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'users'
              ? 'border-stone-900 text-stone-950 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Users & Roles ({users.length})</span>
        </button>
      </div>

      {/* TAB 1: PROPERTIES MODERATION */}
      {activeTab === 'properties' && (
        <div className="space-y-6">
          
          {/* Status Sub-filter */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-lg">
              {(['PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'DRAFT', 'INACTIVE', 'all'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                    statusFilter === st
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {st === 'all' ? 'All' : st.replace('_', ' ')}
                </button>
              ))}
            </div>

            <span className="text-stone-500 font-medium">
              {properties.length} listings in queue
            </span>
          </div>

          {/* Properties Table */}
          {properties.length > 0 ? (
            <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="p-4">Property</th>
                      <th className="p-4">Owner</th>
                      <th className="p-4">Price / Terms</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Verification</th>
                      <th className="p-4 text-right">Moderation Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {properties.map((prop) => (
                      <tr key={prop.id} className="hover:bg-stone-50/70 transition-colors">
                        <td className="p-4 max-w-xs">
                          <p className="font-bold text-stone-900 truncate">{prop.title}</p>
                          <p className="text-[11px] text-stone-500 mt-0.5">
                            {prop.locality}, Mumbai · {prop.category} ({prop.property_type})
                          </p>
                          <p className="text-[10px] text-stone-400 font-mono mt-0.5">
                            ID: {prop.id} {prop.is_sample ? '· [Sample]' : ''}
                          </p>
                        </td>

                        <td className="p-4">
                          <p className="font-semibold text-stone-900">{prop.owner_name || 'Owner'}</p>
                          <p className="text-[11px] text-stone-500">{prop.owner_phone || '-'}</p>
                          <p className="text-[11px] text-stone-400 truncate max-w-[140px]">{prop.owner_email || '-'}</p>
                        </td>

                        <td className="p-4 tabular-nums">
                          <p className="font-bold text-stone-900">{formatPriceINR(prop.price)}</p>
                          <p className="text-[11px] text-stone-500">{formatArea(prop.carpet_area)} carpet</p>
                        </td>

                        <td className="p-4">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            prop.status === 'APPROVED'
                              ? 'bg-emerald-100 text-emerald-900'
                              : prop.status === 'PENDING_APPROVAL'
                                ? 'bg-amber-100 text-amber-950 font-bold border border-amber-300'
                                : prop.status === 'REJECTED'
                                  ? 'bg-red-100 text-red-900'
                                  : 'bg-stone-100 text-stone-800'
                          }`}>
                            {prop.status.replace('_', ' ')}
                          </span>
                        </td>

                        <td className="p-4">
                          <span className={`inline-flex items-center gap-1 text-[11px] font-medium ${
                            prop.verification_status === 'VERIFIED' ? 'text-emerald-700' : 'text-stone-500'
                          }`}>
                            <BadgeCheck className="w-3.5 h-3.5" />
                            {prop.verification_status}
                          </span>
                        </td>

                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1.5 flex-wrap">
                            <Link
                              to={`/properties/${prop.id}`}
                              className="p-1.5 text-stone-600 hover:text-stone-900 rounded hover:bg-stone-100"
                              title="View listing detail"
                            >
                              <Eye className="w-4 h-4" />
                            </Link>

                            {prop.status !== 'APPROVED' && (
                              <button
                                type="button"
                                onClick={() => handleReviewAction(prop.id, 'approve')}
                                className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-semibold text-[11px] shadow-2xs"
                              >
                                Approve
                              </button>
                            )}

                            {prop.status !== 'REJECTED' && (
                              <button
                                type="button"
                                onClick={() => setRejectModalId(prop.id)}
                                className="px-2.5 py-1 bg-red-100 hover:bg-red-200 text-red-800 rounded font-semibold text-[11px]"
                              >
                                Reject
                              </button>
                            )}

                            {prop.status === 'APPROVED' && (
                              <button
                                type="button"
                                onClick={() => handleReviewAction(prop.id, 'deactivate')}
                                className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded font-medium text-[11px]"
                              >
                                Deactivate
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => handleReviewAction(prop.id, 'verify')}
                              className="px-2 py-1 border border-stone-300 hover:bg-stone-100 text-stone-800 rounded font-medium text-[10px]"
                              title="Toggle verified badge"
                            >
                              Verify Title
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-stone-200 p-12 text-center text-xs text-stone-500">
              No listings found with status "{statusFilter}".
            </div>
          )}

        </div>
      )}

      {/* TAB 2: USERS */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="p-4">User</th>
                  <th className="p-4">Contact</th>
                  <th className="p-4">Role</th>
                  <th className="p-4">Capabilities</th>
                  <th className="p-4">Verified</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-stone-50/70 transition-colors">
                    <td className="p-4">
                      <p className="font-bold text-stone-900">{u.name}</p>
                      <p className="text-[10px] text-stone-400 font-mono mt-0.5">ID: {u.id}</p>
                    </td>

                    <td className="p-4">
                      <p className="text-stone-900">{u.email}</p>
                      <p className="text-[11px] text-stone-500">{u.phone}</p>
                    </td>

                    <td className="p-4">
                      <select
                        value={u.role}
                        onChange={(e) => handleUpdateUserRole(u.id, e.target.value)}
                        className="px-2 py-1 text-xs border border-stone-200 rounded bg-white font-medium"
                      >
                        <option value="buyer">Buyer</option>
                        <option value="tenant">Tenant</option>
                        <option value="owner">Owner</option>
                        <option value="agent">Agent</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>

                    <td className="p-4 font-mono text-[11px] text-stone-600">
                      {u.capabilities?.join(', ') || u.role}
                    </td>

                    <td className="p-4">
                      <button
                        type="button"
                        onClick={() => handleToggleUserVerify(u.id, u.is_verified)}
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          u.is_verified ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-100 text-stone-600'
                        }`}
                      >
                        {u.is_verified ? 'Verified' : 'Unverified'}
                      </button>
                    </td>

                    <td className="p-4 text-right text-stone-400 text-[11px]">
                      Registered {new Date(u.created_at).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Reject Reason Modal */}
      {rejectModalId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl border border-stone-200 max-w-md w-full p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-sm font-bold text-stone-900">
              Reject Listing with Constructive Feedback
            </h3>
            <p className="text-stone-600">
              Specify why this listing was rejected so the owner can amend their title documents or pricing details.
            </p>

            <textarea
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g. Please upload clear occupation certificate (OC) and provide accurate carpet area..."
              className="w-full px-3 py-2 border border-stone-200 rounded-lg"
              required
            />

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setRejectModalId(null)}
                className="px-3 py-2 border border-stone-200 rounded text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleReviewAction(rejectModalId, 'reject', rejectReason)}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded font-semibold"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
