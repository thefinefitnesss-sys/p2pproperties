import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Mail, Lock, ShieldCheck, ArrowRight, AlertCircle, Building2 } from 'lucide-react';
import { useProperty } from '../context/PropertyContext';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { loginUser } = useProperty();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const from = (location.state as any)?.from?.pathname || '/dashboard';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await loginUser(email.trim(), password);
      navigate(from, { replace: true });
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleFastLogin = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-2xl border border-stone-200/90 shadow-md p-6 sm:p-8 space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-stone-900 text-stone-50 font-serif text-xl font-bold shadow-xs">
            P2P
          </div>
          <h1 className="text-2xl font-bold font-serif text-stone-900 tracking-tight">
            Sign in to P2P Property
          </h1>
          <p className="text-xs text-stone-600">
            Mumbai's peer-to-peer residential & commercial property marketplace
          </p>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-medium text-stone-700 mb-1">
              Registered Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@domain.com"
                className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white"
                required
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-medium text-stone-700">Password</label>
              <Link to="/forgot-password" className="text-stone-500 hover:text-stone-900 underline text-[11px]">
                Forgot password?
              </Link>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 disabled:bg-stone-400 rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2"
          >
            <span>{loading ? 'Signing In...' : 'Sign In to Account'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          {/* Quick Demo Credentials */}
          <div className="pt-4 border-t border-stone-100 text-center space-y-2">
            <span className="text-[11px] text-stone-500 font-medium block">
              Quick test credentials:
            </span>
            <div className="flex flex-wrap justify-center gap-2">
              <button
                type="button"
                onClick={() => handleFastLogin('admin@p2pproperty.in', 'Admin@12345')}
                className="px-2.5 py-1 text-[11px] bg-stone-100 hover:bg-stone-200 text-stone-800 rounded font-medium"
              >
                Admin (Admin@12345)
              </button>
              <button
                type="button"
                onClick={() => handleFastLogin('sameer.merchant@mumbai.in', 'Owner@12345')}
                className="px-2.5 py-1 text-[11px] bg-stone-100 hover:bg-stone-200 text-stone-800 rounded font-medium"
              >
                Owner (Owner@12345)
              </button>
              <button
                type="button"
                onClick={() => handleFastLogin('ananya.deshmukh@mumbai.in', 'Buyer@12345')}
                className="px-2.5 py-1 text-[11px] bg-stone-100 hover:bg-stone-200 text-stone-800 rounded font-medium"
              >
                Buyer (Buyer@12345)
              </button>
            </div>
          </div>

          <div className="text-center pt-2 text-xs text-stone-600">
            Don't have an account?{' '}
            <Link to="/signup" className="font-semibold text-stone-900 underline hover:text-amber-800">
              Create an account
            </Link>
          </div>

          <div className="flex items-center justify-center gap-1.5 text-[11px] text-stone-500 pt-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Encrypted BCrypt Hash · JWT Bearer Security</span>
          </div>
        </form>

      </div>
    </div>
  );
};
