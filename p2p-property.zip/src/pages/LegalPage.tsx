import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { ShieldCheck, FileText, Scale, ArrowLeft, Clock, CheckCircle2 } from 'lucide-react';
import { api } from '../services/api';

const DEFAULT_LEGAL_DOCS: Record<string, { title: string; subtitle: string; content: string }> = {
  privacy: {
    title: 'Privacy Policy',
    subtitle: 'Data governance, owner masking, and statutory DPDP compliance in Mumbai MMRDA.',
    content: `1. INFORMATION WE COLLECT
P2P Property Technologies Pvt. Ltd. collects information necessary to verify identity, establish lawful property ownership, and coordinate peer-to-peer real estate transactions. This includes name, phone number, email address, property address, and submitted verification documents (such as Sale Deeds, OC/CC, or Society Share Certificates).

2. DIRECT PEER-TO-PEER DATA MASKING
We strictly enforce masked contact channels. Personal contact credentials of sellers and landlords are never displayed openly to public search bots or unregistered crawlers. Contact is facilitated strictly after a verified buyer/tenant submits an enquiry or schedules an authorized site visit.

3. SENSITIVE PROPERTY DOCUMENTS
Uploaded property verification documents (Index II, Title Search, Tax Receipts, Electricity Bills) remain in encrypted storage and are accessible exclusively to authorized verification officers and the listing owner. Documents are never made publicly indexed or freely downloadable.

4. MAHARASHTRA REAL ESTATE REGULATION COMPLIANCE
Data handling procedures align with statutory requirements under the Information Technology Act, 2000, the Digital Personal Data Protection Act, and MahaRERA record-keeping standards for licensed real estate agents.

5. GRIEVANCE OFFICER
For data requests or privacy queries, contact our Grievance Officer at grievance@p2pproperty.in or visit our Mumbai headquarters at Floor 8, Maker Maxity, BKC, Mumbai 400051.`
  },
  terms: {
    title: 'Terms & Conditions',
    subtitle: 'Platform usage agreement for direct buyers, sellers, tenants, and verified brokers.',
    content: `1. ACCEPTANCE OF TERMS
By accessing the P2P Property marketplace or mobile application, you agree to these Terms and Conditions. If you do not accept these terms in full, you must not access the platform.

2. LISTING AUTHENTICITY AND OWNER REPRESENTATION
Every individual or broker submitting a residential or commercial listing warrants that:
(a) They hold lawful title, ownership, or registered power of attorney / authorization from the recorded owner.
(b) All dimensions, carpet area measurements, pricing, and structural specifications are truthful and verifiable.
(c) The listing does not violate any municipal bye-laws of the Municipal Corporation of Greater Mumbai (MCGM).

3. MODERATION AND VERIFICATION WORKFLOW
Submitting a listing creates a record in PENDING_APPROVAL status. P2P Property reserves the sole right to approve, request modifications, or reject listings that do not meet verification criteria or fail documentary proof.

4. PEER-TO-PEER INTERACTIONS
While P2P Property provides verified document validation and structured negotiation tools, all definitive transactional purchase agreements or registered leave and license deeds are entered into directly between the principals. Users are advised to engage qualified Maharashtra legal counsel for title searches.`
  },
  'brokerage-terms': {
    title: 'Brokerage & Advisory Terms',
    subtitle: 'Transparent, deal-specific commission structures with statutory GST invoicing.',
    content: `1. NO ARBITRARY OR HIDDEN COMMISSIONS
P2P Property operates with transparent brokerage terms agreed in advance upon deal creation. There is no hidden surcharge or surprise fee.

2. COMMISSION CALCULATION OPTIONS
Brokerage may be structured as:
(a) Percentage of agreed consideration (e.g. 1% to 2% of finalized sale value).
(b) Fixed lump-sum advisory amount agreed in writing between the transacting parties.

3. COMMISSION STATUS & GST INVOICING
Brokerage invoices are generated in compliance with Indian taxation laws with applicable 18% Goods and Services Tax (GST). Invoices clearly state the deal number, subtotal, GST registration, and bank settlement details.

4. PAYMENT TRANCHES
Brokerage payments must adhere to milestones documented in the deal agreement (such as LOI signing, definitive agreement registration, or possession key handover). Once paid, brokerage fees for executed transactions are non-refundable.`
  },
  'refund-policy': {
    title: 'Refund & Cancellation Policy',
    subtitle: 'Standard refund criteria for verification and advisory packages.',
    content: `1. FREE LISTING SUBMISSION
Creating and submitting property listings on P2P Property is 100% free for individual property owners.

2. ADVISORY & VERIFICATION CANCELLATIONS
Any pre-paid premium title verification or property shoot package may be cancelled within 24 hours of purchase if site physical verification has not yet been initiated by our field officers. Full refunds are processed within 5 to 7 business days to the original payment source.

3. COMPLETED TRANSACTIONS
Brokerage fees paid upon successfully closed deals, registered sale agreements, or executed commercial leases are non-refundable once possession or legal execution is finalized.

4. DISPUTE RESOLUTION
In the event of duplicate billing or payment gateway verification discrepancies, please write to billing@p2pproperty.in with your transaction receipt number.`
  },
  'verification-policy': {
    title: 'Property Verification Disclaimer',
    subtitle: 'Standards, boundaries, and legal disclaimers regarding "VERIFIED" badges.',
    content: `1. SCOPE OF PLATFORM VERIFICATION
Properties bearing the "VERIFIED" badge on P2P Property have successfully passed:
(a) Ownership documentary sanity check (Index II / Sale Deed review).
(b) MCGM Occupancy Certificate (OC) or Completion Certificate validation where applicable.
(c) Physical geo-tagging confirmation of location and floor presence.

2. LEGAL TITLE DISCLAIMER
The "VERIFIED" badge signifies documentary consistency presented to P2P Property at the date of listing review. It does NOT constitute a definitive guarantee of unencumbered title, nor does it replace a formal 30-year Search Report conducted by an advocate in the Sub-Registrar’s office.

3. INDEPENDENT DUE DILIGENCE
Buyers, tenants, and institutional investors are strongly advised to appoint independent legal counsel to conduct search reports, verify society NOCs, and review 7/12 extracts or municipal tax receipts prior to transferring substantial earnest money considerations.`
  }
};

interface LegalPageProps {
  forcedSlug?: string;
}

export const LegalPage: React.FC<LegalPageProps> = ({ forcedSlug }) => {
  const location = useLocation();
  const slug = forcedSlug || location.pathname.replace(/^\//, '') || 'privacy';

  const [doc, setDoc] = useState<{ title: string; subtitle?: string; content: string; updatedAt?: string }>({
    title: DEFAULT_LEGAL_DOCS[slug]?.title || 'Legal Information',
    subtitle: DEFAULT_LEGAL_DOCS[slug]?.subtitle || 'P2P Property statutory compliance & governance.',
    content: DEFAULT_LEGAL_DOCS[slug]?.content || 'Content is loading...'
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDocument();
  }, [slug]);

  const loadDocument = async () => {
    setLoading(true);
    try {
      const res = await api.legal.get(slug);
      if (res && res.content) {
        setDoc({
          title: res.title,
          subtitle: DEFAULT_LEGAL_DOCS[slug]?.subtitle,
          content: res.content,
          updatedAt: res.updatedAt
        });
      } else {
        fallbackToDefault();
      }
    } catch {
      fallbackToDefault();
    } finally {
      setLoading(false);
    }
  };

  const fallbackToDefault = () => {
    const fallback = DEFAULT_LEGAL_DOCS[slug] || DEFAULT_LEGAL_DOCS['privacy'];
    setDoc({
      title: fallback.title,
      subtitle: fallback.subtitle,
      content: fallback.content,
      updatedAt: '2026-10-09'
    });
  };

  const navLinks = [
    { label: 'Privacy Policy', path: '/privacy' },
    { label: 'Terms & Conditions', path: '/terms' },
    { label: 'Brokerage Terms', path: '/brokerage-terms' },
    { label: 'Refund Policy', path: '/refund-policy' },
    { label: 'Verification Policy', path: '/verification-policy' },
  ];

  return (
    <div className="min-h-screen bg-[#FAF9F5] py-12 sm:py-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Navigation Bar */}
        <div className="flex flex-wrap items-center gap-2 mb-10 pb-6 border-b border-stone-200">
          {navLinks.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-colors ${
                location.pathname === item.path
                  ? 'bg-stone-900 text-white'
                  : 'bg-white text-stone-600 hover:text-stone-900 border border-stone-200 hover:bg-stone-50'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </div>

        {/* Document Header */}
        <div className="mb-10">
          <div className="inline-flex items-center gap-2 text-amber-800 text-xs font-semibold uppercase tracking-wider mb-3">
            <Scale className="w-4 h-4 text-amber-700" />
            <span>Maharashtra Legal & Regulatory Framework</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-stone-900">
            {doc.title}
          </h1>
          {doc.subtitle && (
            <p className="mt-2 text-stone-600 text-sm sm:text-base leading-relaxed font-light">
              {doc.subtitle}
            </p>
          )}
          {doc.updatedAt && (
            <div className="flex items-center gap-1.5 text-xs text-stone-400 mt-4">
              <Clock className="w-3.5 h-3.5" />
              <span>Last reviewed: {new Date(doc.updatedAt).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="bg-white rounded-2xl border border-stone-200/90 shadow-sm p-8 sm:p-12 prose prose-stone max-w-none text-stone-700 leading-relaxed text-sm sm:text-base whitespace-pre-line font-light">
          {doc.content}
        </div>

        {/* Legal Disclaimer Box */}
        <div className="mt-10 p-6 bg-stone-100/80 rounded-xl border border-stone-200 text-xs text-stone-500 leading-relaxed">
          <p className="font-semibold text-stone-700 mb-1">Review Notice:</p>
          <p>
            The regulatory documentation above governs peer-to-peer property listing, client verification, and brokerage settlement on P2P Property within the state of Maharashtra. Legal texts are regularly updated to reflect modifications in MahaRERA rules and Maharashtra Stamp Act notifications.
          </p>
        </div>

      </div>
    </div>
  );
};
