import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, Building2, Users2, CheckCircle2, Award, PhoneCall, ArrowRight, MapPin } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#FAF9F5] pb-24">
      {/* Hero Header */}
      <div className="bg-stone-900 text-stone-100 py-16 sm:py-24 border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-xs font-semibold uppercase tracking-wider mb-6">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Direct Peer-to-Peer Real Estate</span>
            </div>
            <h1 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
              Architected for Mumbai. <br />
              <span className="text-amber-400">Zero Artificial Friction.</span>
            </h1>
            <p className="mt-6 text-base sm:text-lg text-stone-300 leading-relaxed font-light">
              P2P Property was engineered to solve the persistent inefficiencies of Mumbai’s real estate marketplace. By connecting verified residential and commercial property owners directly with qualified buyers and tenants, we provide transparency, document authenticity, and predictable transactional economics.
            </p>
          </div>
        </div>
      </div>

      {/* Core Principles */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-8 rounded-2xl border border-stone-200/90 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h2 className="font-serif text-xl font-bold text-stone-900">Direct Owner Verification</h2>
            <p className="text-sm text-stone-600 leading-relaxed">
              Every property submitted on P2P Property undergoes rigorous title document checks, Municipal Corporation of Greater Mumbai (MCGM) record cross-referencing, and geo-tagged site verification before publication.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl border border-stone-200/90 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <Award className="w-6 h-6" />
            </div>
            <h2 className="font-serif text-xl font-bold text-stone-900">Transparent Brokerage</h2>
            <p className="text-sm text-stone-600 leading-relaxed">
              No hidden fees or arbitrary brokerage rates. Deal terms, advisory fees, and GST tax invoices are formally set in structured agreements prior to agreement execution.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl border border-stone-200/90 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <Users2 className="w-6 h-6" />
            </div>
            <h2 className="font-serif text-xl font-bold text-stone-900">End-to-End Governance</h2>
            <p className="text-sm text-stone-600 leading-relaxed">
              From direct enquiry and scheduled site visits to formal negotiations, legal verification, and final handover receipts — every milestone is auditable and tracked in real-time.
            </p>
          </div>
        </div>
      </div>

      {/* Mumbai Regional Coverage */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="bg-stone-900 text-white rounded-3xl p-8 sm:p-14 overflow-hidden relative">
          <div className="max-w-2xl space-y-6 relative z-10">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider">
              <MapPin className="w-4 h-4" />
              <span>Metropolitan Footprint</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-4xl font-bold">
              Serving Prime Mumbai Corridors
            </h2>
            <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
              Our direct network spans luxury residential belts in South Mumbai (Worli, Malabar Hill, Cuffe Parade) and Western Suburbs (Bandra West, Khar, Juhu), alongside Grade-A commercial corridors in Bandra-Kurla Complex (BKC), Lower Parel, and Andheri East.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-stone-800 text-sm">
              <div>
                <p className="font-bold text-amber-400 font-serif text-lg">100%</p>
                <p className="text-stone-400 text-xs">Direct Listings Only</p>
              </div>
              <div>
                <p className="font-bold text-amber-400 font-serif text-lg">MahaRERA</p>
                <p className="text-stone-400 text-xs">Compliance Advisory</p>
              </div>
              <div>
                <p className="font-bold text-amber-400 font-serif text-lg">MMRDA</p>
                <p className="text-stone-400 text-xs">Regional Jurisdiction</p>
              </div>
            </div>

            <div className="pt-6">
              <Link
                to="/properties"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold text-sm transition-colors"
              >
                <span>Browse Verified Properties</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Compliance Notice */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="space-y-1">
            <h3 className="font-semibold text-stone-900 text-base">Regulatory & Brokerage Compliance</h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-2xl">
              P2P Property acts in compliance with Real Estate (Regulation and Development) Act, 2016 and Maharashtra Real Estate Regulatory Authority (MahaRERA) agent registration norms. Independent legal due diligence is recommended prior to signing definitive sale deeds.
            </p>
          </div>
          <Link
            to="/contact"
            className="shrink-0 px-5 py-2.5 bg-stone-900 text-white hover:bg-stone-800 rounded-lg text-xs font-semibold tracking-wide uppercase transition-colors"
          >
            Direct Concierge Desk
          </Link>
        </div>
      </div>
    </div>
  );
};
