import React, { useMemo, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { 
  Building2, 
  Home, 
  MapPin, 
  Bookmark, 
  SlidersHorizontal,
  X,
  Search,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { PropertyCard } from '../components/property/PropertyCard';
import { PropertyFilterBar } from '../components/property/PropertyFilterBar';
import { PropertyCategory, TransactionType } from '../types/property';

interface PropertiesPageProps {
  initialCategory?: PropertyCategory | 'all';
  initialTransaction?: TransactionType | 'all';
  pageTitle?: string;
  pageSubtitle?: string;
}

export const PropertiesPage: React.FC<PropertiesPageProps> = ({
  initialCategory,
  initialTransaction,
  pageTitle,
  pageSubtitle
}) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { 
    properties, 
    filters, 
    setFilters, 
    updateFilter, 
    resetFilters,
    savedPropertyIds 
  } = useProperty();

  // Sync initial query params with context filters on mount/url change
  useEffect(() => {
    const urlCategory = (searchParams.get('category') as PropertyCategory) || initialCategory;
    const urlTransaction = (searchParams.get('transactionType') as TransactionType) || initialTransaction;
    const urlLocation = searchParams.get('location');
    const urlBhk = searchParams.get('bhk');
    const urlType = searchParams.get('propertyType');
    const urlMinPrice = searchParams.get('minPrice');
    const urlMaxPrice = searchParams.get('maxPrice');
    const urlMinArea = searchParams.get('minCarpetArea');
    const urlMaxArea = searchParams.get('maxCarpetArea');
    const urlQuery = searchParams.get('q') || searchParams.get('searchQuery');
    const urlSaved = searchParams.get('saved') === 'true';

    setFilters((prev) => ({
      ...prev,
      category: urlCategory || prev.category || 'all',
      transactionType: urlTransaction || prev.transactionType || 'all',
      location: urlLocation !== null ? urlLocation : prev.location,
      bhk: urlBhk !== null ? urlBhk : prev.bhk,
      propertyType: urlType !== null ? urlType : prev.propertyType,
      minPrice: urlMinPrice ? Number(urlMinPrice) : prev.minPrice,
      maxPrice: urlMaxPrice ? Number(urlMaxPrice) : prev.maxPrice,
      minCarpetArea: urlMinArea ? Number(urlMinArea) : prev.minCarpetArea,
      maxCarpetArea: urlMaxArea ? Number(urlMaxArea) : prev.maxCarpetArea,
      searchQuery: urlQuery !== null ? urlQuery : prev.searchQuery
    }));
  }, [searchParams, initialCategory, initialTransaction]);

  const showSavedOnly = searchParams.get('saved') === 'true';

  // Live filter engine
  const filteredProperties = useMemo(() => {
    return properties.filter((prop) => {
      // Saved filter
      if (showSavedOnly && !savedPropertyIds.includes(prop.id)) {
        return false;
      }

      // Category filter
      if (filters.category && filters.category !== 'all' && prop.category !== filters.category) {
        return false;
      }

      // Transaction filter
      if (filters.transactionType && filters.transactionType !== 'all' && prop.transactionType !== filters.transactionType) {
        return false;
      }

      // Location match
      if (filters.location && filters.location.trim()) {
        const targetLoc = filters.location.toLowerCase();
        const propLoc = `${prop.location.locality} ${prop.location.area} ${prop.location.buildingName}`.toLowerCase();
        if (!propLoc.includes(targetLoc)) {
          return false;
        }
      }

      // Free text search
      if (filters.searchQuery && filters.searchQuery.trim()) {
        const query = filters.searchQuery.toLowerCase();
        const searchCorpus = `${prop.title} ${prop.description} ${prop.location.locality} ${prop.location.buildingName} ${prop.propertyType}`.toLowerCase();
        if (!searchCorpus.includes(query)) {
          return false;
        }
      }

      // Price filter
      if (filters.minPrice !== undefined && prop.pricing.price < filters.minPrice) {
        return false;
      }
      if (filters.maxPrice !== undefined && prop.pricing.price > filters.maxPrice) {
        return false;
      }

      // BHK filter for residential
      if (filters.bhk && filters.bhk.trim()) {
        if (prop.category !== 'residential' || prop.residentialDetails.bhk !== filters.bhk) {
          return false;
        }
      }

      // Property type filter
      if (filters.propertyType && filters.propertyType.trim()) {
        if (prop.propertyType !== filters.propertyType) {
          return false;
        }
      }

      // Carpet area filter
      const carpet = prop.category === 'residential' 
        ? prop.residentialDetails.carpetArea 
        : prop.commercialDetails.carpetArea;

      if (filters.minCarpetArea !== undefined && carpet < filters.minCarpetArea) {
        return false;
      }
      if (filters.maxCarpetArea !== undefined && carpet > filters.maxCarpetArea) {
        return false;
      }

      // Furnishing
      if (filters.furnishing && filters.furnishing.trim()) {
        const propFurnishing = prop.category === 'residential'
          ? prop.residentialDetails.furnishing
          : prop.commercialDetails.furnishing;
        if (propFurnishing !== filters.furnishing) {
          return false;
        }
      }

      // Parking
      if (filters.hasParking) {
        const parking = prop.category === 'residential'
          ? prop.residentialDetails.parking.covered + prop.residentialDetails.parking.open
          : prop.commercialDetails.parking.covered + prop.commercialDetails.parking.open;
        if (parking <= 0) {
          return false;
        }
      }

      // Verified only
      if (filters.verifiedOnly && !prop.isVerified) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'price_asc') return a.pricing.price - b.pricing.price;
      if (filters.sortBy === 'price_desc') return b.pricing.price - a.pricing.price;
      if (filters.sortBy === 'area_desc') {
        const areaA = a.category === 'residential' ? a.residentialDetails.carpetArea : a.commercialDetails.carpetArea;
        const areaB = b.category === 'residential' ? b.residentialDetails.carpetArea : b.commercialDetails.carpetArea;
        return areaB - areaA;
      }
      // default newest
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [properties, filters, showSavedOnly, savedPropertyIds]);

  // Derived Title
  const activeTitle = pageTitle || (
    showSavedOnly 
      ? 'Your Saved Properties' 
      : filters.category === 'residential'
        ? 'Residential Properties in Mumbai'
        : filters.category === 'commercial'
          ? 'Commercial Real Estate in Mumbai'
          : 'All Mumbai Properties'
  );

  const activeSubtitle = pageSubtitle || (
    showSavedOnly
      ? `You have bookmarked ${savedPropertyIds.length} properties for direct review.`
      : 'Connect directly with verified property owners across Mumbai.'
  );

  return (
    <div className="min-h-screen pb-20">
      
      {/* Page Title & Breadcrumb header */}
      <div className="bg-[#FAF9F5] border-b border-stone-200 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
              <Link to="/" className="hover:text-stone-900">Home</Link>
              <span>/</span>
              <span className="text-stone-900 font-medium capitalize">
                {showSavedOnly ? 'Saved' : filters.category === 'all' ? 'Properties' : filters.category}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-serif text-stone-950">
              {activeTitle}
            </h1>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              {activeSubtitle}
            </p>
          </div>

          <div className="text-right hidden sm:block">
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">
              Market Inventory
            </span>
            <p className="text-sm font-semibold text-stone-900">
              {filteredProperties.length} Verified {filteredProperties.length === 1 ? 'Listing' : 'Listings'}
            </p>
          </div>
        </div>
      </div>

      {/* Reusable Filter Bar */}
      <PropertyFilterBar
        filters={filters}
        onFilterChange={updateFilter}
        onReset={resetFilters}
        totalResults={filteredProperties.length}
      />

      {/* Main Content Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Active Filters Summary chips */}
        {(filters.location || filters.bhk || filters.propertyType || filters.verifiedOnly || showSavedOnly) && (
          <div className="flex items-center flex-wrap gap-2 mb-6 text-xs text-stone-600">
            <span className="font-medium text-stone-800">Filtered by:</span>

            {showSavedOnly && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-100 text-amber-900 rounded-md font-medium">
                Saved Watchlist ({savedPropertyIds.length})
                <Link to="/properties" className="hover:text-amber-950">
                  <X className="w-3.5 h-3.5" />
                </Link>
              </span>
            )}

            {filters.location && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md font-medium">
                Location: {filters.location}
                <button type="button" onClick={() => updateFilter('location', '')}>
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            )}

            {filters.bhk && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md font-medium">
                {filters.bhk}
                <button type="button" onClick={() => updateFilter('bhk', '')}>
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            )}

            {filters.propertyType && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md font-medium">
                {filters.propertyType}
                <button type="button" onClick={() => updateFilter('propertyType', '')}>
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            )}

            {filters.verifiedOnly && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 text-emerald-800 rounded-md font-medium">
                Verified Only
                <button type="button" onClick={() => updateFilter('verifiedOnly', false)}>
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            )}

            <button
              type="button"
              onClick={resetFilters}
              className="text-stone-500 hover:text-stone-900 underline ml-2"
            >
              Reset all
            </button>
          </div>
        )}

        {/* Results Grid */}
        {filteredProperties.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center max-w-lg mx-auto my-12 space-y-4">
            <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-500 flex items-center justify-center mx-auto">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-stone-900">
              No matching properties found
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              We couldn’t find direct listings matching your current criteria in Mumbai. Try broadening your location or budget limits.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={resetFilters}
                className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg transition-colors"
              >
                Clear Filters
              </button>
            </div>
          </div>
        )}

      </main>

    </div>
  );
};
