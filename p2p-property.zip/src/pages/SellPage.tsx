import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, 
  ShieldCheck, 
  PlusCircle, 
  ArrowRight, 
  CheckCircle2, 
  TrendingUp, 
  Users, 
  Key 
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { PropertyCard } from '../components/property/PropertyCard';

export const SellPage: React.FC = () => {
  const { properties } = useProperty();

  // Find properties currently listed for sale
  const saleProperties = properties.filter(
    (p) => p.transactionType === 'buy' || p.transactionType === 'sell'
  );

  return (
    <div className="min-h-screen pb-20 space-y-16">
      
      {/* Header Banner */}
      <section className="bg-[#FAF9F5] border-b border-stone-200 py-12 sm:py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center space-y-5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-semibold uppercase tracking-wider">
            <Building2 className="w-3.5 h-3.5" />
            <span>Direct Property Sales · Mumbai</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-bold font-serif text-stone-950 leading-tight">
            Sell or List Your Property Directly
          </h1>

          <p className="text-stone-600 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Eliminate traditional broker friction and unnecessary commission fees. Connect directly with verified, pre-screened buyers searching for residential and commercial real estate in Mumbai.
          </p>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to="/list-property"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
            >
              <PlusCircle className="w-4 h-4 text-amber-400" />
              <span>List Your Property Free</span>
            </Link>
            <Link
              to="/properties?transactionType=buy"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-stone-700 bg-white border border-stone-300 hover:bg-stone-50 rounded-lg transition-colors"
            >
              <span>Explore Active Buyer Demand</span>
            </Link>
          </div>
        </div>
      </section>

      {/* 3 Step Direct Seller Roadmap */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-10 space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-800">
            How It Works For Owners
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-stone-950">
            3 Simple Steps to Deal Directly
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-3">
            <div className="w-10 h-10 rounded-lg bg-stone-100 flex items-center justify-center font-bold text-stone-900 font-serif">
              1
            </div>
            <h3 className="text-base font-bold text-stone-900">List Details & Specs</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Upload property photos, specify carpet area, pricing expectations, and amenities via our straightforward 8-step listing wizard.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-3">
            <div className="w-10 h-10 rounded-lg bg-stone-100 flex items-center justify-center font-bold text-stone-900 font-serif">
              2
            </div>
            <h3 className="text-base font-bold text-stone-900">Get Title Verified</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Our concierge confirms your listing authenticity and applies our verified badge, increasing genuine buyer response rates by up to 3x.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-3">
            <div className="w-10 h-10 rounded-lg bg-stone-100 flex items-center justify-center font-bold text-stone-900 font-serif">
              3
            </div>
            <h3 className="text-base font-bold text-stone-900">Connect & Close Direct</h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Receive verified inquiries and confirmed site visits straight to your inbox without broker dilution or annoying cold calls.
            </p>
          </div>
        </div>
      </section>

      {/* Current Active Properties For Sale */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-800 block mb-1">
              Active Marketplace
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-stone-950">
              Current Properties Listed for Sale
            </h2>
          </div>
          <Link
            to="/buy"
            className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-stone-900 hover:text-amber-800 transition-colors"
          >
            <span>View All For Sale</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {saleProperties.slice(0, 4).map((prop) => (
            <PropertyCard key={prop.id} property={prop} />
          ))}
        </div>
      </section>

    </div>
  );
};
