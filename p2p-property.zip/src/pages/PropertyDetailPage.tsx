import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  MapPin, 
  ShieldCheck, 
  Bookmark, 
  Share2, 
  Calendar, 
  MessageCircle, 
  Building2, 
  Home, 
  Layers, 
  Maximize, 
  Car, 
  Sparkles, 
  Train, 
  Plane, 
  Hospital, 
  School,
  Check,
  Phone,
  ArrowLeft,
  Lock,
  ChevronRight
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { ImageGallery } from '../components/property/ImageGallery';
import { InquiryModal } from '../components/common/InquiryModal';
import { SiteVisitModal } from '../components/common/SiteVisitModal';
import { ShareModal } from '../components/common/ShareModal';
import { PropertyCard } from '../components/property/PropertyCard';
import { formatPriceINR, formatArea } from '../utils/formatters';

export const PropertyDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getPropertyById, isSaved, toggleSaveProperty, properties } = useProperty();

  const [inquiryModalOpen, setInquiryModalOpen] = useState(false);
  const [siteVisitModalOpen, setSiteVisitModalOpen] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);

  const [property, setProperty] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      setLoading(true);
      getPropertyById(id)
        .then((p) => {
          setProperty(p || null);
        })
        .finally(() => setLoading(false));
    }
  }, [id, getPropertyById]);

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto py-24 px-4 text-center text-xs text-stone-500">
        Loading property details from Mumbai database...
      </div>
    );
  }

  if (!property) {
    return (
      <div className="max-w-2xl mx-auto py-24 px-4 text-center space-y-4">
        <h2 className="text-2xl font-serif font-bold text-stone-900">
          Property Not Found
        </h2>
        <p className="text-xs sm:text-sm text-stone-600">
          The property listing you are trying to view might have been completed, unlisted, or does not exist.
        </p>
        <Link
          to="/properties"
          className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-md transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Browse All Mumbai Properties</span>
        </Link>
      </div>
    );
  }

  const saved = isSaved(property.id);

  const carpetArea = property.category === 'residential' 
    ? property.residentialDetails.carpetArea 
    : property.commercialDetails.carpetArea;

  const builtUpArea = property.category === 'residential' 
    ? property.residentialDetails.builtUpArea 
    : property.commercialDetails.builtUpArea;

  const floorNumber = property.category === 'residential'
    ? property.residentialDetails.floor
    : property.commercialDetails.floor;

  const totalFloors = property.category === 'residential'
    ? property.residentialDetails.totalFloors
    : property.commercialDetails.totalFloors;

  const furnishing = property.category === 'residential'
    ? property.residentialDetails.furnishing
    : property.commercialDetails.furnishing;

  const coveredParking = property.category === 'residential'
    ? property.residentialDetails.parking.covered
    : property.commercialDetails.parking.covered;

  const openParking = property.category === 'residential'
    ? property.residentialDetails.parking.open
    : property.commercialDetails.parking.open;

  const bhk = property.category === 'residential' ? property.residentialDetails.bhk : null;

  return (
    <div className="min-h-screen pb-24">
      
      {/* Breadcrumb Bar */}
      <div className="bg-[#FAF9F5] border-b border-stone-200 py-3.5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs text-stone-600">
          <div className="flex items-center gap-2 truncate">
            <Link to="/" className="hover:text-stone-950">Home</Link>
            <ChevronRight className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <Link to={`/properties?category=${property.category}`} className="capitalize hover:text-stone-950">
              {property.category}
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span className="truncate text-stone-900 font-medium">
              {property.location.locality}
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setShareModalOpen(true)}
              className="inline-flex items-center gap-1.5 hover:text-stone-900 transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Share</span>
            </button>
            <button
              type="button"
              onClick={() => toggleSaveProperty(property.id)}
              className={`inline-flex items-center gap-1.5 transition-colors ${
                saved ? 'text-amber-700 font-semibold' : 'hover:text-stone-900'
              }`}
            >
              <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-current' : ''}`} />
              <span className="hidden sm:inline">{saved ? 'Saved' : 'Save'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10">
          
          {/* Left Column (8 cols): Gallery, Overview, Specifications, Amenities, Description, Nearby */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* Gallery Component */}
            <ImageGallery images={property.images} title={property.title} />

            {/* Title & Core Location */}
            <div className="space-y-3 pb-6 border-b border-stone-200">
              <div className="flex items-center gap-2 text-xs">
                {property.isVerified && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 text-emerald-800 bg-emerald-50 rounded font-medium border border-emerald-200/60">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    Verified Direct Listing
                  </span>
                )}
                <span className="text-stone-400">·</span>
                <span className="capitalize font-semibold text-stone-800 uppercase tracking-wider text-[11px]">
                  {property.category}
                </span>
                <span className="text-stone-400">·</span>
                <span className="capitalize font-medium text-stone-600">
                  For {property.transactionType}
                </span>
              </div>

              <h1 className="text-2xl sm:text-4xl font-bold font-serif text-stone-950 leading-tight">
                {property.title}
              </h1>

              <div className="flex items-center gap-2 text-xs sm:text-sm text-stone-600">
                <MapPin className="w-4 h-4 text-stone-400 shrink-0" />
                <span>
                  {property.location.buildingName}, {property.location.area}, {property.location.locality}, Mumbai - {property.location.pincode}
                </span>
              </div>
            </div>

            {/* Quick Specs Highlight Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-5 bg-white rounded-xl border border-stone-200">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                  Carpet Area
                </span>
                <p className="text-base font-bold text-stone-900 mt-0.5 tabular-nums">
                  {formatArea(carpetArea)}
                </p>
                <span className="text-[10px] text-stone-500">Built-up: {formatArea(builtUpArea)}</span>
              </div>

              {bhk ? (
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                    Configuration
                  </span>
                  <p className="text-base font-bold text-stone-900 mt-0.5">
                    {bhk}
                  </p>
                  <span className="text-[10px] text-stone-500">{property.propertyType}</span>
                </div>
              ) : (
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                    Property Type
                  </span>
                  <p className="text-base font-bold text-stone-900 mt-0.5">
                    {property.propertyType}
                  </p>
                  <span className="text-[10px] text-stone-500">Commercial Grade</span>
                </div>
              )}

              <div>
                <span className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                  Floor Level
                </span>
                <p className="text-base font-bold text-stone-900 mt-0.5">
                  {floorNumber === 0 ? 'Ground' : `${floorNumber}th of ${totalFloors}`}
                </p>
                <span className="text-[10px] text-stone-500">High-rise Tower</span>
              </div>

              <div>
                <span className="text-[11px] uppercase tracking-wider text-stone-400 font-semibold block">
                  Car Parking
                </span>
                <p className="text-base font-bold text-stone-900 mt-0.5">
                  {coveredParking + openParking > 0 
                    ? `${coveredParking} Covered${openParking > 0 ? `, ${openParking} Open` : ''}` 
                    : 'Street Parking'}
                </p>
                <span className="text-[10px] text-stone-500">Dedicated Bay</span>
              </div>
            </div>

            {/* Description Section */}
            <div className="space-y-3">
              <h3 className="text-lg font-bold font-serif text-stone-900">
                Property Description
              </h3>
              <p className="text-sm text-stone-700 leading-relaxed whitespace-pre-line">
                {property.description}
              </p>
            </div>

            {/* Detailed Specifications table */}
            <div className="space-y-4 pt-4 border-t border-stone-200">
              <h3 className="text-lg font-bold font-serif text-stone-900">
                Property Specifications
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-xs border border-stone-200 bg-white rounded-xl p-5">
                <div className="flex justify-between py-1.5 border-b border-stone-100">
                  <span className="text-stone-500">Property Category</span>
                  <span className="font-semibold text-stone-900 capitalize">{property.category}</span>
                </div>

                <div className="flex justify-between py-1.5 border-b border-stone-100">
                  <span className="text-stone-500">Transaction</span>
                  <span className="font-semibold text-stone-900 uppercase">{property.transactionType}</span>
                </div>

                <div className="flex justify-between py-1.5 border-b border-stone-100">
                  <span className="text-stone-500">Furnishing</span>
                  <span className="font-semibold text-stone-900 capitalize">{furnishing?.replace('-', ' ')}</span>
                </div>

                {property.category === 'residential' && property.residentialDetails.facing && (
                  <div className="flex justify-between py-1.5 border-b border-stone-100">
                    <span className="text-stone-500">Facing & Orientation</span>
                    <span className="font-semibold text-stone-900">{property.residentialDetails.facing}</span>
                  </div>
                )}

                {property.category === 'residential' && property.residentialDetails.bathrooms && (
                  <div className="flex justify-between py-1.5 border-b border-stone-100">
                    <span className="text-stone-500">Bathrooms</span>
                    <span className="font-semibold text-stone-900">{property.residentialDetails.bathrooms} En-Suite</span>
                  </div>
                )}

                {property.category === 'commercial' && (
                  <>
                    <div className="flex justify-between py-1.5 border-b border-stone-100">
                      <span className="text-stone-500">Dedicated Washrooms</span>
                      <span className="font-semibold text-stone-900">{property.commercialDetails.washrooms}</span>
                    </div>

                    <div className="flex justify-between py-1.5 border-b border-stone-100">
                      <span className="text-stone-500">Power Backup</span>
                      <span className="font-semibold text-stone-900">
                        {property.commercialDetails.powerBackup ? '100% DG Backup' : 'Standard'}
                      </span>
                    </div>

                    <div className="flex justify-between py-1.5 border-b border-stone-100">
                      <span className="text-stone-500">Loading Bay</span>
                      <span className="font-semibold text-stone-900">
                        {property.commercialDetails.loadingUnloadingAvailability ? 'Available' : 'No'}
                      </span>
                    </div>
                  </>
                )}

                <div className="flex justify-between py-1.5 border-b border-stone-100">
                  <span className="text-stone-500">City / Jurisdiction</span>
                  <span className="font-semibold text-stone-900">Mumbai (MCGM)</span>
                </div>

                <div className="flex justify-between py-1.5 border-b border-stone-100">
                  <span className="text-stone-500">Direct Owner Representation</span>
                  <span className="font-semibold text-emerald-800">Verified Individual</span>
                </div>
              </div>
            </div>

            {/* Amenities Section */}
            {property.amenities && property.amenities.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-stone-200">
                <h3 className="text-lg font-bold font-serif text-stone-900">
                  Amenities & Facilities
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {property.amenities.map((amenity: string, idx: number) => (
                    <div 
                      key={idx}
                      className="p-3 bg-white rounded-lg border border-stone-200 flex items-center gap-2.5 text-xs text-stone-800"
                    >
                      <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="font-medium">{amenity}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Nearby Transit & Hubs */}
            {property.nearbyPlaces && property.nearbyPlaces.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-stone-200">
                <h3 className="text-lg font-bold font-serif text-stone-900">
                  Transit & Neighborhood Connectivity
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {property.nearbyPlaces.map((place: any, idx: number) => (
                    <div 
                      key={idx}
                      className="p-3 bg-white rounded-lg border border-stone-200 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        {place.type === 'metro' || place.type === 'railway' ? (
                          <Train className="w-4 h-4 text-stone-500 shrink-0" />
                        ) : place.type === 'airport' ? (
                          <Plane className="w-4 h-4 text-stone-500 shrink-0" />
                        ) : place.type === 'hospital' ? (
                          <Hospital className="w-4 h-4 text-stone-500 shrink-0" />
                        ) : place.type === 'school' ? (
                          <School className="w-4 h-4 text-stone-500 shrink-0" />
                        ) : (
                          <MapPin className="w-4 h-4 text-stone-500 shrink-0" />
                        )}
                        <span className="font-medium text-stone-900">{place.name}</span>
                      </div>
                      <span className="font-semibold text-stone-600 bg-stone-100 px-2 py-0.5 rounded">
                        {place.distanceKm} km
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* Right Column (4 cols): Sticky Purchase / Contact Module */}
          <div className="lg:col-span-4">
            <div className="sticky top-28 space-y-6">
              
              {/* Purchase Box */}
              <div className="bg-white rounded-2xl border border-stone-200 shadow-md p-6 space-y-5">
                
                {/* Pricing display */}
                <div className="pb-4 border-b border-stone-100">
                  <span className="text-[11px] uppercase tracking-wider text-stone-500 font-semibold block">
                    Direct Owner Pricing
                  </span>
                  <div className="text-3xl font-bold font-serif text-stone-950 mt-1 tabular-nums">
                    {formatPriceINR(property.pricing.price, property.pricing.priceDisplayType)}
                  </div>
                  
                  {property.pricing.maintenanceAmount ? (
                    <div className="text-xs text-stone-600 mt-1">
                      Maintenance: ₹{property.pricing.maintenanceAmount.toLocaleString('en-IN')}/mo
                    </div>
                  ) : null}

                  {property.pricing.securityDeposit ? (
                    <div className="text-xs text-stone-600 mt-0.5">
                      Security Deposit: ₹{property.pricing.securityDeposit.toLocaleString('en-IN')}
                    </div>
                  ) : null}

                  {property.pricing.isNegotiable && (
                    <span className="inline-block mt-2 text-[10px] uppercase tracking-wide font-medium text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                      Open to Genuine Negotiation
                    </span>
                  )}
                </div>

                {/* Owner Privacy Protection Notice */}
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/80 text-xs text-stone-600 space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-stone-900">
                    <Lock className="w-3.5 h-3.5 text-stone-600" />
                    <span>Protected Direct Connection</span>
                  </div>
                  <p className="text-[11px] text-stone-500">
                    Direct Listing by Owner {property.maskedContact.nameInitials} (Phone ending {property.maskedContact.verifiedPhoneEnding}). Private contact protected from brokerage telemarketing.
                  </p>
                </div>

                {/* Action Buttons: Contact Owner & Request Site Visit */}
                <div className="space-y-2.5">
                  <button
                    type="button"
                    onClick={() => setInquiryModalOpen(true)}
                    className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Contact Owner Directly</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSiteVisitModalOpen(true)}
                    className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-semibold uppercase tracking-wider text-stone-900 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-lg transition-colors"
                  >
                    <Calendar className="w-4 h-4 text-amber-800" />
                    <span>Request Site Visit</span>
                  </button>
                </div>

                {/* Secondary Action Row: Save Property & Share */}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-100">
                  <button
                    type="button"
                    onClick={() => toggleSaveProperty(property.id)}
                    className={`inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-lg border transition-colors ${
                      saved 
                        ? 'bg-amber-50 border-amber-300 text-amber-800' 
                        : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-current' : ''}`} />
                    <span>{saved ? 'Saved' : 'Save Property'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShareModalOpen(true)}
                    className="inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-stone-700 border border-stone-200 hover:bg-stone-50 rounded-lg transition-colors"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Share Property</span>
                  </button>
                </div>

                {/* Trust guarantee bullets */}
                <div className="space-y-1.5 pt-2 text-[11px] text-stone-500">
                  <div className="flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>No uninvited middlemen broker phone calls</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Owner verified title & occupation certificate</span>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>

        {/* Similar Properties Section (Part 3) */}
        {(() => {
          const similar = properties
            .filter((p) => p.id !== property.id && p.status === 'APPROVED' && (
              p.location.area === property.location.area || 
              p.category === property.category || 
              p.transactionType === property.transactionType
            ))
            .slice(0, 3);

          if (similar.length === 0) return null;

          return (
            <div className="mt-16 pt-12 border-t border-stone-200">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold font-serif text-stone-900">Similar Verified Properties in Mumbai</h3>
                  <p className="text-xs text-stone-500 mt-0.5">Explore matching homes and commercial suites in {property.location.area} and adjacent neighborhoods.</p>
                </div>
                <Link 
                  to={`/properties?location=${encodeURIComponent(property.location.area)}`}
                  className="text-xs font-semibold text-amber-700 hover:text-amber-800 transition-colors"
                >
                  View All in {property.location.area} →
                </Link>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {similar.map((simProp) => (
                  <PropertyCard key={simProp.id} property={simProp} />
                ))}
              </div>
            </div>
          );
        })()}

      </div>

      {/* Floating Bottom Bar on Mobile (Within 15% mobile sticky cap) */}
      <div className="lg:hidden fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-stone-200 p-3 z-40 flex items-center justify-between gap-3 shadow-lg">
        <div>
          <span className="text-[10px] text-stone-500 uppercase tracking-wider block">Price</span>
          <span className="font-serif font-bold text-stone-900 text-base">
            {formatPriceINR(property.pricing.price, property.pricing.priceDisplayType)}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSiteVisitModalOpen(true)}
            className="px-3 py-2 text-xs font-semibold rounded-md border border-stone-300 text-stone-800 bg-white"
          >
            Site Visit
          </button>
          <button
            type="button"
            onClick={() => setInquiryModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 rounded-md shadow-xs"
          >
            Contact Owner
          </button>
        </div>
      </div>

      {/* Modals */}
      <InquiryModal
        property={property}
        isOpen={inquiryModalOpen}
        onClose={() => setInquiryModalOpen(false)}
      />

      <SiteVisitModal
        property={property}
        isOpen={siteVisitModalOpen}
        onClose={() => setSiteVisitModalOpen(false)}
      />

      <ShareModal
        property={property}
        isOpen={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
      />

    </div>
  );
};
