import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { 
  Building2, 
  Search, 
  Filter, 
  Eye, 
  Check, 
  X, 
  AlertTriangle, 
  BadgeCheck, 
  RotateCcw, 
  Clock, 
  ShieldCheck, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';
import { formatPriceINR, formatArea } from '../../utils/formatters';

const STATUS_TABS = [
  { id: 'ALL', label: 'All' },
  { id: 'PENDING', label: 'Pending Approval' },
  { id: 'APPROVED', label: 'Approved' },
  { id: 'REJECTED', label: 'Rejected' },
  { id: 'SOLD', label: 'Sold' },
  { id: 'RENTED', label: 'Rented' },
  { id: 'LEASED', label: 'Leased' },
  { id: 'INACTIVE', label: 'Inactive' }
];

export const AdminPropertiesPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { showToast } = useProperty();

  // Tab & Filter state
  const activeTab = searchParams.get('status') || 'ALL';
  const [searchTerm, setSearchTerm] = useState(searchParams.get('q') || '');
  const [categoryFilter, setCategoryFilter] = useState(searchParams.get('category') || 'ALL');
  const [transactionFilter, setTransactionFilter] = useState(searchParams.get('transaction') || 'ALL');
  const [verificationFilter, setVerificationFilter] = useState(searchParams.get('verification') || 'ALL');
  const [minPrice, setMinPrice] = useState(searchParams.get('min_price') || '');
  const [maxPrice, setMaxPrice] = useState(searchParams.get('max_price') || '');

  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal states for Reject & Request Changes
  const [modalAction, setModalAction] = useState<'reject' | 'request_changes' | null>(null);
  const [modalProperty, setModalProperty] = useState<any | null>(null);
  const [actionReason, setActionReason] = useState<string>('');

  const loadProperties = async () => {
    setLoading(true);
    try {
      const filters: any = {};
      if (activeTab !== 'ALL') {
        filters.status = activeTab === 'PENDING' ? 'PENDING_APPROVAL' : activeTab;
      }
      if (searchTerm.trim()) filters.search = searchTerm.trim();
      if (categoryFilter !== 'ALL') filters.category = categoryFilter;
      if (transactionFilter !== 'ALL') filters.transaction_type = transactionFilter;
      if (verificationFilter !== 'ALL') filters.verification_status = verificationFilter;
      if (minPrice) filters.min_price = minPrice;
      if (maxPrice) filters.max_price = maxPrice;

      const res = await api.admin.properties(filters);
      setProperties(res.properties || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading properties.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProperties();
  }, [activeTab, categoryFilter, transactionFilter, verificationFilter]);

  const handleTabChange = (tabId: string) => {
    const next = new URLSearchParams(searchParams);
    if (tabId === 'ALL') next.delete('status');
    else next.set('status', tabId);
    setSearchParams(next);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadProperties();
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setCategoryFilter('ALL');
    setTransactionFilter('ALL');
    setVerificationFilter('ALL');
    setMinPrice('');
    setMaxPrice('');
    setSearchParams({});
    setTimeout(loadProperties, 0);
  };

  const handleExecuteReview = async (id: string, action: any, reason?: string) => {
    try {
      await api.admin.reviewProperty(id, action, reason);
      showToast(`Property action completed: ${action.replace('_', ' ')}.`);
      setModalAction(null);
      setModalProperty(null);
      setActionReason('');
      loadProperties();
    } catch (err: any) {
      showToast(err.message || 'Error updating property.');
    }
  };

  return (
    <AdminLayout
      title="Property Listings Management"
      subtitle="Comprehensive moderation queue, title verification, approval status, and compliance audit for Mumbai listings."
      onRefresh={loadProperties}
      isRefreshing={loading}
    >
      <div className="space-y-6">

        {/* Tab Strip */}
        <div className="bg-white rounded-xl border border-stone-200 p-1.5 shadow-2xs overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1 min-w-max">
            {STATUS_TABS.map((tab) => {
              const isSelected = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => handleTabChange(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    isSelected
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-950 hover:bg-stone-100'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Search & Multifaceted Filters */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs space-y-3">
          <form onSubmit={handleSearchSubmit} className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by Title, Property ID, Locality, or Owner name/email..."
                className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
              />
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg transition-colors shrink-0"
            >
              Search
            </button>
          </form>

          {/* Secondary filter chips */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-stone-100 text-xs">
            {/* Category */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-stone-500">Category:</span>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-2.5 py-1 border border-stone-200 rounded-md bg-stone-50 text-xs font-medium"
              >
                <option value="ALL">All Categories</option>
                <option value="residential">Residential</option>
                <option value="commercial">Commercial</option>
              </select>
            </div>

            {/* Transaction */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-stone-500">Transaction:</span>
              <select
                value={transactionFilter}
                onChange={(e) => setTransactionFilter(e.target.value)}
                className="px-2.5 py-1 border border-stone-200 rounded-md bg-stone-50 text-xs font-medium"
              >
                <option value="ALL">All Transactions</option>
                <option value="buy">Buy</option>
                <option value="rent">Rent</option>
                <option value="lease">Lease</option>
                <option value="sell">Sell</option>
              </select>
            </div>

            {/* Verification Status */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-stone-500">Verification:</span>
              <select
                value={verificationFilter}
                onChange={(e) => setVerificationFilter(e.target.value)}
                className="px-2.5 py-1 border border-stone-200 rounded-md bg-stone-50 text-xs font-medium"
              >
                <option value="ALL">All Verification</option>
                <option value="VERIFIED">Verified Only</option>
                <option value="UNDER_REVIEW">Under Review</option>
                <option value="UNVERIFIED">Unverified</option>
                <option value="REJECTED">Verification Rejected</option>
              </select>
            </div>

            {/* Price inputs */}
            <div className="flex items-center gap-1">
              <input
                type="number"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                placeholder="Min Price (₹)"
                className="w-28 px-2 py-1 border border-stone-200 rounded-md text-xs"
              />
              <span className="text-stone-400">-</span>
              <input
                type="number"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                placeholder="Max Price (₹)"
                className="w-28 px-2 py-1 border border-stone-200 rounded-md text-xs"
              />
            </div>

            <button
              type="button"
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-stone-600 hover:text-stone-900 text-xs font-medium"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>

            <span className="ml-auto text-stone-400 text-[11px] tabular-nums">
              Showing {properties.length} listings
            </span>
          </div>
        </div>

        {/* Listings Table / Responsive Card View */}
        {properties.length > 0 ? (
          <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="p-3.5">Property</th>
                    <th className="p-3.5">Type & Terms</th>
                    <th className="p-3.5">Location</th>
                    <th className="p-3.5">Price</th>
                    <th className="p-3.5">Owner / Agent</th>
                    <th className="p-3.5">Verification</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Review Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {properties.map((prop) => (
                    <tr key={prop.id} className="hover:bg-stone-50/80 transition-colors">
                      
                      {/* Property image + Title */}
                      <td className="p-3.5 max-w-xs">
                        <div className="flex items-start gap-3">
                          <img
                            src={prop.primaryImage}
                            alt={prop.title}
                            className="w-12 h-12 rounded-lg object-cover border border-stone-200 shrink-0 mt-0.5"
                          />
                          <div className="min-w-0">
                            <Link
                              to={`/admin/properties/${prop.id}`}
                              className="font-bold text-stone-900 hover:text-amber-800 transition-colors block truncate"
                            >
                              {prop.title}
                            </Link>
                            <p className="text-[10px] text-stone-400 font-mono mt-0.5">
                              ID: {prop.id} {prop.is_sample ? '· [Sample]' : ''}
                            </p>
                            <p className="text-[10px] text-stone-500">
                              Added {new Date(prop.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </td>

                      {/* Type & Terms */}
                      <td className="p-3.5 whitespace-nowrap">
                        <span className="capitalize font-bold text-stone-900">{prop.category}</span>
                        <p className="text-[11px] text-stone-500 capitalize">{prop.transaction_type} · {prop.property_type}</p>
                        <p className="text-[10px] text-stone-400">{formatArea(prop.carpet_area)}</p>
                      </td>

                      {/* Location */}
                      <td className="p-3.5">
                        <p className="font-semibold text-stone-900">{prop.locality}</p>
                        <p className="text-[10px] text-stone-500 truncate max-w-[120px]">{prop.address || 'Mumbai'}</p>
                        <p className="text-[10px] text-stone-400">{prop.pincode}</p>
                      </td>

                      {/* Price */}
                      <td className="p-3.5 whitespace-nowrap tabular-nums">
                        <p className="font-bold text-stone-900 text-xs sm:text-sm">
                          {formatPriceINR(prop.price)}
                        </p>
                        {prop.maintenance && (
                          <p className="text-[10px] text-stone-500">
                            +₹{prop.maintenance.toLocaleString('en-IN')}/mo maint.
                          </p>
                        )}
                      </td>

                      {/* Owner / Agent */}
                      <td className="p-3.5 whitespace-nowrap">
                        <p className="font-semibold text-stone-900">{prop.owner_name || 'Owner'}</p>
                        <p className="text-[10px] text-stone-500">{prop.owner_phone || '-'}</p>
                        <p className="text-[10px] text-stone-400 capitalize">{prop.owner_role || 'owner'}</p>
                      </td>

                      {/* Verification Status */}
                      <td className="p-3.5 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                          prop.verification_status === 'VERIFIED'
                            ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                            : prop.verification_status === 'UNDER_REVIEW'
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : prop.verification_status === 'REJECTED'
                                ? 'bg-red-100 text-red-900'
                                : 'bg-stone-100 text-stone-600'
                        }`}>
                          <BadgeCheck className="w-3 h-3" />
                          <span>{prop.verification_status || 'UNVERIFIED'}</span>
                        </span>
                      </td>

                      {/* Listing Status */}
                      <td className="p-3.5 whitespace-nowrap">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          prop.status === 'APPROVED'
                            ? 'bg-emerald-100 text-emerald-900'
                            : prop.status === 'PENDING_APPROVAL'
                              ? 'bg-amber-100 text-amber-950 font-bold border border-amber-300'
                              : prop.status === 'REJECTED'
                                ? 'bg-red-100 text-red-900'
                                : prop.status === 'DRAFT'
                                  ? 'bg-stone-100 text-stone-600'
                                  : 'bg-stone-100 text-stone-800'
                        }`}>
                          {prop.status.replace('_', ' ')}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="p-3.5 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          {/* View detail */}
                          <Link
                            to={`/admin/properties/${prop.id}`}
                            className="p-1.5 text-stone-700 hover:text-stone-950 hover:bg-stone-100 rounded"
                            title="Full review sheet"
                          >
                            <Eye className="w-4 h-4" />
                          </Link>

                          {/* Quick Approve */}
                          {prop.status !== 'APPROVED' && (
                            <button
                              type="button"
                              onClick={() => handleExecuteReview(prop.id, 'approve')}
                              className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-semibold text-[11px] shadow-2xs"
                            >
                              Approve
                            </button>
                          )}

                          {/* Request Changes */}
                          {prop.status !== 'DRAFT' && (
                            <button
                              type="button"
                              onClick={() => {
                                setModalProperty(prop);
                                setModalAction('request_changes');
                              }}
                              className="px-2 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded font-semibold text-[11px]"
                            >
                              Changes
                            </button>
                          )}

                          {/* Quick Reject */}
                          {prop.status !== 'REJECTED' && (
                            <button
                              type="button"
                              onClick={() => {
                                setModalProperty(prop);
                                setModalAction('reject');
                              }}
                              className="px-2 py-1 bg-red-100 hover:bg-red-200 text-red-800 rounded font-semibold text-[11px]"
                            >
                              Reject
                            </button>
                          )}

                          {/* Mark Verified */}
                          {prop.verification_status !== 'VERIFIED' ? (
                            <button
                              type="button"
                              onClick={() => handleExecuteReview(prop.id, 'verify')}
                              className="px-2 py-1 border border-stone-300 hover:bg-stone-100 text-stone-800 rounded text-[10px] font-semibold"
                            >
                              Verify
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleExecuteReview(prop.id, 'unverify')}
                              className="px-2 py-1 border border-stone-200 hover:bg-stone-100 text-stone-500 rounded text-[10px]"
                            >
                              Unverify
                            </button>
                          )}

                          {/* Deactivate */}
                          {prop.status === 'APPROVED' && (
                            <button
                              type="button"
                              onClick={() => handleExecuteReview(prop.id, 'deactivate')}
                              className="px-2 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded text-[10px]"
                            >
                              Deactivate
                            </button>
                          )}
                        </div>
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-stone-200 p-12 text-center text-xs text-stone-500 space-y-2">
            <Building2 className="w-8 h-8 text-stone-300 mx-auto" />
            <p className="font-semibold text-stone-900">No properties found</p>
            <p>Try adjusting your search query, status tab, or active filters.</p>
          </div>
        )}

      </div>

      {/* Reject & Request Changes Reason Modal */}
      {modalAction && modalProperty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-stone-200 max-w-md w-full p-6 space-y-4 shadow-xl text-xs">
            <div className="flex items-center gap-2 font-bold text-sm">
              <AlertTriangle className={`w-5 h-5 ${modalAction === 'reject' ? 'text-red-600' : 'text-amber-600'}`} />
              <span className="text-stone-900">
                {modalAction === 'reject' ? 'Reject Property Listing' : 'Request Changes from Owner'}
              </span>
            </div>

            <p className="text-stone-600">
              Target: <strong className="text-stone-950">{modalProperty.title}</strong> (ID: {modalProperty.id})
            </p>

            <div className="space-y-2">
              <label className="font-semibold text-stone-900 block">Select standard reason:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Missing property information',
                  'Incorrect pricing for micro-market',
                  'Poor quality or blurry images',
                  'Duplicate listing detected',
                  'Owner information needs verification',
                  'Clear Occupation Certificate (OC) required',
                  'Suspected false or unverified claim'
                ].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setActionReason(preset)}
                    className="px-2 py-1 rounded bg-stone-100 hover:bg-stone-200 text-stone-700 text-[11px] transition-colors"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="font-semibold text-stone-900 block mb-1">
                Reason / Note for Owner (Saved to Audit Log):
              </label>
              <textarea
                rows={3}
                value={actionReason}
                onChange={(e) => setActionReason(e.target.value)}
                placeholder="Explain the required correction or rejection cause..."
                className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => {
                  setModalAction(null);
                  setModalProperty(null);
                  setActionReason('');
                }}
                className="px-3.5 py-2 border border-stone-200 rounded-lg text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleExecuteReview(modalProperty.id, modalAction, actionReason)}
                className={`px-4 py-2 text-white rounded-lg font-semibold shadow-xs ${
                  modalAction === 'reject'
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-amber-600 hover:bg-amber-700'
                }`}
              >
                Confirm {modalAction === 'reject' ? 'Rejection' : 'Change Request'}
              </button>
            </div>
          </div>
        </div>
      )}

    </AdminLayout>
  );
};
