import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Building2, 
  MapPin, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  BadgeCheck, 
  ShieldCheck, 
  AlertTriangle, 
  User, 
  Phone, 
  Mail, 
  Calendar, 
  Layers, 
  Maximize, 
  Car, 
  Sparkles, 
  ArrowLeft,
  ExternalLink,
  History,
  Check,
  X
} from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';
import { formatPriceINR, formatArea } from '../../utils/formatters';

export const AdminPropertyDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useProperty();

  const [property, setProperty] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);

  // Review modal
  const [modalAction, setModalAction] = useState<'reject' | 'request_changes' | null>(null);
  const [actionReason, setActionReason] = useState<string>('');

  // Owner verification modal
  const [ownerVerificationModal, setOwnerVerificationModal] = useState(false);
  const [selectedOwnerStatus, setSelectedOwnerStatus] = useState<string>('VERIFIED');

  const loadProperty = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const res = await api.admin.getProperty(id);
      setProperty(res.property);
      setSelectedOwnerStatus(res.property.owner?.verification_status || 'VERIFIED');
    } catch (err: any) {
      showToast(err.message || 'Error loading property details.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProperty();
  }, [id]);

  const handleReviewAction = async (action: any, reason?: string) => {
    if (!id) return;
    try {
      await api.admin.reviewProperty(id, action, reason);
      showToast(`Property action completed: ${action.replace('_', ' ')}.`);
      setModalAction(null);
      setActionReason('');
      loadProperty();
    } catch (err: any) {
      showToast(err.message || 'Failed to submit review.');
    }
  };

  const handleUpdateOwnerVerification = async () => {
    if (!property?.owner?.id) return;
    try {
      await api.admin.updateUserStatus(property.owner.id, {
        verification_status: selectedOwnerStatus
      });
      showToast(`Owner verification set to ${selectedOwnerStatus}.`);
      setOwnerVerificationModal(false);
      loadProperty();
    } catch (err: any) {
      showToast(err.message || 'Error updating owner status.');
    }
  };

  if (loading) {
    return (
      <AdminLayout title="Property Review" subtitle="Loading listing details...">
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center text-xs text-stone-500">
          Fetching comprehensive listing data and compliance records...
        </div>
      </AdminLayout>
    );
  }

  if (!property) {
    return (
      <AdminLayout title="Property Not Found" subtitle="Invalid property identifier">
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center space-y-4">
          <p className="text-sm font-semibold text-stone-900">Property not found</p>
          <Link
            to="/admin/properties"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Property Moderation</span>
          </Link>
        </div>
      </AdminLayout>
    );
  }

  const isCommercial = property.category === 'commercial';
  const photos = property.images || [];

  return (
    <AdminLayout
      title={`Review: ${property.title}`}
      subtitle={`ID: ${property.id} · Submitted ${new Date(property.created_at).toLocaleDateString()}`}
      onRefresh={loadProperty}
    >
      <div className="space-y-6">

        {/* Back Link & Review Actions Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white rounded-2xl border border-stone-200 p-4 shadow-2xs">
          <Link
            to="/admin/properties"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-700 hover:text-stone-950"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Moderation Queue</span>
          </Link>

          <div className="flex items-center gap-2 flex-wrap">
            <Link
              to={`/properties/${property.id}`}
              target="_blank"
              className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-xs font-semibold inline-flex items-center gap-1"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Public View</span>
            </Link>

            {/* Approve Button */}
            {property.status !== 'APPROVED' && (
              <button
                type="button"
                onClick={() => handleReviewAction('approve')}
                className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors shadow-2xs"
              >
                Approve Listing
              </button>
            )}

            {/* Request Changes Button */}
            {property.status !== 'DRAFT' && (
              <button
                type="button"
                onClick={() => setModalAction('request_changes')}
                className="px-3.5 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg text-xs font-semibold transition-colors"
              >
                Request Changes
              </button>
            )}

            {/* Reject Button */}
            {property.status !== 'REJECTED' && (
              <button
                type="button"
                onClick={() => setModalAction('reject')}
                className="px-3.5 py-1.5 bg-red-100 hover:bg-red-200 text-red-800 rounded-lg text-xs font-semibold transition-colors"
              >
                Reject Listing
              </button>
            )}

            {/* Verification Status Action Dropdown */}
            <div className="flex items-center gap-1 pl-2 border-l border-stone-200">
              <span className="text-[11px] font-semibold text-stone-500">Title Verification:</span>
              <select
                value={property.verification_status || 'UNVERIFIED'}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === 'VERIFIED') handleReviewAction('verify');
                  else if (val === 'UNDER_REVIEW') handleReviewAction('under_review');
                  else handleReviewAction('unverify');
                }}
                className="px-2 py-1 border border-stone-300 rounded text-xs font-bold bg-white"
              >
                <option value="VERIFIED">VERIFIED</option>
                <option value="UNDER_REVIEW">UNDER_REVIEW</option>
                <option value="UNVERIFIED">UNVERIFIED</option>
              </select>
            </div>
          </div>
        </div>

        {/* Status Highlights Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-4 rounded-2xl border border-stone-200 text-xs">
          <div>
            <span className="text-stone-400 font-medium block text-[11px]">Listing Status</span>
            <span className={`inline-block mt-1 px-2.5 py-0.5 rounded text-[11px] font-bold ${
              property.status === 'APPROVED'
                ? 'bg-emerald-100 text-emerald-900'
                : property.status === 'PENDING_APPROVAL'
                  ? 'bg-amber-100 text-amber-950 font-bold border border-amber-300'
                  : property.status === 'REJECTED'
                    ? 'bg-red-100 text-red-900'
                    : 'bg-stone-100 text-stone-800'
            }`}>
              {property.status.replace('_', ' ')}
            </span>
          </div>

          <div>
            <span className="text-stone-400 font-medium block text-[11px]">Property Verification</span>
            <span className={`inline-flex items-center gap-1 mt-1 px-2.5 py-0.5 rounded text-[11px] font-bold ${
              property.verification_status === 'VERIFIED'
                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                : property.verification_status === 'UNDER_REVIEW'
                  ? 'bg-amber-100 text-amber-950 border border-amber-300'
                  : 'bg-stone-100 text-stone-600'
            }`}>
              <BadgeCheck className="w-3.5 h-3.5" />
              <span>{property.verification_status || 'UNVERIFIED'}</span>
            </span>
          </div>

          <div>
            <span className="text-stone-400 font-medium block text-[11px]">Price / Rent</span>
            <span className="font-bold font-serif text-stone-900 text-sm mt-1 block tabular-nums">
              {formatPriceINR(property.price)}
            </span>
          </div>

          <div>
            <span className="text-stone-400 font-medium block text-[11px]">Submission Date</span>
            <span className="font-medium text-stone-700 mt-1 block">
              {new Date(property.created_at).toLocaleString()}
            </span>
          </div>
        </div>

        {/* 2-Column Main Section: Left Photo + Specs, Right Owner & Governance */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Left: Photos & Specifications (2 Columns) */}
          <div className="lg:col-span-2 space-y-6">

            {/* Photo Gallery */}
            <div className="bg-white rounded-2xl border border-stone-200 p-5 space-y-4 shadow-2xs">
              <h2 className="text-sm font-bold font-serif text-stone-900">
                Uploaded Photographs ({photos.length})
              </h2>

              {photos.length > 0 ? (
                <div className="space-y-3">
                  <div className="aspect-16/10 rounded-xl overflow-hidden bg-stone-100 border border-stone-200">
                    <img
                      src={photos[selectedPhotoIndex]?.url || photos[0]?.url}
                      alt="Property"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {photos.length > 1 && (
                    <div className="flex items-center gap-2 overflow-x-auto pb-2">
                      {photos.map((p: any, idx: number) => (
                        <button
                          key={p.id || idx}
                          type="button"
                          onClick={() => setSelectedPhotoIndex(idx)}
                          className={`w-20 h-16 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${
                            selectedPhotoIndex === idx ? 'border-stone-900 scale-95' : 'border-stone-200 opacity-70 hover:opacity-100'
                          }`}
                        >
                          <img src={p.url} alt="" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-8 text-center text-xs text-stone-400 border border-dashed border-stone-200 rounded-xl">
                  No images uploaded for this listing.
                </div>
              )}
            </div>

            {/* Core Specifications */}
            <div className="bg-white rounded-2xl border border-stone-200 p-5 space-y-4 shadow-2xs text-xs">
              <h2 className="text-sm font-bold font-serif text-stone-900">
                Property Specifications & Dimensions
              </h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Category</span>
                  <p className="font-bold text-stone-900 capitalize mt-0.5">{property.category}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Transaction</span>
                  <p className="font-bold text-stone-900 capitalize mt-0.5">{property.transaction_type}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Property Type</span>
                  <p className="font-bold text-stone-900 mt-0.5">{property.property_type}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Carpet Area</span>
                  <p className="font-bold text-stone-900 mt-0.5 tabular-nums">{formatArea(property.carpet_area)}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Built-up Area</span>
                  <p className="font-bold text-stone-900 mt-0.5 tabular-nums">{formatArea(property.built_up_area || property.carpet_area * 1.3)}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Floor / Total</span>
                  <p className="font-bold text-stone-900 mt-0.5">Floor {property.floor || 1} of {property.total_floors || 10}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Furnishing</span>
                  <p className="font-bold text-stone-900 capitalize mt-0.5">{property.furnishing || 'semi-furnished'}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Parking</span>
                  <p className="font-bold text-stone-900 mt-0.5">{property.parking || '1 Covered'}</p>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl">
                  <span className="text-stone-400 block text-[11px]">Bedrooms / Bathrooms</span>
                  <p className="font-bold text-stone-900 mt-0.5">{property.bedrooms || 2} BHK / {property.bathrooms || 2} Baths</p>
                </div>
              </div>

              {/* Commercial Specific Attributes */}
              {isCommercial && (
                <div className="pt-4 border-t border-stone-100 space-y-3">
                  <h3 className="font-bold text-stone-900 flex items-center gap-1.5 text-xs">
                    <Building2 className="w-4 h-4 text-amber-700" />
                    <span>Commercial Asset Specifications</span>
                  </h3>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    <div className="p-2.5 bg-amber-50/40 rounded-lg border border-amber-200">
                      <span className="text-[10px] text-stone-500 block">Washrooms</span>
                      <p className="font-bold text-stone-900">{property.washrooms || '2 Private'}</p>
                    </div>

                    <div className="p-2.5 bg-amber-50/40 rounded-lg border border-amber-200">
                      <span className="text-[10px] text-stone-500 block">100% DG Power Backup</span>
                      <p className="font-bold text-stone-900">{property.power_backup ? 'Available' : 'None'}</p>
                    </div>

                    <div className="p-2.5 bg-amber-50/40 rounded-lg border border-amber-200">
                      <span className="text-[10px] text-stone-500 block">Loading / Unloading Bay</span>
                      <p className="font-bold text-stone-900">{property.loading_unloading ? 'Available' : 'None'}</p>
                    </div>

                    <div className="p-2.5 bg-amber-50/40 rounded-lg border border-amber-200">
                      <span className="text-[10px] text-stone-500 block">Road Frontage</span>
                      <p className="font-bold text-stone-900">{property.frontage ? `${property.frontage} ft` : 'Standard'}</p>
                    </div>

                    <div className="p-2.5 bg-amber-50/40 rounded-lg border border-amber-200">
                      <span className="text-[10px] text-stone-500 block">Ceiling Height</span>
                      <p className="font-bold text-stone-900">{property.ceiling_height ? `${property.ceiling_height} ft` : 'Standard'}</p>
                    </div>

                    <div className="p-2.5 bg-amber-50/40 rounded-lg border border-amber-200">
                      <span className="text-[10px] text-stone-500 block">Suitable Business</span>
                      <p className="font-bold text-stone-900 truncate">{property.business_type || 'Office, Retail'}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Description */}
              <div className="pt-3 border-t border-stone-100 space-y-1">
                <span className="text-stone-400 font-medium block text-[11px]">Public Description:</span>
                <p className="text-stone-800 leading-relaxed bg-stone-50 p-3 rounded-xl whitespace-pre-line">
                  {property.description}
                </p>
              </div>

              {/* Location & Address */}
              <div className="pt-3 border-t border-stone-100 space-y-1">
                <span className="text-stone-400 font-medium block text-[11px]">Address & Coordinates:</span>
                <div className="p-3 bg-stone-50 rounded-xl space-y-1">
                  <p className="font-bold text-stone-900 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-stone-500" />
                    <span>{property.address || property.locality}, {property.locality}, Mumbai - {property.pincode}</span>
                  </p>
                  <p className="text-[10px] text-stone-500 font-mono">
                    Lat: {property.latitude || 19.076}, Lng: {property.longitude || 72.877}
                  </p>
                </div>
              </div>

              {/* Amenities */}
              {property.amenities && property.amenities.length > 0 && (
                <div className="pt-3 border-t border-stone-100 space-y-2">
                  <span className="text-stone-400 font-medium block text-[11px]">Declared Amenities:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {property.amenities.map((am: string, i: number) => (
                      <span key={i} className="px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md font-medium text-[11px]">
                        {am}
                      </span>
                    ))}
                  </div>
                </div>
              )}

            </div>

          </div>

          {/* Right: Owner / Agent Card & Audit Trail (1 Column) */}
          <div className="space-y-6">

            {/* Owner Profile Card */}
            {property.owner && (
              <div className="bg-white rounded-2xl border border-stone-200 p-5 space-y-4 shadow-2xs text-xs">
                <div className="flex items-center justify-between">
                  <h2 className="text-sm font-bold font-serif text-stone-900 flex items-center gap-1.5">
                    <User className="w-4 h-4 text-stone-600" />
                    <span>Listing Owner Profile</span>
                  </h2>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    property.owner.verification_status === 'VERIFIED'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-100 text-stone-700'
                  }`}>
                    {property.owner.verification_status}
                  </span>
                </div>

                <div className="space-y-2.5 bg-stone-50 p-3.5 rounded-xl">
                  <div>
                    <span className="text-[10px] text-stone-400 block">Full Name</span>
                    <p className="font-bold text-stone-900 text-sm">{property.owner.name}</p>
                  </div>

                  <div>
                    <span className="text-[10px] text-stone-400 block">Contact Phone</span>
                    <p className="font-medium text-stone-900 flex items-center gap-1">
                      <Phone className="w-3 h-3 text-stone-400" />
                      <span>{property.owner.phone}</span>
                    </p>
                  </div>

                  <div>
                    <span className="text-[10px] text-stone-400 block">Email Address</span>
                    <p className="font-medium text-stone-900 flex items-center gap-1">
                      <Mail className="w-3 h-3 text-stone-400" />
                      <span>{property.owner.email}</span>
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-stone-200/60">
                    <div>
                      <span className="text-[10px] text-stone-400 block">User Role</span>
                      <p className="font-bold uppercase text-stone-800">{property.owner.role}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">Total Listings</span>
                      <p className="font-bold text-stone-900">{property.owner.listings_count}</p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-stone-200/60">
                    <span className="text-[10px] text-stone-400 block">Account Status</span>
                    <p className={`font-bold ${property.owner.account_status === 'SUSPENDED' ? 'text-red-600' : 'text-emerald-700'}`}>
                      {property.owner.account_status}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setOwnerVerificationModal(true)}
                  className="w-full py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl font-semibold transition-colors shadow-2xs"
                >
                  Verify / Review Owner Account
                </button>
              </div>
            )}

            {/* Moderation & Review Trail */}
            <div className="bg-white rounded-2xl border border-stone-200 p-5 space-y-3 shadow-2xs text-xs">
              <h2 className="text-sm font-bold font-serif text-stone-900 flex items-center gap-1.5">
                <History className="w-4 h-4 text-stone-600" />
                <span>Review History & Audit Trail</span>
              </h2>

              {property.reviewHistory && property.reviewHistory.length > 0 ? (
                <div className="divide-y divide-stone-100 space-y-2">
                  {property.reviewHistory.map((rev: any) => (
                    <div key={rev.id} className="pt-2.5 first:pt-0 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          rev.action === 'approve'
                            ? 'bg-emerald-100 text-emerald-800'
                            : rev.action === 'reject'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-amber-100 text-amber-800'
                        }`}>
                          {rev.action}
                        </span>
                        <span className="text-[10px] text-stone-400">
                          {new Date(rev.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      {rev.reason && (
                        <p className="text-stone-700 font-medium">"{rev.reason}"</p>
                      )}
                      <p className="text-[10px] text-stone-400">
                        Admin: {rev.admin_name || 'System Administrator'}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-stone-400 text-center py-4">
                  No previous review records for this listing.
                </p>
              )}
            </div>

          </div>

        </div>

      </div>

      {/* Reject & Request Changes Reason Modal */}
      {modalAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-stone-200 max-w-md w-full p-6 space-y-4 shadow-xl text-xs">
            <div className="flex items-center gap-2 font-bold text-sm">
              <AlertTriangle className={`w-5 h-5 ${modalAction === 'reject' ? 'text-red-600' : 'text-amber-600'}`} />
              <span className="text-stone-900">
                {modalAction === 'reject' ? 'Reject Property Listing' : 'Request Changes from Owner'}
              </span>
            </div>

            <p className="text-stone-600">
              Please enter an official compliance note for <strong className="text-stone-950">{property.title}</strong>.
            </p>

            <div className="space-y-2">
              <label className="font-semibold text-stone-900 block">Select standard feedback:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Missing property documents / OC',
                  'Incorrect pricing for micro-market',
                  'Poor quality or blurry images',
                  'Duplicate listing detected',
                  'Owner phone verification required',
                  'Carpet area discrepancy'
                ].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setActionReason(preset)}
                    className="px-2 py-1 rounded bg-stone-100 hover:bg-stone-200 text-stone-700 text-[11px] transition-colors"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="font-semibold text-stone-900 block mb-1">
                Reason / Note for Owner:
              </label>
              <textarea
                rows={3}
                value={actionReason}
                onChange={(e) => setActionReason(e.target.value)}
                placeholder="Explain the required correction or rejection cause..."
                className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => {
                  setModalAction(null);
                  setActionReason('');
                }}
                className="px-3.5 py-2 border border-stone-200 rounded-lg text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleReviewAction(modalAction, actionReason)}
                className={`px-4 py-2 text-white rounded-lg font-semibold shadow-xs ${
                  modalAction === 'reject'
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-amber-600 hover:bg-amber-700'
                }`}
              >
                Submit {modalAction === 'reject' ? 'Rejection' : 'Change Request'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Owner Verification Modal */}
      {ownerVerificationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-stone-200 max-w-sm w-full p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-sm font-bold text-stone-900">
              Set Owner Verification Status
            </h3>
            <p className="text-stone-600">
              Verify credentials and identity documents for <strong className="text-stone-950">{property.owner.name}</strong>.
            </p>

            <div className="space-y-1.5">
              {(['VERIFIED', 'UNDER_REVIEW', 'UNVERIFIED', 'REJECTED'] as const).map((st) => (
                <label
                  key={st}
                  className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                    selectedOwnerStatus === st ? 'border-stone-900 bg-stone-50 font-bold' : 'border-stone-200'
                  }`}
                >
                  <input
                    type="radio"
                    name="ownerStatus"
                    value={st}
                    checked={selectedOwnerStatus === st}
                    onChange={(e) => setSelectedOwnerStatus(e.target.value)}
                  />
                  <span>{st}</span>
                </label>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setOwnerVerificationModal(false)}
                className="px-3 py-2 border border-stone-200 rounded-lg text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleUpdateOwnerVerification}
                className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg font-semibold shadow-xs"
              >
                Save Status
              </button>
            </div>
          </div>
        </div>
      )}

    </AdminLayout>
  );
};
