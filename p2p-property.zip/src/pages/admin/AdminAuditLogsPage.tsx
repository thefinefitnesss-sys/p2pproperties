import React, { useState, useEffect } from 'react';
import { History, ShieldCheck, Filter, User, Building2, MessageSquare, Calendar } from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';

const ENTITY_FILTERS = ['ALL', 'property', 'user', 'inquiry', 'site_visit'] as const;

export const AdminAuditLogsPage: React.FC = () => {
  const { showToast } = useProperty();
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [entityFilter, setEntityFilter] = useState<string>('ALL');

  const loadLogs = async () => {
    setLoading(true);
    try {
      const res = await api.admin.auditLogs({
        entity_type: entityFilter !== 'ALL' ? entityFilter : undefined,
        limit: 150
      });
      setLogs(res.logs || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading audit logs.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [entityFilter]);

  return (
    <AdminLayout
      title="Platform Governance Audit Trail"
      subtitle="Immutable security trail recording every moderator approval, KYC verification, suspension, and review event."
      onRefresh={loadLogs}
      isRefreshing={loading}
    >
      <div className="space-y-6">

        {/* Filter bar */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-semibold text-stone-500 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              <span>Target Entity:</span>
            </span>
            {ENTITY_FILTERS.map((ef) => (
              <button
                key={ef}
                type="button"
                onClick={() => setEntityFilter(ef)}
                className={`px-3 py-1 rounded-md font-semibold transition-all capitalize ${
                  entityFilter === ef
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                {ef === 'ALL' ? 'All Entities' : ef.replace('_', ' ')}
              </button>
            ))}
          </div>

          <span className="text-stone-400 text-[11px] tabular-nums">
            {logs.length} audit entries recorded
          </span>
        </div>

        {/* Audit Logs Table */}
        {logs.length > 0 ? (
          <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="p-3.5">Timestamp</th>
                    <th className="p-3.5">Action</th>
                    <th className="p-3.5">Admin</th>
                    <th className="p-3.5">Entity Target</th>
                    <th className="p-3.5">Audit Details / Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 font-mono text-[11px]">
                  {logs.map((log) => {
                    const isApprove = log.action.includes('approved') || log.action.includes('verified');
                    const isReject = log.action.includes('rejected') || log.action.includes('suspended');

                    return (
                      <tr key={log.id} className="hover:bg-stone-50/80 transition-colors">
                        
                        {/* Timestamp */}
                        <td className="p-3.5 whitespace-nowrap text-stone-500 font-sans">
                          <p className="font-semibold text-stone-900">{new Date(log.created_at).toLocaleDateString()}</p>
                          <p className="text-[10px] text-stone-400 font-mono">
                            {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                          </p>
                        </td>

                        {/* Action Badge */}
                        <td className="p-3.5 whitespace-nowrap font-sans">
                          <span className={`inline-block px-2.5 py-1 rounded text-[11px] font-bold ${
                            isApprove
                              ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              : isReject
                                ? 'bg-red-100 text-red-900 border border-red-300'
                                : 'bg-stone-100 text-stone-800'
                          }`}>
                            {log.action}
                          </span>
                        </td>

                        {/* Admin Name */}
                        <td className="p-3.5 whitespace-nowrap font-sans">
                          <p className="font-bold text-stone-900">{log.admin_name || 'System Admin'}</p>
                          <p className="text-[10px] text-stone-400 font-mono">ID: {log.admin_id}</p>
                        </td>

                        {/* Target Entity */}
                        <td className="p-3.5 whitespace-nowrap font-sans">
                          <span className="capitalize px-1.5 py-0.5 rounded text-[10px] font-semibold bg-stone-100 text-stone-700">
                            {log.entity_type}
                          </span>
                          <p className="text-[10px] text-stone-400 font-mono mt-0.5">
                            {log.entity_id}
                          </p>
                        </td>

                        {/* Details */}
                        <td className="p-3.5 font-sans text-stone-800 max-w-md">
                          <p className="line-clamp-2 leading-relaxed">
                            {log.details || '-'}
                          </p>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-stone-200 p-12 text-center text-xs text-stone-500 space-y-2">
            <History className="w-8 h-8 text-stone-300 mx-auto" />
            <p className="font-semibold text-stone-900">No audit records found</p>
            <p>Admin actions will automatically appear here as moderation tasks are completed.</p>
          </div>
        )}

      </div>
    </AdminLayout>
  );
};
