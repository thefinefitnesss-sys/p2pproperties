import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Search, 
  ShieldCheck, 
  BadgeCheck, 
  UserX, 
  UserCheck, 
  Building2, 
  Phone, 
  Mail, 
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';

export const AdminUsersPage: React.FC = () => {
  const { showToast, currentUser } = useProperty();

  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [verificationFilter, setVerificationFilter] = useState('ALL');

  // Verify modal
  const [verifyModalUser, setVerifyModalUser] = useState<any | null>(null);
  const [selectedVerificationStatus, setSelectedVerificationStatus] = useState<string>('VERIFIED');

  // Suspend modal
  const [suspendModalUser, setSuspendModalUser] = useState<any | null>(null);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const filters: any = {};
      if (searchTerm.trim()) filters.search = searchTerm.trim();
      if (roleFilter !== 'ALL') filters.role = roleFilter;
      if (statusFilter !== 'ALL') filters.account_status = statusFilter;
      if (verificationFilter !== 'ALL') filters.verification_status = verificationFilter;

      const res = await api.admin.users(filters);
      setUsers(res.users || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading users.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, [roleFilter, statusFilter, verificationFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadUsers();
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setRoleFilter('ALL');
    setStatusFilter('ALL');
    setVerificationFilter('ALL');
    setTimeout(loadUsers, 0);
  };

  const handleUpdateVerification = async () => {
    if (!verifyModalUser) return;
    try {
      await api.admin.updateUserStatus(verifyModalUser.id, {
        verification_status: selectedVerificationStatus
      });
      showToast(`Verification status updated to ${selectedVerificationStatus}.`);
      setVerifyModalUser(null);
      loadUsers();
    } catch (err: any) {
      showToast(err.message || 'Error updating verification.');
    }
  };

  const handleToggleSuspension = async (user: any) => {
    const nextStatus = user.account_status === 'SUSPENDED' ? 'ACTIVE' : 'SUSPENDED';
    try {
      await api.admin.updateUserStatus(user.id, {
        account_status: nextStatus
      });
      showToast(`User ${user.name} is now ${nextStatus}.`);
      setSuspendModalUser(null);
      loadUsers();
    } catch (err: any) {
      showToast(err.message || 'Error updating user suspension status.');
    }
  };

  const handleChangeRole = async (userId: string, newRole: string) => {
    try {
      await api.admin.updateUserStatus(userId, { role: newRole });
      showToast(`User role updated to ${newRole}.`);
      loadUsers();
    } catch (err: any) {
      showToast(err.message || 'Error updating role.');
    }
  };

  return (
    <AdminLayout
      title="User Management & Verification"
      subtitle="Govern buyer, owner, agent, and tenant profiles, verify KYC titles, and manage account statuses."
      onRefresh={loadUsers}
      isRefreshing={loading}
    >
      <div className="space-y-6">

        {/* Filter Bar */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs space-y-3">
          <form onSubmit={handleSearchSubmit} className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search user by name, email, phone, or ID..."
                className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg transition-colors shrink-0"
            >
              Search
            </button>
          </form>

          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-stone-100 text-xs">
            {/* Role Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-stone-500">Role:</span>
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="px-2.5 py-1 border border-stone-200 rounded-md bg-stone-50 text-xs font-medium"
              >
                <option value="ALL">All Roles</option>
                <option value="owner">Owner</option>
                <option value="buyer">Buyer</option>
                <option value="agent">Agent</option>
                <option value="tenant">Tenant</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            {/* Account Status */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-stone-500">Account:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-2.5 py-1 border border-stone-200 rounded-md bg-stone-50 text-xs font-medium"
              >
                <option value="ALL">All Status</option>
                <option value="ACTIVE">Active</option>
                <option value="SUSPENDED">Suspended</option>
              </select>
            </div>

            {/* Verification Status */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-stone-500">Verification:</span>
              <select
                value={verificationFilter}
                onChange={(e) => setVerificationFilter(e.target.value)}
                className="px-2.5 py-1 border border-stone-200 rounded-md bg-stone-50 text-xs font-medium"
              >
                <option value="ALL">All Verification</option>
                <option value="VERIFIED">Verified</option>
                <option value="UNDER_REVIEW">Under Review</option>
                <option value="UNVERIFIED">Unverified</option>
                <option value="REJECTED">Rejected</option>
              </select>
            </div>

            <button
              type="button"
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-stone-600 hover:text-stone-900 text-xs font-medium"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>

            <span className="ml-auto text-stone-400 text-[11px] tabular-nums">
              Showing {users.length} registered accounts
            </span>
          </div>
        </div>

        {/* Users Table */}
        {users.length > 0 ? (
          <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="p-3.5">User</th>
                    <th className="p-3.5">Contact</th>
                    <th className="p-3.5">Role</th>
                    <th className="p-3.5">Listings Count</th>
                    <th className="p-3.5">Verification</th>
                    <th className="p-3.5">Account Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {users.map((u) => {
                    const isSelf = currentUser?.id === u.id;
                    const isSuspended = u.account_status === 'SUSPENDED';

                    return (
                      <tr key={u.id} className="hover:bg-stone-50/80 transition-colors">
                        
                        {/* Name & ID */}
                        <td className="p-3.5">
                          <p className="font-bold text-stone-900 text-xs sm:text-sm">{u.name}</p>
                          <p className="text-[10px] text-stone-400 font-mono mt-0.5">ID: {u.id}</p>
                          <p className="text-[10px] text-stone-500">
                            Joined {new Date(u.created_at).toLocaleDateString()}
                          </p>
                        </td>

                        {/* Contact */}
                        <td className="p-3.5 whitespace-nowrap">
                          <p className="text-stone-900 font-medium flex items-center gap-1">
                            <Mail className="w-3 h-3 text-stone-400" />
                            <span>{u.email}</span>
                          </p>
                          <p className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                            <Phone className="w-3 h-3 text-stone-400" />
                            <span>{u.phone}</span>
                          </p>
                        </td>

                        {/* Role selector */}
                        <td className="p-3.5 whitespace-nowrap">
                          <select
                            value={u.role}
                            disabled={isSelf}
                            onChange={(e) => handleChangeRole(u.id, e.target.value)}
                            className="px-2 py-1 text-xs border border-stone-200 rounded-md bg-white font-medium capitalize disabled:opacity-60"
                          >
                            <option value="owner">Owner</option>
                            <option value="buyer">Buyer</option>
                            <option value="agent">Agent</option>
                            <option value="tenant">Tenant</option>
                            <option value="admin">Admin</option>
                          </select>
                        </td>

                        {/* Listings count */}
                        <td className="p-3.5 whitespace-nowrap tabular-nums">
                          <span className="font-bold text-stone-900 text-xs">
                            {u.properties_count || 0}
                          </span>
                          <span className="text-[11px] text-stone-500 ml-1">properties</span>
                        </td>

                        {/* Verification Status */}
                        <td className="p-3.5 whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                            u.verification_status === 'VERIFIED'
                              ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              : u.verification_status === 'UNDER_REVIEW'
                                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                : u.verification_status === 'REJECTED'
                                  ? 'bg-red-100 text-red-900'
                                  : 'bg-stone-100 text-stone-600'
                          }`}>
                            <BadgeCheck className="w-3 h-3" />
                            <span>{u.verification_status || 'UNVERIFIED'}</span>
                          </span>
                        </td>

                        {/* Account Status Badge */}
                        <td className="p-3.5 whitespace-nowrap">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            isSuspended
                              ? 'bg-red-100 text-red-900 border border-red-300'
                              : 'bg-emerald-100 text-emerald-900'
                          }`}>
                            {u.account_status || 'ACTIVE'}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="p-3.5 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Verify button */}
                            <button
                              type="button"
                              onClick={() => {
                                setVerifyModalUser(u);
                                setSelectedVerificationStatus(u.verification_status || 'VERIFIED');
                              }}
                              className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded font-semibold text-[11px] transition-colors"
                            >
                              Verify KYC
                            </button>

                            {/* Suspend / Reactivate */}
                            {!isSelf && (
                              <button
                                type="button"
                                onClick={() => setSuspendModalUser(u)}
                                className={`px-2.5 py-1 rounded font-semibold text-[11px] transition-colors ${
                                  isSuspended
                                    ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900'
                                    : 'bg-red-50 hover:bg-red-100 text-red-700'
                                }`}
                              >
                                {isSuspended ? 'Reactivate' : 'Suspend'}
                              </button>
                            )}
                          </div>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-stone-200 p-12 text-center text-xs text-stone-500 space-y-2">
            <Users className="w-8 h-8 text-stone-300 mx-auto" />
            <p className="font-semibold text-stone-900">No users found</p>
            <p>Try clearing filters or searching with another term.</p>
          </div>
        )}

      </div>

      {/* Verify Owner/Agent Modal */}
      {verifyModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-stone-200 max-w-sm w-full p-6 space-y-4 shadow-xl text-xs">
            <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
              <BadgeCheck className="w-5 h-5 text-emerald-700" />
              <span>Verify User / Title KYC</span>
            </div>

            <p className="text-stone-600">
              Updating verification tier for <strong className="text-stone-950">{verifyModalUser.name}</strong> ({verifyModalUser.email}).
            </p>

            <div className="space-y-1.5">
              {(['VERIFIED', 'UNDER_REVIEW', 'UNVERIFIED', 'REJECTED'] as const).map((st) => (
                <label
                  key={st}
                  className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                    selectedVerificationStatus === st ? 'border-stone-900 bg-stone-50 font-bold' : 'border-stone-200'
                  }`}
                >
                  <input
                    type="radio"
                    name="verificationTier"
                    value={st}
                    checked={selectedVerificationStatus === st}
                    onChange={(e) => setSelectedVerificationStatus(e.target.value)}
                  />
                  <span>{st}</span>
                </label>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setVerifyModalUser(null)}
                className="px-3.5 py-2 border border-stone-200 rounded-lg text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleUpdateVerification}
                className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg font-semibold shadow-xs"
              >
                Save Verification
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Suspend Confirmation Modal */}
      {suspendModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-stone-200 max-w-sm w-full p-6 space-y-4 shadow-xl text-xs">
            <div className="flex items-center gap-2 text-red-600 font-bold text-sm">
              <AlertTriangle className="w-5 h-5" />
              <span>{suspendModalUser.account_status === 'SUSPENDED' ? 'Reactivate Account' : 'Suspend User Account'}</span>
            </div>

            <p className="text-stone-700 leading-relaxed">
              {suspendModalUser.account_status === 'SUSPENDED' ? (
                <>
                  Are you sure you want to reactivate <strong className="text-stone-950">{suspendModalUser.name}</strong>? They will regain access to manage listings and send inquiries.
                </>
              ) : (
                <>
                  Are you sure you want to suspend <strong className="text-stone-950">{suspendModalUser.name}</strong>? They will be immediately blocked from logging in or performing any actions on the platform.
                </>
              )}
            </p>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setSuspendModalUser(null)}
                className="px-3.5 py-2 border border-stone-200 rounded-lg text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleToggleSuspension(suspendModalUser)}
                className={`px-4 py-2 text-white rounded-lg font-semibold shadow-xs ${
                  suspendModalUser.account_status === 'SUSPENDED'
                    ? 'bg-emerald-700 hover:bg-emerald-800'
                    : 'bg-red-600 hover:bg-red-700'
                }`}
              >
                Confirm {suspendModalUser.account_status === 'SUSPENDED' ? 'Reactivation' : 'Suspension'}
              </button>
            </div>
          </div>
        </div>
      )}

    </AdminLayout>
  );
};
