import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Search, Phone, Mail, Clock, CheckCircle2, RotateCcw } from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';

const VISIT_STATUSES = ['ALL', 'REQUESTED', 'CONFIRMED', 'COMPLETED', 'CANCELLED'] as const;

export const AdminSiteVisitsPage: React.FC = () => {
  const { showToast } = useProperty();
  const [visits, setVisits] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  const loadVisits = async () => {
    setLoading(true);
    try {
      const res = await api.admin.siteVisits({
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
        search: searchTerm.trim() || undefined
      });
      setVisits(res.visits || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading site visits.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVisits();
  }, [statusFilter]);

  const handleUpdateStatus = async (id: string, newStatus: string) => {
    try {
      await api.admin.updateSiteVisitStatus(id, newStatus);
      showToast(`Site visit status updated to ${newStatus}.`);
      loadVisits();
    } catch (err: any) {
      showToast(err.message || 'Error updating visit status.');
    }
  };

  return (
    <AdminLayout
      title="Property Site Visits Management"
      subtitle="Supervise physical walkthrough schedules, buyer visits, and appointment coordination."
      onRefresh={loadVisits}
      isRefreshing={loading}
    >
      <div className="space-y-6">

        {/* Filter Bar */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs space-y-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              loadVisits();
            }}
            className="flex flex-col md:flex-row items-stretch md:items-center gap-3"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by visitor name, visitor email, property title, or owner..."
                className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg transition-colors shrink-0"
            >
              Search
            </button>
          </form>

          {/* Status Pills */}
          <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-stone-100 text-xs">
            <span className="text-[11px] font-semibold text-stone-500 mr-1">Status:</span>
            {VISIT_STATUSES.map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-md font-semibold transition-all text-xs ${
                  statusFilter === st
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                {st}
              </button>
            ))}

            <span className="ml-auto text-stone-400 text-[11px] tabular-nums">
              {visits.length} visits found
            </span>
          </div>
        </div>

        {/* Site Visits Table */}
        {visits.length > 0 ? (
          <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="p-3.5">Property</th>
                    <th className="p-3.5">Customer / Visitor</th>
                    <th className="p-3.5">Scheduled Date & Slot</th>
                    <th className="p-3.5">Notes</th>
                    <th className="p-3.5">Owner / Host</th>
                    <th className="p-3.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {visits.map((v) => (
                    <tr key={v.id} className="hover:bg-stone-50/80 transition-colors">
                      
                      {/* Property */}
                      <td className="p-3.5 max-w-xs">
                        <Link
                          to={`/admin/properties/${v.property_id}`}
                          className="font-bold text-stone-900 hover:text-amber-800 transition-colors block truncate"
                        >
                          {v.property_title}
                        </Link>
                        <p className="text-[11px] text-stone-500 mt-0.5">
                          {v.locality}
                        </p>
                        <p className="text-[10px] text-stone-400 font-mono mt-0.5">
                          ID: {v.property_id}
                        </p>
                      </td>

                      {/* Customer */}
                      <td className="p-3.5 whitespace-nowrap">
                        <p className="font-bold text-stone-900">{v.visitor_name}</p>
                        <p className="text-[11px] text-stone-600 flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-stone-400" />
                          <span>{v.visitor_phone}</span>
                        </p>
                        <p className="text-[10px] text-stone-400 flex items-center gap-1">
                          <Mail className="w-3 h-3 text-stone-400" />
                          <span>{v.visitor_email}</span>
                        </p>
                      </td>

                      {/* Scheduled Date & Time */}
                      <td className="p-3.5 whitespace-nowrap">
                        <p className="font-bold text-stone-900 flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-amber-700" />
                          <span>{v.preferred_date}</span>
                        </p>
                        <p className="text-[11px] text-stone-600 flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3 text-stone-400" />
                          <span>{v.preferred_time}</span>
                        </p>
                      </td>

                      {/* Notes / Message */}
                      <td className="p-3.5 max-w-xs">
                        <p className="text-stone-700 line-clamp-2 bg-stone-50 p-2 rounded-lg">
                          {v.message ? `"${v.message}"` : <span className="text-stone-400 italic">No notes</span>}
                        </p>
                      </td>

                      {/* Owner */}
                      <td className="p-3.5 whitespace-nowrap">
                        <p className="font-semibold text-stone-900">{v.owner_name}</p>
                        <p className="text-[10px] text-stone-500">{v.owner_phone}</p>
                      </td>

                      {/* Status */}
                      <td className="p-3.5 whitespace-nowrap">
                        <select
                          value={v.status}
                          onChange={(e) => handleUpdateStatus(v.id, e.target.value)}
                          className={`px-2.5 py-1 text-xs font-bold rounded-lg border cursor-pointer ${
                            v.status === 'REQUESTED'
                              ? 'bg-amber-50 text-amber-900 border-amber-300'
                              : v.status === 'CONFIRMED'
                                ? 'bg-blue-50 text-blue-900 border-blue-300'
                                : v.status === 'COMPLETED'
                                  ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                                  : 'bg-stone-50 text-stone-800 border-stone-200'
                          }`}
                        >
                          <option value="REQUESTED">REQUESTED</option>
                          <option value="CONFIRMED">CONFIRMED</option>
                          <option value="COMPLETED">COMPLETED</option>
                          <option value="CANCELLED">CANCELLED</option>
                        </select>
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-stone-200 p-12 text-center text-xs text-stone-500 space-y-2">
            <Calendar className="w-8 h-8 text-stone-300 mx-auto" />
            <p className="font-semibold text-stone-900">No site visits found</p>
            <p>Try clearing filters or search query.</p>
          </div>
        )}

      </div>
    </AdminLayout>
  );
};
