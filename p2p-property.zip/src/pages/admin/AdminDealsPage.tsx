import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Briefcase, 
  Search, 
  Filter, 
  TrendingUp, 
  IndianRupee, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Building2, 
  ExternalLink,
  Edit3,
  Receipt,
  Users,
  ShieldCheck,
  ArrowRight
} from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { usePropertyContext } from '../../context/PropertyContext';
import { Deal, DealStats } from '../../types/deal';
import { formatCurrency } from '../../utils/formatters';

export const AdminDealsPage: React.FC = () => {
  const { showToast } = usePropertyContext();

  const [deals, setDeals] = useState<Deal[]>([]);
  const [stats, setStats] = useState<DealStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [commissionStatusFilter, setCommissionStatusFilter] = useState('ALL');
  const [transactionTypeFilter, setTransactionTypeFilter] = useState('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  useEffect(() => {
    loadDeals();
  }, [statusFilter, commissionStatusFilter, transactionTypeFilter, categoryFilter]);

  const loadDeals = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.deals.list({
        status: statusFilter,
        commission_status: commissionStatusFilter,
        transaction_type: transactionTypeFilter,
        category: categoryFilter,
        search: search.trim() || undefined
      });
      setDeals(res.deals || []);
      setStats(res.stats || null);
    } catch (err: any) {
      setError(err.message || 'Error loading administrative deals.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadDeals();
  };

  return (
    <AdminLayout activeTab="deals">
      <div className="space-y-6">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-4">
          <div>
            <h1 className="text-2xl font-bold font-serif text-stone-900 flex items-center gap-2">
              <Briefcase className="w-6 h-6 text-amber-600" />
              <span>Deals, Brokerage & Commission Oversight</span>
            </h1>
            <p className="text-xs text-stone-500 mt-1">
              Administer real-estate transactions, monitor revenue collection, audit commission rates, and track invoices.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Link
              to="/dashboard/deals"
              className="px-3.5 py-1.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Owner/Agent View</span>
            </Link>
          </div>
        </div>

        {/* Stats KPIs */}
        {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-1">
              <div className="flex items-center justify-between text-xs text-stone-500">
                <span>Total Deal Volume</span>
                <Building2 className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-xl sm:text-2xl font-bold font-serif text-stone-900">
                {formatCurrency(stats.totalVolume)}
              </div>
              <div className="text-[11px] text-stone-500">
                {stats.totalDeals} Total Deals ({stats.completedDeals} Won, {stats.activeDeals} Active)
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-1">
              <div className="flex items-center justify-between text-xs text-stone-500">
                <span>Commission Booked</span>
                <IndianRupee className="w-4 h-4 text-purple-600" />
              </div>
              <div className="text-xl sm:text-2xl font-bold font-serif text-stone-900">
                {formatCurrency(stats.totalCommissionBooked)}
              </div>
              <div className="text-[11px] text-stone-500">
                Total contracted facilitation fee
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-1">
              <div className="flex items-center justify-between text-xs text-stone-500">
                <span>Commission Collected</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-xl sm:text-2xl font-bold font-serif text-emerald-700">
                {formatCurrency(stats.totalCommissionCollected)}
              </div>
              <div className="text-[11px] text-stone-500">
                Settled into bank accounts
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-1">
              <div className="flex items-center justify-between text-xs text-stone-500">
                <span>Outstanding Receivables</span>
                <Clock className="w-4 h-4 text-rose-600" />
              </div>
              <div className="text-xl sm:text-2xl font-bold font-serif text-rose-700">
                {formatCurrency(stats.totalOutstandingCommission)}
              </div>
              <div className="text-[11px] text-stone-500">
                Pending collection from clients
              </div>
            </div>
          </div>
        )}

        {/* Filter Bar */}
        <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs space-y-3">
          <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                placeholder="Search across all deals by deal number, client, property title, owner or agent..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-stone-200 rounded-lg text-xs focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              Search
            </button>
          </form>

          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-stone-100 text-xs">
            <div className="flex items-center gap-1.5 text-stone-500 font-semibold">
              <Filter className="w-3.5 h-3.5" />
              <span>Filters:</span>
            </div>

            <select
              value={transactionTypeFilter}
              onChange={(e) => setTransactionTypeFilter(e.target.value)}
              className="px-2.5 py-1.5 border border-stone-200 rounded-lg bg-stone-50 text-stone-700 font-medium"
            >
              <option value="ALL">All Transactions</option>
              <option value="BUY">Buy / Sale</option>
              <option value="RENT">Rent</option>
              <option value="LEASE">Commercial Lease</option>
            </select>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-2.5 py-1.5 border border-stone-200 rounded-lg bg-stone-50 text-stone-700 font-medium"
            >
              <option value="ALL">All Categories</option>
              <option value="RESIDENTIAL">Residential</option>
              <option value="COMMERCIAL">Commercial</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 border border-stone-200 rounded-lg bg-stone-50 text-stone-700 font-medium"
            >
              <option value="ALL">All Stages</option>
              <option value="NEGOTIATION">Negotiation</option>
              <option value="AGREED">Agreed</option>
              <option value="AGREEMENT_PENDING">Agreement Pending</option>
              <option value="AGREEMENT_SIGNED">Agreement Signed</option>
              <option value="PAYMENT_PENDING">Payment Pending</option>
              <option value="COMPLETED">Completed</option>
              <option value="CANCELLED">Cancelled</option>
              <option value="FAILED">Failed</option>
            </select>

            <select
              value={commissionStatusFilter}
              onChange={(e) => setCommissionStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 border border-stone-200 rounded-lg bg-stone-50 text-stone-700 font-medium"
            >
              <option value="ALL">All Brokerage Statuses</option>
              <option value="NOT_SET">Not Set</option>
              <option value="AGREED">Agreed</option>
              <option value="INVOICED">Invoiced</option>
              <option value="PARTIALLY_PAID">Partially Paid</option>
              <option value="PAID">Paid</option>
              <option value="WAIVED">Waived</option>
            </select>

            {(statusFilter !== 'ALL' || commissionStatusFilter !== 'ALL' || transactionTypeFilter !== 'ALL' || categoryFilter !== 'ALL' || search) && (
              <button
                onClick={() => {
                  setStatusFilter('ALL');
                  setCommissionStatusFilter('ALL');
                  setTransactionTypeFilter('ALL');
                  setCategoryFilter('ALL');
                  setSearch('');
                }}
                className="text-[11px] text-amber-700 hover:underline font-semibold ml-auto cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
        </div>

        {/* Deals Table */}
        {loading ? (
          <div className="py-12 text-center text-xs text-stone-500">
            Loading deal registry and financial ledger...
          </div>
        ) : error ? (
          <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        ) : deals.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center border border-stone-200 space-y-3">
            <Briefcase className="w-10 h-10 text-stone-400 mx-auto" />
            <h3 className="text-base font-bold text-stone-900">No Transaction Deals Recorded</h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              No deals match the specified administrative filters.
            </p>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-stone-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 text-stone-600 font-mono text-[10px] uppercase border-b border-stone-200">
                  <tr>
                    <th className="py-3 px-4">Deal Number</th>
                    <th className="py-3 px-4">Property</th>
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4">Owner / Agent</th>
                    <th className="py-3 px-4 text-right">Agreed Value</th>
                    <th className="py-3 px-4 text-right">Commission</th>
                    <th className="py-3 px-4 text-center">Commission Status</th>
                    <th className="py-3 px-4 text-center">Deal Stage</th>
                    <th className="py-3 px-4 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {deals.map(deal => (
                    <tr key={deal.id} className="hover:bg-amber-50/20 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-stone-900">
                        <Link to={`/dashboard/deals/${deal.id}`} className="hover:text-amber-700">
                          {deal.dealNumber}
                        </Link>
                        <span className="block text-[10px] text-stone-400 font-normal">
                          {new Date(deal.createdAt).toLocaleDateString('en-IN')}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <p className="font-bold text-stone-900 line-clamp-1">{deal.property?.title}</p>
                        <p className="text-[11px] text-stone-500">{deal.property?.locality}</p>
                      </td>

                      <td className="py-3.5 px-4">
                        <p className="font-semibold text-stone-900">{deal.customer?.name}</p>
                        <p className="text-[11px] text-stone-500 font-mono">{deal.customer?.mobile}</p>
                      </td>

                      <td className="py-3.5 px-4">
                        <p className="font-semibold text-stone-900">Owner: {deal.owner?.name}</p>
                        <p className="text-[11px] text-stone-500">Agent: {deal.assignedAgent?.name || 'Self'}</p>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-bold text-stone-900">
                        {formatCurrency(deal.agreedPropertyValue || deal.agreedRent || deal.agreedLeaseValue || 0)}
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-semibold text-amber-700">
                        {formatCurrency(deal.commissionAmount)}
                        <span className="block text-[10px] text-stone-400 font-normal">
                          {deal.commissionType === 'PERCENTAGE' ? `${deal.commissionRate}%` : 'Fixed'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                          deal.commissionStatus === 'PAID' ? 'bg-emerald-100 text-emerald-800' :
                          deal.commissionStatus === 'PARTIALLY_PAID' ? 'bg-blue-100 text-blue-800' :
                          deal.commissionStatus === 'INVOICED' ? 'bg-purple-100 text-purple-800' :
                          deal.commissionStatus === 'AGREED' ? 'bg-amber-100 text-amber-800' :
                          'bg-stone-100 text-stone-600'
                        }`}>
                          {deal.commissionStatus}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-stone-100 text-stone-800 border border-stone-200">
                          {deal.dealStatus}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <Link
                          to={`/dashboard/deals/${deal.id}`}
                          className="inline-flex items-center gap-1 px-3 py-1 bg-stone-900 hover:bg-stone-800 text-white rounded-md text-[11px] font-semibold transition-colors"
                        >
                          <span>Manage</span>
                          <ArrowRight className="w-3 h-3" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>
    </AdminLayout>
  );
};
