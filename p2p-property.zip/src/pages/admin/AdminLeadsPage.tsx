import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Users, 
  Search, 
  Filter, 
  Kanban, 
  List, 
  ArrowRight, 
  Phone, 
  MessageSquare, 
  Calendar, 
  Building2, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  ChevronRight, 
  TrendingUp, 
  Sparkles,
  ExternalLink,
  RefreshCw,
  UserCheck,
  X,
  FileText
} from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';
import { Lead, LeadStatus, LeadPriority } from '../../types/lead';
import { formatPriceINR } from '../../utils/formatters';

const STAGES: { key: LeadStatus; label: string; color: string; border: string; bg: string }[] = [
  { key: 'NEW', label: 'New Enquiries', color: 'text-blue-700', border: 'border-blue-200', bg: 'bg-blue-50/60' },
  { key: 'CONTACTED', label: 'Contacted', color: 'text-purple-700', border: 'border-purple-200', bg: 'bg-purple-50/60' },
  { key: 'QUALIFIED', label: 'Qualified', color: 'text-amber-700', border: 'border-amber-200', bg: 'bg-amber-50/60' },
  { key: 'SITE_VISIT', label: 'Site Visits', color: 'text-indigo-700', border: 'border-indigo-200', bg: 'bg-indigo-50/60' },
  { key: 'NEGOTIATING', label: 'Negotiating', color: 'text-orange-700', border: 'border-orange-200', bg: 'bg-orange-50/60' },
  { key: 'WON', label: 'Won Deals', color: 'text-emerald-700', border: 'border-emerald-200', bg: 'bg-emerald-50/60' },
];

export const AdminLeadsPage: React.FC = () => {
  const { showToast } = useProperty();

  const [leads, setLeads] = useState<Lead[]>([]);
  const [kpis, setKpis] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [priorityFilter, setPriorityFilter] = useState('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [transactionFilter, setTransactionFilter] = useState('ALL');

  // Lead Assignment State
  const [assignModalLead, setAssignModalLead] = useState<Lead | null>(null);
  const [agentsList, setAgentsList] = useState<any[]>([]);
  const [selectedAgentId, setSelectedAgentId] = useState('');
  const [assignNotes, setAssignNotes] = useState('');
  const [assigning, setAssigning] = useState(false);

  // Status Change State
  const [statusModalLead, setStatusModalLead] = useState<Lead | null>(null);
  const [newStatus, setNewStatus] = useState<LeadStatus>('NEW');

  // Note Modal
  const [noteModalLead, setNoteModalLead] = useState<Lead | null>(null);
  const [noteText, setNoteText] = useState('');

  const loadData = async () => {
    setLoading(true);
    try {
      const [leadsRes, agentsRes] = await Promise.all([
        api.admin.leads({
          status: statusFilter,
          priority: priorityFilter,
          category: categoryFilter,
          transaction_type: transactionFilter,
          search
        }),
        api.admin.agentsList()
      ]);
      setLeads(leadsRes.leads || []);
      setKpis(leadsRes.kpis || null);
      setAgentsList(agentsRes.agents || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading admin leads.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [statusFilter, priorityFilter, categoryFilter, transactionFilter]);

  const handleAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignModalLead || !selectedAgentId) return;
    setAssigning(true);
    try {
      const res = await api.admin.assignLead(assignModalLead.id, selectedAgentId, assignNotes);
      showToast(res.message || 'Lead assigned successfully.');
      setAssignModalLead(null);
      setSelectedAgentId('');
      setAssignNotes('');
      loadData();
    } catch (err: any) {
      showToast(err.message || 'Error assigning lead.');
    } finally {
      setAssigning(false);
    }
  };

  const handleUpdateStatus = async (leadId: string, status: string) => {
    try {
      await api.leads.updateStatus(leadId, status);
      showToast(`Status updated to ${status}.`);
      loadData();
    } catch (err: any) {
      showToast(err.message || 'Error updating status.');
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteModalLead || !noteText.trim()) return;
    try {
      await api.leads.addNote(noteModalLead.id, noteText);
      showToast('Admin note added to timeline.');
      setNoteModalLead(null);
      setNoteText('');
      loadData();
    } catch (err: any) {
      showToast(err.message || 'Error adding note.');
    }
  };

  return (
    <AdminLayout
      title="Lead Management & Governance"
      subtitle="Network-wide oversight of buyer inquiries, agent assignments, qualification stages, and deal pipelines."
      onRefresh={loadData}
      isRefreshing={loading}
    >
      <div className="space-y-6">

        {/* Global KPIs */}
        {kpis && (
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            <div className="bg-white p-3.5 rounded-xl border border-stone-200 shadow-2xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500 block">Total Inquiries</span>
              <span className="text-xl font-bold text-stone-900 font-serif">{kpis.totalLeads}</span>
            </div>
            <div className="bg-blue-50/60 p-3.5 rounded-xl border border-blue-200 shadow-2xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block">Fresh Inquiries</span>
              <span className="text-xl font-bold text-blue-900 font-serif">{kpis.newLeads}</span>
            </div>
            <div className="bg-amber-50/60 p-3.5 rounded-xl border border-amber-200 shadow-2xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 block">Active Deals</span>
              <span className="text-xl font-bold text-amber-950 font-serif">{kpis.activeLeads}</span>
            </div>
            <div className="bg-indigo-50/60 p-3.5 rounded-xl border border-indigo-200 shadow-2xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 block">Site Visits</span>
              <span className="text-xl font-bold text-indigo-900 font-serif">{kpis.siteVisits}</span>
            </div>
            <div className="bg-orange-50/60 p-3.5 rounded-xl border border-orange-200 shadow-2xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-orange-700 block">Negotiations</span>
              <span className="text-xl font-bold text-orange-900 font-serif">{kpis.negotiations}</span>
            </div>
            <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200 shadow-2xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block">Deals Won</span>
              <span className="text-xl font-bold text-emerald-900 font-serif">{kpis.wonDeals}</span>
            </div>
            <div className="bg-rose-50/60 p-3.5 rounded-xl border border-rose-200 shadow-2xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 block">Lost Leads</span>
              <span className="text-xl font-bold text-rose-900 font-serif">{kpis.lostLeads}</span>
            </div>
          </div>
        )}

        {/* Filters and View Bar */}
        <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-stone-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2 flex-1">
            <div className="relative flex-1 min-w-[200px] max-w-xs">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && loadData()}
                placeholder="Search leads, phone, property..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs py-1.5 px-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
            >
              <option value="ALL">All Statuses</option>
              <option value="NEW">New</option>
              <option value="CONTACTED">Contacted</option>
              <option value="QUALIFIED">Qualified</option>
              <option value="SITE_VISIT">Site Visit</option>
              <option value="NEGOTIATING">Negotiating</option>
              <option value="WON">Won</option>
              <option value="LOST">Lost</option>
            </select>

            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="text-xs py-1.5 px-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
            >
              <option value="ALL">All Priorities</option>
              <option value="URGENT">Urgent</option>
              <option value="HIGH">High</option>
              <option value="MEDIUM">Medium</option>
              <option value="LOW">Low</option>
            </select>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-xs py-1.5 px-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
            >
              <option value="ALL">All Categories</option>
              <option value="residential">Residential</option>
              <option value="commercial">Commercial</option>
            </select>

            <select
              value={transactionFilter}
              onChange={(e) => setTransactionFilter(e.target.value)}
              className="text-xs py-1.5 px-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900"
            >
              <option value="ALL">All Transactions</option>
              <option value="buy">Sale</option>
              <option value="rent">Rent</option>
              <option value="lease">Lease</option>
            </select>
          </div>

          <div className="flex items-center gap-1 bg-stone-100 p-0.5 rounded-lg border border-stone-200 shrink-0 self-end md:self-auto">
            <button
              type="button"
              onClick={() => setViewMode('kanban')}
              className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                viewMode === 'kanban' 
                  ? 'bg-white text-stone-900 shadow-2xs' 
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Kanban className="w-3.5 h-3.5" />
              <span>Pipeline</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                viewMode === 'table' 
                  ? 'bg-white text-stone-900 shadow-2xs' 
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List View</span>
            </button>
          </div>
        </div>

        {/* View Mode Rendering */}
        {loading ? (
          <div className="p-12 text-center text-xs text-stone-500 bg-white rounded-xl border border-stone-200">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-stone-400" />
            Loading governance leads pipeline...
          </div>
        ) : leads.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-xl border border-stone-200 text-xs text-stone-500">
            No leads match current filter selection.
          </div>
        ) : viewMode === 'kanban' ? (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 overflow-x-auto pb-6">
            {STAGES.map((st) => {
              const stageLeads = leads.filter((l) => l.status === st.key);
              return (
                <div key={st.key} className="flex flex-col bg-stone-100/70 rounded-xl p-3 border border-stone-200/90 min-w-[270px]">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-stone-200">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-stone-800">
                      {st.label}
                    </h3>
                    <span className="text-[11px] font-bold px-1.5 py-0.5 rounded-full bg-white text-stone-700 border border-stone-200 font-mono">
                      {stageLeads.length}
                    </span>
                  </div>

                  <div className="space-y-3 flex-1 overflow-y-auto max-h-[70vh]">
                    {stageLeads.map((lead) => (
                      <div 
                        key={lead.id}
                        className="bg-white rounded-lg p-3 border border-stone-200 shadow-2xs space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between text-[10px]">
                          <span className={`px-1.5 py-0.5 rounded font-mono font-semibold uppercase ${
                            lead.priority === 'URGENT' ? 'bg-rose-100 text-rose-800' :
                            lead.priority === 'HIGH' ? 'bg-amber-100 text-amber-800' :
                            'bg-stone-100 text-stone-700'
                          }`}>
                            {lead.priority}
                          </span>
                          <span className="text-stone-400 font-mono text-[9px] uppercase">
                            {lead.source.replace('_', ' ')}
                          </span>
                        </div>

                        <div>
                          <Link 
                            to={`/dashboard/leads/${lead.id}`}
                            className="font-bold text-stone-900 hover:text-amber-800 transition-colors block text-[13px]"
                          >
                            {lead.customer?.name}
                          </Link>
                          <div className="text-[11px] text-stone-500 flex items-center gap-1.5 mt-0.5">
                            <span>{lead.customer?.customerType}</span>
                            <span>·</span>
                            <span>{lead.bhk || lead.businessType || 'Inquiry'}</span>
                          </div>
                        </div>

                        {lead.property && (
                          <div className="p-1.5 bg-stone-50 rounded border border-stone-200/80 text-[11px]">
                            <p className="font-medium text-stone-800 truncate">{lead.property.title}</p>
                            <p className="text-stone-500 font-serif text-[10px]">
                              {formatPriceINR(lead.property.price, 'total')}
                            </p>
                          </div>
                        )}

                        {/* Owner & Assigned agent */}
                        <div className="text-[10px] text-stone-500 space-y-0.5 pt-1 border-t border-stone-100">
                          <div>
                            <span className="text-stone-400">Owner:</span> {lead.ownerName || 'Self listed'}
                          </div>
                          {lead.assignedAgentName && (
                            <div className="text-amber-800 font-medium">
                              <span className="text-stone-400">Assigned:</span> {lead.assignedAgentName}
                            </div>
                          )}
                        </div>

                        {/* Admin quick actions */}
                        <div className="flex items-center justify-between pt-1 border-t border-stone-100">
                          <button
                            type="button"
                            onClick={() => { setAssignModalLead(lead); setSelectedAgentId(lead.assignedAgentId || ''); }}
                            className="text-[10px] font-semibold text-stone-700 hover:text-amber-800 inline-flex items-center gap-1"
                          >
                            <UserCheck className="w-3 h-3" />
                            <span>{lead.assignedAgentId ? 'Reassign' : 'Assign'}</span>
                          </button>

                          <select
                            value={lead.status}
                            onChange={(e) => handleUpdateStatus(lead.id, e.target.value)}
                            className="text-[10px] py-0.5 px-1 bg-stone-50 border border-stone-200 rounded"
                          >
                            <option value="NEW">New</option>
                            <option value="CONTACTED">Contacted</option>
                            <option value="QUALIFIED">Qualified</option>
                            <option value="SITE_VISIT">Site Visit</option>
                            <option value="NEGOTIATING">Negotiating</option>
                            <option value="WON">Won</option>
                            <option value="LOST">Lost</option>
                          </select>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-stone-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-600 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Lead ID</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Property</th>
                    <th className="py-3 px-4">Owner</th>
                    <th className="py-3 px-4">Assigned Agent</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Priority</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {leads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-4 font-mono text-stone-400 text-[10px]">{lead.id}</td>
                      <td className="py-3 px-4">
                        <Link to={`/dashboard/leads/${lead.id}`} className="font-bold text-stone-900 hover:text-amber-800">
                          {lead.customer?.name}
                        </Link>
                        <div className="text-[10px] text-stone-500">{lead.customer?.mobile}</div>
                      </td>
                      <td className="py-3 px-4 max-w-[200px]">
                        {lead.property ? (
                          <div className="truncate font-medium text-stone-800">{lead.property.title}</div>
                        ) : (
                          <span className="text-stone-400 italic">None</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-stone-700">{lead.ownerName || 'Direct'}</td>
                      <td className="py-3 px-4">
                        {lead.assignedAgentName ? (
                          <span className="text-amber-900 font-medium">{lead.assignedAgentName}</span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => { setAssignModalLead(lead); }}
                            className="text-[10px] text-stone-400 hover:text-stone-700 underline"
                          >
                            Unassigned (Assign)
                          </button>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-stone-100">
                          {lead.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                          lead.priority === 'URGENT' ? 'bg-rose-100 text-rose-800' :
                          lead.priority === 'HIGH' ? 'bg-amber-100 text-amber-800' :
                          'bg-stone-100 text-stone-700'
                        }`}>
                          {lead.priority}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => { setAssignModalLead(lead); setSelectedAgentId(lead.assignedAgentId || ''); }}
                            className="p-1 text-stone-600 hover:text-stone-900"
                            title="Assign Agent"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setNoteModalLead(lead)}
                            className="p-1 text-stone-600 hover:text-stone-900"
                            title="Add Note"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                          <Link
                            to={`/dashboard/leads/${lead.id}`}
                            className="px-2 py-1 text-[11px] font-semibold border border-stone-200 rounded text-stone-700 hover:bg-stone-50"
                          >
                            View
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

      {/* Assign Agent Modal */}
      {assignModalLead && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-3.5">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm">Assign Lead: {assignModalLead.customer?.name}</h3>
              <button onClick={() => setAssignModalLead(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAssign} className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-700 font-medium mb-1">Select Assignee (Agent / Owner / Admin) *</label>
                <select
                  value={selectedAgentId}
                  onChange={(e) => setSelectedAgentId(e.target.value)}
                  required
                  className="w-full p-2 border border-stone-200 rounded-md bg-white"
                >
                  <option value="">-- Choose verified user --</option>
                  {agentsList.map((ag) => (
                    <option key={ag.id} value={ag.id}>
                      {ag.name} ({ag.role.toUpperCase()}) - {ag.email}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Assignment Instructions</label>
                <textarea
                  rows={2}
                  value={assignNotes}
                  onChange={(e) => setAssignNotes(e.target.value)}
                  placeholder="e.g. Please follow up on financing readiness and book an in-person site visit."
                  className="w-full p-2 border border-stone-200 rounded-md"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={() => setAssignModalLead(null)} className="px-3 py-1.5 border border-stone-200 rounded-md">
                  Cancel
                </button>
                <button type="submit" disabled={assigning} className="px-4 py-1.5 bg-stone-900 text-white rounded-md font-semibold disabled:opacity-50">
                  {assigning ? 'Assigning...' : 'Confirm Assignment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Note Modal */}
      {noteModalLead && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-stone-200 p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-stone-900 text-sm">Add Note for {noteModalLead.customer?.name}</h3>
              <button onClick={() => setNoteModalLead(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddNote} className="space-y-3">
              <textarea
                rows={3}
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                required
                placeholder="Log internal admin note..."
                className="w-full p-2.5 text-xs border border-stone-200 rounded-md"
              />
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setNoteModalLead(null)} className="px-3 py-1.5 text-xs border border-stone-200 rounded-md">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-1.5 text-xs bg-stone-900 text-white rounded-md font-semibold">
                  Save Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </AdminLayout>
  );
};
