import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Users, 
  MessageSquare, 
  Calendar, 
  ArrowRight, 
  Eye, 
  BadgeCheck, 
  ShieldCheck, 
  Activity,
  AlertTriangle,
  Briefcase
} from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';
import { formatPriceINR, formatArea } from '../../utils/formatters';

export const AdminDashboardPage: React.FC = () => {
  const { showToast } = useProperty();
  const [metrics, setMetrics] = useState<any>(null);
  const [activities, setActivities] = useState<any[]>([]);
  const [pendingProperties, setPendingProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Rejection modal
  const [rejectModalProp, setRejectModalProp] = useState<any | null>(null);
  const [rejectReason, setRejectReason] = useState<string>('');

  const loadData = async () => {
    setLoading(true);
    try {
      const [metRes, actRes, propsRes] = await Promise.all([
        api.admin.metrics(),
        api.admin.activity(),
        api.admin.properties({ status: 'PENDING_APPROVAL' })
      ]);
      setMetrics(metRes.metrics);
      setActivities(actRes.activities || []);
      setPendingProperties(propsRes.properties || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading dashboard metrics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleQuickApprove = async (propId: string) => {
    try {
      await api.admin.reviewProperty(propId, 'approve');
      showToast('Property successfully approved and published live.');
      loadData();
    } catch (err: any) {
      showToast(err.message || 'Error approving property.');
    }
  };

  const handleQuickReject = async () => {
    if (!rejectModalProp || !rejectReason.trim()) {
      showToast('Please specify a rejection reason.');
      return;
    }
    try {
      await api.admin.reviewProperty(rejectModalProp.id, 'reject', rejectReason.trim());
      showToast('Property rejected with feedback logged.');
      setRejectModalProp(null);
      setRejectReason('');
      loadData();
    } catch (err: any) {
      showToast(err.message || 'Error rejecting property.');
    }
  };

  return (
    <AdminLayout
      title="Platform Governance & Moderation"
      subtitle="Real-time oversight of Mumbai properties, user verification, enquiries, and transactions."
      onRefresh={loadData}
      isRefreshing={loading}
    >
      <div className="space-y-6">

        {/* 7 Summary Cards */}
        {metrics ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3">
            
            {/* Total Properties */}
            <Link
              to="/admin/properties"
              className="bg-white p-4 rounded-xl border border-stone-200 hover:border-stone-400 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-stone-500">
                <span className="text-[11px] font-semibold">Total Properties</span>
                <Building2 className="w-4 h-4 text-stone-400 group-hover:text-stone-900 transition-colors" />
              </div>
              <p className="text-2xl font-bold font-serif text-stone-900 mt-2 tabular-nums">
                {metrics.totalProps}
              </p>
              <span className="text-[10px] text-stone-400 mt-0.5 block">Direct listings</span>
            </Link>

            {/* Pending Approval */}
            <Link
              to="/admin/properties?status=PENDING"
              className="bg-amber-50/50 p-4 rounded-xl border border-amber-300 hover:border-amber-400 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-amber-900">
                <span className="text-[11px] font-bold">Pending Review</span>
                <Clock className="w-4 h-4 text-amber-700 animate-pulse" />
              </div>
              <p className="text-2xl font-bold font-serif text-amber-950 mt-2 tabular-nums">
                {metrics.pendingProps}
              </p>
              <span className="text-[10px] text-amber-700 mt-0.5 block font-medium">Needs admin action</span>
            </Link>

            {/* Approved Properties */}
            <Link
              to="/admin/properties?status=APPROVED"
              className="bg-emerald-50/40 p-4 rounded-xl border border-emerald-300 hover:border-emerald-400 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-emerald-900">
                <span className="text-[11px] font-bold">Approved Live</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              </div>
              <p className="text-2xl font-bold font-serif text-emerald-950 mt-2 tabular-nums">
                {metrics.approvedProps}
              </p>
              <span className="text-[10px] text-emerald-700 mt-0.5 block font-medium">Publicly searchable</span>
            </Link>

            {/* Rejected Properties */}
            <Link
              to="/admin/properties?status=REJECTED"
              className="bg-white p-4 rounded-xl border border-stone-200 hover:border-red-300 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-stone-500">
                <span className="text-[11px] font-semibold">Rejected</span>
                <XCircle className="w-4 h-4 text-red-500" />
              </div>
              <p className="text-2xl font-bold font-serif text-stone-900 mt-2 tabular-nums">
                {metrics.rejectedProps}
              </p>
              <span className="text-[10px] text-stone-400 mt-0.5 block">Audit logged</span>
            </Link>

            {/* Active Users */}
            <Link
              to="/admin/users"
              className="bg-white p-4 rounded-xl border border-stone-200 hover:border-stone-400 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-stone-500">
                <span className="text-[11px] font-semibold">Active Users</span>
                <Users className="w-4 h-4 text-stone-400 group-hover:text-stone-900 transition-colors" />
              </div>
              <p className="text-2xl font-bold font-serif text-stone-900 mt-2 tabular-nums">
                {metrics.activeUsers}
              </p>
              <span className="text-[10px] text-stone-400 mt-0.5 block">{metrics.totalUsers} registered</span>
            </Link>

            {/* New Enquiries */}
            <Link
              to="/admin/enquiries"
              className="bg-white p-4 rounded-xl border border-stone-200 hover:border-stone-400 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-stone-500">
                <span className="text-[11px] font-semibold">New Enquiries</span>
                <MessageSquare className="w-4 h-4 text-stone-400 group-hover:text-stone-900 transition-colors" />
              </div>
              <p className="text-2xl font-bold font-serif text-stone-900 mt-2 tabular-nums">
                {metrics.newInquiries}
              </p>
              <span className="text-[10px] text-stone-400 mt-0.5 block">{metrics.totalInquiries} total</span>
            </Link>

            {/* Upcoming Site Visits */}
            <Link
              to="/admin/site-visits"
              className="bg-white p-4 rounded-xl border border-stone-200 hover:border-stone-400 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-stone-500">
                <span className="text-[11px] font-semibold">Upcoming Visits</span>
                <Calendar className="w-4 h-4 text-stone-400 group-hover:text-stone-900 transition-colors" />
              </div>
              <p className="text-2xl font-bold font-serif text-stone-900 mt-2 tabular-nums">
                {metrics.upcomingVisits}
              </p>
              <span className="text-[10px] text-stone-400 mt-0.5 block">{metrics.totalVisits} scheduled</span>
            </Link>

            {/* Leads Pipeline */}
            <Link
              to="/admin/leads"
              className="bg-amber-50/40 p-4 rounded-xl border border-amber-300 hover:border-amber-400 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-amber-900">
                <span className="text-[11px] font-bold">Leads Pipeline</span>
                <Activity className="w-4 h-4 text-amber-700" />
              </div>
              <p className="text-2xl font-bold font-serif text-amber-950 mt-2 tabular-nums">
                Active
              </p>
              <span className="text-[10px] text-amber-700 mt-0.5 block font-medium">Kanban & Assignment</span>
            </Link>

            {/* Deals & Revenue */}
            <Link
              to="/admin/deals"
              className="bg-amber-100/50 p-4 rounded-xl border border-amber-300 hover:border-amber-400 transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between text-amber-950">
                <span className="text-[11px] font-bold">Deals & Revenue</span>
                <Briefcase className="w-4 h-4 text-amber-700" />
              </div>
              <p className="text-2xl font-bold font-serif text-amber-950 mt-2 tabular-nums">
                Deals
              </p>
              <span className="text-[10px] text-amber-800 mt-0.5 block font-medium">Brokerage & Invoices</span>
            </Link>

          </div>
        ) : (
          <div className="p-8 bg-white rounded-xl border border-stone-200 text-center text-xs text-stone-500">
            Loading real-time marketplace metrics...
          </div>
        )}

        {/* Two-Column Section: Pending Verification Queue & Recent Activity Feed */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Pending Review Queue (2 Columns) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold font-serif text-stone-900 flex items-center gap-2">
                  <span>Pending Moderation Queue</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                    {pendingProperties.length} awaiting approval
                  </span>
                </h2>
                <p className="text-xs text-stone-500">Direct owner submissions requiring verification before appearing publicly</p>
              </div>

              <Link
                to="/admin/properties?status=PENDING"
                className="text-xs font-semibold text-stone-800 hover:text-stone-950 flex items-center gap-1"
              >
                <span>View all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {pendingProperties.length > 0 ? (
              <div className="space-y-3">
                {pendingProperties.slice(0, 5).map((prop) => (
                  <div
                    key={prop.id}
                    className="bg-white rounded-xl border border-amber-200/80 p-4 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-amber-400 transition-all"
                  >
                    <div className="flex items-start gap-3.5 min-w-0">
                      <img
                        src={prop.primaryImage}
                        alt={prop.title}
                        className="w-16 h-16 rounded-lg object-cover border border-stone-200 shrink-0"
                      />
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 uppercase">
                            {prop.category} · {prop.transaction_type}
                          </span>
                          <span className="text-[10px] text-stone-400 font-mono">
                            ID: {prop.id}
                          </span>
                        </div>
                        <h3 className="font-bold text-xs sm:text-sm text-stone-900 truncate">
                          {prop.title}
                        </h3>
                        <p className="text-[11px] text-stone-500 truncate">
                          {prop.locality}, Mumbai · <span className="font-bold text-stone-900">{formatPriceINR(prop.price)}</span> ({formatArea(prop.carpet_area)})
                        </p>
                        <p className="text-[10px] text-stone-500">
                          Listed by: <span className="font-medium text-stone-700">{prop.owner_name}</span> ({prop.owner_phone})
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100">
                      <Link
                        to={`/admin/properties/${prop.id}`}
                        className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Review</span>
                      </Link>
                      <button
                        type="button"
                        onClick={() => handleQuickApprove(prop.id)}
                        className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors shadow-2xs"
                      >
                        Approve
                      </button>
                      <button
                        type="button"
                        onClick={() => setRejectModalProp(prop)}
                        className="px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-800 rounded-lg text-xs font-semibold transition-colors"
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-stone-200 p-8 text-center text-xs text-stone-500 space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="font-semibold text-stone-900">All submissions reviewed!</p>
                <p>There are no pending properties requiring moderation right now.</p>
              </div>
            )}
          </div>

          {/* Recent Activity Feed (1 Column) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold font-serif text-stone-900 flex items-center gap-2">
                <Activity className="w-4 h-4 text-stone-600" />
                <span>Audit & Activity Stream</span>
              </h2>
              <Link
                to="/admin/audit-logs"
                className="text-xs font-semibold text-stone-800 hover:text-stone-950 flex items-center gap-1"
              >
                <span>Full log</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs space-y-3">
              {activities.length > 0 ? (
                <div className="divide-y divide-stone-100 space-y-3">
                  {activities.slice(0, 8).map((act) => (
                    <div key={act.id} className="pt-3 first:pt-0 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          act.action.includes('approved') || act.action.includes('verified')
                            ? 'bg-emerald-100 text-emerald-800'
                            : act.action.includes('rejected') || act.action.includes('suspended')
                              ? 'bg-red-100 text-red-800'
                              : 'bg-stone-100 text-stone-700'
                        }`}>
                          {act.action}
                        </span>
                        <span className="text-[10px] text-stone-400 font-mono">
                          {new Date(act.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-xs text-stone-800 font-medium leading-snug">
                        {act.details || `Admin action performed on ${act.entity_type}`}
                      </p>
                      <p className="text-[10px] text-stone-400">
                        Admin: {act.admin_name || 'System Admin'} · {new Date(act.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-stone-400 text-center py-6">
                  No recent audit activity recorded.
                </p>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* Reject Modal */}
      {rejectModalProp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-stone-200 max-w-md w-full p-6 space-y-4 shadow-xl text-xs">
            <div className="flex items-center gap-2 text-red-600 font-bold">
              <AlertTriangle className="w-4 h-4" />
              <span>Reject Property Listing</span>
            </div>
            
            <p className="text-stone-700">
              Rejecting <strong className="text-stone-950">{rejectModalProp.title}</strong>. Please select or write a constructive reason so the owner can amend it.
            </p>

            <div className="space-y-2">
              <label className="font-semibold text-stone-900 block">Common reasons:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Missing property documents / OC',
                  'Incorrect pricing for locality',
                  'Poor quality or misleading images',
                  'Duplicate listing detected',
                  'Owner phone verification required'
                ].map((reason) => (
                  <button
                    key={reason}
                    type="button"
                    onClick={() => setRejectReason(reason)}
                    className="px-2 py-1 rounded bg-stone-100 hover:bg-stone-200 text-stone-700 text-[11px] transition-colors"
                  >
                    {reason}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="font-semibold text-stone-900 block mb-1">
                Feedback for Owner (Stored in Audit Log):
              </label>
              <textarea
                rows={3}
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Specify required corrections clearly..."
                className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-stone-900 text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => {
                  setRejectModalProp(null);
                  setRejectReason('');
                }}
                className="px-3.5 py-2 border border-stone-200 rounded-lg text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleQuickReject}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold shadow-xs"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

    </AdminLayout>
  );
};
