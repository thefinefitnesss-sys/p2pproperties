import React, { useState, useEffect } from 'react';
import { Settings, Server, Database, ShieldCheck, CheckCircle2, Lock, Cpu } from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';

export const AdminSettingsPage: React.FC = () => {
  const { showToast } = useProperty();
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const res = await api.admin.settings();
      setSettings(res.system);
    } catch (err: any) {
      showToast(err.message || 'Error fetching system settings.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  return (
    <AdminLayout
      title="System Settings & Database Overview"
      subtitle="Production environment runtime, database integrity, and security configuration parameters."
      onRefresh={loadSettings}
      isRefreshing={loading}
    >
      <div className="space-y-6">

        {settings ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            
            {/* System Runtime Card */}
            <div className="bg-white rounded-2xl border border-stone-200 p-5 space-y-4 shadow-2xs">
              <h2 className="text-sm font-bold font-serif text-stone-900 flex items-center gap-2">
                <Server className="w-4 h-4 text-stone-600" />
                <span>Runtime Environment</span>
              </h2>

              <div className="divide-y divide-stone-100">
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">Platform Name</span>
                  <span className="font-bold text-stone-900">{settings.platformName}</span>
                </div>
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">System Build Version</span>
                  <span className="font-mono text-stone-900 font-semibold">{settings.version}</span>
                </div>
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">Deployment Environment</span>
                  <span className="capitalize font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {settings.environment}
                  </span>
                </div>
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">System Uptime</span>
                  <span className="tabular-nums font-mono text-stone-900">
                    {Math.floor(settings.uptimeSeconds / 60)} minutes ({settings.uptimeSeconds}s)
                  </span>
                </div>
              </div>
            </div>

            {/* Database Engine Card */}
            <div className="bg-white rounded-2xl border border-stone-200 p-5 space-y-4 shadow-2xs">
              <h2 className="text-sm font-bold font-serif text-stone-900 flex items-center gap-2">
                <Database className="w-4 h-4 text-stone-600" />
                <span>Database Engine & Integrity</span>
              </h2>

              <div className="divide-y divide-stone-100">
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">Engine Type</span>
                  <span className="font-bold text-stone-900">{settings.databaseEngine}</span>
                </div>
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">Integrity Health</span>
                  <span className="font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{settings.databaseStatus}</span>
                  </span>
                </div>
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">Users Table Record Count</span>
                  <span className="font-bold tabular-nums text-stone-900">{settings.records?.users}</span>
                </div>
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">Properties Record Count</span>
                  <span className="font-bold tabular-nums text-stone-900">{settings.records?.properties}</span>
                </div>
                <div className="py-2.5 flex items-center justify-between">
                  <span className="text-stone-500">Audit Logs Count</span>
                  <span className="font-bold tabular-nums text-stone-900">{settings.records?.auditLogs}</span>
                </div>
              </div>
            </div>

            {/* Security Hardening Overview */}
            <div className="md:col-span-2 bg-stone-900 text-stone-200 rounded-2xl p-6 space-y-3 shadow-md border border-stone-800">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4" />
                <span>Security Governance Hardening Active</span>
              </div>
              <h3 className="text-lg font-bold font-serif text-white">
                Admin Role Enforcement & IDOR Protection Active
              </h3>
              <p className="text-xs text-stone-400 leading-relaxed max-w-3xl">
                Every administrative endpoint rigorously evaluates cryptographically verified JSON Web Tokens on the Express server. Non-admin roles (buyers, tenants, owners, and agents) receive 403 Forbidden with zero data exposure. Suspended accounts are immediately blocked from session generation and mutation APIs.
              </p>
            </div>

          </div>
        ) : (
          <div className="p-8 bg-white rounded-xl border border-stone-200 text-center text-xs text-stone-500">
            Loading system configuration...
          </div>
        )}

      </div>
    </AdminLayout>
  );
};
