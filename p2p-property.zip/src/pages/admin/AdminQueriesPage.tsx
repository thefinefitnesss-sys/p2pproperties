import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, 
  MapPin, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  Search, 
  User, 
  ArrowRight,
  Filter,
  Sparkles,
  ShieldCheck,
  Briefcase
} from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';
import { formatPriceINR } from '../../utils/formatters';

export const AdminQueriesPage: React.FC = () => {
  const { showToast } = useProperty();
  const [queries, setQueries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [search, setSearch] = useState('');

  const loadQueries = async () => {
    setLoading(true);
    try {
      const res = await api.queries.list({
        status: statusFilter === 'ALL' ? undefined : statusFilter,
        search: search || undefined
      });
      setQueries(res.queries || []);
    } catch (err: any) {
      showToast(err.message || 'Error fetching queries.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQueries();
  }, [statusFilter]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadQueries();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'NEW':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800">New</span>;
      case 'IN_PROGRESS':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800">In Progress</span>;
      case 'MATCHED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800">Matched</span>;
      case 'SITE_VISIT':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800">Site Visit</span>;
      case 'FULFILLED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-900">Fulfilled</span>;
      case 'CLOSED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-stone-100 text-stone-700">Closed</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-stone-100 text-stone-700">{status}</span>;
    }
  };

  return (
    <AdminLayout
      title="Property Requirements & Off-Market Matches"
      subtitle="Supervise customer property queries, match engine allocations, and broker sourcing."
      activeTab="queries"
      onRefresh={loadQueries}
      isRefreshing={loading}
    >
      <div className="space-y-6">
        
        {/* Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-stone-200">
          <form onSubmit={handleSearch} className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by Query ID (P2P-Q-...), customer, location..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:border-stone-900"
            />
          </form>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-stone-500 font-medium">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
            >
              <option value="ALL">All Statuses</option>
              <option value="NEW">New</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="MATCHED">Matched</option>
              <option value="SITE_VISIT">Site Visit</option>
              <option value="FULFILLED">Fulfilled</option>
              <option value="CLOSED">Closed</option>
            </select>
          </div>
        </div>

        {/* Query Table */}
        <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-stone-600">
              <thead className="bg-stone-50 text-stone-700 uppercase font-bold text-[10px] tracking-wider border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4">Query ID</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Requirement</th>
                  <th className="py-3 px-4">Target Locality</th>
                  <th className="py-3 px-4">Budget Range</th>
                  <th className="py-3 px-4">Off-Market</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {loading ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-stone-400">
                      Loading queries...
                    </td>
                  </tr>
                ) : queries.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-stone-400">
                      No customer queries found.
                    </td>
                  </tr>
                ) : (
                  queries.map((q) => (
                    <tr key={q.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-stone-900">
                        {q.queryNumber}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-stone-900">{q.customer?.name}</div>
                        <div className="text-[10px] text-stone-400">{q.customer?.email}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-stone-800">
                          {q.transactionType} · {q.bhk || q.propertyType}
                        </div>
                        <div className="text-[10px] text-stone-400">{q.category}</div>
                      </td>
                      <td className="py-3 px-4 max-w-[180px] truncate" title={q.preferredLocations}>
                        {q.preferredLocations || 'Mumbai General'}
                      </td>
                      <td className="py-3 px-4 font-medium text-stone-900">
                        {q.budgetMin ? formatPriceINR(q.budgetMin) : 'Any'} – {q.budgetMax ? formatPriceINR(q.budgetMax) : 'Open'}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center gap-1 font-bold ${q.offMarketMatchCount > 0 ? 'text-amber-700' : 'text-stone-400'}`}>
                          {q.offMarketMatchCount} Candidate{q.offMarketMatchCount === 1 ? '' : 's'}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {getStatusBadge(q.status)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Link
                          to={`/dashboard/queries/${q.id}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-stone-900 bg-stone-100 hover:bg-stone-200 rounded transition-colors"
                        >
                          <span>Manage</span>
                          <ArrowRight className="w-3 h-3" />
                        </Link>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </AdminLayout>
  );
};
