import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Search, RotateCcw, Clock, Phone, Mail, Building2, CheckCircle2 } from 'lucide-react';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { api } from '../../services/api';
import { useProperty } from '../../context/PropertyContext';
import { formatPriceINR } from '../../utils/formatters';

const ENQUIRY_STATUSES = [
  'ALL',
  'NEW',
  'CONTACTED',
  'SITE_VISIT',
  'NEGOTIATING',
  'CLOSED',
  'CANCELLED'
] as const;

export const AdminEnquiriesPage: React.FC = () => {
  const { showToast } = useProperty();
  const [enquiries, setEnquiries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  const loadEnquiries = async () => {
    setLoading(true);
    try {
      const res = await api.admin.enquiries({
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
        search: searchTerm.trim() || undefined
      });
      setEnquiries(res.enquiries || []);
    } catch (err: any) {
      showToast(err.message || 'Error loading enquiries.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEnquiries();
  }, [statusFilter]);

  const handleUpdateStatus = async (id: string, newStatus: string) => {
    try {
      await api.admin.updateEnquiryStatus(id, newStatus);
      showToast(`Enquiry status updated to ${newStatus}.`);
      loadEnquiries();
    } catch (err: any) {
      showToast(err.message || 'Error updating enquiry.');
    }
  };

  return (
    <AdminLayout
      title="Buyer & Tenant Enquiries"
      subtitle="Track peer-to-peer inquiry conversations, buyer interest, and negotiation progress across Mumbai properties."
      onRefresh={loadEnquiries}
      isRefreshing={loading}
    >
      <div className="space-y-6">

        {/* Filter Bar */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs space-y-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              loadEnquiries();
            }}
            className="flex flex-col md:flex-row items-stretch md:items-center gap-3"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by buyer name, buyer email, property title, or owner..."
                className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg transition-colors shrink-0"
            >
              Search
            </button>
          </form>

          {/* Status Pills */}
          <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-stone-100 text-xs">
            <span className="text-[11px] font-semibold text-stone-500 mr-1">Status:</span>
            {ENQUIRY_STATUSES.map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-md font-semibold transition-all text-xs ${
                  statusFilter === st
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                {st}
              </button>
            ))}

            <span className="ml-auto text-stone-400 text-[11px] tabular-nums">
              {enquiries.length} enquiries found
            </span>
          </div>
        </div>

        {/* Enquiries Table */}
        {enquiries.length > 0 ? (
          <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="p-3.5">Property</th>
                    <th className="p-3.5">Buyer / Tenant</th>
                    <th className="p-3.5">Message / Inquiry</th>
                    <th className="p-3.5">Owner / Agent</th>
                    <th className="p-3.5">Date</th>
                    <th className="p-3.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {enquiries.map((inq) => (
                    <tr key={inq.id} className="hover:bg-stone-50/80 transition-colors">
                      
                      {/* Property */}
                      <td className="p-3.5 max-w-xs">
                        <Link
                          to={`/admin/properties/${inq.property_id}`}
                          className="font-bold text-stone-900 hover:text-amber-800 transition-colors block truncate"
                        >
                          {inq.property_title}
                        </Link>
                        <p className="text-[11px] text-stone-500 mt-0.5">
                          {inq.locality} · {formatPriceINR(inq.price)}
                        </p>
                        <p className="text-[10px] text-stone-400 font-mono mt-0.5">
                          ID: {inq.property_id}
                        </p>
                      </td>

                      {/* Buyer */}
                      <td className="p-3.5 whitespace-nowrap">
                        <p className="font-bold text-stone-900">{inq.buyer_name}</p>
                        <p className="text-[11px] text-stone-600 flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-stone-400" />
                          <span>{inq.buyer_phone}</span>
                        </p>
                        <p className="text-[10px] text-stone-400 flex items-center gap-1">
                          <Mail className="w-3 h-3 text-stone-400" />
                          <span>{inq.buyer_email}</span>
                        </p>
                      </td>

                      {/* Message */}
                      <td className="p-3.5 max-w-xs">
                        <p className="text-stone-800 font-medium line-clamp-2 bg-stone-50 p-2 rounded-lg">
                          "{inq.message}"
                        </p>
                        {inq.preferred_contact_time && (
                          <p className="text-[10px] text-stone-500 mt-1 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-stone-400" />
                            <span>Preferred: {inq.preferred_contact_time}</span>
                          </p>
                        )}
                      </td>

                      {/* Owner */}
                      <td className="p-3.5 whitespace-nowrap">
                        <p className="font-semibold text-stone-900">{inq.owner_name}</p>
                        <p className="text-[10px] text-stone-500">{inq.owner_phone}</p>
                        <p className="text-[10px] text-stone-400">{inq.owner_email}</p>
                      </td>

                      {/* Date */}
                      <td className="p-3.5 whitespace-nowrap text-stone-500 text-[11px]">
                        {new Date(inq.created_at).toLocaleDateString()}
                        <span className="block text-[10px] text-stone-400">
                          {new Date(inq.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="p-3.5 whitespace-nowrap">
                        <select
                          value={inq.status}
                          onChange={(e) => handleUpdateStatus(inq.id, e.target.value)}
                          className={`px-2.5 py-1 text-xs font-bold rounded-lg border cursor-pointer ${
                            inq.status === 'NEW'
                              ? 'bg-amber-50 text-amber-900 border-amber-300'
                              : inq.status === 'CLOSED'
                                ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                                : inq.status === 'CANCELLED'
                                  ? 'bg-red-50 text-red-900 border-red-200'
                                  : 'bg-stone-50 text-stone-800 border-stone-200'
                          }`}
                        >
                          <option value="NEW">NEW</option>
                          <option value="CONTACTED">CONTACTED</option>
                          <option value="SITE_VISIT">SITE_VISIT</option>
                          <option value="NEGOTIATING">NEGOTIATING</option>
                          <option value="CLOSED">CLOSED</option>
                          <option value="CANCELLED">CANCELLED</option>
                        </select>
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-stone-200 p-12 text-center text-xs text-stone-500 space-y-2">
            <MessageSquare className="w-8 h-8 text-stone-300 mx-auto" />
            <p className="font-semibold text-stone-900">No enquiries found</p>
            <p>Try clearing filters or search query.</p>
          </div>
        )}

      </div>
    </AdminLayout>
  );
};
