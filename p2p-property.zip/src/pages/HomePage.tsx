import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Search, 
  MapPin, 
  ArrowRight, 
  ShieldCheck, 
  KeyRound, 
  Building2, 
  Home, 
  Sparkles, 
  Layers,
  CheckCircle2,
  PhoneCall
} from 'lucide-react';
import { useProperty } from '../context/PropertyContext';
import { PropertyCard } from '../components/property/PropertyCard';
import { 
  PropertyCategory, 
  TransactionType 
} from '../types/property';
import { 
  POPULAR_MUMBAI_AREAS, 
  RESIDENTIAL_TYPE_OPTIONS, 
  COMMERCIAL_TYPE_OPTIONS 
} from '../data/sampleProperties';

export const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { properties, setFilters } = useProperty();

  // Hero Search State
  const [category, setCategory] = useState<PropertyCategory>('residential');
  const [transaction, setTransaction] = useState<TransactionType>('buy');
  const [location, setLocation] = useState('');
  const [propertyType, setPropertyType] = useState('');
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [minArea, setMinArea] = useState<string>('');
  const [maxArea, setMaxArea] = useState<string>('');

  // Handle category change (update valid transaction defaults)
  const handleCategoryChange = (cat: PropertyCategory) => {
    setCategory(cat);
    setPropertyType('');
    if (cat === 'residential' && (transaction === 'lease' || transaction === 'sell')) {
      setTransaction('buy');
    }
  };

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();

    const queryParams = new URLSearchParams();
    queryParams.set('category', category);
    queryParams.set('transactionType', transaction);

    if (location) queryParams.set('location', location);
    if (propertyType) queryParams.set('propertyType', propertyType);
    if (minPrice) queryParams.set('minPrice', minPrice);
    if (maxPrice) queryParams.set('maxPrice', maxPrice);
    if (minArea) queryParams.set('minCarpetArea', minArea);
    if (maxArea) queryParams.set('maxCarpetArea', maxArea);

    navigate(`/properties?${queryParams.toString()}`);
  };

  // Transaction options based on category
  const residentialTransactions: TransactionType[] = ['buy', 'rent'];
  const commercialTransactions: TransactionType[] = ['buy', 'rent', 'lease', 'sell'];
  const currentTransactions = category === 'residential' ? residentialTransactions : commercialTransactions;

  // Property types based on category
  const currentTypes = category === 'residential' ? RESIDENTIAL_TYPE_OPTIONS : COMMERCIAL_TYPE_OPTIONS;

  // Featured Mumbai Properties
  const featuredProperties = properties.filter((p) => p.isFeatured).slice(0, 4);

  return (
    <div className="space-y-16 sm:space-y-24">
      
      {/* HERO SECTION */}
      <section className="relative pt-6 sm:pt-10 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
        
        {/* Subtle architectural backdrop */}
        <div className="absolute inset-0 -z-10 bg-radial from-amber-50/60 via-[#FAF9F5] to-[#FAF9F5]" />

        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* Hero Header Typography */}
          <div className="text-center max-w-3xl mx-auto space-y-3 sm:space-y-4">
            
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-200/80 text-stone-800 text-[11px] font-semibold tracking-wide uppercase">
              <ShieldCheck className="w-3.5 h-3.5 text-stone-900" />
              <span>Direct Peer-to-Peer Real Estate · Mumbai</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold font-serif text-stone-950 tracking-tight leading-[1.15] text-balance">
              Find the right property. Deal directly.
            </h1>

            <p className="text-base sm:text-lg text-stone-600 max-w-2xl mx-auto font-normal leading-relaxed">
              Buy, sell, rent or lease residential and commercial properties across Mumbai.
            </p>
          </div>

          {/* SEARCH INTERFACE CONTAINER */}
          <div className="bg-white rounded-2xl shadow-xl border border-stone-200/80 p-5 sm:p-7 max-w-5xl mx-auto backdrop-blur-xs">
            
            <form onSubmit={handleHeroSearch} className="space-y-5">
              
              {/* Row 1: Category & Transaction Selector */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pb-4 border-b border-stone-100">
                
                {/* Property Category Tabs */}
                <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-lg">
                  <button
                    type="button"
                    onClick={() => handleCategoryChange('residential')}
                    className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-md transition-all ${
                      category === 'residential'
                        ? 'bg-white text-stone-950 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <Home className="w-3.5 h-3.5 text-stone-500" />
                    <span>Residential</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCategoryChange('commercial')}
                    className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-md transition-all ${
                      category === 'commercial'
                        ? 'bg-white text-stone-950 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    <Building2 className="w-3.5 h-3.5 text-stone-500" />
                    <span>Commercial</span>
                  </button>
                </div>

                {/* Transaction Sub-tabs */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
                  <span className="text-xs text-stone-400 font-medium mr-1 hidden sm:inline">Action:</span>
                  {currentTransactions.map((tx) => (
                    <button
                      key={tx}
                      type="button"
                      onClick={() => setTransaction(tx)}
                      className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-wider rounded-md border transition-all ${
                        transaction === tx
                          ? 'border-stone-900 bg-stone-900 text-white'
                          : 'border-stone-200 bg-stone-50 text-stone-600 hover:border-stone-400'
                      }`}
                    >
                      {tx}
                    </button>
                  ))}
                </div>

              </div>

              {/* Row 2: Location, Property Type, Budget, Area */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                
                {/* Location Search */}
                <div>
                  <label className="block font-semibold text-stone-800 mb-1.5">
                    Mumbai Location
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                    <select
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white font-medium text-stone-800"
                    >
                      <option value="">All Mumbai Localities</option>
                      {POPULAR_MUMBAI_AREAS.map((loc) => (
                        <option key={loc} value={loc}>{loc}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Property Type Dropdown */}
                <div>
                  <label className="block font-semibold text-stone-800 mb-1.5">
                    Property Type
                  </label>
                  <select
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value)}
                    className="w-full px-3 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white font-medium text-stone-800"
                  >
                    <option value="">All {category === 'residential' ? 'Home' : 'Commercial'} Types</option>
                    {currentTypes.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>

                {/* Budget Range */}
                <div>
                  <label className="block font-semibold text-stone-800 mb-1.5">
                    Budget (₹ Min - Max)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      value={minPrice}
                      onChange={(e) => setMinPrice(e.target.value)}
                      placeholder="Min (₹)"
                      className="w-full px-2.5 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white text-stone-800"
                    />
                    <input
                      type="number"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(e.target.value)}
                      placeholder="Max (₹)"
                      className="w-full px-2.5 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white text-stone-800"
                    />
                  </div>
                </div>

                {/* Carpet Area Range */}
                <div>
                  <label className="block font-semibold text-stone-800 mb-1.5">
                    Carpet Area (sq.ft)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      value={minArea}
                      onChange={(e) => setMinArea(e.target.value)}
                      placeholder="Min sq.ft"
                      className="w-full px-2.5 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white text-stone-800"
                    />
                    <input
                      type="number"
                      value={maxArea}
                      onChange={(e) => setMaxArea(e.target.value)}
                      placeholder="Max sq.ft"
                      className="w-full px-2.5 py-2.5 border border-stone-200 rounded-lg focus:outline-hidden focus:border-stone-900 bg-white text-stone-800"
                    />
                  </div>
                </div>

              </div>

              {/* Row 3: Search Properties CTA Button */}
              <div className="pt-2 flex items-center justify-between flex-wrap gap-4">
                
                {/* Popular Quick Filter tags */}
                <div className="flex items-center gap-2 text-xs text-stone-500 overflow-x-auto pb-1 sm:pb-0">
                  <span className="font-medium text-stone-700 shrink-0">Popular:</span>
                  <button
                    type="button"
                    onClick={() => { setCategory('residential'); setTransaction('buy'); setPropertyType('3 BHK'); setLocation('Bandra West'); }}
                    className="hover:text-stone-900 underline underline-offset-2 shrink-0"
                  >
                    3 BHK Bandra
                  </button>
                  <span className="text-stone-300">·</span>
                  <button
                    type="button"
                    onClick={() => { setCategory('commercial'); setTransaction('rent'); setPropertyType('Office'); setLocation('Bandra Kurla Complex (BKC)'); }}
                    className="hover:text-stone-900 underline underline-offset-2 shrink-0"
                  >
                    BKC Offices
                  </button>
                  <span className="text-stone-300">·</span>
                  <button
                    type="button"
                    onClick={() => { setCategory('residential'); setTransaction('buy'); setPropertyType('4+ BHK'); setLocation('Worli'); }}
                    className="hover:text-stone-900 underline underline-offset-2 shrink-0"
                  >
                    Worli Sea-View
                  </button>
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 text-xs font-semibold uppercase tracking-wider text-white bg-stone-950 hover:bg-stone-800 rounded-lg shadow-md transition-all group"
                >
                  <Search className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  <span>Search Properties</span>
                </button>

              </div>

            </form>
          </div>

          {/* Value Pillars under hero */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 text-center">
            <div className="p-3 bg-white/60 border border-stone-200/60 rounded-xl">
              <p className="font-serif font-bold text-lg text-stone-900">100% Direct</p>
              <p className="text-xs text-stone-500 mt-0.5">Deal straight with genuine owners</p>
            </div>
            <div className="p-3 bg-white/60 border border-stone-200/60 rounded-xl">
              <p className="font-serif font-bold text-lg text-stone-900">Verified Titles</p>
              <p className="text-xs text-stone-500 mt-0.5">Pre-checked OC & RERA statuses</p>
            </div>
            <div className="p-3 bg-white/60 border border-stone-200/60 rounded-xl">
              <p className="font-serif font-bold text-lg text-stone-900">Zero Spam</p>
              <p className="text-xs text-stone-500 mt-0.5">No random broker database selling</p>
            </div>
            <div className="p-3 bg-white/60 border border-stone-200/60 rounded-xl">
              <p className="font-serif font-bold text-lg text-stone-900">Mumbai Focus</p>
              <p className="text-xs text-stone-500 mt-0.5">Deep micro-market coverage</p>
            </div>
          </div>

        </div>
      </section>

      {/* FEATURED PROPERTIES SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-800 block mb-1">
              Curated Direct Listings
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-stone-950">
              Featured Mumbai Properties
            </h2>
          </div>
          <Link
            to="/properties"
            className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-stone-900 hover:text-amber-800 transition-colors group"
          >
            <span>Explore All Properties</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProperties.map((prop) => (
            <PropertyCard key={prop.id} property={prop} />
          ))}
        </div>
      </section>

      {/* WHY DIRECT PEER-TO-PEER SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-stone-900 text-stone-100 rounded-3xl p-8 sm:p-12 lg:p-16 border border-stone-800 relative overflow-hidden">
          
          <div className="max-w-3xl space-y-4 relative z-10">
            <span className="text-xs font-semibold uppercase tracking-widest text-amber-400">
              The P2P Property Difference
            </span>
            <h2 className="text-2xl sm:text-4xl font-serif font-bold tracking-tight text-white leading-tight">
              Why deal directly in Mumbai real estate?
            </h2>
            <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
              Traditional real estate transactions in Mumbai are burdened with arbitrary commission conflicts, unsolicited agent phone harassment, and misquoted pricing. P2P Property replaces opaque intermediaries with verified, transparent direct agreements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-10 relative z-10">
            <div className="p-6 bg-stone-800/70 border border-stone-700/60 rounded-xl space-y-3">
              <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                01
              </div>
              <h3 className="text-base font-semibold text-white">Genuine Price Discovery</h3>
              <p className="text-xs text-stone-400 leading-relaxed">
                Negotiate terms face-to-face with the actual property owner without middlemen artificially inflating numbers or holding listings hostage.
              </p>
            </div>

            <div className="p-6 bg-stone-800/70 border border-stone-700/60 rounded-xl space-y-3">
              <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                02
              </div>
              <h3 className="text-base font-semibold text-white">Guarded Privacy Masking</h3>
              <p className="text-xs text-stone-400 leading-relaxed">
                Owners are shielded from endless telemarketing calls. Buyers and tenants connect only after submitting genuine verified requirements.
              </p>
            </div>

            <div className="p-6 bg-stone-800/70 border border-stone-700/60 rounded-xl space-y-3">
              <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                03
              </div>
              <h3 className="text-base font-semibold text-white">Scheduled Verified Visits</h3>
              <p className="text-xs text-stone-400 leading-relaxed">
                Book physical building walkthroughs with pre-cleared society security coordinates, floor access, and direct owner appointments.
              </p>
            </div>
          </div>

          <div className="pt-10 flex flex-col sm:flex-row items-center gap-4 relative z-10 border-t border-stone-800 mt-10">
            <Link
              to="/list-property"
              className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 text-xs font-semibold uppercase tracking-wider text-stone-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-sm"
            >
              List Your Mumbai Property Now
            </Link>
            <span className="text-xs text-stone-400">
              No upfront listing charge · Direct buyer inquiries
            </span>
          </div>

        </div>
      </section>

      {/* EXPLORE MUMBAI MICRO-MARKETS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-800">
            Mumbai Micro-Markets
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-stone-950">
            Browse by Premier Locations
          </h2>
          <p className="text-xs sm:text-sm text-stone-600">
            From premier sea-facing coastal homes to commercial central business districts.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { name: 'Bandra West', count: 'Carter Rd, Pali Hill', cat: 'residential' },
            { name: 'BKC', count: 'G Block Central Hub', cat: 'commercial' },
            { name: 'Worli', count: 'Sea Face & High-rises', cat: 'residential' },
            { name: 'Lower Parel', count: 'Mills & Showrooms', cat: 'commercial' },
            { name: 'Powai', count: 'Hiranandani Gardens', cat: 'residential' },
            { name: 'Andheri West', count: 'Media & Commercial', cat: 'commercial' },
          ].map((item) => (
            <Link
              key={item.name}
              to={`/properties?location=${encodeURIComponent(item.name)}&category=${item.cat}`}
              className="p-4 bg-white rounded-xl border border-stone-200/90 hover:border-stone-900 transition-colors text-center group"
            >
              <h4 className="font-semibold text-stone-900 text-sm group-hover:text-amber-800">
                {item.name}
              </h4>
              <p className="text-[11px] text-stone-500 mt-1">{item.count}</p>
            </Link>
          ))}
        </div>
      </section>

    </div>
  );
};
