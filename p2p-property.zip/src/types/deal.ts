import { Customer } from './lead';

export type DealStatus = 
  | 'NEGOTIATION'
  | 'AGREED'
  | 'AGREEMENT_PENDING'
  | 'AGREEMENT_SIGNED'
  | 'PAYMENT_PENDING'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'FAILED';

export type DealTransactionType = 'BUY' | 'RENT' | 'LEASE';
export type DealCategory = 'RESIDENTIAL' | 'COMMERCIAL';

export type CommissionType = 'PERCENTAGE' | 'FIXED_AMOUNT';

export type CommissionPayer = 
  | 'BUYER'
  | 'TENANT'
  | 'OWNER'
  | 'LANDLORD'
  | 'BOTH_PARTIES'
  | 'OTHER';

export type CommissionStatus = 
  | 'NOT_SET'
  | 'AGREED'
  | 'INVOICED'
  | 'PARTIALLY_PAID'
  | 'PAID'
  | 'WAIVED'
  | 'CANCELLED';

export type PaymentMethod = 
  | 'UPI'
  | 'NEFT_RTGS'
  | 'CHEQUE'
  | 'CASH'
  | 'BANK_TRANSFER'
  | 'ONLINE';

export interface DealPayment {
  id: string;
  dealId: string;
  receiptNumber: string;
  amount: number;
  paymentMethod: PaymentMethod;
  transactionReference?: string;
  paymentDate: string;
  payerName?: string;
  recordedById: string;
  recordedByName?: string;
  notes?: string;
  createdAt: string;
}

export interface DealInvoice {
  id: string;
  dealId: string;
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  subtotal: number;
  gstRate: number;
  gstAmount: number;
  totalAmount: number;
  status: 'DRAFT' | 'ISSUED' | 'PAID' | 'CANCELLED';
  notes?: string;
  createdAt: string;
}

export interface DealActivity {
  id: string;
  dealId: string;
  performedById: string;
  performedByName?: string;
  performedByRole?: string;
  action: string;
  details?: string;
  createdAt: string;
}

export interface Deal {
  id: string;
  dealNumber: string;
  leadId?: string;
  propertyId: string;
  customerId: string;
  ownerId: string;
  assignedAgentId?: string;
  transactionType: DealTransactionType;
  category: DealCategory;
  dealStatus: DealStatus;
  agreedPropertyValue?: number;
  agreedRent?: number;
  agreedLeaseValue?: number;
  commissionType: CommissionType;
  commissionRate?: number;
  commissionBase?: number;
  commissionAmount: number;
  commissionPayer: CommissionPayer;
  commissionStatus: CommissionStatus;
  expectedClosingDate?: string;
  actualClosingDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;

  // Calculated fields
  paidAmount?: number;
  remainingAmount?: number;

  // Joined relations
  property?: {
    id: string;
    title: string;
    locality: string;
    city: string;
    price?: number;
    monthly_rent?: number;
    lease_rate_psf?: number;
    primary_photo?: string;
    property_type?: string;
    bedrooms?: number;
    category?: string;
    transaction_type?: string;
  };
  customer?: Customer;
  owner?: {
    id: string;
    name: string;
    email: string;
    phone?: string;
  };
  assignedAgent?: {
    id: string;
    name: string;
    email: string;
    phone?: string;
  };
  payments?: DealPayment[];
  invoices?: DealInvoice[];
  activities?: DealActivity[];
}

export interface DealStats {
  totalDeals: number;
  activeDeals: number;
  completedDeals: number;
  cancelledDeals: number;
  totalVolume: number;
  totalCommissionBooked: number;
  totalCommissionCollected: number;
  totalOutstandingCommission: number;
}
