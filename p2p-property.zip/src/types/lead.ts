export type LeadStatus = 
  | 'NEW'
  | 'CONTACTED'
  | 'QUALIFIED'
  | 'SITE_VISIT'
  | 'NEGOTIATING'
  | 'WON'
  | 'LOST'
  | 'CLOSED';

export type LeadPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';

export type LeadSource = 
  | 'WEBSITE'
  | 'WHATSAPP'
  | 'PHONE'
  | 'PROPERTY_ENQUIRY'
  | 'REFERRAL'
  | 'ADMIN_CREATED';

export type CustomerType = 'BUYER' | 'TENANT';

export type FollowUpStatus = 'PENDING' | 'COMPLETED' | 'CANCELLED';

export interface Customer {
  id: string;
  name: string;
  mobile: string;
  email: string;
  userId?: string;
  customerType: CustomerType;
  preferredTransaction?: 'buy' | 'rent' | 'lease';
  preferredCategory?: 'residential' | 'commercial';
  preferredLocations?: string;
  budgetMin?: number;
  budgetMax?: number;
  preferredPropertyTypes?: string;
  bhk?: string;
  carpetAreaMin?: number;
  carpetAreaMax?: number;
  furnishingPreference?: string;
  parkingRequirement?: string;
  businessType?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LeadFollowUp {
  id: string;
  leadId: string;
  followUpDate: string;
  followUpTime?: string;
  note: string;
  assignedTo?: string;
  assignedToName?: string;
  status: FollowUpStatus;
  createdAt: string;
  updatedAt: string;
}

export interface LeadActivity {
  id: string;
  leadId: string;
  performedById: string;
  performedByName?: string;
  performedByRole?: string;
  action: string;
  details?: string;
  createdAt: string;
}

export interface Lead {
  id: string;
  propertyId?: string;
  customerId: string;
  ownerId: string;
  assignedAgentId?: string;
  source: LeadSource;
  status: LeadStatus;
  priority: LeadPriority;
  customerMessage?: string;
  internalNotes?: string;
  preferredContactMethod?: string;
  budget?: number;
  requirementType?: string;
  businessType?: string;
  requiredCarpetArea?: number;
  bhk?: string;
  furnishingPreference?: string;
  parkingRequirement?: string;
  createdAt: string;
  updatedAt: string;
  lastContactedAt?: string;
  nextFollowUpAt?: string;
  
  // Enriched joins
  customer?: Customer;
  property?: {
    id: string;
    title: string;
    category: string;
    transactionType: string;
    propertyType: string;
    locality: string;
    address?: string;
    price: number;
    rent?: number;
    carpetArea?: number;
    bedrooms?: number;
    furnishing?: string;
    parking?: string;
    businessType?: string;
    primaryImage?: string;
  };
  ownerName?: string;
  ownerEmail?: string;
  ownerPhone?: string;
  assignedAgentName?: string;
  assignedAgentEmail?: string;
  assignedAgentPhone?: string;
  nextFollowUp?: LeadFollowUp | null;
  followUps?: LeadFollowUp[];
  activities?: LeadActivity[];
  siteVisits?: any[];
  assignments?: any[];
}
