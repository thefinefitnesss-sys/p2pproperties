export type UserRole = 'owner' | 'buyer' | 'agent' | 'tenant' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  capabilities?: string[];
  isVerified: boolean;
  avatarUrl?: string;
  createdAt: string;
}

export type PropertyCategory = 'residential' | 'commercial';

export type TransactionType = 'buy' | 'rent' | 'lease' | 'sell';

export type ResidentialType = 
  | '1 BHK'
  | '2 BHK'
  | '3 BHK'
  | '4+ BHK'
  | 'Apartment'
  | 'Villa'
  | 'Independent House'
  | 'Plot';

export type CommercialType =
  | 'Office'
  | 'Shop'
  | 'Showroom'
  | 'Warehouse'
  | 'Godown'
  | 'Restaurant/Cafe'
  | 'Clinic'
  | 'Commercial Building'
  | 'Industrial Unit'
  | 'Commercial Land'
  | 'Co-working Space';

export type PropertyType = ResidentialType | CommercialType;

export type FurnishingStatus = 'unfurnished' | 'semi-furnished' | 'fully-furnished';

export interface PropertyImage {
  id: string;
  url: string;
  caption?: string;
  isPrimary?: boolean;
}

export interface Amenity {
  id: string;
  name: string;
  category: 'safety' | 'leisure' | 'convenience' | 'infrastructure';
  icon?: string;
}

export interface Location {
  buildingName: string;
  area: string;
  locality: string;
  city: string;
  pincode: string;
  landmark?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export interface ResidentialDetails {
  bhk: string;
  bedrooms: number;
  bathrooms: number;
  balconies?: number;
  carpetArea: number; // in sq ft
  builtUpArea: number; // in sq ft
  floor: number;
  totalFloors: number;
  furnishing: FurnishingStatus;
  parking: {
    covered: number;
    open: number;
  };
  facing?: string;
  ageOfProperty?: string;
}

export interface CommercialDetails {
  commercialType: CommercialType;
  carpetArea: number; // in sq ft
  builtUpArea: number; // in sq ft
  floor: number;
  totalFloors: number;
  furnishing: FurnishingStatus;
  parking: {
    covered: number;
    open: number;
  };
  washrooms: number;
  powerBackup: boolean;
  loadingUnloadingAvailability: boolean;
  suitableBusinessType: string[];
}

export interface PropertyPricing {
  price: number; // INR
  priceDisplayType: 'total' | 'per_month' | 'per_year';
  maintenanceAmount?: number; // Monthly INR
  securityDeposit?: number; // INR
  isNegotiable: boolean;
}

export interface NearbyPlace {
  name: string;
  type: 'metro' | 'railway' | 'airport' | 'highway' | 'hospital' | 'school' | 'commercial_hub';
  distanceKm: number;
}

export interface BaseProperty {
  id: string;
  title: string;
  slug: string;
  category: PropertyCategory;
  transactionType: TransactionType;
  propertyType: PropertyType;
  location: Location;
  pricing: PropertyPricing;
  images: PropertyImage[];
  description: string;
  amenities: string[];
  nearbyPlaces: NearbyPlace[];
  isVerified: boolean;
  isFeatured?: boolean;
  ownerId: string;
  ownerType: 'owner' | 'authorized_representative';
  // Contact details are kept private to protect owners; exposed only via secure inquiry routing
  maskedContact: {
    nameInitials: string;
    verifiedPhoneEnding: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface ResidentialProperty extends BaseProperty {
  category: 'residential';
  residentialDetails: ResidentialDetails;
  commercialDetails?: never;
}

export interface CommercialProperty extends BaseProperty {
  category: 'commercial';
  commercialDetails: CommercialDetails;
  residentialDetails?: never;
}

export type Property = ResidentialProperty | CommercialProperty;

export interface PropertyInquiry {
  id: string;
  propertyId: string;
  propertyTitle: string;
  buyerName: string;
  buyerEmail: string;
  buyerPhone: string;
  message: string;
  preferredContactTime?: string;
  status: 'pending' | 'connected' | 'closed';
  createdAt: string;
}

export interface SiteVisit {
  id: string;
  propertyId: string;
  propertyTitle: string;
  visitorName: string;
  visitorPhone: string;
  visitorEmail: string;
  requestedDate: string;
  timeSlot: string;
  notes?: string;
  status: 'requested' | 'confirmed' | 'rescheduled' | 'cancelled';
  createdAt: string;
}

export interface CommissionDeal {
  id: string;
  propertyId: string;
  buyerId?: string;
  sellerId?: string;
  transactionType: TransactionType;
  dealAmount: number;
  estimatedCommissionPercent: number;
  estimatedCommissionAmount: number;
  status: 'draft' | 'under_review' | 'deal_closed' | 'commission_received';
  notes?: string;
  createdAt: string;
}

export interface PropertyFilterState {
  category?: PropertyCategory | 'all';
  transactionType?: TransactionType | 'all';
  location?: string;
  minPrice?: number;
  maxPrice?: number;
  bhk?: string;
  propertyType?: string;
  minCarpetArea?: number;
  maxCarpetArea?: number;
  furnishing?: string;
  hasParking?: boolean;
  verifiedOnly?: boolean;
  searchQuery?: string;
  sortBy?: 'newest' | 'price_asc' | 'price_desc' | 'area_asc' | 'area_desc';
}
