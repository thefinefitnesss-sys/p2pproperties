import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  Property, 
  PropertyFilterState, 
  PropertyInquiry, 
  SiteVisit, 
  User 
} from '../types/property';
import { api, setAuthToken, getAuthToken } from '../services/api';

interface PropertyContextType {
  properties: Property[];
  loadingProperties: boolean;
  savedPropertyIds: string[];
  currentUser: User | null;
  filters: PropertyFilterState;
  toastMessage: string | null;
  pagination: { page: number; limit: number; total: number; totalPages: number };
  authModalOpen: boolean;
  authModalMode: 'login' | 'signup';
  setFilters: React.Dispatch<React.SetStateAction<PropertyFilterState>>;
  updateFilter: <K extends keyof PropertyFilterState>(key: K, value: PropertyFilterState[K]) => void;
  resetFilters: () => void;
  toggleSaveProperty: (propertyId: string) => Promise<void>;
  isSaved: (propertyId: string) => boolean;
  refreshProperties: () => Promise<void>;
  getPropertyById: (id: string) => Promise<Property | undefined>;
  createInquiry: (propertyId: string, message: string, preferredTime?: string, extra?: Record<string, any>) => Promise<void>;
  requestSiteVisit: (propertyId: string, date: string, time: string, message?: string) => Promise<void>;
  loginUser: (email: string, pass: string) => Promise<void>;
  signupUser: (data: { name: string; email: string; phone: string; password: string; role?: string }) => Promise<void>;
  logoutUser: () => void;
  updateUserProfile: (data: { name?: string; phone?: string; role?: string }) => Promise<void>;
  openAuthModal: (mode?: 'login' | 'signup') => void;
  closeAuthModal: () => void;
  showToast: (msg: string) => void;
}

const DEFAULT_FILTERS: PropertyFilterState = {
  category: 'all',
  transactionType: 'all',
  location: '',
  minPrice: undefined,
  maxPrice: undefined,
  bhk: '',
  propertyType: '',
  minCarpetArea: undefined,
  maxCarpetArea: undefined,
  furnishing: '',
  hasParking: false,
  verifiedOnly: false,
  searchQuery: '',
  sortBy: 'newest'
};

const PropertyContext = createContext<PropertyContextType | undefined>(undefined);

export const PropertyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loadingProperties, setLoadingProperties] = useState(true);
  const [savedPropertyIds, setSavedPropertyIds] = useState<string[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [filters, setFilters] = useState<PropertyFilterState>(DEFAULT_FILTERS);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');
  const [pagination, setPagination] = useState({ page: 1, limit: 12, total: 0, totalPages: 1 });

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4000);
  }, []);

  // Fetch Current User on mount if token exists
  useEffect(() => {
    const token = getAuthToken();
    if (token) {
      api.auth.getMe()
        .then((res) => {
          if (res.user) {
            setCurrentUser(res.user);
          }
        })
        .catch(() => {
          setAuthToken(null);
          setCurrentUser(null);
        });
    }
  }, []);

  // Load Saved Properties for logged in user
  const refreshSavedProperties = useCallback(async () => {
    if (!getAuthToken()) {
      setSavedPropertyIds([]);
      return;
    }
    try {
      const res = await api.savedProperties.list();
      if (res.properties) {
        setSavedPropertyIds(res.properties.map((p) => p.id));
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      refreshSavedProperties();
    } else {
      setSavedPropertyIds([]);
    }
  }, [currentUser, refreshSavedProperties]);

  // Fetch Public Approved Properties with filters & pagination
  const refreshProperties = useCallback(async () => {
    setLoadingProperties(true);
    try {
      const res = await api.properties.list({
        category: filters.category !== 'all' ? filters.category : undefined,
        transactionType: filters.transactionType !== 'all' ? filters.transactionType : undefined,
        location: filters.location || undefined,
        minPrice: filters.minPrice,
        maxPrice: filters.maxPrice,
        bhk: filters.bhk || undefined,
        propertyType: filters.propertyType || undefined,
        minCarpetArea: filters.minCarpetArea,
        maxCarpetArea: filters.maxCarpetArea,
        furnishing: filters.furnishing || undefined,
        hasParking: filters.hasParking || undefined,
        verifiedOnly: filters.verifiedOnly || undefined,
        searchQuery: filters.searchQuery || undefined,
        sortBy: filters.sortBy || 'newest',
        page: pagination.page,
        limit: pagination.limit
      });

      setProperties(res.properties || []);
      if (res.pagination) {
        setPagination(res.pagination);
      }
    } catch (err: any) {
      console.error('Failed to fetch properties:', err);
    } finally {
      setLoadingProperties(false);
    }
  }, [filters, pagination.page, pagination.limit]);

  useEffect(() => {
    refreshProperties();
  }, [refreshProperties]);

  const updateFilter = <K extends keyof PropertyFilterState>(key: K, value: PropertyFilterState[K]) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value
    }));
  };

  const resetFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  const toggleSaveProperty = async (propertyId: string) => {
    if (!currentUser) {
      showToast('Please log in to save properties to your watchlist.');
      setAuthModalMode('login');
      setAuthModalOpen(true);
      return;
    }

    const isAlreadySaved = savedPropertyIds.includes(propertyId);
    try {
      if (isAlreadySaved) {
        await api.savedProperties.unsave(propertyId);
        setSavedPropertyIds((prev) => prev.filter((id) => id !== propertyId));
        showToast('Property removed from saved listings');
      } else {
        await api.savedProperties.save(propertyId);
        setSavedPropertyIds((prev) => [...prev, propertyId]);
        showToast('Property saved to your watchlist');
      }
    } catch (err: any) {
      showToast(err.message || 'Error updating saved status.');
    }
  };

  const isSaved = (propertyId: string) => savedPropertyIds.includes(propertyId);

  const getPropertyById = async (id: string): Promise<Property | undefined> => {
    try {
      const res = await api.properties.getById(id);
      return res.property;
    } catch {
      // Fallback to cache if loaded
      return properties.find((p) => p.id === id);
    }
  };

  const createInquiry = async (propertyId: string, message: string, preferredTime?: string, extra?: Record<string, any>) => {
    if (!currentUser) {
      showToast('Please sign in to contact the verified owner.');
      setAuthModalMode('login');
      setAuthModalOpen(true);
      throw new Error('Authentication required.');
    }
    const res = await api.inquiries.create(propertyId, {
      message,
      preferred_contact_time: preferredTime,
      ...(extra || {})
    });
    showToast(res.message || 'Inquiry sent directly to owner.');
  };

  const requestSiteVisit = async (propertyId: string, date: string, time: string, message?: string) => {
    if (!currentUser) {
      showToast('Please sign in to book a physical site visit.');
      setAuthModalMode('login');
      setAuthModalOpen(true);
      throw new Error('Authentication required.');
    }
    const res = await api.siteVisits.create(propertyId, {
      preferred_date: date,
      preferred_time: time,
      message
    });
    showToast(res.message || 'Site visit request scheduled.');
  };

  const loginUser = async (email: string, pass: string) => {
    const res = await api.auth.login({ email, password: pass });
    setAuthToken(res.token);
    setCurrentUser(res.user);
    setAuthModalOpen(false);
    showToast(`Welcome back, ${res.user.name}!`);
  };

  const signupUser = async (data: { name: string; email: string; phone: string; password: string; role?: string }) => {
    const res = await api.auth.signup(data);
    setAuthToken(res.token);
    setCurrentUser(res.user);
    setAuthModalOpen(false);
    showToast(`Account created successfully! Welcome, ${res.user.name}.`);
  };

  const logoutUser = () => {
    setAuthToken(null);
    setCurrentUser(null);
    setSavedPropertyIds([]);
    showToast('Signed out successfully.');
  };

  const updateUserProfile = async (data: { name?: string; phone?: string; role?: string }) => {
    const res = await api.auth.updateProfile(data);
    setCurrentUser(res.user);
    showToast('Profile updated successfully.');
  };

  const openAuthModal = (mode: 'login' | 'signup' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setAuthModalOpen(false);
  };

  return (
    <PropertyContext.Provider
      value={{
        properties,
        loadingProperties,
        savedPropertyIds,
        currentUser,
        filters,
        toastMessage,
        pagination,
        authModalOpen,
        authModalMode,
        setFilters,
        updateFilter,
        resetFilters,
        toggleSaveProperty,
        isSaved,
        refreshProperties,
        getPropertyById,
        createInquiry,
        requestSiteVisit,
        loginUser,
        signupUser,
        logoutUser,
        updateUserProfile,
        openAuthModal,
        closeAuthModal,
        showToast
      }}
    >
      {children}
    </PropertyContext.Provider>
  );
};

export const useProperty = (): PropertyContextType => {
  const context = useContext(PropertyContext);
  if (!context) {
    throw new Error('useProperty must be used within a PropertyProvider');
  }
  return context;
};

export const usePropertyContext = useProperty;
