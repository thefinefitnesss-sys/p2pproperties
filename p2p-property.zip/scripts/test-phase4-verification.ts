import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const BASE_URL = 'http://localhost:3000';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.resolve(__dirname, '..', 'data', 'p2p_property.sqlite');

interface TestResult {
  step: number;
  name: string;
  pass: boolean;
  details: string;
}

const results: TestResult[] = [];

function record(step: number, name: string, pass: boolean, details: string) {
  results.push({ step, name, pass, details });
  console.log(`[Step ${step}] ${name}: ${pass ? 'PASS' : 'FAIL'} - ${details}`);
}

async function request(path: string, options: any = {}) {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

async function runPhase4Tests() {
  console.log('================================================================');
  console.log('STARTING PHASE 4: LEAD & CUSTOMER MANAGEMENT SYSTEM VERIFICATION');
  console.log('================================================================\n');

  try {
    // 0. Login credentials for Admin, Sample Owner, and Sample Buyer
    const adminLogin = await request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'admin@p2pproperty.in', password: 'Admin@12345' })
    });
    const adminToken = adminLogin.data.token;
    if (!adminToken) throw new Error('Failed to get Admin token');

    const ownerLogin = await request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'sameer.merchant@mumbai.in', password: 'Owner@12345' })
    });
    const ownerToken = ownerLogin.data.token;
    const ownerId = ownerLogin.data.user.id;
    if (!ownerToken) throw new Error('Failed to get Owner token');

    const timestamp = Date.now();
    const buyerSignup = await request('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        name: `Ananya Deshmukh ${timestamp}`,
        email: `ananya.buyer.${timestamp}@mumbai.in`,
        phone: `+91 98201 ${String(timestamp).slice(-5)}`,
        password: 'Buyer@12345',
        role: 'buyer'
      })
    });
    const buyerToken = buyerSignup.data.token;
    const buyerId = buyerSignup.data.user.id;
    if (!buyerToken) throw new Error('Failed to get Buyer token');

    // Create a secondary owner and agent for unauthorized test and assignment test
    const otherOwnerSignup = await request('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        name: `Other Owner ${timestamp}`,
        email: `other.owner.${timestamp}@mumbai.in`,
        phone: `+91 91234 ${String(timestamp).slice(-5)}`,
        password: 'Password@123',
        role: 'owner'
      })
    });
    const otherOwnerToken = otherOwnerSignup.data.token;
    const otherOwnerId = otherOwnerSignup.data.user.id;

    const agentSignup = await request('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        name: `Assigned Agent ${timestamp}`,
        email: `agent.${timestamp}@mumbai.in`,
        phone: `+91 98765 ${String(timestamp).slice(-5)}`,
        password: 'Password@123',
        role: 'agent'
      })
    });
    const agentToken = agentSignup.data.token;
    const agentId = agentSignup.data.user.id;

    // Use Sample Residential Property owned by Sameer Merchant: prop-mum-01
    const testPropId = 'prop-mum-01';

    // -------------------------------------------------------------
    // Test 1: Buyer creates enquiry
    // -------------------------------------------------------------
    const enquiryMsg = `Verification inquiry from buyer ${timestamp} interested in Carter Road residence with 3 BHK.`;
    const inqRes = await request(`/api/properties/${testPropId}/inquiries`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${buyerToken}` },
      body: JSON.stringify({
        message: enquiryMsg,
        preferred_contact_time: 'Evening (4 PM - 8 PM)',
        preferred_contact_method: 'WHATSAPP',
        budget: 87500000,
        bhk: '3 BHK'
      })
    });
    record(
      1,
      'Buyer creates enquiry',
      inqRes.status === 201 && Boolean(inqRes.data.inquiryId),
      `Status ${inqRes.status}, inquiryId: ${inqRes.data.inquiryId}`
    );

    // -------------------------------------------------------------
    // Test 2: Lead is created
    // -------------------------------------------------------------
    const createdLeadId = inqRes.data.leadId;
    record(
      2,
      'Lead is created automatically',
      Boolean(createdLeadId) && inqRes.data.isDuplicate === false,
      `Lead ID generated: ${createdLeadId}`
    );

    // -------------------------------------------------------------
    // Test 3: Owner sees the lead
    // -------------------------------------------------------------
    const ownerLeadsRes = await request('/api/leads', {
      method: 'GET',
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    const ownerHasLead = ownerLeadsRes.data.leads?.some((l: any) => l.id === createdLeadId);
    record(
      3,
      'Owner sees the lead in lead inbox',
      ownerLeadsRes.status === 200 && ownerHasLead,
      `Owner found lead in inbox (${ownerLeadsRes.data.leads?.length} total leads for owner)`
    );

    // -------------------------------------------------------------
    // Test 4: Unauthorized owner cannot see unrelated leads
    // -------------------------------------------------------------
    const otherOwnerLeadsRes = await request('/api/leads', {
      method: 'GET',
      headers: { Authorization: `Bearer ${otherOwnerToken}` }
    });
    const otherOwnerHasLead = otherOwnerLeadsRes.data.leads?.some((l: any) => l.id === createdLeadId);
    const idorCheck = await request(`/api/leads/${createdLeadId}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${otherOwnerToken}` }
    });
    record(
      4,
      'Unauthorized owner cannot see unrelated leads (IDOR protected)',
      !otherOwnerHasLead && idorCheck.status === 403,
      `Unrelated lead list: ${!otherOwnerHasLead}, direct IDOR access returned status: ${idorCheck.status}`
    );

    // -------------------------------------------------------------
    // Test 5: Admin sees the lead
    // -------------------------------------------------------------
    const adminLeadRes = await request(`/api/leads/${createdLeadId}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    record(
      5,
      'Admin sees the lead',
      adminLeadRes.status === 200 && adminLeadRes.data.lead?.id === createdLeadId,
      `Admin retrieved lead successfully, customer: ${adminLeadRes.data.lead?.customer?.name}`
    );

    // -------------------------------------------------------------
    // Test 6: Admin can assign lead
    // -------------------------------------------------------------
    const assignRes = await request(`/api/admin/leads/${createdLeadId}/assign`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: JSON.stringify({
        assigned_to_id: agentId,
        notes: 'Handled by senior Bandra luxury specialist agent.'
      })
    });
    record(
      6,
      'Admin can assign lead',
      assignRes.status === 200 && Boolean(assignRes.data.assignedTo?.id === agentId),
      `Assigned to agent ${agentId}, status ${assignRes.status}`
    );

    // -------------------------------------------------------------
    // Test 7: Assigned agent sees lead
    // -------------------------------------------------------------
    const agentLeadsRes = await request('/api/leads', {
      method: 'GET',
      headers: { Authorization: `Bearer ${agentToken}` }
    });
    const agentHasLead = agentLeadsRes.data.leads?.some((l: any) => l.id === createdLeadId);
    const agentDetailRes = await request(`/api/leads/${createdLeadId}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${agentToken}` }
    });
    record(
      7,
      'Assigned agent sees lead',
      agentHasLead && agentDetailRes.status === 200,
      `Agent inbox contains lead: ${agentHasLead}, direct access: ${agentDetailRes.status}`
    );

    // -------------------------------------------------------------
    // Test 8: Lead status changes correctly
    // -------------------------------------------------------------
    const statusUpdateRes = await request(`/api/leads/${createdLeadId}/status`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${agentToken}` },
      body: JSON.stringify({ status: 'QUALIFIED' })
    });
    const updatedLeadCheck = await request(`/api/leads/${createdLeadId}`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    record(
      8,
      'Lead status changes correctly',
      statusUpdateRes.status === 200 && updatedLeadCheck.data.lead?.status === 'QUALIFIED',
      `Status changed to QUALIFIED, response status ${statusUpdateRes.status}`
    );

    // -------------------------------------------------------------
    // Test 9: Notes are saved
    // -------------------------------------------------------------
    const testNote = `Buyer confirmed pre-approval letter for luxury purchase at ${new Date().toLocaleTimeString()}`;
    const noteRes = await request(`/api/leads/${createdLeadId}/notes`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${agentToken}` },
      body: JSON.stringify({ note: testNote })
    });
    record(
      9,
      'Notes are saved',
      noteRes.status === 200,
      `Note saved with status ${noteRes.status}`
    );

    // -------------------------------------------------------------
    // Test 10: Activity timeline records changes
    // -------------------------------------------------------------
    const timelineRes = await request(`/api/leads/${createdLeadId}/timeline`, {
      headers: { Authorization: `Bearer ${agentToken}` }
    });
    const activities = timelineRes.data.activities || [];
    const hasNoteAct = activities.some((a: any) => a.action === 'NOTE_ADDED' && a.details?.includes(testNote));
    const hasStatusAct = activities.some((a: any) => a.action === 'STATUS_CHANGED');
    const hasAssignAct = activities.some((a: any) => a.action === 'LEAD_ASSIGNED');
    record(
      10,
      'Activity timeline records changes',
      timelineRes.status === 200 && hasNoteAct && hasStatusAct && hasAssignAct,
      `Timeline entries: ${activities.length}, contains Note: ${hasNoteAct}, Status: ${hasStatusAct}, Assign: ${hasAssignAct}`
    );

    // -------------------------------------------------------------
    // Test 11: Follow-up can be scheduled
    // -------------------------------------------------------------
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    const followUpRes = await request(`/api/leads/${createdLeadId}/follow-ups`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${agentToken}` },
      body: JSON.stringify({
        follow_up_date: tomorrow,
        follow_up_time: '11:00 AM',
        note: 'Call client to coordinate physical walk-through with architect.'
      })
    });
    record(
      11,
      'Follow-up can be scheduled',
      followUpRes.status === 201 && Boolean(followUpRes.data.followUpId),
      `Follow-up ID: ${followUpRes.data.followUpId}`
    );

    // -------------------------------------------------------------
    // Test 12: Site visit connects to the lead
    // -------------------------------------------------------------
    const visitRes = await request(`/api/properties/${testPropId}/site-visits`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${buyerToken}` },
      body: JSON.stringify({
        preferred_date: tomorrow,
        preferred_time: '04:00 PM - 05:00 PM',
        message: 'Looking forward to meeting owner on-site.'
      })
    });
    record(
      12,
      'Site visit connects to the lead',
      visitRes.status === 201 && visitRes.data.leadId === createdLeadId,
      `Visit ID: ${visitRes.data.visitId}, linked to leadId: ${visitRes.data.leadId}`
    );

    // -------------------------------------------------------------
    // Test 13: Site visit activity appears in timeline
    // -------------------------------------------------------------
    const timelineRes2 = await request(`/api/leads/${createdLeadId}/timeline`, {
      headers: { Authorization: `Bearer ${agentToken}` }
    });
    const hasVisitAct = timelineRes2.data.activities?.some((a: any) => a.action === 'SITE_VISIT_REQUESTED');
    record(
      13,
      'Site visit activity appears in timeline',
      Boolean(hasVisitAct),
      `Timeline contains SITE_VISIT_REQUESTED: ${hasVisitAct}`
    );

    // -------------------------------------------------------------
    // Test 14: Duplicate enquiry handling works
    // -------------------------------------------------------------
    const duplicateRes = await request(`/api/properties/${testPropId}/inquiries`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${buyerToken}` },
      body: JSON.stringify({
        message: 'Repeat enquiry: Checking if Saturday is open for inspection.'
      })
    });
    record(
      14,
      'Duplicate enquiry handling works',
      duplicateRes.status === 201 && duplicateRes.data.isDuplicate === true && duplicateRes.data.leadId === createdLeadId,
      `Recognized duplicate: ${duplicateRes.data.isDuplicate}, kept leadId: ${duplicateRes.data.leadId}`
    );

    // -------------------------------------------------------------
    // Test 15: Residential lead fields work
    // -------------------------------------------------------------
    const resLeadCheck = await request(`/api/leads/${createdLeadId}`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const l1 = resLeadCheck.data.lead;
    const resFieldsOk = l1?.bhk === '3 BHK' && l1?.requirementType === 'residential' && Number(l1?.budget) > 0;
    record(
      15,
      'Residential lead fields work',
      Boolean(resFieldsOk),
      `BHK: ${l1?.bhk}, requirementType: ${l1?.requirementType}, budget: ${l1?.budget}`
    );

    // -------------------------------------------------------------
    // Test 16: Commercial lead fields work
    // -------------------------------------------------------------
    const commLeadCreate = await request('/api/leads', {
      method: 'POST',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        name: `Commercial Prospect ${timestamp}`,
        mobile: `+91 99887 ${String(timestamp).slice(-5)}`,
        email: `corp.${timestamp}@fintech.in`,
        requirement_type: 'commercial',
        business_type: 'Fintech Corporate HQ',
        required_carpet_area: 4500,
        budget: 650000,
        source: 'WEBSITE',
        priority: 'HIGH',
        customer_type: 'TENANT'
      })
    });
    const commLeadId = commLeadCreate.data.leadId;
    const commLeadCheck = await request(`/api/leads/${commLeadId}`, {
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    const l2 = commLeadCheck.data.lead;
    const commFieldsOk = l2?.requirementType === 'commercial' && l2?.businessType === 'Fintech Corporate HQ' && l2?.requiredCarpetArea === 4500;
    record(
      16,
      'Commercial lead fields work',
      commLeadCreate.status === 201 && commFieldsOk,
      `Business type: ${l2?.businessType}, carpet area: ${l2?.requiredCarpetArea}, reqType: ${l2?.requirementType}`
    );

    // -------------------------------------------------------------
    // Test 17: Dashboard counts match database
    // -------------------------------------------------------------
    const ownerInboxRes = await request('/api/leads', {
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    const reportedTotal = ownerInboxRes.data.stats?.totalLeads;
    const listCount = ownerInboxRes.data.leads?.length;
    // Check against direct sqlite file count for owner
    const SQL = await initSqlJs();
    const dbBuffer = fs.readFileSync(DB_FILE);
    const db = new SQL.Database(dbBuffer);
    const dbRes = db.exec(`SELECT COUNT(*) FROM leads WHERE owner_id = '${ownerId}' OR assigned_agent_id = '${ownerId}';`);
    const dbCount = Number(dbRes[0]?.values[0]?.[0] || 0);

    record(
      17,
      'Dashboard counts match database',
      reportedTotal === dbCount && listCount === dbCount,
      `Stats total: ${reportedTotal}, items: ${listCount}, direct sqlite count: ${dbCount}`
    );

    // -------------------------------------------------------------
    // Test 18: Unauthorized API requests are rejected
    // -------------------------------------------------------------
    const noAuthRes = await request('/api/leads', { method: 'GET' });
    const buyerForbiddenRes = await request('/api/leads', {
      method: 'GET',
      headers: { Authorization: `Bearer ${buyerToken}` }
    });
    const buyerAdminForbiddenRes = await request('/api/admin/leads', {
      method: 'GET',
      headers: { Authorization: `Bearer ${buyerToken}` }
    });
    record(
      18,
      'Unauthorized API requests are rejected',
      noAuthRes.status === 401 && buyerForbiddenRes.status === 403 && buyerAdminForbiddenRes.status === 403,
      `No-auth: ${noAuthRes.status} (401), Buyer leads: ${buyerForbiddenRes.status} (403), Buyer admin: ${buyerAdminForbiddenRes.status} (403)`
    );

  } catch (err: any) {
    console.error('Test execution error:', err);
  }

  console.log('\n================================================================');
  console.log('PHASE 4 VERIFICATION SUMMARY:');
  console.log('================================================================');
  const allPass = results.length === 18 && results.every((r) => r.pass);
  results.forEach((r) => {
    console.log(`[${r.pass ? 'PASS' : 'FAIL'}] Test ${r.step}: ${r.name}`);
  });
  console.log(`\nTOTAL: ${results.filter((r) => r.pass).length} / ${results.length} PASSED. ALL PASS: ${allPass}`);
  process.exit(allPass ? 0 : 1);
}

runPhase4Tests();
