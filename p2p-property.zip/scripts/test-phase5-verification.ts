import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const BASE_URL = 'http://localhost:3000';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.resolve(__dirname, '..', 'data', 'p2p_property.sqlite');

interface TestResult {
  step: number;
  name: string;
  pass: boolean;
  details: string;
}

const results: TestResult[] = [];

function record(step: number, name: string, pass: boolean, details: string) {
  results.push({ step, name, pass, details });
  console.log(`[Step ${step}] ${name}: ${pass ? 'PASS' : 'FAIL'} - ${details}`);
}

async function request(path: string, options: any = {}) {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

async function runPhase5Tests() {
  console.log('================================================================');
  console.log('STARTING PHASE 5: DEAL, BROKERAGE & COMMISSION SYSTEM VERIFICATION');
  console.log('================================================================\n');

  try {
    // 0. Login credentials for Admin, Sample Owner, and Sample Buyer
    const adminLogin = await request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'admin@p2pproperty.in', password: 'Admin@12345' })
    });
    const adminToken = adminLogin.data.token;
    if (!adminToken) throw new Error('Failed to get Admin token');

    const ownerLogin = await request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'sameer.merchant@mumbai.in', password: 'Owner@12345' })
    });
    const ownerToken = ownerLogin.data.token;
    const ownerId = ownerLogin.data.user.id;
    if (!ownerToken) throw new Error('Failed to get Owner token');

    const buyerLogin = await request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'ananya.deshmukh@mumbai.in', password: 'Buyer@12345' })
    });
    const buyerToken = buyerLogin.data.token;
    const buyerId = buyerLogin.data.user.id;
    if (!buyerToken) throw new Error('Failed to get Buyer token');

    // Create a secondary owner to test IDOR protections
    const timestamp = Date.now();
    const otherOwnerSignup = await request('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        name: `Other Owner ${timestamp}`,
        email: `other.owner.${timestamp}@mumbai.in`,
        password: 'Password@12345',
        phone: '+91 98999 88888',
        role: 'owner'
      })
    });
    const otherOwnerToken = otherOwnerSignup.data.token;

    // Fetch existing leads for owner to find a suitable lead for conversion
    const ownerLeadsRes = await request('/api/leads', {
      method: 'GET',
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    const leads = ownerLeadsRes.data.leads || [];
    if (leads.length === 0) throw new Error('No leads found for owner');

    // Select lead-101 (Carter Road 3 BHK) or first available lead
    const targetLead = leads.find((l: any) => l.id === 'lead-101') || leads[0];
    const targetLeadId = targetLead.id;

    // If an active deal exists for this lead from a prior test run, cancel it so tests are 100% repeatable
    const existingDealCheck = await request(`/api/leads/${targetLeadId}/deal`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    if (existingDealCheck.data?.deal && existingDealCheck.data.deal.deal_status !== 'CANCELLED') {
      await request(`/api/deals/${existingDealCheck.data.deal.id}`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({ deal_status: 'CANCELLED' })
      });
    }

    // -------------------------------------------------------------
    // Test 1: Buyer is rejected when attempting to convert lead (403)
    // -------------------------------------------------------------
    const unauthorizedConvert = await request(`/api/leads/${targetLeadId}/convert-to-deal`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${buyerToken}` },
      body: JSON.stringify({
        agreed_property_value: 85000000,
        commission_rate: 1.0
      })
    });
    record(
      1,
      'Unauthorized buyer cannot convert lead into deal',
      unauthorizedConvert.status === 403,
      `Status: ${unauthorizedConvert.status} (Expected: 403)`
    );

    // -------------------------------------------------------------
    // Test 2: Authorized Owner converts qualified lead into Deal
    // -------------------------------------------------------------
    const agreedPrice = 85000000; // ₹8.5 Cr
    const commRate = 1.0; // 1%
    const expectedCommission = (agreedPrice * commRate) / 100; // ₹8,50,000

    const convertRes = await request(`/api/leads/${targetLeadId}/convert-to-deal`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        transaction_type: 'BUY',
        category: 'RESIDENTIAL',
        deal_status: 'NEGOTIATION',
        agreed_property_value: agreedPrice,
        commission_type: 'PERCENTAGE',
        commission_rate: commRate,
        commission_payer: 'BUYER',
        expected_closing_date: '2026-11-15',
        notes: 'Terms finalized during weekend walk-through. Token draft pending.'
      })
    });

    const createdDealId = convertRes.data.dealId;
    const createdDealNumber = convertRes.data.dealNumber;
    record(
      2,
      'Lead converted to deal with accurate commission calculation',
      convertRes.status === 201 && 
      Boolean(createdDealId) && 
      convertRes.data.commissionAmount === expectedCommission,
      `Status: ${convertRes.status}, Deal ID: ${createdDealId}, Number: ${createdDealNumber}, Commission: ₹${convertRes.data.commissionAmount}`
    );

    // -------------------------------------------------------------
    // Test 3: Duplicate active deal conversion prevention (409)
    // -------------------------------------------------------------
    const duplicateConvert = await request(`/api/leads/${targetLeadId}/convert-to-deal`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        agreed_property_value: agreedPrice,
        commission_rate: 1.0
      })
    });
    record(
      3,
      'Duplicate active deal prevention for same lead',
      duplicateConvert.status === 409 && Boolean(duplicateConvert.data.existingDealId),
      `Status: ${duplicateConvert.status} (Expected: 409), Existing Deal: ${duplicateConvert.data.existingDealNumber}`
    );

    // -------------------------------------------------------------
    // Test 4: Deal details retrieval & structure verification
    // -------------------------------------------------------------
    const getDealRes = await request(`/api/deals/${createdDealId}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    const dealData = getDealRes.data.deal;
    record(
      4,
      'Deal details retrieval with linked relations',
      getDealRes.status === 200 &&
      dealData?.dealNumber === createdDealNumber &&
      dealData?.commissionAmount === expectedCommission &&
      Boolean(dealData?.property?.title) &&
      Boolean(dealData?.customer?.name),
      `Property: "${dealData?.property?.title}", Customer: "${dealData?.customer?.name}", Status: ${dealData?.dealStatus}`
    );

    // -------------------------------------------------------------
    // Test 5: IDOR Protection on Deal access
    // -------------------------------------------------------------
    const idorDealRes = await request(`/api/deals/${createdDealId}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${otherOwnerToken}` }
    });
    record(
      5,
      'Unrelated owner blocked from accessing deal (IDOR protection)',
      idorDealRes.status === 403,
      `Status: ${idorDealRes.status} (Expected: 403 Forbidden)`
    );

    // -------------------------------------------------------------
    // Test 6: Deal Status progression
    // -------------------------------------------------------------
    const updateStageRes = await request(`/api/deals/${createdDealId}`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        deal_status: 'AGREEMENT_SIGNED'
      })
    });
    record(
      6,
      'Deal status progression to AGREEMENT_SIGNED',
      updateStageRes.status === 200 && updateStageRes.data.status === 'AGREEMENT_SIGNED',
      `Status: ${updateStageRes.status}, New Stage: ${updateStageRes.data.status}`
    );

    // -------------------------------------------------------------
    // Test 7: Invalid status is rejected (400)
    // -------------------------------------------------------------
    const invalidStatusRes = await request(`/api/deals/${createdDealId}`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        deal_status: 'NOT_A_VALID_STATUS'
      })
    });
    record(
      7,
      'Invalid deal status is rejected',
      invalidStatusRes.status === 400,
      `Status: ${invalidStatusRes.status} (Expected: 400)`
    );

    // -------------------------------------------------------------
    // Test 8: Flexible Brokerage update (Fixed amount & payer change)
    // -------------------------------------------------------------
    const fixedAmount = 900000; // ₹9,00,000 fixed
    const updateCommRes = await request(`/api/deals/${createdDealId}/commission`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        commission_type: 'FIXED_AMOUNT',
        commission_amount: fixedAmount,
        commission_payer: 'BOTH_PARTIES',
        commission_status: 'AGREED'
      })
    });
    record(
      8,
      'Commission updated to fixed amount with payer adjustment',
      updateCommRes.status === 200 && 
      updateCommRes.data.commissionAmount === fixedAmount &&
      updateCommRes.data.commissionPayer === 'BOTH_PARTIES',
      `Commission: ₹${updateCommRes.data.commissionAmount}, Payer: ${updateCommRes.data.commissionPayer}, Status: ${updateCommRes.data.commissionStatus}`
    );

    // -------------------------------------------------------------
    // Test 9: Tax Invoice Generation (with 18% GST calculation)
    // -------------------------------------------------------------
    const subtotal = fixedAmount;
    const expectedGst = subtotal * 0.18; // ₹1,62,000
    const expectedTotal = subtotal + expectedGst; // ₹10,62,000

    const invoiceRes = await request(`/api/deals/${createdDealId}/invoices`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        issue_date: '2026-10-09',
        due_date: '2026-10-24',
        subtotal: subtotal,
        gst_rate: 18,
        notes: 'Brokerage fee for Carter Road residential transaction.'
      })
    });
    const invData = invoiceRes.data.invoice;
    record(
      9,
      'Professional tax invoice generated with 18% GST calculation',
      invoiceRes.status === 201 &&
      Boolean(invData?.invoiceNumber) &&
      invData?.subtotal === subtotal &&
      invData?.gstAmount === expectedGst &&
      invData?.totalAmount === expectedTotal,
      `Invoice #: ${invData?.invoiceNumber}, Subtotal: ₹${invData?.subtotal}, GST: ₹${invData?.gstAmount}, Total: ₹${invData?.totalAmount}`
    );

    // -------------------------------------------------------------
    // Test 10: Deal Commission Status transitions to INVOICED
    // -------------------------------------------------------------
    const dealAfterInvoice = await request(`/api/deals/${createdDealId}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    record(
      10,
      'Deal commission status updated to INVOICED',
      dealAfterInvoice.data.deal?.commissionStatus === 'INVOICED',
      `Commission Status: ${dealAfterInvoice.data.deal?.commissionStatus}`
    );

    // -------------------------------------------------------------
    // Test 11: Record First Partial Payment (Commission status -> PARTIALLY_PAID)
    // -------------------------------------------------------------
    const partialPayment = 450000; // 50%
    const pay1Res = await request(`/api/deals/${createdDealId}/payments`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        amount: partialPayment,
        payment_method: 'NEFT_RTGS',
        transaction_reference: 'CMS88192014',
        payment_date: '2026-10-09',
        payer_name: 'Ananya Deshmukh',
        notes: 'First 50% installment of brokerage.'
      })
    });
    record(
      11,
      'Partial commission payment recorded and status set to PARTIALLY_PAID',
      pay1Res.status === 201 &&
      pay1Res.data.payment?.commissionStatus === 'PARTIALLY_PAID' &&
      pay1Res.data.payment?.totalPaid === partialPayment &&
      pay1Res.data.payment?.remainingAmount === (fixedAmount - partialPayment),
      `Receipt: ${pay1Res.data.payment?.receiptNumber}, Paid: ₹${pay1Res.data.payment?.totalPaid}, Remaining: ₹${pay1Res.data.payment?.remainingAmount}`
    );

    // -------------------------------------------------------------
    // Test 12: Record Final Payment (Commission status -> PAID)
    // -------------------------------------------------------------
    const finalPayment = 450000; // remaining 50%
    const pay2Res = await request(`/api/deals/${createdDealId}/payments`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        amount: finalPayment,
        payment_method: 'UPI',
        transaction_reference: 'UPI/981920/HDFC',
        payment_date: '2026-10-09',
        payer_name: 'Ananya Deshmukh',
        notes: 'Final settlement of brokerage.'
      })
    });
    record(
      12,
      'Final settlement recorded and commission status set to PAID',
      pay2Res.status === 201 &&
      pay2Res.data.payment?.commissionStatus === 'PAID' &&
      pay2Res.data.payment?.totalPaid === fixedAmount &&
      pay2Res.data.payment?.remainingAmount === 0,
      `Receipt: ${pay2Res.data.payment?.receiptNumber}, Total Paid: ₹${pay2Res.data.payment?.totalPaid}, Remaining: ₹${pay2Res.data.payment?.remainingAmount}`
    );

    // -------------------------------------------------------------
    // Test 13: Deal Activity history tracks timeline entries
    // -------------------------------------------------------------
    const dealWithTimeline = await request(`/api/deals/${createdDealId}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    const activities = dealWithTimeline.data.deal?.activities || [];
    const hasCreated = activities.some((a: any) => a.action === 'DEAL_CREATED');
    const hasStatus = activities.some((a: any) => a.action === 'STATUS_CHANGED');
    const hasCommission = activities.some((a: any) => a.action === 'COMMISSION_UPDATED');
    const hasInvoice = activities.some((a: any) => a.action === 'INVOICE_GENERATED');
    const hasPayment = activities.some((a: any) => a.action === 'PAYMENT_RECORDED');

    record(
      13,
      'Deal activity history logs all critical transactions',
      hasCreated && hasStatus && hasCommission && hasInvoice && hasPayment,
      `Total Activities: ${activities.length} (Created: ${hasCreated}, Status: ${hasStatus}, Comm: ${hasCommission}, Invoice: ${hasInvoice}, Payment: ${hasPayment})`
    );

    // -------------------------------------------------------------
    // Test 14: Lead Timeline reflects conversion to deal
    // -------------------------------------------------------------
    const leadTimelineRes = await request(`/api/leads/${targetLeadId}/timeline`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    const leadActs = leadTimelineRes.data.activities || [];
    const leadConvertedAct = leadActs.some((a: any) => a.action === 'CONVERTED_TO_DEAL');
    record(
      14,
      'Lead activity timeline updated with CONVERTED_TO_DEAL',
      leadConvertedAct,
      `Lead Timeline Entries: ${leadActs.length}, Converted event present: ${leadConvertedAct}`
    );

    // -------------------------------------------------------------
    // Test 15: Admin sees all deals across the platform
    // -------------------------------------------------------------
    const adminDealsRes = await request('/api/deals', {
      method: 'GET',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const adminFoundDeal = adminDealsRes.data.deals?.some((d: any) => d.id === createdDealId);
    record(
      15,
      'Admin has global visibility of deals and revenue stats',
      adminDealsRes.status === 200 && adminFoundDeal && Boolean(adminDealsRes.data.stats),
      `Total Deals in Platform: ${adminDealsRes.data.deals?.length}, Volume: ₹${adminDealsRes.data.stats?.totalVolume}, Commission Booked: ₹${adminDealsRes.data.stats?.totalCommissionBooked}`
    );

    // -------------------------------------------------------------
    // Test 16: Deal completion marks actual closing date
    // -------------------------------------------------------------
    const completeDealRes = await request(`/api/deals/${createdDealId}`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${ownerToken}` },
      body: JSON.stringify({
        deal_status: 'COMPLETED'
      })
    });
    const finalDealRes = await request(`/api/deals/${createdDealId}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    record(
      16,
      'Deal completion sets status to COMPLETED and sets actual closing date',
      completeDealRes.status === 200 &&
      finalDealRes.data.deal?.dealStatus === 'COMPLETED' &&
      Boolean(finalDealRes.data.deal?.actualClosingDate),
      `Final Status: ${finalDealRes.data.deal?.dealStatus}, Actual Closing Date: ${finalDealRes.data.deal?.actualClosingDate}`
    );

    // -------------------------------------------------------------
    // Test 17: Database persistence check via SQLite file
    // -------------------------------------------------------------
    const SQL = await initSqlJs();
    const dbBuffer = fs.readFileSync(DB_FILE);
    const directDb = new SQL.Database(dbBuffer);

    const dbDealCheck = directDb.exec(`SELECT deal_number, deal_status, commission_amount, commission_status FROM deals WHERE id = '${createdDealId}';`);
    const dbPaymentsCheck = directDb.exec(`SELECT COUNT(*), SUM(amount) FROM deal_payments WHERE deal_id = '${createdDealId}';`);
    const dbInvoicesCheck = directDb.exec(`SELECT COUNT(*) FROM deal_invoices WHERE deal_id = '${createdDealId}';`);

    const dealRow = dbDealCheck[0]?.values[0];
    const payRows = dbPaymentsCheck[0]?.values[0];
    const invCount = dbInvoicesCheck[0]?.values[0]?.[0];

    const dbMatches = 
      dealRow?.[0] === createdDealNumber &&
      dealRow?.[1] === 'COMPLETED' &&
      dealRow?.[3] === 'PAID' &&
      Number(payRows?.[0]) === 2 &&
      Number(payRows?.[1]) === fixedAmount &&
      Number(invCount) >= 1;

    record(
      17,
      'SQLite physical database persistence matches API state',
      Boolean(dbMatches),
      `DB Deal: ${dealRow?.[0]} [${dealRow?.[1]}], Payments Count: ${payRows?.[0]}, Sum: ₹${payRows?.[1]}, Invoices: ${invCount}`
    );

    // -------------------------------------------------------------
    // Test 18: Unauthenticated access rejected (401)
    // -------------------------------------------------------------
    const noAuthDeals = await request('/api/deals', { method: 'GET' });
    const noAuthDeal = await request(`/api/deals/${createdDealId}`, { method: 'GET' });
    record(
      18,
      'Unauthenticated requests are strictly rejected (401)',
      noAuthDeals.status === 401 && noAuthDeal.status === 401,
      `List: ${noAuthDeals.status}, Detail: ${noAuthDeal.status}`
    );

  } catch (err: any) {
    console.error('Fatal test execution failure:', err);
  }

  console.log('\n================================================================');
  console.log('PHASE 5 VERIFICATION SUMMARY:');
  console.log('================================================================');
  results.forEach(r => {
    console.log(`[${r.pass ? 'PASS' : 'FAIL'}] Test ${r.step}: ${r.name}`);
  });
  const passedCount = results.filter(r => r.pass).length;
  console.log(`\nTOTAL: ${passedCount} / ${results.length} PASSED. ALL PASS: ${passedCount === results.length}`);
  
  if (passedCount !== results.length) {
    process.exit(1);
  }
}

runPhase5Tests();
