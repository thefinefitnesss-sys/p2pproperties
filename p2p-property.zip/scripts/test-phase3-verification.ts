import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.resolve(__dirname, '..', 'data', 'p2p_property.sqlite');
const BASE_URL = 'http://localhost:3000';

interface TestResult {
  step: number;
  name: string;
  passed: boolean;
  details: string;
}

const results: TestResult[] = [];

function record(step: number, name: string, passed: boolean, details: string) {
  results.push({ step, name, passed, details });
  console.log(`[${passed ? 'PASS' : 'FAIL'}] Test ${step}: ${name} - ${details}`);
}

async function readDiskDb(): Promise<Database> {
  const SQL = await initSqlJs();
  const fileBuffer = fs.readFileSync(DB_FILE);
  return new SQL.Database(fileBuffer);
}

async function runTests() {
  console.log('==================================================');
  console.log('STARTING PHASE 3 ADMIN VERIFICATION TESTS');
  console.log('==================================================\n');

  // Obtain tokens for: Buyer, Owner, Admin
  let buyerToken = '';
  let ownerToken = '';
  let adminToken = '';

  const loginBuyer = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'ananya.deshmukh@mumbai.in', password: 'Buyer@12345' })
  });
  buyerToken = (await loginBuyer.json()).token;

  const loginOwner = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'sameer.merchant@mumbai.in', password: 'Owner@12345' })
  });
  ownerToken = (await loginOwner.json()).token;

  const loginAdmin = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'admin@p2pproperty.in', password: 'Admin@12345' })
  });
  adminToken = (await loginAdmin.json()).token;

  // 1. Normal buyer cannot access /admin
  try {
    const res = await fetch(`${BASE_URL}/api/admin/metrics`, {
      headers: { Authorization: `Bearer ${buyerToken}` }
    });
    if (res.status === 403) {
      record(1, 'Normal Buyer Cannot Access Admin API', true, `HTTP 403 Forbidden returned (${res.status})`);
    } else {
      record(1, 'Normal Buyer Cannot Access Admin API', false, `Expected 403, got ${res.status}`);
    }
  } catch (err: any) {
    record(1, 'Normal Buyer Cannot Access Admin API', false, err.message);
  }

  // 2. Owner cannot access /admin
  try {
    const res = await fetch(`${BASE_URL}/api/admin/metrics`, {
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    if (res.status === 403) {
      record(2, 'Owner Cannot Access Admin API', true, `HTTP 403 Forbidden returned (${res.status})`);
    } else {
      record(2, 'Owner Cannot Access Admin API', false, `Expected 403, got ${res.status}`);
    }
  } catch (err: any) {
    record(2, 'Owner Cannot Access Admin API', false, err.message);
  }

  // 3. Admin can access /admin
  try {
    const res = await fetch(`${BASE_URL}/api/admin/metrics`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const data = await res.json();
    if (res.status === 200 && data.metrics && data.metrics.totalProps !== undefined) {
      record(3, 'Admin Can Access Admin API', true, `HTTP 200 OK returned with real metrics (${data.metrics.totalProps} total props)`);
    } else {
      record(3, 'Admin Can Access Admin API', false, `Status ${res.status}`);
    }
  } catch (err: any) {
    record(3, 'Admin Can Access Admin API', false, err.message);
  }

  // Helper: Create a fresh test property by Owner
  const unique = Date.now();
  let testPropId = '';
  try {
    const createRes = await fetch(`${BASE_URL}/api/properties`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ownerToken}`
      },
      body: JSON.stringify({
        title: `Juhu Sea Face Luxury Suite - Phase 3 Test ${unique}`,
        description: 'Exquisite beach-facing luxury residence for verification testing.',
        category: 'residential',
        transaction_type: 'buy',
        property_type: '3 BHK',
        price: 75000000,
        carpet_area: 1450,
        locality: 'Juhu',
        city: 'Mumbai',
        pincode: '400049',
        status: 'PENDING_APPROVAL'
      })
    });
    const cData = await createRes.json();
    testPropId = cData.propertyId;
  } catch (err: any) {
    console.error('Failed to create test property:', err);
  }

  // 4. Admin can see pending properties
  try {
    const res = await fetch(`${BASE_URL}/api/admin/properties?status=PENDING`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const data = await res.json();
    const found = data.properties?.some((p: any) => p.id === testPropId);
    if (res.ok && found) {
      record(4, 'Admin Can See Pending Properties', true, `Property ${testPropId} found in PENDING list`);
    } else {
      record(4, 'Admin Can See Pending Properties', false, `found=${found}, total pending=${data.properties?.length}`);
    }
  } catch (err: any) {
    record(4, 'Admin Can See Pending Properties', false, err.message);
  }

  // 5. Admin can approve a property
  try {
    const res = await fetch(`${BASE_URL}/api/admin/properties/${testPropId}/review`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({ action: 'approve' })
    });
    const data = await res.json();
    if (res.ok && data.status === 'APPROVED') {
      record(5, 'Admin Can Approve a Property', true, `Review action 'approve' succeeded: status=${data.status}`);
    } else {
      record(5, 'Admin Can Approve a Property', false, `Status ${res.status}: ${JSON.stringify(data)}`);
    }
  } catch (err: any) {
    record(5, 'Admin Can Approve a Property', false, err.message);
  }

  // 6. Approved property appears publicly
  try {
    const res = await fetch(`${BASE_URL}/api/properties?limit=100`);
    const data = await res.json();
    const isPublic = data.properties?.some((p: any) => p.id === testPropId);
    const detailRes = await fetch(`${BASE_URL}/api/properties/${testPropId}`);
    if (isPublic && detailRes.ok) {
      record(6, 'Approved Property Appears Publicly', true, `Visible in public list and public detail returns HTTP 200`);
    } else {
      record(6, 'Approved Property Appears Publicly', false, `isPublic=${isPublic}, detailStatus=${detailRes.status}`);
    }
  } catch (err: any) {
    record(6, 'Approved Property Appears Publicly', false, err.message);
  }

  // Helper 2: Create a second property for rejection test
  let testProp2Id = '';
  try {
    const createRes = await fetch(`${BASE_URL}/api/properties`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ownerToken}`
      },
      body: JSON.stringify({
        title: `Andheri Industrial Unit - Phase 3 Test ${unique}`,
        description: 'Commercial unit with incomplete OC documents.',
        category: 'commercial',
        transaction_type: 'lease',
        property_type: 'Office',
        price: 250000,
        carpet_area: 1200,
        locality: 'Andheri East',
        city: 'Mumbai',
        pincode: '400069',
        status: 'PENDING_APPROVAL'
      })
    });
    const cData = await createRes.json();
    testProp2Id = cData.propertyId;
  } catch (err: any) {
    console.error('Failed to create second test property:', err);
  }

  // 7. Admin can reject a property (with reason)
  try {
    const res = await fetch(`${BASE_URL}/api/admin/properties/${testProp2Id}/review`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({
        action: 'reject',
        reason: 'Missing clear occupation certificate and sanctioned floor plan'
      })
    });
    const data = await res.json();
    if (res.ok && data.status === 'REJECTED') {
      record(7, 'Admin Can Reject a Property', true, `Property rejected with logged reason, status: ${data.status}`);
    } else {
      record(7, 'Admin Can Reject a Property', false, `Status ${res.status}: ${JSON.stringify(data)}`);
    }
  } catch (err: any) {
    record(7, 'Admin Can Reject a Property', false, err.message);
  }

  // 8. Rejected property does not appear publicly
  try {
    const listRes = await fetch(`${BASE_URL}/api/properties?limit=100`);
    const listData = await listRes.json();
    const inPublicList = listData.properties?.some((p: any) => p.id === testProp2Id);
    const detailRes = await fetch(`${BASE_URL}/api/properties/${testProp2Id}`);
    if (!inPublicList && detailRes.status === 403) {
      record(8, 'Rejected Property Does Not Appear Publicly', true, 'Omitted from public search list and detail blocked with HTTP 403');
    } else {
      record(8, 'Rejected Property Does Not Appear Publicly', false, `inPublicList=${inPublicList}, detailStatus=${detailRes.status}`);
    }
  } catch (err: any) {
    record(8, 'Rejected Property Does Not Appear Publicly', false, err.message);
  }

  // 9. Admin can request changes
  try {
    const res = await fetch(`${BASE_URL}/api/admin/properties/${testPropId}/review`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({
        action: 'request_changes',
        reason: 'Please upload higher-resolution balcony terrace photos'
      })
    });
    const data = await res.json();
    if (res.ok && data.status === 'DRAFT') {
      record(9, 'Admin Can Request Changes', true, `Status reverted to DRAFT with feedback, status: ${data.status}`);
    } else {
      record(9, 'Admin Can Request Changes', false, `Status ${res.status}: ${JSON.stringify(data)}`);
    }
  } catch (err: any) {
    record(9, 'Admin Can Request Changes', false, err.message);
  }

  // 10. Admin can verify owner
  try {
    const res = await fetch(`${BASE_URL}/api/admin/users/usr-owner-sameer/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({
        verification_status: 'VERIFIED'
      })
    });
    // Re-fetch owner user
    const checkRes = await fetch(`${BASE_URL}/api/admin/users/usr-owner-sameer`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const checkData = await checkRes.json();
    if (res.ok && checkData.user?.verification_status === 'VERIFIED') {
      record(10, 'Admin Can Verify Owner', true, `Owner verified successfully (verification_status: ${checkData.user.verification_status})`);
    } else {
      record(10, 'Admin Can Verify Owner', false, `res=${res.status}, status=${checkData.user?.verification_status}`);
    }
  } catch (err: any) {
    record(10, 'Admin Can Verify Owner', false, err.message);
  }

  // 11. Admin can suspend a user
  // Create a throwaway user to test suspension
  const suspendUserEmail = `susp_test_${unique}@mumbai.in`;
  let suspendUserId = '';
  let suspendUserToken = '';
  try {
    const sUp = await fetch(`${BASE_URL}/api/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Spammer Test',
        email: suspendUserEmail,
        phone: '+91 99999 00001',
        password: 'Password@123',
        role: 'buyer'
      })
    });
    const sData = await sUp.json();
    suspendUserId = sData.user.id;
    suspendUserToken = sData.token;

    // Admin suspends user
    const suspRes = await fetch(`${BASE_URL}/api/admin/users/${suspendUserId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({ account_status: 'SUSPENDED' })
    });
    if (suspRes.ok) {
      record(11, 'Admin Can Suspend a User', true, `User ${suspendUserId} marked as SUSPENDED`);
    } else {
      record(11, 'Admin Can Suspend a User', false, `Status ${suspRes.status}`);
    }
  } catch (err: any) {
    record(11, 'Admin Can Suspend a User', false, err.message);
  }

  // 12. Suspended user cannot perform protected actions
  try {
    // 12a. Suspended user makes protected API request
    const protectedRes = await fetch(`${BASE_URL}/api/dashboard/my-properties`, {
      headers: { Authorization: `Bearer ${suspendUserToken}` }
    });
    // 12b. Suspended user tries to log in
    const loginAttempt = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: suspendUserEmail, password: 'Password@123' })
    });

    if (protectedRes.status === 403 && loginAttempt.status === 403) {
      record(12, 'Suspended User Cannot Perform Protected Actions', true, `Protected request returned HTTP 403, and login returned HTTP 403`);
    } else {
      record(12, 'Suspended User Cannot Perform Protected Actions', false, `protected=${protectedRes.status}, login=${loginAttempt.status}`);
    }
  } catch (err: any) {
    record(12, 'Suspended User Cannot Perform Protected Actions', false, err.message);
  }

  // 13. Enquiry management works
  try {
    // Create enquiry
    const enqRes = await fetch(`${BASE_URL}/api/properties/prop-mum-01/inquiries`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${buyerToken}`
      },
      body: JSON.stringify({ message: 'Phase 3 admin moderation test enquiry' })
    });
    const enqData = await enqRes.json();
    const inqId = enqData.inquiryId;

    // Admin updates status to NEGOTIATING
    const updateRes = await fetch(`${BASE_URL}/api/admin/enquiries/${inqId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({ status: 'NEGOTIATING' })
    });

    // Admin lists enquiries
    const listRes = await fetch(`${BASE_URL}/api/admin/enquiries?status=NEGOTIATING`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const listData = await listRes.json();
    const foundInq = listData.enquiries?.some((e: any) => e.id === inqId);

    if (updateRes.ok && foundInq) {
      record(13, 'Enquiry Management Works', true, `Enquiry ${inqId} status updated to NEGOTIATING and confirmed in admin list`);
    } else {
      record(13, 'Enquiry Management Works', false, `update=${updateRes.status}, found=${foundInq}`);
    }
  } catch (err: any) {
    record(13, 'Enquiry Management Works', false, err.message);
  }

  // 14. Site visit management works
  try {
    // Create visit
    const vRes = await fetch(`${BASE_URL}/api/properties/prop-mum-01/site-visits`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${buyerToken}`
      },
      body: JSON.stringify({
        preferred_date: '2026-10-25',
        preferred_time: '2:00 PM - 4:00 PM',
        message: 'Admin visit schedule moderation test'
      })
    });
    const vData = await vRes.json();
    const vId = vData.visitId;

    // Admin updates status to CONFIRMED
    const updateRes = await fetch(`${BASE_URL}/api/admin/site-visits/${vId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({ status: 'CONFIRMED' })
    });

    // Admin lists site visits
    const listRes = await fetch(`${BASE_URL}/api/admin/site-visits?status=CONFIRMED`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const listData = await listRes.json();
    const foundVisit = listData.visits?.some((v: any) => v.id === vId);

    if (updateRes.ok && foundVisit) {
      record(14, 'Site Visit Management Works', true, `Site visit ${vId} confirmed and verified in admin list`);
    } else {
      record(14, 'Site Visit Management Works', false, `update=${updateRes.status}, found=${foundVisit}`);
    }
  } catch (err: any) {
    record(14, 'Site Visit Management Works', false, err.message);
  }

  // 15. Audit log records admin actions
  try {
    const res = await fetch(`${BASE_URL}/api/admin/audit-logs`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const data = await res.json();
    const hasLogs = Array.isArray(data.logs) && data.logs.length > 0;
    const actionsFound = data.logs.map((l: any) => l.action);
    const hasApproval = actionsFound.some((a: string) => a.includes('approved'));
    const hasSuspension = actionsFound.some((a: string) => a.includes('suspended'));

    if (hasLogs && hasApproval && hasSuspension) {
      record(15, 'Audit Log Records Admin Actions', true, `Audit logs present (${data.logs.length} entries); verified approval and suspension events recorded`);
    } else {
      record(15, 'Audit Log Records Admin Actions', false, `hasLogs=${hasLogs}, hasApproval=${hasApproval}, hasSuspension=${hasSuspension}`);
    }
  } catch (err: any) {
    record(15, 'Audit Log Records Admin Actions', false, err.message);
  }

  // 16. Dashboard counts match the database
  try {
    const diskDb = await readDiskDb();
    const dbTotalProps = Number(diskDb.exec("SELECT COUNT(*) FROM properties;")[0]?.values[0]?.[0] || 0);
    const dbApprovedProps = Number(diskDb.exec("SELECT COUNT(*) FROM properties WHERE status = 'APPROVED';")[0]?.values[0]?.[0] || 0);
    const dbPendingProps = Number(diskDb.exec("SELECT COUNT(*) FROM properties WHERE status = 'PENDING_APPROVAL';")[0]?.values[0]?.[0] || 0);
    const dbTotalUsers = Number(diskDb.exec("SELECT COUNT(*) FROM users;")[0]?.values[0]?.[0] || 0);

    const metricsRes = await fetch(`${BASE_URL}/api/admin/metrics`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const metricsData = await metricsRes.json();
    const m = metricsData.metrics;

    const matchTotalProps = m.totalProps === dbTotalProps;
    const matchApprovedProps = m.approvedProps === dbApprovedProps;
    const matchPendingProps = m.pendingProps === dbPendingProps;
    const matchTotalUsers = m.totalUsers === dbTotalUsers;

    if (matchTotalProps && matchApprovedProps && matchPendingProps && matchTotalUsers) {
      record(16, 'Dashboard Counts Match Real Database', true, `Exact DB match: TotalProps=${m.totalProps}, Approved=${m.approvedProps}, Pending=${m.pendingProps}, TotalUsers=${m.totalUsers}`);
    } else {
      record(16, 'Dashboard Counts Match Real Database', false, `Mismatch: DB(props=${dbTotalProps}, approved=${dbApprovedProps}, pending=${dbPendingProps}, users=${dbTotalUsers}) vs API(props=${m.totalProps}, approved=${m.approvedProps}, pending=${m.pendingProps}, users=${m.totalUsers})`);
    }
  } catch (err: any) {
    record(16, 'Dashboard Counts Match Real Database', false, err.message);
  }

  console.log('\n==================================================');
  console.log('SUMMARY REPORT');
  console.log('==================================================');
  const allPassed = results.every(r => r.passed);
  console.log(`Total checks: ${results.length}`);
  console.log(`Passed: ${results.filter(r => r.passed).length}`);
  console.log(`Failed: ${results.filter(r => !r.passed).length}`);
  console.log(`Overall Result: ${allPassed ? 'ALL PASS' : 'SOME FAILED'}`);
}

runTests().catch(console.error);
