import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import { getJwtSecret } from '../server/auth.js';
import jwt from 'jsonwebtoken';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.resolve(__dirname, '..', 'data', 'p2p_property.sqlite');
const BASE_URL = 'http://localhost:3000';

interface TestResult {
  step: number;
  name: string;
  passed: boolean;
  details: string;
}

const results: TestResult[] = [];

function record(step: number, name: string, passed: boolean, details: string) {
  results.push({ step, name, passed, details });
  console.log(`[${passed ? 'PASS' : 'FAIL'}] Step ${step}: ${name} - ${details}`);
}

async function readDiskDb(): Promise<Database> {
  const SQL = await initSqlJs();
  const fileBuffer = fs.readFileSync(DB_FILE);
  return new SQL.Database(fileBuffer);
}

async function run() {
  console.log('==================================================');
  console.log('STARTING COMPLETE PHASE 2 BACKEND VERIFICATION');
  console.log('==================================================\n');

  // 1. Start the backend/server
  try {
    const res = await fetch(`${BASE_URL}/api/properties`);
    if (res.ok) {
      record(1, 'Server Running & Responding', true, `HTTP ${res.status} on ${BASE_URL}/api/properties`);
    } else {
      record(1, 'Server Running & Responding', false, `HTTP ${res.status}`);
    }
  } catch (err: any) {
    record(1, 'Server Running & Responding', false, `Fetch failed: ${err.message}`);
  }

  // 2. Verify JWT_SECRET environment variable is being read correctly
  try {
    const secret = getJwtSecret();
    const token = jwt.sign({ test: 'sample', id: 'usr-test' }, secret, { expiresIn: '1h' });
    const verified = jwt.verify(token, secret) as any;
    if (secret && verified.id === 'usr-test') {
      record(2, 'JWT_SECRET Environment Variable', true, `Secret present (length: ${secret.length}), tokens sign & verify correctly`);
    } else {
      record(2, 'JWT_SECRET Environment Variable', false, 'Secret invalid or verification failed');
    }
  } catch (err: any) {
    record(2, 'JWT_SECRET Environment Variable', false, `Error: ${err.message}`);
  }

  // 3. Verify database can be opened and read/written
  try {
    const db = await readDiskDb();
    const testTableRes = db.exec("SELECT count(*) as count FROM users;");
    const count = Number(testTableRes[0]?.values[0]?.[0] || 0);
    
    // Check tables exist
    const tablesRes = db.exec("SELECT name FROM sqlite_master WHERE type='table';");
    const tableNames = tablesRes[0]?.values.map(v => v[0]) || [];
    const expectedTables = ['users', 'properties', 'property_images', 'property_amenities', 'property_inquiries', 'site_visits', 'saved_properties'];
    const allTablesPresent = expectedTables.every(t => tableNames.includes(t));

    if (count > 0 && allTablesPresent) {
      record(3, 'Database Opened & Schema Verified', true, `DB opened successfully, ${count} users registered, all tables verified: [${expectedTables.join(', ')}]`);
    } else {
      record(3, 'Database Opened & Schema Verified', false, `count=${count}, tables=${tableNames.join(', ')}`);
    }
  } catch (err: any) {
    record(3, 'Database Opened & Schema Verified', false, `DB error: ${err.message}`);
  }

  // 4. Test pre-seeded Admin account
  let adminToken = '';
  try {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@p2pproperty.in', password: 'Admin@12345' })
    });
    const data = await res.json();
    if (res.ok && data.token && data.user.role === 'admin') {
      adminToken = data.token;
      record(4, 'Pre-seeded Admin Account', true, `Admin authenticated: ${data.user.name} (${data.user.email}), role: ${data.user.role}`);
    } else {
      record(4, 'Pre-seeded Admin Account', false, `Status ${res.status}: ${JSON.stringify(data)}`);
    }
  } catch (err: any) {
    record(4, 'Pre-seeded Admin Account', false, `Error: ${err.message}`);
  }

  // 5. Test pre-seeded Owner account
  let ownerToken = '';
  let ownerUser: any = null;
  try {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'sameer.merchant@mumbai.in', password: 'Owner@12345' })
    });
    const data = await res.json();
    if (res.ok && data.token && data.user.role === 'owner') {
      ownerToken = data.token;
      ownerUser = data.user;
      record(5, 'Pre-seeded Owner Account', true, `Owner authenticated: ${data.user.name} (${data.user.email}), role: ${data.user.role}`);
    } else {
      record(5, 'Pre-seeded Owner Account', false, `Status ${res.status}: ${JSON.stringify(data)}`);
    }
  } catch (err: any) {
    record(5, 'Pre-seeded Owner Account', false, `Error: ${err.message}`);
  }

  // 6. Test pre-seeded Buyer account
  let buyerToken = '';
  let buyerUser: any = null;
  try {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'ananya.deshmukh@mumbai.in', password: 'Buyer@12345' })
    });
    const data = await res.json();
    if (res.ok && data.token && data.user.role === 'buyer') {
      buyerToken = data.token;
      buyerUser = data.user;
      record(6, 'Pre-seeded Buyer Account', true, `Buyer authenticated: ${data.user.name} (${data.user.email}), role: ${data.user.role}`);
    } else {
      record(6, 'Pre-seeded Buyer Account', false, `Status ${res.status}: ${JSON.stringify(data)}`);
    }
  } catch (err: any) {
    record(6, 'Pre-seeded Buyer Account', false, `Error: ${err.message}`);
  }

  // 7. Test login and logout
  try {
    // 7a. Test invalid credentials
    const badRes = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@p2pproperty.in', password: 'WrongPassword999' })
    });
    const badCredentialsRejected = badRes.status === 401;

    // 7b. Test /api/auth/me session with valid token
    const meRes = await fetch(`${BASE_URL}/api/auth/me`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const meData = await meRes.json();
    const sessionValid = meRes.ok && meData.user && meData.user.id === 'usr-admin-1';

    // 7c. Test request without token (simulating client logout where token is cleared)
    const unauthRes = await fetch(`${BASE_URL}/api/auth/me`);
    const unauthRejected = unauthRes.status === 401;

    if (badCredentialsRejected && sessionValid && unauthRejected) {
      record(7, 'Login and Logout Flows', true, 'Session validation, invalid credential rejection (401), and client-side token discard (401) all verified');
    } else {
      record(7, 'Login and Logout Flows', false, `bad: ${badRes.status}, me: ${meRes.status}, unauth: ${unauthRes.status}`);
    }
  } catch (err: any) {
    record(7, 'Login and Logout Flows', false, `Error: ${err.message}`);
  }

  // 8. Create a new test user
  const uniqueId = Date.now();
  const testUserEmail = `testuser_${uniqueId}@mumbai.in`;
  try {
    const signupRes = await fetch(`${BASE_URL}/api/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: `Rohan Mehra ${uniqueId}`,
        email: testUserEmail,
        phone: '+91 98200 11223',
        password: 'Password@123',
        role: 'buyer'
      })
    });
    const signupData = await signupRes.json();
    if (signupRes.status === 201 && signupData.token && signupData.user) {
      // Also verify we can log in with new credentials
      const loginRes = await fetch(`${BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: testUserEmail, password: 'Password@123' })
      });
      const loginData = await loginRes.json();
      if (loginRes.ok && loginData.user.email === testUserEmail) {
        record(8, 'Create New Test User', true, `User created (${testUserEmail}) and successfully authenticated`);
      } else {
        record(8, 'Create New Test User', false, 'Signup succeeded but login failed');
      }
    } else {
      record(8, 'Create New Test User', false, `Signup failed with status ${signupRes.status}: ${JSON.stringify(signupData)}`);
    }
  } catch (err: any) {
    record(8, 'Create New Test User', false, `Error: ${err.message}`);
  }

  // 9. Create a test property while logged in as the Owner
  let createdPropertyId = '';
  const testPropTitle = `Khar West Luxury Garden Penthouse - Test ${uniqueId}`;
  try {
    const propRes = await fetch(`${BASE_URL}/api/properties`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ownerToken}`
      },
      body: JSON.stringify({
        title: testPropTitle,
        description: 'Exquisite duplex penthouse with private landscaped terrace, Italian marble flooring, and 2 dedicated stilt parking spots.',
        category: 'residential',
        transaction_type: 'buy',
        property_type: '3 BHK',
        price: 89000000,
        carpet_area: 1720,
        built_up_area: 2200,
        bedrooms: 3,
        bathrooms: 3,
        floor: 9,
        total_floors: 12,
        furnishing: 'fully-furnished',
        parking: '2 Covered',
        address: '14th Road, Khar West',
        locality: 'Khar West',
        city: 'Mumbai',
        pincode: '400052',
        latitude: 19.071,
        longitude: 72.836,
        status: 'PENDING_APPROVAL',
        amenities: ['Private Terrace', '2 Dedicated Parkings', 'Full DG Backup', 'Biometric Security']
      })
    });
    const propData = await propRes.json();
    if (propRes.status === 201 && propData.propertyId) {
      createdPropertyId = propData.propertyId;
      record(9, 'Create Property as Owner', true, `Property created with ID: ${createdPropertyId}, status: ${propData.status}`);
    } else {
      record(9, 'Create Property as Owner', false, `Status ${propRes.status}: ${JSON.stringify(propData)}`);
    }
  } catch (err: any) {
    record(9, 'Create Property as Owner', false, `Error: ${err.message}`);
  }

  // 10. Confirm the property is saved to the database
  try {
    const diskDb = await readDiskDb();
    const query = diskDb.exec(`SELECT id, title, owner_id, status FROM properties WHERE id = '${createdPropertyId}';`);
    if (query.length > 0 && query[0].values.length > 0) {
      const row = query[0].values[0];
      record(10, 'Confirm Saved to Database', true, `Property confirmed in SQLite DB on disk: id=${row[0]}, owner_id=${row[2]}`);
    } else {
      record(10, 'Confirm Saved to Database', false, `Property ${createdPropertyId} not found in DB`);
    }
  } catch (err: any) {
    record(10, 'Confirm Saved to Database', false, `Error: ${err.message}`);
  }

  // 11. Confirm its initial status is PENDING_APPROVAL
  try {
    const diskDb = await readDiskDb();
    const query = diskDb.exec(`SELECT status FROM properties WHERE id = '${createdPropertyId}';`);
    const statusVal = query[0]?.values[0]?.[0];
    if (statusVal === 'PENDING_APPROVAL') {
      record(11, 'Initial Status is PENDING_APPROVAL', true, `Status confirmed as PENDING_APPROVAL in SQLite DB`);
    } else {
      record(11, 'Initial Status is PENDING_APPROVAL', false, `Expected PENDING_APPROVAL, got: ${statusVal}`);
    }
  } catch (err: any) {
    record(11, 'Initial Status is PENDING_APPROVAL', false, `Error: ${err.message}`);
  }

  // 12. Confirm it does NOT appear publicly before approval
  try {
    // 12a. Check public listings list
    const publicListRes = await fetch(`${BASE_URL}/api/properties?limit=100`);
    const publicListData = await publicListRes.json();
    const inPublicList = publicListData.properties.some((p: any) => p.id === createdPropertyId);

    // 12b. Check direct unauthenticated access to the property detail
    const publicDetailRes = await fetch(`${BASE_URL}/api/properties/${createdPropertyId}`);
    const detailProtected = publicDetailRes.status === 403;

    if (!inPublicList && detailProtected) {
      record(12, 'Does NOT Appear Publicly Before Approval', true, 'Property omitted from public search list and rejected (HTTP 403) from public detail view');
    } else {
      record(12, 'Does NOT Appear Publicly Before Approval', false, `inPublicList=${inPublicList}, detailStatus=${publicDetailRes.status}`);
    }
  } catch (err: any) {
    record(12, 'Does NOT Appear Publicly Before Approval', false, `Error: ${err.message}`);
  }

  // 13. Log in as Admin
  try {
    const adminLoginRes = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@p2pproperty.in', password: 'Admin@12345' })
    });
    const data = await adminLoginRes.json();
    if (adminLoginRes.ok && data.user.role === 'admin') {
      adminToken = data.token;
      record(13, 'Log in as Admin', true, `Admin authenticated successfully, user=${data.user.email}`);
    } else {
      record(13, 'Log in as Admin', false, `Failed: ${JSON.stringify(data)}`);
    }
  } catch (err: any) {
    record(13, 'Log in as Admin', false, `Error: ${err.message}`);
  }

  // 14. Approve the test property
  try {
    const approveRes = await fetch(`${BASE_URL}/api/admin/properties/${createdPropertyId}/review`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({ action: 'approve' })
    });
    const approveData = await approveRes.json();
    if (approveRes.ok && approveData.status === 'APPROVED') {
      record(14, 'Approve Test Property by Admin', true, `Review action 'approve' succeeded: status=${approveData.status}`);
    } else {
      record(14, 'Approve Test Property by Admin', false, `Status ${approveRes.status}: ${JSON.stringify(approveData)}`);
    }
  } catch (err: any) {
    record(14, 'Approve Test Property by Admin', false, `Error: ${err.message}`);
  }

  // 15. Confirm the property then appears on the public /properties page
  try {
    const publicListRes = await fetch(`${BASE_URL}/api/properties?limit=100`);
    const publicListData = await publicListRes.json();
    const inPublicList = publicListData.properties.some((p: any) => p.id === createdPropertyId);

    const publicDetailRes = await fetch(`${BASE_URL}/api/properties/${createdPropertyId}`);
    const detailOk = publicDetailRes.status === 200;

    if (inPublicList && detailOk) {
      record(15, 'Appears on Public /properties and Details', true, 'Property is now visible in public search list and returns HTTP 200 on detail view');
    } else {
      record(15, 'Appears on Public /properties and Details', false, `inPublicList=${inPublicList}, detailStatus=${publicDetailRes.status}`);
    }
  } catch (err: any) {
    record(15, 'Appears on Public /properties and Details', false, `Error: ${err.message}`);
  }

  // 16. Test that the Owner can edit their own property
  try {
    const updatedTitle = `${testPropTitle} [Price Revised]`;
    const editRes = await fetch(`${BASE_URL}/api/properties/${createdPropertyId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ownerToken}`
      },
      body: JSON.stringify({
        title: updatedTitle,
        price: 86000000
      })
    });
    const editData = await editRes.json();
    if (editRes.ok) {
      // Verify in DB on disk
      const diskDb = await readDiskDb();
      const checkQ = diskDb.exec(`SELECT title, price FROM properties WHERE id = '${createdPropertyId}';`);
      const row = checkQ[0]?.values[0];
      if (row && row[0] === updatedTitle && Number(row[1]) === 86000000) {
        record(16, 'Owner Can Edit Their Own Property', true, `Title and price updated successfully to "${updatedTitle}" and ₹8.6 Cr`);
      } else {
        record(16, 'Owner Can Edit Their Own Property', false, `DB values did not match: ${JSON.stringify(row)}`);
      }
    } else {
      record(16, 'Owner Can Edit Their Own Property', false, `Status ${editRes.status}: ${JSON.stringify(editData)}`);
    }
  } catch (err: any) {
    record(16, 'Owner Can Edit Their Own Property', false, `Error: ${err.message}`);
  }

  // 17. Confirm another user cannot edit that property
  try {
    const unauthorizedEditRes = await fetch(`${BASE_URL}/api/properties/${createdPropertyId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${buyerToken}` // Buyer trying to edit owner's property
      },
      body: JSON.stringify({
        title: 'Unauthorized Edit Attempt',
        price: 1000
      })
    });
    const unauthData = await unauthorizedEditRes.json();
    if (unauthorizedEditRes.status === 403) {
      record(17, 'Non-Owner Forbidden From Editing', true, `HTTP 403 Forbidden correctly returned: "${unauthData.error}"`);
    } else {
      record(17, 'Non-Owner Forbidden From Editing', false, `Expected 403, got ${unauthorizedEditRes.status}`);
    }
  } catch (err: any) {
    record(17, 'Non-Owner Forbidden From Editing', false, `Error: ${err.message}`);
  }

  // 18. Test creating an enquiry as the Buyer
  let createdInquiryId = '';
  try {
    const inqRes = await fetch(`${BASE_URL}/api/properties/${createdPropertyId}/inquiries`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${buyerToken}`
      },
      body: JSON.stringify({
        message: 'Hello, I am interested in this Khar West penthouse. Can we discuss payment terms?',
        preferred_contact_time: 'Weekday evenings after 6 PM'
      })
    });
    const inqData = await inqRes.json();
    if (inqRes.status === 201 && inqData.inquiryId) {
      createdInquiryId = inqData.inquiryId;
      record(18, 'Create Enquiry as Buyer', true, `Enquiry created with ID: ${createdInquiryId}`);
    } else {
      record(18, 'Create Enquiry as Buyer', false, `Status ${inqRes.status}: ${JSON.stringify(inqData)}`);
    }
  } catch (err: any) {
    record(18, 'Create Enquiry as Buyer', false, `Error: ${err.message}`);
  }

  // 19. Confirm the Owner can see the enquiry
  try {
    const ownerInqRes = await fetch(`${BASE_URL}/api/dashboard/inquiries`, {
      headers: { Authorization: `Bearer ${ownerToken}` }
    });
    const ownerInqData = await ownerInqRes.json();
    if (ownerInqRes.ok && Array.isArray(ownerInqData.received)) {
      const foundInquiry = ownerInqData.received.find((i: any) => i.id === createdInquiryId);
      if (foundInquiry) {
        record(19, 'Owner Can See Enquiry in Dashboard', true, `Enquiry found: buyer "${foundInquiry.buyer_name}", property "${foundInquiry.property_title}"`);
      } else {
        record(19, 'Owner Can See Enquiry in Dashboard', false, `Enquiry ${createdInquiryId} not found in received list`);
      }
    } else {
      record(19, 'Owner Can See Enquiry in Dashboard', false, `Status ${ownerInqRes.status}`);
    }
  } catch (err: any) {
    record(19, 'Owner Can See Enquiry in Dashboard', false, `Error: ${err.message}`);
  }

  // 20. Test requesting a site visit
  let createdVisitId = '';
  try {
    const visitRes = await fetch(`${BASE_URL}/api/properties/${createdPropertyId}/site-visits`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${buyerToken}`
      },
      body: JSON.stringify({
        preferred_date: '2026-10-18',
        preferred_time: '11:00 AM - 1:00 PM',
        message: 'Requesting weekend morning site visit accompanied by family architect.'
      })
    });
    const visitData = await visitRes.json();
    if (visitRes.status === 201 && visitData.visitId) {
      createdVisitId = visitData.visitId;
      // Also confirm Owner sees it in their dashboard
      const ownerVisitsRes = await fetch(`${BASE_URL}/api/dashboard/site-visits`, {
        headers: { Authorization: `Bearer ${ownerToken}` }
      });
      const ownerVisitsData = await ownerVisitsRes.json();
      const foundVisit = ownerVisitsData.received?.find((v: any) => v.id === createdVisitId);
      if (foundVisit) {
        record(20, 'Request Site Visit & Owner Visibility', true, `Site visit ${createdVisitId} booked and visible in Owner dashboard`);
      } else {
        record(20, 'Request Site Visit & Owner Visibility', false, 'Visit booked but not visible in owner dashboard');
      }
    } else {
      record(20, 'Request Site Visit & Owner Visibility', false, `Status ${visitRes.status}: ${JSON.stringify(visitData)}`);
    }
  } catch (err: any) {
    record(20, 'Request Site Visit & Owner Visibility', false, `Error: ${err.message}`);
  }

  console.log('\n==================================================');
  console.log('SUMMARY REPORT');
  console.log('==================================================');
  const allPassed = results.every(r => r.passed);
  console.log(`Total checks: ${results.length}`);
  console.log(`Passed: ${results.filter(r => r.passed).length}`);
  console.log(`Failed: ${results.filter(r => !r.passed).length}`);
  console.log(`Overall Result: ${allPassed ? 'ALL PASS' : 'SOME FAILED'}`);
}

run().catch(console.error);
