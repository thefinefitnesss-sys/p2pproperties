import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.resolve(__dirname, '..', 'data', 'p2p_property.sqlite');

const BASE_URL = 'http://localhost:3000/api';

async function request(endpoint: string, options: any = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

async function runTests() {
  console.log('================================================================');
  console.log('STARTING QUERY MODE & OFF-MARKET PROPERTY MATCHING VERIFICATION');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, details?: string) {
    if (condition) {
      console.log(`[PASS] ${testName}${details ? ` - ${details}` : ''}`);
      passed++;
    } else {
      console.error(`[FAIL] ${testName}${details ? ` - ${details}` : ''}`);
      failed++;
    }
  }

  try {
    // 1. Authenticate Admin
    const adminLogin = await request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        email: 'admin@p2pproperty.in',
        password: 'Admin@12345'
      })
    });
    const adminToken = adminLogin.data.token;
    assert(adminLogin.status === 200 && !!adminToken, 'Test 1: Admin authenticated successfully');

    // Create a new Agent
    const agentEmail = `agent_${Date.now()}@mumbai.in`;
    const agentSignup = await request('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        name: 'Vikram Joshi (Broker)',
        email: agentEmail,
        phone: '+91 98200 44556',
        password: 'password123',
        role: 'agent'
      })
    });
    const agentToken = agentSignup.data.token;
    const agentId = agentSignup.data.user?.id;
    assert(agentSignup.status === 201 && !!agentToken, 'Test 2: Agent account created and authenticated', `Agent ID: ${agentId}`);

    // Create Customer 1 (Buyer/Tenant)
    const cust1Email = `cust1_${Date.now()}@mumbai.in`;
    const cust1Signup = await request('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        name: 'Aditya Birla Client',
        email: cust1Email,
        phone: '+91 98111 22334',
        password: 'password123',
        role: 'buyer'
      })
    });
    const cust1Token = cust1Signup.data.token;
    const cust1Id = cust1Signup.data.user?.id;
    assert(cust1Signup.status === 201 && !!cust1Token, 'Test 3: Customer 1 authenticated', `Customer User ID: ${cust1Id}`);

    // Create Customer 2 (Separate Customer for IDOR test)
    const cust2Email = `cust2_${Date.now()}@mumbai.in`;
    const cust2Signup = await request('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        name: 'Kavita Menon',
        email: cust2Email,
        phone: '+91 98222 33445',
        password: 'password123',
        role: 'buyer'
      })
    });
    const cust2Token = cust2Signup.data.token;
    assert(cust2Signup.status === 201 && !!cust2Token, 'Test 4: Customer 2 authenticated');

    // 2. Customer 1 submits a BUY residential requirement
    const queryPayload1 = {
      transaction_type: 'BUY',
      category: 'RESIDENTIAL',
      preferred_locations: 'Bandra West, Pali Hill, Carter Road',
      budget_min: 150000000,
      budget_max: 200000000,
      property_type: 'Apartment',
      bhk: '3 BHK',
      area_min: 1400,
      area_max: 2000,
      furnishing: 'fully-furnished',
      parking_required: '2 Covered',
      requirements_text: 'Looking for sea view or prime Pali Hill gated complex with 2 car parks.',
      priority: 'HIGH'
    };

    const q1Res = await request('/queries', {
      method: 'POST',
      headers: { Authorization: `Bearer ${cust1Token}` },
      body: JSON.stringify(queryPayload1)
    });

    assert(q1Res.status === 201, 'Test 5: Customer 1 successfully posts requirement');
    const { queryId, queryNumber, leadId, customerId } = q1Res.data;
    assert(queryNumber?.startsWith('P2P-Q-'), 'Test 6: Unique Query ID generated', `Query Number: ${queryNumber}`);
    assert(!!leadId, 'Test 7: Query connects to Lead CRM system', `Lead ID: ${leadId}`);

    // Customer submits a RENT commercial requirement
    const queryPayload2 = {
      transaction_type: 'LEASE',
      category: 'COMMERCIAL',
      preferred_locations: 'Bandra Kurla Complex (BKC)',
      budget_min: 500000,
      budget_max: 800000,
      property_type: 'Office',
      area_min: 3000,
      area_max: 5000,
      business_type: 'Fintech HQ',
      lease_duration: '5 Years',
      requirements_text: 'Grade-A corporate floor in BKC with central AC and power backup.'
    };
    const q2Res = await request('/queries', {
      method: 'POST',
      headers: { Authorization: `Bearer ${cust1Token}` },
      body: JSON.stringify(queryPayload2)
    });
    assert(q2Res.status === 201, 'Test 8: Commercial LEASE requirement posted successfully', `Query: ${q2Res.data.queryNumber}`);

    // 3. Customer 1 retrieves their queries
    const cust1List = await request('/queries', {
      headers: { Authorization: `Bearer ${cust1Token}` }
    });
    assert(cust1List.data.queries?.length >= 2, 'Test 9: Customer 1 sees their submitted queries', `Count: ${cust1List.data.queries?.length}`);

    // 4. Security / IDOR: Customer 2 CANNOT access Customer 1's query
    const cust2Access = await request(`/queries/${queryId}`, {
      headers: { Authorization: `Bearer ${cust2Token}` }
    });
    assert(cust2Access.status === 403, 'Test 10: IDOR Protection: Unrelated customer blocked from viewing query', `HTTP ${cust2Access.status}`);

    // 5. Admin can view and assign Query to Agent
    const adminGetQuery = await request(`/queries/${queryId}`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(adminGetQuery.status === 200, 'Test 11: Admin can access any query', `Customer: ${adminGetQuery.data.query?.customer?.name}`);

    // Admin assigns Query to Agent
    const assignRes = await request(`/queries/${queryId}/status`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: JSON.stringify({
        assigned_agent_id: agentId,
        status: 'IN_PROGRESS',
        priority: 'HIGH'
      })
    });
    assert(assignRes.status === 200, 'Test 12: Admin assigns query to Agent', 'Status updated to IN_PROGRESS');

    // 6. Assigned Agent can now view the query
    const agentGetQuery = await request(`/queries/${queryId}`, {
      headers: { Authorization: `Bearer ${agentToken}` }
    });
    assert(agentGetQuery.status === 200, 'Test 13: Assigned agent can access query', `Agent: ${agentGetQuery.data.query?.assignedAgentName}`);

    // Verify inventory matching engine found public matches
    assert(agentGetQuery.data.query?.listedMatches !== undefined, 'Test 14: Matching engine returns listed inventory matches separately');

    // 7. Assigned Agent adds an Off-Market Match
    const offMarketPayload = {
      location: 'Pali Hill, Bandra West',
      property_type: 'Apartment',
      transaction_type: 'BUY',
      asking_price: 185000000,
      area: 1680,
      bhk: '3 BHK',
      availability: 'IMMEDIATE',
      owner_or_representative_name: 'Dr. Cyrus Poonawalla Estate Rep',
      owner_or_representative_contact_reference: 'Phone: +91 98200 99881 (Direct Family Office)',
      match_notes: 'Fully furnished sea-facing apartment. Not listed publicly due to owner privacy preference.',
      status: 'AVAILABLE'
    };

    const addMatchRes = await request(`/queries/${queryId}/matches`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${agentToken}` },
      body: JSON.stringify(offMarketPayload)
    });
    assert(addMatchRes.status === 201, 'Test 15: Agent creates Off-Market Match', `Match ID: ${addMatchRes.data.matchId}`);
    const matchId = addMatchRes.data.matchId;

    // 8. Security: Off-market match does NOT appear in public property search
    const publicSearch = await request('/properties?search=Pali+Hill');
    const foundInPublic = (publicSearch.data.properties || []).some((p: any) => p.title?.includes('Poonawalla') || p.id === matchId);
    assert(!foundInPublic, 'Test 16: Public Listing Protection: Off-market match NEVER appears in public properties');

    // 9. Agent updates match status to CUSTOMER_INTERESTED
    const updateMatchRes = await request(`/queries/${queryId}/matches/${matchId}`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${agentToken}` },
      body: JSON.stringify({
        status: 'CUSTOMER_INTERESTED',
        match_notes: 'Client reviewed private brief and expressed keen interest in weekend inspection.'
      })
    });
    assert(updateMatchRes.status === 200, 'Test 17: Agent updates off-market match status');

    // 10. Customer views query - Private owner contact reference is REDACTED for customer
    const custView = await request(`/queries/${queryId}`, {
      headers: { Authorization: `Bearer ${cust1Token}` }
    });
    assert(custView.data.query?.offMarketMatches?.length >= 1, 'Test 18: Customer sees their curated off-market match');
    const custMatch = custView.data.query?.offMarketMatches[0];
    assert(custMatch.ownerOrRepresentativeContactReference === undefined, 'Test 19: Privacy Protection: Private owner contact information is masked from customer');
    assert(custMatch.matchNotes === undefined, 'Test 20: Privacy Protection: Internal broker notes masked from customer');
    assert(custMatch.label === 'OFF-MARKET — PRIVATE', 'Test 21: Off-market match clearly labeled as OFF-MARKET — PRIVATE');

    // 11. Schedule Site Visit for Off-Market Match
    const visitRes = await request(`/queries/${queryId}/matches/${matchId}/schedule-visit`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${agentToken}` },
      body: JSON.stringify({
        preferred_date: '2026-10-18',
        preferred_time: '11:00 AM',
        notes: 'Site visit for off-market candidate in Pali Hill with family.'
      })
    });
    assert(visitRes.status === 201, 'Test 22: Site visit connected to off-market match and query', `Visit ID: ${visitRes.data.visitId}`);

    // Verify lead status was updated to SITE_VISIT
    const leadCheck = await request(`/leads/${leadId}`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(leadCheck.data.lead?.status === 'SITE_VISIT', 'Test 23: Lead CRM pipeline updated to SITE_VISIT from off-market match');

    // 12. Convert Lead to Deal (Existing Deal & Brokerage Workflow Integration)
    const dealRes = await request(`/leads/${leadId}/convert-to-deal`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: JSON.stringify({
        agreed_property_value: 185000000,
        commission_type: 'PERCENTAGE',
        commission_rate: 1.0,
        commission_payer: 'BUYER',
        expected_closing_date: '2026-11-15',
        notes: 'Deal progressing from off-market match in Pali Hill.'
      })
    });
    assert(dealRes.status === 201, 'Test 24: Lead progressed to Deal with Commission calculation', `Deal ID: ${dealRes.data.deal?.deal_number}, Commission: ₹${dealRes.data.deal?.commission_amount}`);

    // 13. Convert Off-Market Match to Public Listing Workflow (Requires normal moderation)
    const convertListingRes = await request(`/queries/${queryId}/matches/${matchId}/convert-to-listing`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${agentToken}` }
    });
    assert(convertListingRes.status === 201, 'Test 25: Off-market match converted to DRAFT listing for normal moderation', `Property ID: ${convertListingRes.data.propertyId}, Status: ${convertListingRes.data.status}`);
    assert(convertListingRes.data.status === 'DRAFT', 'Test 26: Converted listing starts strictly in DRAFT status');

    // 14. Verify Database Persistence directly in SQLite disk file
    const SQL = await initSqlJs();
    const dbBuffer = fs.readFileSync(DB_FILE);
    const sqliteDb = new SQL.Database(dbBuffer);

    const qryDbRes = sqliteDb.exec(`SELECT * FROM property_requirements WHERE id = '${queryId}';`);
    assert(qryDbRes.length > 0 && qryDbRes[0].values.length > 0, 'Test 27: Query persists in SQLite physical database file');

    const matchDbRes = sqliteDb.exec(`SELECT * FROM off_market_matches WHERE id = '${matchId}';`);
    assert(matchDbRes.length > 0 && matchDbRes[0].values.length > 0, 'Test 28: Off-market match persists in SQLite physical database file');

    const auditDbRes = sqliteDb.exec(`SELECT COUNT(*) FROM audit_logs WHERE entity_type IN ('PROPERTY_REQUIREMENT', 'OFF_MARKET_MATCH');`);
    const auditCount = Number(auditDbRes[0]?.values[0]?.[0] || 0);
    assert(auditCount >= 2, 'Test 29: Audit Log records query creation, match creation, and updates', `Audit entries: ${auditCount}`);

    // 15. Verify Unrelated Agent CANNOT access private match
    const agent2Email = `agent2_${Date.now()}@mumbai.in`;
    const agent2Signup = await request('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({
        name: 'Unrelated Agent',
        email: agent2Email,
        phone: '+91 98333 44556',
        password: 'password123',
        role: 'agent'
      })
    });
    const agent2Token = agent2Signup.data.token;

    const agent2Attempt = await request(`/queries/${queryId}/matches`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${agent2Token}` },
      body: JSON.stringify({
        location: 'Malabar Hill',
        property_type: 'Apartment',
        transaction_type: 'BUY'
      })
    });
    assert(agent2Attempt.status === 403, 'Test 30: IDOR Protection: Unrelated agent blocked from adding match to non-assigned query', `HTTP ${agent2Attempt.status}`);

    console.log('\n================================================================');
    console.log(`QUERY & OFF-MARKET MATCH VERIFICATION SUMMARY:`);
    console.log(`Passed: ${passed}`);
    console.log(`Failed: ${failed}`);
    console.log(`Overall Result: ${failed === 0 ? 'ALL PASS' : 'SOME TESTS FAILED'}`);
    console.log('================================================================');

    if (failed > 0) process.exit(1);
  } catch (err: any) {
    console.error('Fatal test error:', err.message);
    process.exit(1);
  }
}

runTests();
